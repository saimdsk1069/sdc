import os
import json
from django.core.exceptions import ImproperlyConfigured
#
# Read the platform property file.
#
import logging

logger = logging.getLogger(__name__)


with open("/opt/djangoappsconfig/props/django_platform.props") as f:
    props = json.loads(f.read())
try:
    platform = props['PLATFORM']
    #print "LOADING PROPS FOR ", platform
except KeyError:
    error_msg = "{0} is not defined"
    raise ImproperlyConfigured(error_msg)
#
# Get the rest of the properties based on the platform
#
all_props = {}
no_comment_props = ''
with open("/opt/djangoappsconfig/props/AG_SADCeFarms.props") as f:
    for line in f:
        # Read file 1 line at a time, remove anything after '<!--', and strip newline if there is one
        line_no_comment = line.split('<!--')[0].strip()
        no_comment_props = no_comment_props + line_no_comment + '\n'
try:
    props = json.loads(no_comment_props)
    platform_stuff = props[platform]
    for key in platform_stuff:
        #print key, platform_stuff[key]
        all_props[key] = platform_stuff[key]
    # Get general properties
    general = props['GENERAL']
    for key in general:
        #print key, general[key]
        all_props[key] = general[key]
except KeyError:
    error_msg = "{0} is not defined"
    raise ImproperlyConfigured(error_msg)

def get_prop(prop_key):
    try:
        return all_props[prop_key]
    except KeyError:
        error_msg = "Set the {0} environment variable".format(prop_key)
        raise ImproperlyConfigured(error_msg)

def set_prop(prop_key, prop_value):
    if prop_key not in all_props:
        print("Property key %s not found in all_props" % prop_key)
    all_props[prop_key] = prop_value

def get_platform():
    try:
        return platform
    except KeyError:
        error_msg = "Set the platform variable"
        raise ImproperlyConfigured(error_msg)
