import os
from  admin_authAdmin.NJCrypto import PWCrypto
from config_settings import *
import logging

logger = logging.getLogger(__name__)




BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
project_name = BASE_DIR.split("\\")[-1]
# print "\nBASE_DIR IS:", BASE_DIR
# print "\nproject_name is:", project_name
WEB_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = '0l$%+q00126tqa#xk*y)$-zeky&yqa(6m&=d%dqbmld1c(mpuu'
# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True


# Slack integration
#slackbot_token = get_prop('SLACKBOT_TOKEN')

# A boolean that specifies whether to use the X-Forwarded-Host header in preference to the Host header. This should only be enabled if a proxy which sets this header is in use.
USE_X_FORWARDED_HOST = True
# A boolean that specifies whether to use the X-Forwarded-Port header in preference to the SERVER_PORT META variable. This should only be enabled if a proxy which sets this header is in use.
# USE_X_FORWARDED_PORT = True

ALLOWED_HOSTS = []

# Application definition

INSTALLED_APPS = [
    # 'reports.apps.ReportsConfig',
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'reports',
    'messaging',
    'admin_authAdmin',
    'admin_todolist',
    'admin_finance',
    'common',
    'dashboard_user',
    'dashboard_application',
    'mapping',
    'rest_framework',
    # 'eFCommon',
    # 'eFHome',
    # 'eFPlanning',
    # 'eFManage',
    #'resultSave',
    'corsheaders',
    'django_extensions',
    # database app contains models for all applications
    'database',
    'workflow',
    # 'proxy'
]

#DEFAULT_FILE_STORAGE = 'db_file_storage.storage.DatabaseFileStorage'

MIDDLEWARE_CLASSES = [
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.auth.middleware.SessionAuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'security.SecurityProcessor.RequestSecurityProcessor',
    'security.RequestUser.CurrentUserMiddleware'
]

CORS_ORIGIN_ALLOW_ALL = DEBUG

ROOT_URLCONF = 'AG_SADCeFarms.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'templates_project')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'AG_SADCeFarms.wsgi.application'

# So slashes aren't required for POST requests to REST endpoints
APPEND_SLASH = False
#
# For keyczar keys:
#
ENCRYPTED_FIELDS_KEYDIR = get_prop('CRYPT_KEYSTORE')

# Decrypt the database password
pc = PWCrypto()
pt_dbpassword = pc.decryptString(get_prop('DB_PASSWORD'), ENCRYPTED_FIELDS_KEYDIR )

#print "DATABASE NAME:", get_prop('DB_NAME')
logger.debug(" DATABASE NAME: %s " % get_prop('DB_NAME'))

# Database
# https://docs.djangoproject.com/en/1.9/ref/settings/#databases
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.oracle', # Add 'postgresql_psycopg2', 'mysql', 'sqlite3' or 'oracle'.
        'NAME': get_prop('DB_NAME'),                      # Or path to database file if using sqlite3.
        'USER': get_prop('DB_USER'),                      # Not used with sqlite3.
        'PASSWORD': pt_dbpassword,                  # Not used with sqlite3.
        'HOST': '',                      # Set to empty string for localhost. Not used with sqlite3.
        'PORT': '',                      # Set to empty string for default. Not used with sqlite3.
        'OPTIONS': {
            'threaded': True,
        },
    }
}


# Password validation
# https://docs.djangoproject.com/en/1.9/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {
            'format' : "[%(asctime)s] %(levelname)s [%(name)s:%(lineno)s] %(message)s",
            'datefmt' : "%d/%b/%Y %H:%M:%S"
        },
        'simple': {
            'format': '%(levelname)s %(message)s'
        },
    },
    'handlers': {
        'file': {
            'level': 'DEBUG',
            'class': 'logging.FileHandler',
            'filename': '/opt/djangoappsconfig/logs/AG_SADCeFarms.log',
            'formatter': 'verbose'
        },
    },
    'loggers': {
        'django': {
            'handlers':['file'],
            'propagate': True,
            'level':'INFO',
        },
        'reports': {
            'handlers': ['file'],
            'level': 'DEBUG',
        },
        'admin_authAdmin': {
            'handlers': ['file'],
            'level': 'DEBUG',
        },
        'workflow': {
            'handlers': ['file'],
            'level': 'DEBUG',
        },
        'security': {
            'handlers': ['file'],
            'level': 'DEBUG',
        },
        'common': {
            'handlers': ['file'],
            'level': 'DEBUG',
        },
        'AG_SADCeFarms': {
            'handlers': ['file'],
            'level': 'DEBUG',
        },
        'admin_finance': {
            'handlers': ['file'],
            'level': 'DEBUG',
        },
        'admin_todolist': {
            'handlers': ['file'],
            'level': 'DEBUG',
        },
        'dashboard_application': {
            'handlers': ['file'],
            'level': 'DEBUG',
        },
        'dashboard_farm': {
            'handlers': ['file'],
            'level': 'DEBUG',
        },
        'dashboard_user': {
            'handlers': ['file'],
            'level': 'DEBUG',
        },
        'database': {
            'handlers': ['file'],
            'level': 'DEBUG',
        },
        'deployment': {
            'handlers': ['file'],
            'level': 'DEBUG',
        },
        'mapping': {
            'handlers': ['file'],
            'level': 'DEBUG',
        },

    }
}

# Internationalization
# https://docs.djangoproject.com/en/1.9/topics/i18n/

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'America/New_York'

USE_I18N = True

USE_L10N = True

USE_TZ = True

# Rest framework stuff
# REST_FRAMEWORK = {
#     'PAGE_SIZE': 3
# }


#STATIC_URL = get_prop("STATIC_PREFIX")
STATIC_URL = '/static_collected/AG_SADCeFarms/'


# print "Before setting static_root, base_dir is:", BASE_DIR
STATIC_ROOT = os.path.join(BASE_DIR, "static_collected/")
# print "STATIC_ROOT IS:", STATIC_ROOT

STATICFILES_DIRS = [
    os.path.join(BASE_DIR, "static_project"),
]

# print("STATICFILES_DIRS:", STATICFILES_DIRS)


# Sessions
# todo:
#   todo - SESSION_COOKIE_PATH value after AA integration
#   todo - SESSION_COOKIE_SECURE make it True outside of dev PC
#   todo - SESSION_COOKIE_AGE sync w/ AA
#   todo - SESSION_EXPIRE_AT_BROWSER_CLOSE and SESSION_COOKIE_AGE are not compatible.
#           When you set an expiration date to a cookie, this cookie becomes no browser-length cookie.

#SESSION_COOKIE_AGE = 14400  # 4 hrs in sec  Note: Default is 1209600 (2 weeks)
#SESSION_EXPIRE_AT_BROWSER_CLOSE = True  # May not work for all browsers
# SESSION_COOKIE_HTTPONLY   # Default is True; so that JS won't be able to access (based on browser)
                            # may have to set False; based on how we decide to cleanup cookie/session

SESSION_COOKIE_NAME = 'myNJAGSADCeFarms'
SESSION_COOKIE_PATH = '/AG_SADCeFarmsWeb'
SESSION_COOKIE_SECURE = False
SESSION_ENGINE = 'django.contrib.sessions.backends.cached_db'
#SESSION_EXPIRED_URL = 'http://www.nj.gov'
SESSION_SERIALIZER = 'django.contrib.sessions.serializers.PickleSerializer'
# SESSION_SAVE_EVERY_REQUEST = True
