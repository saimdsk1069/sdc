"""eFarmsTest URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.9/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import include, url
from . import views
from django.contrib import admin
# import AG_SADCeFarms_authAdmin.views


urlpatterns = [
    url(r'^$', views.prehome),
    # url(r'^home/', include('eFHome.urls', namespace='eFHome')),
    # url(r'^bs_map/', include('bs_map.urls', namespace='bs_map')),
    # url(r'^planning/', include('eFPlanning.url_pl', namespace='eFPlanning')),
    # url(r'^processfile/', include('eFCommon.urls', namespace='eFCommon')),  # file upload/download/..
    # url(r'^processrule/', include('eFCommon.urls', namespace='eFCommon')),  # process rules

    # url(r'^efmanage/', include('eFManage.urls_efm', namespace='eFManage')),  # app mgmt - program, questionnaire, ..
    url(r'^reports/', include('reports.urls', namespace='reports')),
    # url(r'^saveres/', include('resultSave.urls', namespace='resultSave')),

    # url(r'^$', AG_SADCeFarms_authAdmin.views.home_page),
    # url(r'^', include('reports.urls', namespace='reports')),
    url(r'^', include('common.urls', namespace='common')),
    url(r'^', include('admin_authAdmin.urls', namespace='admin_authAdmin')),
    url(r'^', include('security.urls', namespace='security')),
    url(r'^', include('admin_todolist.urls', namespace='admin_todolist')),
    url(r'^', include('admin_finance.urls', namespace='admin_finance')),
    url(r'^', include('mapping.urls', namespace='mapping')),
    url(r'^', include('workflow.urls', namespace='workflow')),
    url(r'^', include('dashboard_application.urls', namespace='dashboard_application')),
    url(r'^', include('dashboard_farm.urls', namespace='dashboard_farm')),
    url(r'^', include('dashboard_user.urls', namespace='dashboard_user')),
    url(r'^admin/', admin.site.urls),
    # url(r'^static_AG_SADCeFarms/', admin.site.urls),

]
