from django.shortcuts import HttpResponsePermanentRedirect
def prehome(request):
    return HttpResponsePermanentRedirect('/AG_SADCeFarms/home/')
