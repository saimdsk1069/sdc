import urllib
import urllib2
import logging
import json
import cookielib
import ssl
import sys

logger = logging.getLogger(__name__)

class AGSTokenRequestor:
    """
        Make a request of an ArcGIS server to get a valid token for the ArcGIS user.

        Input:

        Returns:
            dictionary containing token related information
    """
    def __init__(self, agsTokenServer, agsproxy, agsproxytype, agsuser, agspassword ):
        """
            Create cookie jar so subsequent requests use the same cookies.  Also create holder
            for cookie name and value.

        """
        self.agsTokenServer = agsTokenServer
        self.agsproxy = agsproxy
        self.agsproxytype = agsproxytype
        self.agsuser = agsuser
        self.agspassword = agspassword
        self.cj = cookielib.CookieJar()
        self.AGSCookieName = ''
        self.AGSCookieValue = ''


    def getAGSCookie(self):
        return self.AGSCookieName, self.AGSCookieValue

    def getAGSToken( self, tokenDuration ):
        """

            Input:
                tokenDuration - Requested token duration

            Returns:
                dictionary containing token related information
        """
        # Host name for token request
        tokenRequestURL = self.agsTokenServer+"/arcgis/tokens/generateToken"
        logger.debug("GETTING: " + tokenRequestURL)
        tokenRequestParams = {'request': 'getToken', 'username': self.agsuser, 'password': self.agspassword, 'expiration': str(tokenDuration),'f': 'json'}
        tokenRequestParamsEncoded = urllib.urlencode(tokenRequestParams)
        #logger.debug("TOKEN PARAMETERS:" + tokenRequestParamsEncoded)
        #
        # Format of valid token response: {u'token': u'Gl2Cftwe....', u'expires': 1360353275566L}
        # Format of error from token request: {u'error': {u'message': u'You are not authorized', u'code': 200, u'details': u'Invalid credentials'}}
        #
        try:
            # If outbound proxy is defined, create a proxy handler
            proxy = None
            if self.agsproxy != "":
                logger.debug("Outbound proxy is %s %s" %( self.agsproxy, self.agsproxytype ) )
                proxy = urllib2.ProxyHandler({self.agsproxytype: self.agsproxy})
            else:
                logger.debug("Outbound proxy is not defined")
            #
            # If version >= 2.7.10, you must force it to not verify the certificate
            httpscontext = None
            if sys.version_info >= (2,7,9):
                httpscontext = urllib2.HTTPSHandler(context=ssl.SSLContext(ssl.PROTOCOL_TLSv1))
            if proxy is not None and httpscontext is not None:
                logger.debug("Proxy is set and version >= 2.7.9")
                opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(self.cj), proxy, httpscontext)
            if proxy is not None and httpscontext is None:
                logger.debug("Proxy is set and version < 2.7.9")
                opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(self.cj), proxy)
            if proxy is None and httpscontext is not None:
                logger.debug("Proxy is not set and version >= 2.7.9")
                opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(self.cj), httpscontext)
            if proxy is None and httpscontext is None:
                logger.debug("Proxy is not set and version < 2.7.9")
                opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(self.cj))
            response = opener.open(tokenRequestURL, tokenRequestParamsEncoded )
            tokenResponse = response.read()
            logger.debug("BEFORE CONVERSION: " + tokenResponse)
            responseConverted = json.loads(tokenResponse)
            logger.debug("CONVERTED RESPONSE: " + str(responseConverted))
            return responseConverted
        except urllib2.HTTPError as e:
            return { 'error': { 'message': 'Error Connecting to Server' } }
        except urllib2.URLError as e:
            return { 'error': { 'message': 'Error Connecting to Server' } }
        except ValueError as e:
            return { 'error': { 'message': 'Error Connecting to Server, Invalid URL' } }
