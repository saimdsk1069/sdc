import adminArcGIS as AGSADM
import logging

logger = logging.getLogger(__name__)
#
# Create users and add users to roles in AGS
#
def addUser( username, password, fullname, email, admin_username, admin_password, agshosturl ):
    agsadmin = AGSADM.AGSAdministrator()
    # log into AGS
    loggedIn = agsadmin.login(admin_username, admin_password, agshosturl)
    if loggedIn:
        logger.debug( "Logged in to " + agshosturl)
        logger.debug("Adding: %s %s %s  on %s " % ( username, fullname, email, agshosturl ) )
        if agsadmin.userExists( username):
            msg = "User %s already exists on %s" % ( username, agshosturl )
            logger.debug( msg )
            return False, msg
        else:
            logger.debug("User %s does not exist, adding to %s" % ( username, agshosturl ))
            success, message = agsadmin.addUser( username, password, fullname, email, "")
            if success:
                msg = "User %s added successfully" % username
                logger.debug(msg)
                return True, msg
            else:
                msg = "Failed adding %s" % username
                logger.debug(msg)
                return False, msg
    else:
        msg = "Login failed for %s" % agshosturl
        logger.debug(msg )
        return False, msg

def addUserToRole( username, agsrole, admin_username, admin_password, agshosturl ):
    agsadmin = AGSADM.AGSAdministrator()
    # log into AGS
    loggedIn = agsadmin.login(admin_username, admin_password, agshosturl)
    if loggedIn:
        logger.debug( "Logged in to " + agshosturl)
        logger.debug("Adding: %s to role %s  on %s " % ( username, agsrole, agshosturl ) )
        if agsadmin.userExists( username):
            msg = "User %s exists on %s" % ( username, agshosturl )
            logger.debug( msg )
            # Check to see if role exists
            roles = agsadmin.getRoles()
            # Just check against role names
            rolenames = []
            for role in roles:
                rolenames.append(role['rolename'])
            logger.debug("ROLES FROM AGS:" + ",".join(rolenames) )
            if agsrole not in rolenames:
                msg = "Role %s does not exist on %s " % ( agsrole, agshosturl )
                logger.debug(msg)
                return False, msg
            # User exists, role exits, so add user to role
            success, message = agsadmin.addUsersToRole( agsrole, username)
            if success:
                msg = "User %s added to role %s on %s" % ( username, agsrole, agshosturl )
                logger.debug(msg)
                return True, msg
            else:
                msg = "Failed adding %s to role %s on %s" % ( username, agsrole, agshosturl )
                logger.debug(msg)
                return False, msg
        else:
            msg = "User %s does not exist on %s" % (username, agshosturl )
            logger.debug(msg)
            return False, msg
    else:
        msg = "Login failed for %s" % agshosturl
        logger.debug(msg )
        return False, msg

def removeUser( username, admin_username, admin_password, agshosturl ):
    agsadmin = AGSADM.AGSAdministrator()
    # log into AGS
    loggedIn = agsadmin.login(admin_username, admin_password, agshosturl)
    if loggedIn:
        logger.debug( "Logged in to " + agshosturl)
        logger.debug("Removing %s " % ( username ) )
        if agsadmin.userExists( username):
            msg = "User %s exists on %s" % ( username, agshosturl )
            success, message = agsadmin.removeUser( username )
            if success:
                msg = "User %s removed successfully" % username
                logger.debug( msg )
                return True, msg
            else:
                msg = "Failed to remove user %s from %s" % ( username, agshosturl )
                logger.debug(msg)
                return False, msg
        else:
            msg = "User %s does not exist on %s" % ( username, agshosturl )
            logger.debug(msg)
            return False, msg
    else:
        msg = "Login failed for %s" % agshosturl
        logger.debug(msg )
        return False, msg
