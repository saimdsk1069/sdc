import smtplib
from email.mime.text import MIMEText
from django import template
from AG_SADCeFarms import settings

import logging

logger = logging.getLogger(__name__)

def send(email_type, first_name, last_name, email, access_code ):
    from_person = settings.get_prop("FROM_EMAIL")
    subject = "Registration for access to the eFarms Application"
    register_url = settings.get_prop("REGISTERURL")
    prereg_message = """
    Dear {{first_name}} {{last_name}}:

    Thank you for registering for access to the eFarms Application.
    We have received your initial information and are ready for you to
    do the next steps to complete the registration.

    We have generated an access code for you to use in the next step.

    Your access code is: {{access_code}}

    Please go to {{register_url}} to complete the
    registration process.

    Please keep this email for future reference.

    Thank you,

    NJ Department of Agriculture eFarms Administrator
    """
    unregistered_message = """
    Dear {{first_name}} {{last_name}}:

    You have been invited to access the eFarms Application.

    We are ready for you to do the next steps to complete the
    registration process.

    We have generated an access code for you to use in the next step.

    Your access code is: {{access_code}}

    Please go to {{register_url}} to complete the
    registration process.

    Please keep this email for future reference.

    Thank you,

    NJ Department of Agriculture eFarms Administrator
    """
    invited_message = """
    Dear {{first_name}} {{last_name}}:

    You have been re-invited to access the eFarms application.

    We have generated an access code for you to use in the next step.

    Your access code is: {{access_code}}

    Please go to {{register_url}} to complete the
    registration process.

    Please keep this email for future reference.

    Thank you,

    NJ Department of Agriculture eFarms Administrator
    """

    #print "++++ EMAIL TYPE:", email_type (AG)
    logger.debug("++++ EMAIL TYPE:  %s" % email_type)
    if email_type == 'Preregistered':
        message = prereg_message
    if email_type == 'Unregistered':
        message = unregistered_message
    if email_type == 'Invited':
        message = invited_message

    e_template = template.Template(message)
    e_context = template.Context( {
        'first_name': first_name,
        'last_name': last_name,
        'access_code': access_code,
        'register_url': register_url
    })
    e_msg = e_template.render(e_context)
    logger.debug(e_msg)
    msg = MIMEText(e_msg)
    msg['Subject'] = subject
    msg['From'] = from_person
    try:
        #print "Making email connection"
        s = smtplib.SMTP(settings.get_prop("MAILHOST"))
        s.set_debuglevel(True)
        #print "Sending email" (AG)
        logger.debug("Sending email")
        s.sendmail(from_person, [email], msg.as_string())
        s.quit()
    except smtplib.SMTPConnectError as e:
        #print("Error sending email to " + email )(AG)
        #print("Error sending email to %s" % email ) (AG)
        logger.debug("Error sending email to %s" % email)
    except smtplib.SMTPDataError as e:
        #print("SMTP DATA ERROR:" + e.message )
        logger.debug("SMTP DATA ERROR %s" % e.message)

