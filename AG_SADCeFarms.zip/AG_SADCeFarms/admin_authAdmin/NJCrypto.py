#!/python-custom/bin/python
from Crypto.Cipher import AES
from Crypto import Random
from Crypto.Random import random
from keyczar import keyczar


import binascii

class PWCrypto:

    def decryptString(self, ciphertext, keystore ):
        crypter = keyczar.Crypter.Read(keystore)
        plaintext = crypter.Decrypt(ciphertext)
        return plaintext

    def encryptString(self, plaintext, keystore ):
        crypter = keyczar.Crypter.Read(keystore)
        ciphertext = crypter.Encrypt(plaintext)
        return ciphertext

    def genPassword(self, pw_length ):
        alphabet = "abcdefghijklmnopqrstuvwxyz"
        specialchars ="!@#$%^&*(){}[]"
        #pw_length = 8
        mypw = ""

        for i in range(pw_length-1):
            next_index = random.randrange(len(alphabet))
            mypw = mypw + alphabet[next_index]

        # replace 1 or 2 characters with a number
        for i in range(random.randrange(1,3)):
            replace_index = random.randrange(len(mypw)//2)
            mypw = mypw[0:replace_index] + str(random.randrange(10)) + mypw[replace_index+1:]

        # replace 1 or 2 letters with an uppercase letter
        for i in range(random.randrange(1,3)):
            replace_index = random.randrange(len(mypw)//2,len(mypw))
            mypw = mypw[0:replace_index] + mypw[replace_index].upper() + mypw[replace_index+1:]

        # Tack on special character at the end
        spindx = random.randrange(len(specialchars))
        mypw = mypw[0:pw_length-1] + specialchars[spindx]

        return mypw




