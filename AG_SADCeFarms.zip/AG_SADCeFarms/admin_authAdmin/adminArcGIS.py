import urllib
import urllib2
import cookielib
import json

class AGSAdministrator:

    def login( self, username, password, hosturl):
        self.hosturl = hosturl
        loginURL = '/arcgis/admin/login'
        adminURL = '/arcgis/admin'
        query_args = { 'username':username, 'password':password, 'encrypted': 'false' }
        encoded_args = urllib.urlencode(query_args)
        url = self.hosturl+loginURL
        self.cj = cookielib.CookieJar()
        self.opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(self.cj))
        response = self.opener.open(url, encoded_args)
        url = hosturl+adminURL
        response = self.opener.open(url)
        if response.read().find('Logged in: '+ username) != -1:
            return True
        else:
            return False

    def userExists( self, username):
        """
        Format of user search response
        {
          "users": [
            {
              "username": "test",
              "description": "",
              "email": "",
              "fullname": "",
              "disabled": false
            },
            {
              "username": "teste",
              "description": "",
              "email": "",
              "fullname": "",
              "disabled": false
            },
            {
              "username": "tester",
              "description": "",
              "email": "",
              "fullname": "",
              "disabled": false
            },
            {
              "username": "tester1",
              "description": "",
              "email": "",
              "fullname": "",
              "disabled": false
            }
          ],
          "hasMore": false
        }
    """
        query_args = { 'filter': username, 'maxCount': '', 'f': 'pjson' }
        encoded_args = urllib.urlencode(query_args)
        usersearchURL = '/arcgis/admin/security/users/search'
        url = self.hosturl+ usersearchURL
        response = self.opener.open(url, encoded_args)
        users = json.loads( response.read() )
        # process entire dictionary in case of partial matches
        userslist = users['users']
        for user in userslist:
            if user['username'] == username:
                return True
        return False

    def addUser( self, username, password, fullname='', email='',  description=''):
        """
        Response: {"status": "success"}
        """
        addUserURL = '/arcgis/admin/security/users/add'
        query_args = { 'username': username, 'password': password, 'fullname': fullname, 'email': email,\
            'description': description, 'f': 'pjson', 'encrypted': 'false' }
        encoded_args = urllib.urlencode(query_args)
        url = self.hosturl+ addUserURL
        response = self.opener.open(url, encoded_args)
        addResponse = json.loads( response.read() )
        #print addResponse
        #
        if addResponse['status'] != 'success':
            messages = addResponse['messages']
            message = ''
            for msg in messages:
                message = message + ' ' + msg
            return False, message
        else:
            return True, "success"

    def removeUser( self, username ):
        """
            Looks like remove always returns success :-(
        """
        #print "REMOVING:", username
        removeUserURL = '/arcgis/admin/security/users/remove'
        query_args = { 'username': username, 'f': 'pjson' }
        encoded_args = urllib.urlencode(query_args)
        url = self.hosturl+ removeUserURL
        response = self.opener.open(url, encoded_args)
        removeResponse = json.loads( response.read() )
        #print "REMOVE:", removeResponse
        if removeResponse['status'] != 'success':
            messages = removeResponse['messages']
            message = ''
            for msg in messages:
                message = message + ' ' + msg
            return False, message
        else:
            return True, "success"


    def getUsers( self ):
        """
            Get all users
        """
        getRolesURL = '/arcgis/admin/security/users/getUsers'
        query_args = { 'f': 'pjson' }
        encoded_args = urllib.urlencode(query_args)
        url = self.hosturl+ getRolesURL
        response = self.opener.open(url, encoded_args)
        userResponse = json.loads( response.read() )
        return userResponse['users']

        #rolename=RDWebEditor&users=arowan%2Ccklaube%2Cfoo&f=pjson&

    def getRoles( self ):
        """
            Get all roles
        """
        getRolesURL = '/arcgis/admin/security/roles/getRoles'
        query_args = { 'f': 'pjson' }
        encoded_args = urllib.urlencode(query_args)
        url = self.hosturl+ getRolesURL
        response = self.opener.open(url, encoded_args)
        roleResponse = json.loads( response.read() )
        return roleResponse['roles']

    def getRoleNames( self ):
        """
            Get all roles
        """
        getRolesURL = '/arcgis/admin/security/roles/getRoles'
        query_args = { 'f': 'pjson' }
        encoded_args = urllib.urlencode(query_args)
        url = self.hosturl+ getRolesURL
        response = self.opener.open(url, encoded_args)
        roleResponse = json.loads( response.read() )
        return roleResponse['roles']['rolename']

    def addRole( self, rolename, description):
        """

        """
        theURL = '/arcgis/admin/security/roles/add'
        query_args = { 'rolename': rolename, 'description': description, 'f': 'pjson' }
        encoded_args = urllib.urlencode(query_args)
        url = self.hosturl+ theURL
        response = self.opener.open(url, encoded_args)
        userResponse = json.loads( response.read() )
        if userResponse['status'] != 'success':
            messages = userResponse['messages']
            message = ''
            for msg in messages:
                message = message + ' ' + msg
            return False, message
        else:
            return True, "success"


    def updateRole( self, rolename, description):
        """

        """
        theURL = '/arcgis/admin/security/roles/update'
        query_args = { 'rolename': rolenameame, 'description': users, 'f': 'pjson' }
        encoded_args = urllib.urlencode(query_args)
        url = self.hosturl+ theURL
        response = self.opener.open(url, encoded_args)
        userResponse = json.loads( response.read() )
        if userResponse['status'] != 'success':
            messages = userResponse['messages']
            message = ''
            for msg in messages:
                message = message + ' ' + msg
            return False, message
        else:
            return True, "success"


    def addUsersToRole( self, rolename, users):
        """

            Input:

                rolename - ArcGIS server role ( Must exist )
                users - comma separated list of users

            Responses from call to ArcGIS:

            Successful response:

                {"status": "success"}

            Bad role specified:

                {
                  "status": "error",
                  "messages": ["java.lang.NullPointerException"],
                  "code": 500
                }

            Invalid user specified:

                {
                    "status": "error",
                    "messages": ["User(s) do not exist."]
                }

        """
        theURL = '/arcgis/admin/security/roles/addUsersToRole'
        query_args = { 'rolename': rolename, 'users': users, 'f': 'pjson' }
        encoded_args = urllib.urlencode(query_args)
        url = self.hosturl+ theURL
        response = self.opener.open(url, encoded_args)
        userResponse = json.loads( response.read() )
        if userResponse['status'] != 'success':
            messages = userResponse['messages']
            message = ''
            for msg in messages:
                message = message + ' ' + msg
            return False, message
        else:
            return True, "success"

    def getUsersWithinRole( self, role ):

        theURL = '/arcgis/admin/security/roles/getUsersWithinRole'
        query_args = { 'rolename': rolenameame, 'f': 'pjson' }
        encoded_args = urllib.urlencode(query_args)
        url = self.hosturl+ theURL
        response = self.opener.open(url, encoded_args)
        userResponse = json.loads( response.read() )
        return userResponse['users']

    def removeUsersFromRole( self, role, users):

        theURL = '/arcgis/admin/security/roles/removeUsersFromRole'
        query_args = { 'rolename': rolenameame, 'users': users, 'f': 'pjson' }
        encoded_args = urllib.urlencode(query_args)
        url = self.hosturl+ theURL
        response = self.opener.open(url, encoded_args)
        userResponse = json.loads( response.read() )
        if userResponse['status'] != 'success':
            messages = userResponse['messages']
            message = ''
            for msg in messages:
                message = message + ' ' + msg
            return False, message
        else:
            return True, "success"

