from models import AuthUserSadc, AuthRoleSadc, AuthPermissionSadc

from django.core.exceptions import ObjectDoesNotExist
from django.http import HttpResponseRedirect
import OGISMessages
import NJSSO
from AG_SADCeFarms import settings
import copy
import urllib
import urllib2
import logging
import json
import NJCrypto
import cookielib
import AGSTokenRequestor as AGST
import socket

logger = logging.getLogger(__name__)

def getUserAndResourceTokens( application, portal_user_key, request):
    """
        Using the data returned from the database for a specific application, retrieve token for the user defined
        by the portal_user_key and any resource tokens.

        Input:
            application - django object representing a row in the oah_apps table that matches the
                application being run
            portal_user_key - The external app id associated with the portal user.  A corresponding
                should exist in ArcGIS server
            request - the HTTP request coming into the app.  Needed to extract IP address from client
                to generate an ArcGIS token.

        Response:  JSON Object in the following format:

        {

        "portalhost": https://longpond.oit.state.nj.us,

        "useraccess":
           {"token": "bJWojponM57ZyUXUJh_e59WdL82K", "expires": 1425104121616},
         "resourceaccess":
            {
              "AG_AltRes2": {"token": "bJWojponM57ZyUXUJh_e59WdL82K", "expires": 1425104121863},
              "AG_AlternateResource": {"token": "bJWojponM57ZyUXUJh_e59WdL82K", "expires": 1425104121774}
            },
         "remoteaccess":
            {
               "http://django.wsgi.com/index.html":
                  {"token": "bJWojponM57ZyUXUJh_e59WdL82K", "expires": 1425104121680}
            }
        }

        Note: "resourceaccess" could be an empty dictionary ( {} )
    """
    #logger.debug("META: %s" % str(request.META))
    hostIP = request.META['REMOTE_ADDR']
    logger.debug( "IPADDR FOR TOKEN: %s" % hostIP)
    if 'HTTP_REFERER' in request.META:
        http_referer = request.META['HTTP_REFERER']
        logger.debug( "HTTP_REFERER: %s" % http_referer)
    else:
        http_referer = ""
        logger.debug( "HTTP_REFERER NOT DEFINED")
    http_host = request.META['HTTP_HOST']
    logger.debug( "HTTP_HOST: %s" % http_host)
    server_name = request.META['SERVER_NAME']
    logger.debug( "SERVER_NAME: %s" % server_name)

    njc = NJCrypto.PWCrypto()
    encryptionKey = settings.get_prop('AGSPasswordKey')

    # Get instance of AGS token requestor
    agst = AGST.AGSTokenRequestor()

    # Get token if username is not empty and matches portal_user_key
    shortUserToken = {}
    longUserToken = {}
    #remote_referer = OGISAuthProps.OGIS_AuthHandler_GLOBALS['AGS_REMOTE_REFERER']
    if portal_user_key != "":
        theuser = application.user.filter(username=portal_user_key)
        username = theuser[0].username
        user_pw = theuser[0].ags_password
        logger.debug( "FETCHING TOKEN FOR %s with password of %s" % (username, user_pw) )
        decryptpw = njc.decryptPassword(encryptionKey, user_pw)
        # Get short lived token
        shortUserToken = agst.getAGSToken( portal_user_key, decryptpw )
        logger.debug( "SHORT TOKEN:", shortUserToken)
        # Pass in the referer to generate short and long token
        if http_referer != '':
            longUserToken = agst.getAGSToken( portal_user_key, decryptpw, http_referer )
            logger.debug( "LONG TOKEN:", longUserToken)
    else:
        logger.debug("No Portal User Key defined.  Skipped creating user token and remote token")

    # Get tokens for any resources that are associated with the application
    resourceTokens = {}
    resources = application.resource.all()
    if len(resources) != 0:
        for resource in resources:
            logger.debug("Resource: %s" % resource.resource_name)
            logger.debug("    Resource Description: %s" % resource.description)
            logger.debug("       Resource Username: %s" % resource.ags_user)
            logger.debug("       Resource Password: %s" % resource.ags_password)
            decryptpw = njc.decryptPassword(encryptionKey, resource.ags_password)
            #token = agst.getAGSToken( resource.ags_user, decryptpw, hostIP, http_referer )
            if http_referer != '':
                token = agst.getAGSToken( resource.ags_user, decryptpw, http_referer )
                logger.debug( "LONG RESOURCE TOKEN:", token)
            else:
                token = agst.getAGSToken( resource.ags_user, decryptpw )
                logger.debug( "SHORT RESOURCE TOKEN:", token)            
            logger.debug( "TOKEN: %s" % token)
            resourceTokens[resource.resource_name] = token

    # Get AGS cookie to determine which web balanced web server should be used
    AGSCookieName, AGSCookieValue = agst.getAGSCookie()
    # Get portal host name to return to client in json response
    mynj_host = settings.get_prop('MYNJ_HOST')
    mynj_portal = settings.get_prop('MYNJ_PORTAL')
    mynj_url = mynj_host + "/" + mynj_portal + "/portal/dt"
    # Combine usertokens and resource tokens and return them to views.py
    responseDict = { 'portalhost': mynj_url, 'useraccess': { 'short': shortUserToken, 'long': longUserToken  }, 'resourceaccess': resourceTokens }
    responseJSON = json.dumps( responseDict )
    return AGSCookieName, AGSCookieValue, responseJSON


