all_urls = []
ul = open('urls.log')
for url in ul:
    print url
    if url.startswith('/'):
        # Replace < with space so just url is retrieved
        the_url = url.replace('<',' ').split()[0].strip()
        # Strip trailing slashes
        if the_url.endswith('/'):
            the_url = the_url[:-1]
        if the_url != '':
            all_urls.append(the_url)
sorted_unique_urls = sorted(set(all_urls))
urls_output = open('unique_urls.log', 'w')
for url in sorted_unique_urls:
    urls_output.write(url+"\n")
urls_output.close()

