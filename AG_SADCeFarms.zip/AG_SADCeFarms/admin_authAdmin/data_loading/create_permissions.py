from database.models import AuthUrlPermission, AuthRoleSadc, AuthUrl

pfile = open('admin_authAdmin/data_loading/permissions.log','r')
for line in pfile:
    fields = line.strip().split(',')
    print fields
    auth_url_guid = fields[1]
    auth_role_guid = fields[3]
    permission_type = fields[4]
    print "ADDING:",auth_url_guid,auth_role_guid,permission_type
    # Get the AuthUrl instance
    try:
        au = AuthUrl.objects.get(auth_url_guid=auth_url_guid)
    except Exception as e:
        print e
        print "Error getting auth url data"
    # Get the AuthRoleSadc instance
    try:
        ar = AuthRoleSadc.objects.get(auth_role_guid=auth_role_guid)
    except Exception as e:
        print e
        print "Error getting auth role data"
    try:
        aup = AuthUrlPermission(auth_url_guid=au, auth_role_guid=ar,permission_type=permission_type)
        aup.save()
    except Exception as e:
        print e
        print "Error occurred while saving url permission"
pfile.close()