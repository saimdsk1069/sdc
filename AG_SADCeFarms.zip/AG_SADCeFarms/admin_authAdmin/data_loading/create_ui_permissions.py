from database.models import AuthUiComponent, AuthRoleSadc, AuthUiPermission

ui_perms = {
    'ui_fiscal': [
        '4fdf8749-f39b-4e5d-91b5-14fbb31a646e,SADC STAFF - FISCAL - STAFF'
    ],
    'ui_sysadmin': [
        'a6018f41-4e81-4063-9d36-9a07eb27a51d,SYSTEM ADMINISTRATOR - OGIS - ADMIN'
    ],
    'ui_useradmin': [
        'a6018f41-4e81-4063-9d36-9a07eb27a51d,SYSTEM ADMINISTRATOR - OGIS - ADMIN',
        '7f1db1cb-6436-4854-b4a2-3f5e0ddde51f,SYSTEM ADMINISTRATOR - SADC - USER MANAGER'
    ],
    'ui_appadmin': [
        'a6018f41-4e81-4063-9d36-9a07eb27a51d,SYSTEM ADMINISTRATOR - OGIS - ADMIN',
        'cf34869a-7945-413f-b834-f03c2689b407,SYSTEM ADMINISTRATOR - SADC - APPLICATION MANAGER'
    ]

}

for ui_component, perms in ui_perms.items():
    print "Component:", ui_component
    uic = AuthUiComponent(auth_ui_component_name=ui_component)
    uic.save()
    uic_guid = uic.auth_ui_component_guid
    for perm in perms:
        role_guid = perm.split(',')[0]
        role = AuthRoleSadc.objects.get(auth_role_guid=role_guid)
        print "Role GUID:", role_guid
        uip = AuthUiPermission(auth_ui_component_guid=uic,auth_role_guid=role)
        uip.save()