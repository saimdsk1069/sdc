# read through angular app.js and create a csv file with state, url, public/not public, and ui_permissions
appjsfile = open('app.js')

permlist = []
for line in appjsfile:
    line = line.strip()
    if '//' in line:
        # get the location of the comment and strip out everything after it
        comment_pos = line.find('//')
        line = line[:comment_pos]
    if '.state' in line:
        controller_line = ''
        state_pos_start = line.find('.state') + 8
        state_pos_end = line.find("'", state_pos_start)
        state = line[state_pos_start:state_pos_end]
        # print "state:%s" % state
        permlist.append('state:'+state)
    if 'controller' in line:
        if 'controllerAs' not in line:
            con_start_pos = line.find("'")
            con_end_pos = line.find("'", con_start_pos+1)
            controller = line[con_start_pos+1:con_end_pos]
            permlist.append('controller:'+controller)
    if 'url:' in line:
        url_start_pos = line.find("'")
        url_end_pos = line.find("'", url_start_pos+1)
        url = line[url_start_pos+1:url_end_pos]
        if not url.startswith('/'):
            url = '(/)'+url
        # print "url:%s" % url
        permlist.append('url:'+url)
    if 'ui_access' in line:
        start_bracket_pos = line.find('[') + 1
        end_bracket_pos = line.find(']')
        ui_access = line[start_bracket_pos:end_bracket_pos].replace("'","").replace(" ","")
        if ui_access == '':
            public = 'Yes'
        else:
            public = 'No'
        permlist.append('public:'+public)
        permlist.append('ui_access:'+ui_access)

count = 0
controller_list = []
for entry in permlist:
    if entry.startswith('state:'):
        state = entry[entry.find(':')+1:]
    if entry.startswith('url:'):
        url = entry[entry.find(':')+1:]
    if entry.startswith('public:'):
        public = entry[entry.find(':')+1:]
    if entry.startswith('controller:'):
        controller = entry[entry.find(':')+1:]
        controller_list.append(controller)
    if entry.startswith('ui_access:'):
        ui_access = entry[entry.find(':')+1:]
        clist_str = ",".join(controller_list)
        print('"%s","%s","%s","%s","%s"' % (state,url,clist_str,public,ui_access))
        controller_list = []

# for line in appjsfile:
#     line = line.strip()
#     if '//' in line:
#         # get the location of the comment and strip out everything after it
#         comment_pos = line.find('//')
#         line = line[:comment_pos]
#     if '.state' in line:
#         controller_line = ''
#         state_pos_start = line.find('.state') + 8
#         state_pos_end = line.find("'", state_pos_start)
#         state = line[state_pos_start:state_pos_end]
#         # print "state:%s" % state
#         permlist.append(state)
#     if 'controller:' in line:
#         con_start_pos = line.find("'")
#         con_end_pos = line.find("'", url_start_pos+1)
#         controller = line[url_start_pos+1:url_end_pos]
#
#     if 'url:' in line:
#         url_start_pos = line.find("'")
#         url_end_pos = line.find("'", url_start_pos+1)
#         url = line[url_start_pos+1:url_end_pos]
#         if not url.startswith('/'):
#             url = '(/)'+url
#         # print "url:%s" % url
#         permlist.append(url)
#     if 'ui_access' in line:
#         start_bracket_pos = line.find('[') + 1
#         end_bracket_pos = line.find(']')
#         ui_access = line[start_bracket_pos:end_bracket_pos].replace("'","").replace(" ","")
#         if ui_access == '':
#             public = 'Yes'
#         else:
#             public = 'No'
#         permlist.append(public)
#         permlist.append(ui_access)
#
# count = 0
# for entry in permlist:
#     if count == 4:
#         print '%s,%s,%s,%s'% ( state, url, public, ui_access)
#         count = 0
#     if count == 0:
#         state = entry
#     if count == 1:
#         url = entry
#     if count == 2:
#         public = entry
#     if count == 3:
#         ui_access = entry
#     count += 1