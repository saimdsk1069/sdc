import pandas as pd
import numpy as np
import re
import json
import collections
import uuid

def check_value( value_to_check ):
    if type(value_to_check) is not unicode:
        if np.isnan(value_to_check):
            return ''
    else:
        return str(value_to_check)

def add_to_perm_dict( perm_dict, keyval_to_add, guid, url):
    if keyval_to_add not in perm_dict:
        print "****ERROR COULDN'T FIND ENTRY IN PERMISSION DICTIONARY FOR ", keyval_to_add
        exit(1)
    else:
        perm_dict[keyval_to_add].append( {'guid': guid, 'url': url})
    return perm_dict


def write_insert_statements( all_records ):
    sql = open('auth_user_sadc_insert.sql', 'w')
    sql.write('set define off\n')
    # sql.write('INSERT INTO auth_user_sadc\n')
    col_list = []
    for col_name, data in all_records[0].items():
        col_list.append(col_name)
    # sql.write('( %s )\n' % (', '.join(col_list)))
    # sql.write('VALUES\n')

    for row in all_records:
        insert_stmt = 'INSERT INTO auth_user_sadc (%s) VALUES \n(' % (', '.join(col_list))
        for col_name, value in row.items():
            if type(value) is int:
                insert_stmt = insert_stmt + "%i" % value
            else:
                insert_stmt = insert_stmt + "'%s'" % value

            if col_name == 'AUTH_USER_NAME':
                insert_stmt = insert_stmt + ' );'
            else:
                insert_stmt = insert_stmt + ', '
        sql.write('%s\n' % insert_stmt)
    sql.close()

all_records = []

ss = pd.ExcelFile('init_permissions.xlsx')

# Build dictionary of roles with key of role name and value of guid
role_dict = {}
role_sheet = ss.parse('Roles')
for i in role_sheet.index:
    role_name = role_sheet['ROLE NAME'][i]
    role_guid = role_sheet['GUID'][i]
    print role_sheet['ROLE NAME'][i], role_sheet['GUID'][i]
    role_dict[role_name] = role_guid

# build dictionary for permissions by using role_dict keys as keys for the new dictionary
perm_dict = {}
for role_name in role_dict.keys():
    print "ROLE KEY:", role_name
    # create an empty list to store the urls
    perm_dict[role_name] = []
# process the urls sheets and build out the permissions dictionary
urls_sheet = ss.parse('URL&PERMS')
for i in urls_sheet.index:
    public_access = check_value(urls_sheet['PUBLIC ACCESS'][i])
    authenticated_access = check_value(urls_sheet['AUTHENTICATED ACCESS'][i])
    security_access = check_value(urls_sheet['SECURITY ADMIN ACCESS'][i])
    ogis_admin_access = check_value(urls_sheet['OGIS USER ADMIN ACCESS'][i])
    sadc_admin_access = check_value(urls_sheet['SADC USER ADMIN ACCESS'][i])
    finance_access = check_value(urls_sheet['FINANCE ADMIN ACCESS'][i])
    url = check_value(urls_sheet['URL'][i])
    guid = check_value(urls_sheet['GUID'][i])

    if public_access != '':
        perm_dict = add_to_perm_dict( perm_dict, public_access, guid, url)
    if authenticated_access != '':
        perm_dict = add_to_perm_dict( perm_dict, authenticated_access, guid, url)
    if security_access != '':
        perm_dict = add_to_perm_dict( perm_dict, security_access, guid, url)
    if ogis_admin_access != '':
        perm_dict = add_to_perm_dict( perm_dict, ogis_admin_access, guid, url)
    if sadc_admin_access != '':
        perm_dict = add_to_perm_dict( perm_dict, sadc_admin_access, guid, url)
    if finance_access != '':
        perm_dict = add_to_perm_dict( perm_dict, finance_access, guid, url)

normal_permissions = [ 'GET', 'POST', 'PUT', 'DELETE']

perm_file = open('permissions.log', 'w')
for permkey, url_list in perm_dict.items():
    print "PERM KEY:", permkey
    # Get the guid associated with that key
    role_guid = role_dict[permkey]
    # process each permission and build entries for insert statements
    for url in url_list:
        url_guid = url['guid']
        url = url['url']
        for permission in normal_permissions:
            perm_file.write("%s,%s,%s,%s,%s\n" % (url, url_guid, permkey, role_guid, permission))

perm_file.close()