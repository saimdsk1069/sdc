import pandas as pd
import numpy as np
import re
import json
import collections
import uuid

def clean_phone(phone_string):
    # Get rid of ()- and spaces & and convert any characters to lower case
    phone_string = phone_string.replace('(','').replace(')','').replace('-','').replace(' ','').lower()
    # check for any non numeric characters.  In a couple cases the phone has a slash or backslash and contains
    # 2 phone numbers.
    p = re.search('\d*([a-z.,/\\\]*)\d*', phone_string)
    ext_str = p.groups()[0]
    if ext_str != '':
        # There is an extension. Phone number is before the group.  Extension is after.
        ext_str_loc = phone_string.find(ext_str)
        phone_num = phone_string[:ext_str_loc]
        phone_ext = phone_string[ext_str_loc+len(ext_str):]
    else:
        phone_num = phone_string
        phone_ext = ''
    return phone_num, phone_ext


def write_insert_statements( all_records ):
    sql = open('auth_user_sadc_insert.sql', 'w')
    sql.write('set define off\n')
    # sql.write('INSERT INTO auth_user_sadc\n')
    col_list = []
    for col_name, data in all_records[0].items():
        col_list.append(col_name)
    # sql.write('( %s )\n' % (', '.join(col_list)))
    # sql.write('VALUES\n')

    for row in all_records:
        insert_stmt = 'INSERT INTO auth_user_sadc (%s) VALUES \n(' % (', '.join(col_list))
        for col_name, value in row.items():
            if type(value) is int:
                insert_stmt = insert_stmt + "%i" % value
            else:
                insert_stmt = insert_stmt + "'%s'" % value

            if col_name == 'AUTH_USER_NAME':
                insert_stmt = insert_stmt + ' );'
            else:
                insert_stmt = insert_stmt + ', '
        sql.write('%s\n' % insert_stmt)
    sql.close()



all_records = []

required_columns = ['SALUTATION', 'FIRST_NAME', 'LAST_NAME', 'TITLE', 'ADDRESS', 'ADDRESS 2',
                    'CITY', 'STATE', 'ZIP', 'PHONE_PRIMARY', 'PHONE_ALTERNATE', 'EMAIL_PRIMARY']

sheet_to_person_type = {
    'eFarms Test Users':                    'Individual'
}
# From the person_type table
# Individual
# Corporation
# Business / Partnership / LLC
# Trust
# Estate
# Non-Profit
# Municipality
# Municipality Agriculture Board
# County
# CADB
# County Freeholder
# Committee Member
# SADC Staff
# Other

ss = pd.ExcelFile('eFarmsTestUsersAnkit.xlsx')

record_count = 0
records_written = 0
records_skipped = 0
for sheet in ss.sheet_names:
    print "Processing Sheet:", sheet
    # Make sure sheet name can be translated to person type and contact type
    if sheet not in sheet_to_person_type:
        print "    +++SHEET NAME %s NOT FOUND IN PERSON_TYPE TRANSLATION TABLE" % sheet
        continue
    df = ss.parse(sheet)
    # print "DF:", df
    for i in df.index:
        record_count += 1
        # start with empty record
        # user_record = {}
        user_record = collections.OrderedDict()
        # flag for error so record isn't created
        record_good = True
        for column in required_columns:
            # Null columns are not unicode.  So check them for NaN and convert
            if type(df[column][i]) is not unicode:
                if np.isnan(df[column][i]):
                    # print "Column is NaN"
                    value = ''
                else:
                    value = str(df[column][i])
            else:
                # Replace newline with space, single apostrophe with double apostrophe, and remove semi-colon
                value = str(df[column][i]).replace('\n', ' ').replace("'", "''").replace(';', '').strip()
                # if '\n' in value:
                #     value = value.replace('\n', ' ')
                #     print "    +++INFO: Newline found in %s. Translating to space." % value
                # # Remove ';' ( Found in one record's email address ), and escape &
                # value = value.replace(';', '')
            # Process depends on column type
            if column == 'PHONE_PRIMARY':
                phone_num, phone_ext = clean_phone(value)
                user_record['PHONE_PRIMARY'] = phone_num
                # Case where extension is actually alternate phone number
                if len(phone_ext) == 10:
                    user_record['PHONE_ALTERNATE'] = phone_ext
                    user_record['PHONE_PRIMARY_EXT'] = ''
                else:
                    user_record[column+'_EXT'] = phone_ext
            elif column == 'PHONE_ALTERNATE':
                phone_num, phone_ext = clean_phone(value)
                user_record['PHONE_ALTERNATE'] = phone_num
                if len(phone_ext) == 10:
                    print "    +++ERROR: ALTERNATE PHONE CONTAINS EXTENSION THAT EXCEEDS ALLOWED LENGTH. Cannot create user %s %s" % ( user_record['FIRST_NAME'], user_record['LAST_NAME'])
                    record_good = False
                else:
                    user_record[column+'_EXT'] = phone_ext
            elif column == 'ZIP':
                dashpos = value.find('-')
                if dashpos != -1:
                    zip = value[:dashpos]
                    zip4 = value[dashpos+1:]
                else:
                    zip = value
                    zip4 = ''
                # print "    ZIP:", zip
                # print "    ZIP4:", zip4
                ozip = zip.zfill(5)
                if ozip == '00000':
                    ozip = ''
                user_record['ZIP'] = ozip
                user_record['ZIP4'] = zip4
            elif column == 'EMAIL_PRIMARY':
                value = value.lower()
                if value == '':
                    print "    +++ERROR: EMAIL IS BLANK. Cannot create user %s %s" % ( user_record['FIRST_NAME'], user_record['LAST_NAME'])
                    record_good = False
                else:
                    user_record['EMAIL_PRIMARY'] = value
            else:
                if column == 'FIRST_NAME':
                    if value == '':
                        print "    +++WARNING: FIRST_NAME IS BLANK FOR RECORD", user_record
                if column == 'LAST_NAME':
                    if value == '':
                        print "    +++WARNING: LAST_NAME IS BLANK FOR RECORD", user_record
                # If column name is ADDRESS 2, change it to ADDRESS_2
                if column == 'ADDRESS 2':
                    user_record['ADDRESS_2'] = value
                else:
                    # Replace any apostrophes with double apostrophe
                    # value = value.replace("'", "''")
                    user_record[column] = value

            # Derive  PERSON_TYPE_DESC
            user_record['PERSON_TYPE_DESC'] = sheet_to_person_type[sheet]
            # For testing, add a remove_flg as 42 for these folks so it's easy to delete while testing.
            user_record['REMOVE_FLG'] = 4
            # Add a uuid
            user_record['AUTH_USER_GUID']  = str(uuid.uuid4())
            # Set status to 'Created'
            user_record['AUTH_USER_STATUS_DESC'] = 'Unregistered'
        # Only keep it if the record is good
        if record_good:
            records_written += 1
            # Set user name to be the same as email
            user_record['AUTH_USER_NAME'] = user_record['EMAIL_PRIMARY']
            all_records.append(user_record)
        else:
            records_skipped += 1
print "+++There were %i records processed, %i were written, %i were skipped" % ( record_count, records_written, records_skipped)
# print records
# records_json = json.dumps(all_records, indent=4, separators=(',', ': '))
# print records_json
write_insert_statements(all_records)
