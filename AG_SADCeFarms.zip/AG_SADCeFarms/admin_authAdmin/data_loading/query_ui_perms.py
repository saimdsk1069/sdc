from database.models import AuthUserSadc, AuthRoleSadc, AuthUiComponent, AuthUiPermission
user_name = 'james.debruyne@tech.nj.gov'
user = AuthUserSadc.objects.get(auth_user_name=user_name)
roles = user.role.filter(active_flg=1)
print "Roles for %s" % user_name
for role in roles:
    print "Role GUID: %35s Role Name: %s" % (role.auth_role_guid, role.auth_role_name)
    auth_perm = AuthUiPermission.objects.filter(auth_role_guid=role)
    print "Found %i permissions for role %s" % ( len(auth_perm), role.auth_role_guid )
    for p in auth_perm:
        print "Component:", p.auth_ui_component_guid.auth_ui_component_name

# print "The ui permissions for the roles:"
# auth_ui_comp_access = []
#
# aup = AuthUiPermission.objects.filter(auth_role_guid__in=roles)
# print "There are %i auth permission records" % len(aup)
# for p in aup:
#     print "Component:", p.auth_ui_component_guid.auth_ui_component_name
#     auth_ui_comp_access.append(p.auth_ui_component_guid.auth_ui_component_name)
# print "Auth component access:", list(set(auth_ui_comp_access))