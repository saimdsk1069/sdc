from database.models import AuthRoleSadc, AuthUrlPermission, AuthUrl
import collections
import json

urls_and_perms = { 'urls_and_perms': [] }

urls = AuthUrl.objects.filter(active_flg=1).order_by('auth_url_address')
for url in urls:
    url_address = url.auth_url_address
    url_dict ={'url': url_address, 'roles': []}
    url_perms = AuthUrlPermission.objects.filter(auth_url_guid=url.auth_url_guid).order_by('auth_role_guid__auth_role_name')
    role_dict = collections.OrderedDict()
    role_list = []
    for url_perm in url_perms:
        role_name = url_perm.auth_role_guid.auth_role_name
        perm = url_perm.permission_type
        if role_name in role_list:
            role_dict[role_name][perm]= 'Y'
        else:
            role_list.append(role_name)
            role_dict[role_name] = { 'GET': 'N', 'PUT': 'N', 'POST': 'N', 'DELETE': 'N'}
            role_dict[role_name][perm]= 'Y'
    url_out = { 'url': url_address, 'roles': [] }
    for role_name in role_list:
        role_out = { 'role': role_name, 'perms': role_dict[role_name]}
        url_out['roles'].append(role_out)
    urls_and_perms['urls_and_perms'].append(url_out)
    # print "URL:", url_address, "ROLE DICT:", role_dict

# print urls_and_perms
perm_out = json.dumps(urls_and_perms, sort_keys=False, indent=4, separators=(',', ': '))
ofile = open('perms.log', 'w')
ofile.write(perm_out)
ofile.close()

