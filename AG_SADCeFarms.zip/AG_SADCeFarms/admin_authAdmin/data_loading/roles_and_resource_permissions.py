from database.models import AuthRoleSadc, AuthUrlPermission, AuthUrl
import json
from collections import OrderedDict

roles_urls_and_permissions = OrderedDict()
aup = AuthUrlPermission.objects.select_related()\
    .order_by('auth_role_guid__auth_role_name','auth_url_guid__auth_url_address')
print "Query is done"
for a in aup:
    role_name = a.auth_role_guid.auth_role_name
    url = a.auth_url_guid.auth_url_address
    permission = a.permission_type
    # print a.auth_role_guid.auth_role_name, a.auth_url_guid.auth_url_address, a.permission_type
    if role_name not in roles_urls_and_permissions:
        roles_urls_and_permissions[role_name] = OrderedDict()
        roles_urls_and_permissions[role_name][url] = {'GET':'N','PUT':'N','POST':'N','DELETE':'N'}
        roles_urls_and_permissions[role_name][url][permission]='Y'
    else:
        if url not in roles_urls_and_permissions[role_name]:
            roles_urls_and_permissions[role_name][url] = {'GET':'N','PUT':'N','POST':'N','DELETE':'N'}
            roles_urls_and_permissions[role_name][url][permission]='Y'
        else:
            roles_urls_and_permissions[role_name][url][permission]='Y'

results = []
for role_name, urls_and_perms in roles_urls_and_permissions.items():
    role_to_add = {'role':role_name,'urls': []}
    for url,perms in urls_and_perms.items():
        # print "role:", role_name, "url:", url, 'Perms:',perms
        url_to_add = { 'url': url, 'perms': perms }
        role_to_add['urls'].append(url_to_add)
    results.append(role_to_add)

print json.dumps(results, indent=4)