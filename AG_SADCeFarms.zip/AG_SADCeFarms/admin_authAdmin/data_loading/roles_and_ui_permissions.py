from database.models import AuthRoleSadc, AuthUiPermission, AuthUiComponent

roles = AuthRoleSadc.objects.order_by('tier_desc','auth_role_name')
for role in roles:
    aup = role.authuipermission_set.all()
    if len(aup) != 0:
        print "Role:", role.auth_role_name
        for a in aup:
            print "    UI Component:", a.auth_ui_component_guid.auth_ui_component_name