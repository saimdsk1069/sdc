from database.models import AuthUrl, AuthUrlPermission, AuthRoleSadc


def get_role_guids_for_url_and_method(url,method):
    role_guids = []
    try:
        url_permission = AuthUrlPermission.objects.filter(auth_url_guid__auth_url_address=url,permission_type=method)
        for perm in url_permission:
            role_guids.append(perm.auth_role_guid.auth_role_guid)
            print "Role with %s access to %s: %s" % ( test_method, test_url, perm.auth_role_guid.auth_role_name )
    except Exception as e:
        print "EXCEPTION:", e

    return role_guids

test_url = raw_input("Enter the url to test -> ")
test_url = test_url.strip()
test_method = raw_input("Enter the method to test (GET,POST,PUT,DELETE) -> ")
test_method = test_method.strip()

role_guids_with_access = get_role_guids_for_url_and_method(test_url, test_method)
print "VALID ROLE GUIDS:", role_guids_with_access
