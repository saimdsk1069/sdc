select c.auth_ui_component_name, r.auth_role_name from auth_ui_component c, auth_role_sadc r, auth_ui_permission p
  where p.auth_role_guid = r.auth_role_guid
    and p.auth_ui_component_guid = c.auth_ui_component_guid
  order by c.auth_ui_component_name