from database.models import AuthUiPermission, AuthUiComponent

ui_components = AuthUiComponent.objects.all().order_by('auth_ui_component_name')
for comp in ui_components:
    print "     %s\n" % comp.auth_ui_component_name
    comp_guid = comp.auth_ui_component_guid
    perms = AuthUiPermission.objects.filter(auth_ui_component_guid=comp_guid)
    for perm in perms:
        print "         ", perm.auth_role_guid.auth_role_name
    print "\n"