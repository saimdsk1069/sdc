select u.auth_url_address, p.permission_type, r.auth_role_name from auth_url u, auth_role_sadc r, auth_url_permission p
  where p.auth_role_guid = r.auth_role_guid
    and p.auth_url_guid = u.auth_url_guid
  order by r.auth_role_name