from database.models import AuthUrlPermission

url_guid = '89c704a0-5e93-4019-9845-8f7cc6515359'
print "AUTH URL GUID:", url_guid
ui_perms = AuthUrlPermission.objects.filter(auth_url_guid=url_guid)
for perm in ui_perms:
    print "Role GUID: %s %s Permission: %s" % ( perm.auth_role_guid.auth_role_guid, perm.auth_role_guid.auth_role_name, perm.permission_type )