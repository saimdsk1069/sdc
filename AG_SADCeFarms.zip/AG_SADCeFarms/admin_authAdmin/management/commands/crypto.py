from django.core.management.base import BaseCommand, CommandError
from admin_authAdmin.NJCrypto import PWCrypto
from AG_SADCeFarms import settings
import logging

logger = logging.getLogger(__name__)
class Command(BaseCommand):
    help = 'Allows encryption/decryption of string for property files'

    def add_arguments(self, parser):
        group = parser.add_mutually_exclusive_group(required=True)
        group.add_argument('-e', action='store',
            dest='plaintext',
            help='Encrypt plaintext')
        group.add_argument('-d', action='store',
            dest='ciphertext',
            help='decrypt plaintext')

    def handle(self, *args, **options):
        pc = PWCrypto()
        keystore = settings.ENCRYPTED_FIELDS_KEYDIR
        if options['plaintext'] is not None:
            ciphertext = pc.encryptString(options['plaintext'], keystore)
            #print "CIPHERTEXT:", ciphertext
            logger.debug("CIPHERTEXT: %s" % ciphertext)
            #print "LEN OF CIPHERTEXT:", len(ciphertext)
            logger.debug("LEN OF CIPHERTEXT: %s" % len(ciphertext))
        if options['ciphertext'] is not None:
            plaintext = pc.decryptString(options['ciphertext'], keystore)
            #print "PLAINTEXT:", plaintext
            logger.debug("PLAINTEXT: %s" % plaintext)

