import json
import logging

logger = logging.getLogger(__name__)
class CPIGQuestionaire:
    def __init__(self, qjson ):
        qf = open( qjson, 'r')
        qfstuff = qf.read()
        self.qdict = json.loads(qfstuff)

        # Get question order and break out question sections and questions into different dictionaries
        self.__get_order()
        self.current_question = 0

    def __get_order(self):
        self.qorder = []
        self.qsections = {}
        self.qquestions = {}
        self.dquestions = {}

        qsects = self.qdict['question_list']
        for qsect in qsects:
            sguid = qsect['question_section_guid']
            ssect_name = qsect['question_section']
            self.qsections[sguid] = { 'section_name': ssect_name }
            questions = qsect['questions']
            for question in questions:
                qguid = question['question_guid']
                self.qquestions[qguid] = question
                self.qorder.append( { "sguid": sguid, "qguid": qguid})

    def show_order(self):
        for q in self.qorder:
            #print q
            logger.debug("for q in self.qorder %s" % q)
        #print "SECTIONS:"
        logger.debug("Sections")
        for s in self.qsections:
            #print s
            logger.debug("for q in self.qsections %s" % s)
        #print "QUESTIONS:"
        logger.debug("Questions")
        for q in self.qquestions:
            #print q
            logger.debug("q in self.qquestions %s" % q)

    def show_questionaire(self):
        qsects = self.qdict['question_list']
        for qsect in qsects:
            sect_name = qsect['question_section']
            #print "SECTION NAME:", sect_name
            logger.debug("SECTION NAME: %s " % sect_name)
            questions = qsect['questions']
            for question in questions:
                if 'id' in question.keys():
                    #print "     Q ID", question['id']
                    logger.debug("     Q ID %s" % question['id'])
                #print "     Q GUID     :", question['question_guid']
                logger.debug("     Q GUID     : %s" % question['question_guid'])
                #print "     Q HEADING  :", question['question_heading']
                logger.debug("     Q HEADING  : %s" % question['question_heading'])
                #print "     Q TEXT     :", question['question_text']
                logger.debug("     Q TEXT     : %s" % question['question_text'])
                #print "     Q HELP TEXT:", question['question_help_text']
                logger.debug("     Q HELP TEXT: %s" % question['question_help_text'])
                #print "     Q NOTES    :", question['allow_notes']
                logger.debug("     Q NOTES    : %s" % question['allow_notes'])
                #print "     Q UPLOADS  :", question['allow_uploads']
                logger.debug("     Q UPLOADS  : %s " % question['allow_uploads'])
                #print "     Q TYPE     :", question['question_type']
                logger.debug("     Q TYPE     : %s" % question['question_type'])
                if 'dependent_question' in question.keys():
                    #print "     HAS DEPENDENT QUESTIONS"
                    logger.debug("Has dependant properties")
                print ""

    def __get_yesno(self):
        return "Enter Yes or No: -->"

    def __get_inputfields(self, q_guid):
        response = ""
        input_fields = self.qquestions[q_guid]['input']
        for field in input_fields:
            response = response + "     " + field['fieldname'] + "-->\n"
        return response

    def __q_details(self):
        s_guid = self.qorder[self.current_question]['sguid']
        q_guid = self.qorder[self.current_question]['qguid']
        s_name = self.qsections[s_guid]['section_name']
        q_heading = self.qquestions[q_guid]['question_heading']
        q_text = self.qquestions[q_guid]['question_text']
        q_type = self.qquestions[q_guid]['question_type']
        response = '--------------------------------------------------\n'
        response = response + "SECTION: " + s_name + "\n"
        response = response + "QUESTION: " + q_heading + "\n"
        response = response + "  Text: " + q_text + "\n\n"
        if q_type == "YesNo":
            response = response + self.__get_yesno() + "\n\n"
        elif q_type == "InputFields":
            response = response + self.__get_inputfields(q_guid) + "\n\n"
        return response


    # def get_question(self):
    #     if self.current_question < len(self.qorder) -1 :
    #         response = self.__q_details()
    #         last = False
    #         self.current_question += 1
    #         response = response + "\nNext Question: " + str(self.current_question)
    #         response = response + '\n--------------------------------------------------'
    #
    #     else:
    #         response = self.__q_details()
    #         last = True
    #         response = response + "\nSubmit Questionaire"
    #         response = response + '\n--------------------------------------------------'
    #
    #     return last, response

    def get_first_question(self):
        return { "previous_question": "", "next_question": self.qorder[1]['qguid'],
                 "question_section": self.qorder[0]['sguid'], "question": self.qorder[0]['qguid'] }

    def get_question(self, q_guid ):
        tot_qs = len(self.qorder)
        q_count = 0
        for qs in self.qorder:
            if ( qs['qguid'] == q_guid ):
                s_guid = qs['sguid']
                if q_count == 0:
                    previous_question_guid = ""
                    next_question_guid = self.qorder[q_count + 1]['qguid']
                elif q_count == tot_qs:
                    previous_question_guid = self.qorder[q_count - 1 ]['qguid']
                    next_question_guid = ""
                else:
                    previous_question_guid = self.qorder[q_count - 1 ]['qguid']
                    next_question_guid = self.qorder[q_count + 1 ]['qguid']
                question = self.qorder[q_count]['qguid']
                return { "previous_question": previous_question_guid, "next_question": next_question_guid,
                    "question_section": s_guid, "question": q_guid }

            q_count += 1
        # TODO: Return error message
        #print "NO MATCH FOR QUESTION"
        logger.debug("NO MATCH FOR QUESTION")





if __name__ == '__main__':
    cpq = CPIGQuestionaire( 'questions.json.withguids' )
    #cpq.show_questionaire()
    #cpq.show_order()
    last, response = cpq.get_question()
    while not last :
        #print "%s" % response
        logger.debug("%s" % response)
        getstuff = raw_input("Press Enter to Continue")
        last, response = cpq.get_question()
    #print "%s" % response
    logger.debug("%s" % response)






