#!c:\users\odgdebr\.virtualenvs\djangodevdesktop\scripts\python.exe
import sys
from pyresttest import resttest
resttest.command_line_run(sys.argv[1:])
