from django.conf.urls import url
import views

urlpatterns = [

    url(r'^counties$', views.RoleCounty.as_view(), name="counties" ),
    url(r'^municipalities$', views.RoleMunicipality.as_view(), name="municipalities" ),

    url(r'^users$', views.User.as_view(), name="users" ),
    url(r'^users/(?P<auth_user_guid>[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$', views.User.as_view(), name="users" ),
    url(r'^status$', views.UserStatus.as_view(), name="status" ),
    url(r'^status/(?P<status>[a-zA-Z-]*)$', views.UserStatus.as_view(), name="status" ),
    url(r'^contacttype$', views.ContactTypeView.as_view(), name="contacttype" ),
    url(r'^contacttype/(?P<contact_type_desc>[a-zA-Z- ]*)$', views.ContactTypeView.as_view(), name="contacttype" ),
    url(r'^orgtypes$', views.OrganizationType.as_view(), name="orgtype" ),

    url(r'^roles$', views.RoleRoles.as_view(), name="roles" ),
    url(r'^roles/p/(?P<partner_guid>[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/t/(?P<tier_desc>[0-9a-zA-Z /&]*)/g/(?P<tier_group_desc>[0-9a-zA-Z /&]*)/s/(?P<tier_subgroup_desc>[0-9a-zA-Z /&]*)/c/(?P<county>[0-9]{2})/m/(?P<municipality>[0-9]{4})$', views.RoleRoles.as_view(), name="roles" ),
    url(r'^partners$', views.RolePartner.as_view(), name="partners" ),
    url(r'^partners/(?P<partner_guid>.*)$', views.RolePartner.as_view(), name="partners" ),
    url(r'^tiers$', views.RoleTier.as_view(), name="tiers" ),
    url(r'^tiers/(?P<tier>.*)$', views.RoleTier.as_view(), name="tiers" ),
    url(r'^groups$', views.RoleTierGroup.as_view(), name="groups" ),
    url(r'^groups/(?P<tier_group>.*)$', views.RoleTierGroup.as_view(), name="groups" ),
    url(r'^subgroups$', views.RoleTierSubgroup.as_view(), name="subgroups" ),
    url(r'^subgroups/(?P<tier_subgroup>.*)$', views.RoleTierSubgroup.as_view(), name="subgroups" ),

    url(r'^invite$', views.InviteUser.as_view(), name="invite" ),
    url(r'^activate', views.ActivateUser.as_view(), name="activate" ),
    url(r'^deactivate$', views.DeactivateUser.as_view(), name="deactivate" ),
    url(r'^preregister$', views.PreregisterUser.as_view(), name="preregister" ),
    url(r'^register$', views.RegisterUser.as_view(), name="register" ),
    url(r'^reregister$', views.ReregisterUser.as_view(), name="reregister" ),
    url(r'^unregister$', views.UnregisterUser.as_view(), name="unregister" ),
    # url(r'^getcreds$', views.getcreds, name="test_credentials" ),
    # url(r'^getsessiontime$', views.getsessiontime, name="getsessiontime" ),
    # url(r'^setsessionvalue', views.setsessionvalue, name="setsessionvalue" ),
    # url(r'^updatesessionvalue', views.updatesessionvalue, name="updatesessionvalue" ),
]
