from AG_SADCeFarms import settings
from database.models import (
    AuthUrl,
    AuthUserSadc,
    AuthRoleSadc,
    TierGroup,
    TierSubgroup,
    Tier,
    Partner,
    County,
    Municipality,
    PersonType,
    AuthUserStatusSadc,
    ContactType,
)

from .serializers import (
    TierGroupSerializer,
    TierSubgroupSerializer,
    TierSerializer,
    PartnerSerializer,
    AuthUserSadcSerializer,
    AuthRoleSadcSerializer,
    CountySerializer,
    MunicipalitySerializer,
    PersonTypeSerializer,
    AuthUserStatusSadcSerializer,
    ContactTypeSerializer
)

from django.http import Http404, HttpResponse
from django.core.exceptions import ObjectDoesNotExist
from django.middleware.csrf import get_token
from django.utils import timezone

from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

import logging
import traceback
import sys
import json
import hashlib
from datetime import datetime, timedelta
import time

from security.myNJSelfRegistration import myNJAuth, ClientCreateException, GrantFailureException, ResumeFailureException
from security import Authenticate
import AG_RegisterEmail
from common.error_messages import authAdminErrors

logger = logging.getLogger(__name__)

class UserStatusValues:
    """
        Do initial load of status values to reduce traffic
    """
    unregistered_status = None
    unregistered_status_value = None
    deactivated_status = None
    deactivated_status_value = None
    invited_status = None
    invited_status_value = None
    nonreg_status = None
    nonreg_status_value = None
    prereg_status = None
    prereg_status_value = None
    registered_status = None
    registered_status_value = None

    def __init__(self):
        logger.debug("++++++++++++++++++INITIALIZING THE USER STATUS VALUES")
        all_valid = True
        # Get an created user status type.  Error out if not found
        try:
            self.unregistered_status = AuthUserStatusSadc.objects.get(auth_user_status_sadc_desc='Unregistered')
            self.unregistered_status_value = self.unregistered_status.auth_user_status_sadc_desc
        except AuthUserStatusSadc.DoesNotExist:
            all_valid = False
            error = "err-s001"
            logger.debug(authAdminErrors[error]['d_msg'])
        # Get deactivated user status type.
        try:
            self.deactivated_status = AuthUserStatusSadc.objects.get(auth_user_status_sadc_desc='Deactivated')
            self.deactivated_status_value = self.deactivated_status.auth_user_status_sadc_desc
        except AuthUserStatusSadc.DoesNotExist:
            all_valid = False
            error = "err-s003"
            logger.debug(authAdminErrors[error]['d_msg'])
        # Get created user status type.
        try:
            self.invited_status = AuthUserStatusSadc.objects.get(auth_user_status_sadc_desc='Invited')
            self.invited_status_value = self.invited_status.auth_user_status_sadc_desc
        except AuthUserStatusSadc.DoesNotExist:
            all_valid = False
            error = "err-s003"
            logger.debug(authAdminErrors[error]['d_msg'])
        # Get an preregisterd user status type.  Error out if not found
        try:
            self.prereg_status = AuthUserStatusSadc.objects.get(auth_user_status_sadc_desc='Preregistered')
            self.prereg_status_value = self.prereg_status.auth_user_status_sadc_desc
        except AuthUserStatusSadc.DoesNotExist:
            all_valid = False
            error = "err-s005"
            logger.debug(authAdminErrors[error]['d_msg'])
        # Get an registerd user status type.  Error out if not found
        try:
            self.reg_status = AuthUserStatusSadc.objects.get(auth_user_status_sadc_desc='Registered')
            self.reg_status_value = self.reg_status.auth_user_status_sadc_desc
        except AuthUserStatusSadc.DoesNotExist:
            all_valid = False
            error = "err-s006"
            logger.debug(authAdminErrors[error]['d_msg'])

        # If any fail, throw and ObjectDoesNotExist exception so client can be notified.
        if not all_valid:
            raise ObjectDoesNotExist

# get all of the required status values
userStatusObj = UserStatusValues()

class User(APIView):
    """
        Users
    """
    def get(self, request, auth_user_guid=None, format=None):
        if Authenticate.get_session_credentials(request) is None:
            error = "err-s007"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result": "error", "message": error}, status=status.HTTP_400_BAD_REQUEST)

        if auth_user_guid is not None:
            try:
                the_user = AuthUserSadc.objects.get(auth_user_guid=auth_user_guid)
                logger.debug("USER STATUS: %s" % the_user.auth_user_status_desc )
                serializer = AuthUserSadcSerializer(the_user)
                return Response(serializer.data)
            except AuthUserSadc.DoesNotExist:
                raise Http404
        else:
            # the_users = AuthUserSadc.objects.filter(legacy_flg__isnull=True).order_by('last_name', 'first_name')
            # Sort is done on the grid
            the_users = AuthUserSadc.objects.filter(legacy_flg__isnull=True)
            serializer = AuthUserSadcSerializer(the_users, many=True)
            return Response(serializer.data)
    def put(self, request, auth_user_guid=None):
        if auth_user_guid == None:
            error = "err-a001"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result": "error", "message": error}, status=status.HTTP_400_BAD_REQUEST)
        logger.debug("USER PUT REQUEST: %s" %request.data)
        try:
            the_user = AuthUserSadc.objects.get(auth_user_guid=auth_user_guid)
            logger.debug("REQUEST DATA IN: %s" % request.data)
            serializer = AuthUserSadcSerializer(the_user, data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            logger.debug("SERIALIZER ERRORS: %s" % serializer.errors)
            return Response({"result": "error", "message": serializer.errors }, status=status.HTTP_400_BAD_REQUEST)
        except AuthUserSadc.DoesNotExist:
            error = "err-a002"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result": "error", "message": error}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        logger.debug("USER POST REQUEST: %s" % request.data)
        # Make sure email is not empty
        if 'email_primary' not in request.data:
            error = "err-a003"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result": "error", "message": error}, status=status.HTTP_400_BAD_REQUEST)
        if request.data['email_primary'] == '':
            error = "err-a004"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result": "error", "message": error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            # check to see if username with that email already exists
            try:
                request.data['email_primary'] = request.data['email_primary'].lower()
                user = AuthUserSadc.objects.get(auth_user_name=request.data['email_primary'])
                # If exception isn't thrown, that means user exists.  So error out.
                error = "err-a005"
                logger.debug(authAdminErrors[error]['d_msg'])
                return Response({"result": "error", "message": error}, status=status.HTTP_400_BAD_REQUEST)
            except AuthUserSadc.DoesNotExist:
                # That is the proper response.  It shouldn't exist.
                # Set status to created
                request.data['auth_user_status_desc'] = userStatusObj.unregistered_status.auth_user_status_sadc_desc
                logger.debug("UPDATED REQUEST DATA: %s" %request.data)
                # serializer = AuthUserSadcSerializer(data=request.data)
                serializer = AuthUserSadcSerializer(data=request.data)
                logger.debug("SERIALIZED USER: %s" % serializer)
                if serializer.is_valid():
                    serializer.save()
                    logger.debug(">>VALID SERIALIZER FOR USER %s" % serializer.data)
                    return Response(serializer.data)
                else:
                    error = "err-a006"
                    logger.debug(authAdminErrors[error]['d_msg'])
                    logger.debug("Serializer errors for user POST: %s", serializer.errors)
                    return Response({"result": "error", "message": error}, status=status.HTTP_400_BAD_REQUEST)

class RolePartner(APIView):
    """
        Partner for Roles
    """
    def get(self, request, partner_guid=None, format=None):
        if partner_guid is not None:
            try:
                partners = Partner.objects.get(partner_guid=partner_guid)
                serializer = PartnerSerializer(partners)
            except Partner.DoesNotExist:
                raise Http404
        else:
            partners = Partner.objects.all().order_by('partner_name')
            serializer = PartnerSerializer(partners, many=True)
        return Response(serializer.data)


class RoleTier(APIView):
    """
        Tier for Roles
    """
    def get(self, request, tier=None, format=None):
        if tier is not None:
            try:
                tiers = Tier.objects.get(tier_desc=tier)
                serializer = TierSerializer(tiers)
            except Tier.DoesNotExist:
                raise Http404
        else:
            tiers = Tier.objects.all().order_by('tier_desc')
            serializer = TierSerializer(tiers, many=True)
        return Response(serializer.data)


class OrganizationType(APIView):
    """
    List all person types ( organization types )
    """
    def get(self, request):
        orgtypes = PersonType.objects.all()
        # add csrf token to response
        csrf_token = get_token(request)
        serializer = PersonTypeSerializer(orgtypes, many=True)
        return Response(serializer.data)


class RoleTierGroup(APIView):
    """
        Group for Roles
    """
    def get(self, request, tier_group=None, format=None):
        # if user has the group 'OGIS', return all role groups
        # if OGISAuthAdmin.is_tier_group_ogis(request):
        #     tierGroupTypes = TierGroupType.objects.all()
        # else:
        #     tierGroupTypes = TierGroupType.objects.exclude(typeval='OGIS')
        if tier_group is not None:
            try:
                tierGroups = TierGroup.objects.get(tier_group_desc=tier_group)
                serializer = TierGroupSerializer(tierGroups)
            except TierGroup.DoesNotExist:
                raise Http404
        else:
            tierGroups = TierGroup.objects.all().order_by('tier_group_desc')
            serializer = TierGroupSerializer(tierGroups, many=True)
        return Response(serializer.data)


class RoleTierSubgroup(APIView):
    """
        Sub-Group for Roles
    """
    def get(self, request, tier_subgroup=None, format=None):
        # if user has the group 'OGIS', return all role groups
        # if OGISAuthAdmin.is_tier_group_ogis(request):
        #     tierGroupTypes = TierGroupType.objects.all()
        # else:
        #     tierGroupTypes = TierGroupType.objects.exclude(typeval='OGIS')
        if tier_subgroup is not None:
            try:
                tierSubgroups = TierSubgroup.objects.get(tier_subgroup_desc=tier_subgroup)
                serializer = TierSubgroupSerializer(tierSubgroups)
            except TierSubgroup.DoesNotExist:
                raise Http404

        else:
            tierSubgroups = TierSubgroup.objects.all().order_by('tier_subgroup_desc')
            serializer = TierSubgroupSerializer(tierSubgroups, many=True)
        return Response(serializer.data)


class RoleCounty(APIView):
    """
        County for Roles
    """
    def get(self, request, format=None):
        counties = County.objects.all().order_by('county_code')
        serializer = CountySerializer(counties, many=True)
        return Response(serializer.data)


class RoleMunicipality(APIView):
    """
        Municipality for Roles
    """
    def get(self, request, format=None):
        # check security
        municipalities = Municipality.objects.filter(active_flg=True).order_by('muni_code')
        serializer = MunicipalitySerializer(municipalities, many=True)
        return Response(serializer.data)


class RoleRoles(APIView):
    """
        Roles
    """
    def get(self, request, partner_guid='00000000-0000-0000-0000-000000000000', tier_desc='',
            tier_group_desc='', tier_subgroup_desc='', county='00', municipality='0000', format=None):

        ignore_guid = '00000000-0000-0000-0000-000000000000'
        ignore_county = '00'
        ignore_muni = '0000'

        kwargs = {}
        # only active roles!
        kwargs['active_flg'] = True
        # build rest of filters
        if partner_guid != ignore_guid:
            kwargs['partner_guid'] = partner_guid
        if tier_desc != '':
            kwargs['tier_desc'] = tier_desc
        if tier_group_desc != '':
            kwargs['tier_group_desc'] = tier_group_desc
        if tier_subgroup_desc != '':
            kwargs['tier_subgroup_desc'] = tier_subgroup_desc
        if county != ignore_county:
            kwargs['county_code'] = county
        if municipality != ignore_muni:
            kwargs['muni_code'] = municipality
        roles = AuthRoleSadc.objects.filter(**kwargs).order_by('auth_role_name')
        serializer = AuthRoleSadcSerializer(roles, many=True)
        return Response(serializer.data)


class UserStatus(APIView):
    """
        User Status
    """
    def get(self, request, status=None, format=None):
        if status is not None:
            try:
                the_status = AuthUserStatusSadc.objects.get(auth_user_status_sadc_desc=status)
                serializer = AuthUserStatusSadcSerializer(the_status)
                return Response(serializer.data)
            except AuthUserStatusSadc.DoesNotExist:
                raise Http404
        else:
            statuses = AuthUserStatusSadc.objects.all()
            serializer = AuthUserStatusSadcSerializer(statuses, many=True)
            return Response(serializer.data)


class ContactTypeView(APIView):
    """
        Contact Type
    """
    def get(self, request, contact_type_desc=None, format=None):
        if contact_type_desc is not None:
            try:
                the_contact_type = ContactType.objects.get(contact_type_desc=contact_type_desc)
                serializer = ContactTypeSerializer(the_contact_type)
                return Response(serializer.data)
            except ContactType.DoesNotExist:
                raise Http404
        else:
            contact_types = ContactType.objects.all()
            serializer = ContactTypeSerializer(contact_types, many=True)
            return Response(serializer.data)


class InviteUser(APIView):
    """
        Invite a user
    """
    def post(self, request):
        error_status = False
        # Incoming request contains {'auth_user_guids': [ 'auth_user_guid': 'xxxx-xxxx....' , ... ]}
        logger.debug("INVITE POST REQUEST: %s" % request.data)
        guid_list = request.data
        # Do each invite separately
        for guid_obj in guid_list['auth_user_guids']:
            logger.debug("Processing GUID: %s" % guid_obj)
            auth_user_guid = guid_obj['auth_user_guid']
            # get it from the database and update it
            try:
                user = AuthUserSadc.objects.get(auth_user_guid=auth_user_guid)
                # Don't invite registered or deactivated users
                if user.auth_user_status_desc.auth_user_status_sadc_desc != userStatusObj.deactivated_status_value and \
                    user.auth_user_status_desc.auth_user_status_sadc_desc != userStatusObj.reg_status_value:
                    current_user_status = user.auth_user_status_desc.auth_user_status_sadc_desc
                    logger.debug("USER CURRENT STATUS: %s" % current_user_status)
                    user.auth_user_status_desc = userStatusObj.invited_status
                    # Add registration token to the database
                    m = hashlib.md5()
                    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M')
                    auth_code_text = user.first_name+user.last_name+user.email_primary+timestamp
                    m.update(auth_code_text)
                    user.auth_code = m.hexdigest()
                    user.save()
                    guid_obj['status'] ='Success'
                    guid_obj['user_status'] = userStatusObj.invited_status_value
                    # Email the user the invite code
                    if current_user_status == userStatusObj.prereg_status_value:
                        email_type = 'Preregistered'
                    if current_user_status == userStatusObj.unregistered_status_value:
                        email_type = 'Unregistered'
                    if current_user_status == userStatusObj.invited_status_value:
                        email_type = 'Invited'
                    # TODO: Why was I clearing out the auth_id??????
                    #user.auth_id = ''
                    # Send email notification
                    logger.debug("SENDING EMAIL:")
                    # TODO:  Fix email from desktop
                    AG_RegisterEmail.send( email_type, user.first_name, user.last_name, user.email_primary, user.auth_code)
                    logger.debug("EMAIL SENT")
                    #----------------------------
                else:
                    guid_obj['status'] ='Failed'
                    guid_obj['user_status'] = user.auth_user_status_desc.auth_user_status_sadc_desc
                # Do all of the email stuff
            except AuthUserSadc.DoesNotExist:
                error_status = True
                guid_obj['status'] ='Does Not Exist'
                #print "UPDATED GUID OBJECT:", guid_obj
                logger.debug( "UPDATED GUID OBJECT: %s" % guid_obj)
            except Exception as e:
                traceback.print_exc(file=sys.stdout)
                error_status = True
                guid_obj['status'] = 'Error while saving'
                #print "UPDATED GUID OBJECT:", guid_obj
                logger.debug( "UPDATED GUID OBJECT: %s" % guid_obj)
        if error_status:
            return Response(guid_list, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response(guid_list)

class PreregisterUser(APIView):
    """
        Pre-Register users
    """
    # Use OPTIONS request to set the csrf token
    def options(self, request, format=None ):
        logger.debug("INSIDE OPTIONS FUNCTION")
        csrf_token = get_token(request)
        logger.debug("PREREG NEW CSRF TOKEN IS: " + csrf_token)
        return Response()

    def post(self, request, format=None):
        logger.debug("POST PRE REG DATA: %s" % request.data)
        if 'email_primary' not in request.data:
            error = "err-a003"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        if request.data['email_primary'] == '':
            error = "err-a004"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            # Check to see if user already exists with that email, that indicates person already pre-registered.
            request.data['email_primary'] = request.data['email_primary'].lower()
            username_check = request.data['email_primary']
            try:
                user = AuthUserSadc.objects.get(auth_user_name=username_check)
                # If exception isn't thrown, that means user exists.  So error out.
                error = "err-a005"
                logger.debug(authAdminErrors[error]['d_msg'])
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except ObjectDoesNotExist:
                #print("CREATE USER ATTEMPT TO SERIALIZE", request.data)
                logger.debug("CREATE USER ATTEMPT TO SERIALIZE %s" % request.data)
                # Set the status to pre-registered
                try:
                    #print "BEFORE GETTING AUTH USER STATUS PREREG FIELD"
                    logger.debug("BEFORE GETTING AUTH USER STATUS PREREG FIELD")
                    prereg_status = AuthUserStatusSadc.objects.get(auth_user_status_sadc_desc='Preregistered')
                    #print "PREREGISTERD STATUS:", prereg_status
                    logger.debug("PREREGISTERD STATUS: %s" % prereg_status)
                    request.data['auth_user_status_desc'] = prereg_status.auth_user_status_sadc_desc
                    #print "UPDATED REQUEST DATA:", request.data
                    logger.debug("UPDATED REQUEST DATA: %s" % request.data)
                    # serializer = AuthUserSadcSerializer(data=request.data)
                    serializer = AuthUserSadcSerializer(data=request.data)
                    #print "SERIALIZED USER:", serializer
                    logger.debug( "SERIALIZED USER: %s" % serializer)
                    if serializer.is_valid():
                        serializer.save()
                        #print ">>VALID SERIALIZER FOR PREREG USER", serializer.data
                        logger.debug(">>VALID SERIALIZER FOR PREREG USER %s" % serializer.data)
                        # TODO Add email notification to a group.
                        return Response(serializer.data)
                    else:
                        error = "err-a006"
                        logger.debug(authAdminErrors[error]['d_msg'])
                        logger.debug("Serializer errors for user POST: %s", serializer.errors)
                        return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                except AuthUserStatusSadc.DoesNotExist:
                    error = "err-s005"
                    logger.debug(authAdminErrors[error]['d_msg'])       
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                except Exception as e:
                    #print"Another error occurred:", e
                    logger.debug("Another error occurred: %s"  % e)

class RegisterUser(APIView):
    """
        Register a user
    """
    # Use OPTIONS request to set the csrf token
    def options(self, request, format=None ):
        #print "INSIDE OPTIONS FUNCTION"
        logger.debug( "INSIDE OPTIONS FUNCTION")
        csrf_token = get_token(request)
        #print ("PREREG NEW CSRF TOKEN IS: " + csrf_token)
        logger.debug("PREREG NEW CSRF TOKEN IS: %s" % csrf_token)
        return Response()
    """
    Check to see if user has correct auth_code, and is Invited.
    """
    def post(self, request, format=None):
        try:
            invited_status = AuthUserStatusSadc.objects.get(auth_user_status_sadc_desc='Invited')
        except ObjectDoesNotExist:
            error = "err-s003"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        try:
            registered_status = AuthUserStatusSadc.objects.get(auth_user_status_sadc_desc='Registered')
        except ObjectDoesNotExist:
            error = "err-s006"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        # Search for the user
        try:
            # Force email and auth code to lower for correct comparison
            the_user = AuthUserSadc.objects.get(auth_user_name=request.data['email'].lower().strip(),
                auth_code=request.data['auth_code'].lower().strip())
            #print "DOING REGISTRATION STUFF NOW", the_user.auth_user_status_desc, registered_status.auth_user_status_sadc_desc
            logger.debug( "DOING REGISTRATION STUFF NOW %s" % the_user.auth_user_status_desc, registered_status.auth_user_status_sadc_desc)
            #print "USER STATUS:", type(the_user.auth_user_status_desc)
            logger.debug( "USER STATUS: %s" % type(the_user.auth_user_status_desc))
            #print "REGISTERED STATUS:", type(registered_status)
            logger.debug( "REGISTERED STATUS: %s" % type(registered_status))
            if the_user.auth_user_status_desc == registered_status:
                error = "err-r001"
                logger.debug(authAdminErrors[error]['d_msg'])
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            else:
                # User hasn't fully completed the registration process so do myNJ Stuff
                wsdl = settings.get_prop('SELFREGWSDL')
                selfregtoken = settings.get_prop('SELFREGTOKEN')
                mynjrole = settings.get_prop('APPROLE')
                # get required user stuff
                username = the_user.auth_user_name
                email = the_user.email_primary
                contact_name = the_user.first_name + ' ' + the_user.last_name
                business_name = the_user.organization
                auth_id = the_user.auth_id
                # TODO: FIGURE OUT BEST WAY TO HANDLE REGRANT
                reGrantRevoked = True
                try:
                    logger.debug("Creating Client")
                    authClient = myNJAuth( wsdl, selfregtoken )
                    logger.debug("Survived creating client")
                    # If auth_id is empty, do grant, otherwise process was interrupted, so do resume
                    if auth_id == '':
                        logger.debug("Doing Grant for %s" % username)
                        grantResponse = authClient.grant( mynjrole, business_name, contact_name, email, username, reGrantRevoked, selfregtoken )
                        # Only success will return here, so save auth id and return redirect url back
                        the_user.auth_id = grantResponse.AuthID
                        redirectURL = grantResponse.AuthURL
                        logger.debug("Completed grant. Redirect URL is " + redirectURL)
                    else:
                        logger.debug("Doing Resume for %s" % username)
                        resumeResponse = authClient.resume( auth_id, selfregtoken )
                        # Only success will return here, so send redirect url back
                        redirectURL = resumeResponse.AuthURL
                        logger.debug("Completed resume. Redirect URL is " + redirectURL)
                    # update status of user and save it
                    logger.debug("Setting user status to registered" )
                    the_user.auth_user_status_desc = registered_status
                    the_user.save()
                    logger.debug("REDIRECTING AFTER GRANT/RESUME TO: " + redirectURL)
                    return Response({"success": redirectURL }, status=status.HTTP_200_OK )
                except ClientCreateException as e:
                    logger.debug("Error creating client from WSDL %s" % wsdl )
                    logger.debug( e.args[0] )
                    error = "err-r002"
                    logger.debug(authAdminErrors[error]['d_msg'])
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                except GrantFailureException as e:
                    logger.info("Error doing grant" )
                    logger.info(e)
                    error = "err-r003"
                    logger.debug(authAdminErrors[error]['d_msg'])
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                except ResumeFailureException as e:
                    logger.info("Error doing resume" )
                    logger.info(e)
                    error = "err-r004"
                    logger.debug(authAdminErrors[error]['d_msg'])
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                except Exception as e:
                    logger.debug("Other exeception:")
                    logger.debug( e)
                    error = "err-r005"
                    logger.debug(authAdminErrors[error]['d_msg'])
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        except ObjectDoesNotExist:
            error = "err-a002"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

class ReregisterUser(APIView):
    """
        Allow resetting of user to invited so they can try to reregister again.
    """

    def post(self, request, format=None):
        try:
            invited_status = AuthUserStatusSadc.objects.get(auth_user_status_sadc_desc='Invited')
        except ObjectDoesNotExist:
            error = "err-s003"
            logger.debug(authAdminErrors[error]['d_msg'])       
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        try:
            registered_status = AuthUserStatusSadc.objects.get(auth_user_status_sadc_desc='Registered')
        except ObjectDoesNotExist:
            error = "err-s006"
            logger.debug(authAdminErrors[error]['d_msg'])       
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        # Search for the user
        try:
            # Force email and auth code to lower for correct comparison
            the_user = AuthUserSadc.objects.get(auth_user_name=request.data['email'].lower().strip())
            logger.debug( "DOING REREGISTRATION STUFF NOW %s" % the_user.auth_user_status_desc, registered_status.auth_user_status_sadc_desc)
            logger.debug( "USER STATUS: %s" % type(the_user.auth_user_status_desc))
            logger.debug( "REGISTERED STATUS: %s" % type(registered_status))
            if the_user.auth_user_status_desc != registered_status:
                error = "err-r006"
                logger.debug(authAdminErrors[error]['d_msg'])       
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            else:
                # User is registered so set user back to invited and clear out the auth_id field
                the_user.auth_user_status_desc = invited_status
                # the_user.auth_id = '' # It may need to be cleared.  Will decide after testing.
                try:
                    the_user.save()
                except Exception as e:
                    logger.debug("Error resetting registration for user %s" % request.data['email'].lower().strip() )
                    logger.debug( e.args[0] )
                    error = "err-r007"
                    logger.debug(authAdminErrors[error]['d_msg'])
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        except ObjectDoesNotExist:
            error = "err-a002"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

class UnregisterUser(APIView):
    """
        Unegister a user
    """
    # Use OPTIONS request to set the csrf token
    def options(self, request, format=None ):
        #print "INSIDE OPTIONS FUNCTION"
        logger.debug( "INSIDE OPTIONS FUNCTION")
        csrf_token = get_token(request)
        #print ("PREREG NEW CSRF TOKEN IS: " + csrf_token)
        logger.debug ("PREREG NEW CSRF TOKEN IS: %s " % csrf_token)
        return Response()
    def post(self, request):
        error_status = False
        # Incoming request contains {'auth_user_guids': [ 'auth_user_guid': 'xxxx-xxxx....' , ... ]}
        #print("UNREGISTER POST REQUEST:", request.data)
        logger.debug("UNREGISTER POST REQUEST: %s" % request.data)
        guid_list = request.data
        # Do each invite separately
        for guid_obj in guid_list['auth_user_guids']:
            #print "Processing GUID:", guid_obj
            logger.debug( "Processing GUID: %s" % guid_obj)
            auth_user_guid = guid_obj['auth_user_guid']
            # get it from the database and update it
            try:
                user = AuthUserSadc.objects.get(auth_user_guid=auth_user_guid)
                # Don't unregister already unregistered or deactivated users
                if user.auth_user_status_desc.auth_user_status_sadc_desc != userStatusObj.deactivated_status_value and \
                    user.auth_user_status_desc.auth_user_status_sadc_desc != userStatusObj.unregistered_status_value:
                    user.auth_user_status_desc = userStatusObj.unregistered_status
                    user.auth_code = ''
                    user.auth_id = ''
                    user.save()
                    guid_obj['status'] ='Success'
                    guid_obj['user_status'] = userStatusObj.unregistered_status_value
                else:
                    guid_obj['status'] ='Failed'
                    guid_obj['user_status'] = user.auth_user_status_desc.auth_user_status_sadc_desc
                # Do all of the email stuff
            except AuthUserSadc.DoesNotExist:
                error_status = True
                guid_obj['status'] ='Does Not Exist'
                #print "UPDATED GUID OBJECT:", guid_obj
                logger.debug( "UPDATED GUID OBJECT: %s" % guid_obj)
            except Exception as e:
                traceback.print_exc(file=sys.stdout)
                error_status = True
                guid_obj['status'] = 'Error while saving'
                #print "UPDATED GUID OBJECT:", guid_obj
                logger.debug( "UPDATED GUID OBJECT: %s" % guid_obj)
        if error_status:
            return Response(guid_list, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response(guid_list)

class ActivateUser(APIView):
    """
        Activate a User
    """
    def post(self, request):
        error_status = False
        # Incoming request contains {'auth_user_guids': [ 'auth_user_guid': 'xxxx-xxxx....' , ... ]}
        #print(" POST REQUEST:", request.data)
        logger.debug(" POST REQUEST: %s" % request.data)
        guid_list = request.data
        # Do each invite separately
        for guid_obj in guid_list['auth_user_guids']:
            #print "Processing GUID:", guid_obj
            logger.debug( "Processing GUID: %s" % guid_obj)
            auth_user_guid = guid_obj['auth_user_guid']
            # get it from the database and update it
            try:
                user = AuthUserSadc.objects.get(auth_user_guid=auth_user_guid)
                # Don't update unless status is deactivated
                if user.auth_user_status_desc.auth_user_status_sadc_desc != userStatusObj.deactivated_status_value:
                    guid_obj['status'] ='Failed'
                    guid_obj['user_status'] = user.auth_user_status_desc.auth_user_status_sadc_desc
                else:
                    user.auth_user_status_desc = user.previous_status_desc
                    user.previous_status_desc = None
                    user.save()
                    guid_obj['status'] ='Success'
                    guid_obj['user_status'] = user.auth_user_status_desc.auth_user_status_sadc_desc
            except AuthUserSadc.DoesNotExist:
                error_status = True
                guid_obj['status'] ='err-a002'
                #print "UPDATED GUID OBJECT:", guid_obj
                logger.debug( "UPDATED GUID OBJECT: %s" % guid_obj)
            except Exception as e:
                traceback.print_exc(file=sys.stdout)
                error_status = True
                guid_obj['status'] = 'err-a0012'
                #print "UPDATED GUID OBJECT:", guid_obj
                logger.debug( "UPDATED GUID OBJECT: %s" % guid_obj)
        if error_status:
            return Response(guid_list, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response(guid_list)


class DeactivateUser(APIView):
    """
        Deactivate a User
    """
    # TODO FIX LOGIC FOR WHETHER USER IS CURRENTLY AUTHORIZED OR NOT
    def post(self, request):
        error_status = False

        # Incoming request contains {'auth_user_guids': [ 'auth_user_guid': 'xxxx-xxxx....' , ... ]}
        #print(" POST REQUEST:", request.data)
        logger.debug(" POST REQUEST: %s" % request.data)
        guid_list = request.data
        # Do each invite separately
        for guid_obj in guid_list['auth_user_guids']:
            #print "Processing GUID:", guid_obj
            logger.debug( "Processing GUID: %s" % guid_obj)
            auth_user_guid = guid_obj['auth_user_guid']
            # get it from the database and update it
            try:
                user = AuthUserSadc.objects.get(auth_user_guid=auth_user_guid)
                # Check current user status and change to deactivated only if not already deactivated
                if user.auth_user_status_desc.auth_user_status_sadc_desc != userStatusObj.deactivated_status_value:
                    logger.debug("User status is not deactivated")
                    # Save current status as previous status
                    user.previous_status_desc = user.auth_user_status_desc
                    # Set new status to deactivated
                    user.auth_user_status_desc = userStatusObj.deactivated_status
                    user.save()
                    guid_obj['status'] ='Success'
                    guid_obj['user_status'] = userStatusObj.deactivated_status_value
                else:
                    # User is already deactivated, so don't update previous status value.
                    guid_obj['status'] ='Success'
                    guid_obj['user_status'] = userStatusObj.deactivated_status_value
                # Do all of the email stuff
            except AuthUserSadc.DoesNotExist:
                error_status = True
                guid_obj['status'] ='err-a002'
                #print "UPDATED GUID OBJECT:", guid_obj
                logger.debug( "UPDATED GUID OBJECT: %s" % guid_obj)
            except Exception as e:
                traceback.print_exc(file=sys.stdout)
                error_status = True
                guid_obj['status'] = 'err-a0012'
                #print "UPDATED GUID OBJECT:", guid_obj
                logger.debug( "UPDATED GUID OBJECT: %s" % guid_obj)
        if error_status:
            return Response(guid_list, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response(guid_list)

