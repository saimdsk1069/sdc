from rest_framework import serializers

from database.models import (
    Fund,
    Appropriation,
    ProgramType,
    Expense,
    ExpenseType,
    ExpenseStatus,
    ExpensePayment,
    Farm,
    FundTransaction,
    GrantType,
    PartnerGrant,
    CompetitivePool,
    PaymentSource,
    PaymentStatus,
    StatusTransfer,
    Reappropriation,
    ReappropriationDetail,
    TransactionType)

from django.core.exceptions import ValidationError
from rest_framework.renderers import JSONRenderer
from rest_framework.parsers import JSONParser

import json
import cgi
import traceback
import logging

logger = logging.getLogger(__name__)


class FlattenMixin(object):
    """Flattens the specified related objects in this representation"""
    def to_representation(self, obj):
        assert hasattr(self.Meta, 'flatten'), (
            'Class {serializer_class} missing "Meta.flatten" attribute'.format(
                serializer_class=self.__class__.__name__
            )
        )
        # Get the current object representation
        rep = super(FlattenMixin, self).to_representation(obj)
        # Iterate the specified related objects with their serializer
        for field, serializer_class in self.Meta.flatten:
            serializer = serializer_class(context = self.context)
            objrep = serializer.to_representation(getattr(obj, field))
            #Include their fields, prefixed, in the current   representation
            for key in objrep:
                rep[key] = objrep[key]
        return rep


# #*************************************************************************************
# # Grant Types
# #*************************************************************************************
class GrantTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = GrantType
        fields = (
            'grant_type_desc'
        )


# #*************************************************************************************
# # FundTransSerializer
# #*************************************************************************************

class FilteredTransSerializer(serializers.ListSerializer):
    def to_representation(self, data):
        data = data.filter(cancelled_flg=False)
        return super(FilteredTransSerializer, self).to_representation(data)

class FundTransSerializer(serializers.ModelSerializer):
    application_id = serializers.SerializerMethodField('get_appid') #serializers.CharField(source='expense_payment_guid.expense_guid.application_id.application_id', read_only=True)
    farm_id = serializers.SerializerMethodField('get_farmid') #serializers.CharField(source='expense_payment_guid.expense_guid.farm_id.farm_id', read_only=True)
    farm_name = serializers.CharField(source='expense_payment_guid.expense_guid.farm_key.farm_name', read_only=True)
    expense_type = serializers.CharField(source='expense_payment_guid.expense_guid.expense_type.expense_type_desc', read_only=True)

    def get_appid(self,fundtrans):
        if fundtrans.expense_payment_guid:
            if fundtrans.expense_payment_guid.expense_guid.application_key:
                return '-'.join(  ['A',str(fundtrans.expense_payment_guid.expense_guid.application_key.application_type_guid.application_type_id),'{:>06d}'.format(fundtrans.expense_payment_guid.expense_guid.application_key.application_key)]  )
        else:
            return None
    def get_farmid(self,fundtrans):
        if fundtrans.expense_payment_guid:
            return '-'.join(  ['F','{:>06d}'.format(fundtrans.expense_payment_guid.expense_guid.farm_key.farm_key)]  )
        else:
            return None
    class Meta:
            list_serializer_class = FilteredTransSerializer
            model = FundTransaction
            fields = (
                'fund_transaction_guid',
                'fund_guid',
                'transaction_type_desc',
                'transaction_status',
                'amount',
                'description',
                'notes',
                'expense_payment_guid',
                'transaction_date',
                'application_id',
                'farm_id',
                'farm_name',
                'cancelled_flg',
                'expense_type'
            )
            read_only_fields = ('fund_transaction_guid',
                'fund_guid',
                'transaction_type_desc',
                'transaction_status',
                'amount',
                'description',
                'notes',
                'expense_payment_guid',
                'transaction_date',
                'application_id',
                'farm_id',
                'farm_name',
                'cancelled_flg',
                'expense_type')

class FundAppropsSerializer(serializers.ModelSerializer):
    program_name = serializers.CharField(source='program_type_guid.program_name', read_only=True)
    appropriation_name = serializers.SerializerMethodField('get_name')

    def get_name(self,appropriation):
        year = str(appropriation.year)
        unit = str(appropriation.appropriation_unit)
        program = str(appropriation.program_type_guid.program_code)
        grant = str(appropriation.grant_type_desc.grant_type_desc)
        return '-'.join([str(x) for x in [year,unit,program,grant] if x not in [None,' ','']])

    def get_payments(self, fund):
        qs = FundTransaction.objects.filter(fund_guid=fund)
        serializer = AppReappropSerializer(instance=qs, many=True)
        return serializer.data

    class Meta:
        model = Appropriation
        fields = (
            'appropriation_guid',
            'appropriation_unit',
            'appropriation_name',
            'year',
            'program_type_guid',
            'program_name',
            'pl_type',
            'grant_type_desc',
            'initial_amount',
            'balance',
            'pending',
            'appropriation_date',
            'encumbered',
            'spent',
            'reappropriated_out',
            'reappropriated_in'
        )
        read_only_fields = ('appropriation_guid',
                            'appropriation_unit',
                            'appropriation_name',
                            'year',
                            'program_type_guid',
                            'pl_type',
                            'grant_type_desc',
                            'initial_amount',
                            'balance',
                            'pending',
                            'appropriation_date',
                            'encumbered',
                            'spent',
                            'reappropriated_out',
                            'reappropriated_in',
                            'program_name')


class FundSerializer(serializers.ModelSerializer):
    fund_approps = FundAppropsSerializer(read_only=True,many=True)
    fund_trans = FundTransSerializer(read_only=True,many=True)
    class Meta:
        model = Fund
        fields = (
            'fund_guid',
            'fund_id',
            'fund_name',
            'fund_description',
            'balance',
            'encumbered',
            'spent',
            'fund_approps',
            'fund_trans'
        )
        read_only_fields = ('fund_guid','balance','encumbered','spent','fund_approps','fund_trans')

    def update(self, instance, validated_data):
        """
        Update and return an existing `Fund` instance, given the validated data.
        """
        #print "VALIDATED DATA:", validated_data
        logger.debug( "VALIDATED DATA: %s" % validated_data)

        #print "INSTANCE:", instance
        logger.debug( "INSTANCE: %s" % instance)
        instance.fund_id = validated_data.get('fund_id', instance.fund_id)
        instance.fund_name = validated_data.get('fund_name', instance.fund_name)
        instance.fund_description = validated_data.get('fund_description', instance.fund_description)


        instance.save()
        return instance


class NewFundSerializer(serializers.ModelSerializer):
    fund_approps = FundAppropsSerializer(read_only=True,many=True)
    fund_trans = FundTransSerializer(read_only=True,many=True)
    class Meta:
        model = Fund
        fields = (
            'fund_guid',
            'fund_id',
            'fund_name',
            'fund_description',
            'balance',
            'encumbered',
            'spent',
            'fund_approps',
            'fund_trans'
        )
        read_only_fields = ('fund_guid','encumbered','spent','fund_approps','fund_trans')


    def create(self, validated_data):
        #print "create function VALIDATED DATA:", validated_data
        logger.debug( "create function VALIDATED DATA: %s" % validated_data)

        try:
            newfund = Fund.objects.create(**validated_data)
            logger.debug( "FUND CREATED: %s" % newfund)
            #print "FUND CREATED:", newfund
            newfund.save()
            return newfund
        except ValidationError: # it's a django Validataion Error
            #print("ERROR CREATING FUND IN SERIALIZER")
            logger.debug("ERROR CREATING FUND IN SERIALIZER")
            #raise serializers.ValidationError("Error Creating New User")


# #*************************************************************************************
# # Fund Transactions
# #*************************************************************************************

class NewFundTransactionSerializer(serializers.ModelSerializer):
    fund_id = serializers.CharField(source='fund_guid.fund_id', read_only=True)
    fund_name = serializers.CharField(source='fund_guid.fund_name', read_only=True)
    application_id = serializers.SerializerMethodField('get_appid') #serializers.CharField(source='expense_payment_guid.expense_guid.application_id.application_id', read_only=True)
    farm_id = serializers.SerializerMethodField('get_farmid') #serializers.CharField(source='expense_payment_guid.expense_guid.farm_id.farm_id', read_only=True)
    farm_name = serializers.CharField(source='expense_payment_guid.expense_guid.farm_key.farm_name', read_only=True)

    def get_appid(self,fundtrans):
        if fundtrans.expense_payment_guid:
            return '-'.join(  ['A',str(fundtrans.expense_payment_guid.expense_guid.application_key.application_type_guid.application_type_id),'{:>06d}'.format(fundtrans.expense_payment_guid.expense_guid.application_key.application_key)]  )
        else:
            return None
    def get_farmid(self,fundtrans):
        if fundtrans.expense_payment_guid:
            return '-'.join(  ['F','{:>06d}'.format(fundtrans.expense_payment_guid.expense_guid.farm_key.farm_key)]  )
        else:
            return None

    class Meta:
            model = FundTransaction
            fields = (
                'fund_transaction_guid',
                'fund_guid',
                'transaction_type_desc',
                'transaction_status',
                'amount',
                'description',
                'notes',
                'expense_payment_guid',
                'transaction_date',
                'fund_id',
                'fund_name',
                'application_id',
                'farm_id',
                'farm_name',
                'cancelled_flg'
            )
            read_only_fields = (
                'fund_transaction_guid',
                'fund_id',
                'fund_name',
                'application_id',
                'farm_id',
                'farm_name')

    def create(self, validated_data):
        #print "create function VALIDATED DATA:", validated_data
        logger.debug( "create function VALIDATED DATA: %s" % validated_data)
        try:
            newtrans = FundTransaction.objects.create(**validated_data)
            newtrans.save()
            return newtrans
        except ValidationError:
            #print("Validation error")
            logger.debug("Validation error")

class FundTransactionSerializer(serializers.ModelSerializer):
    fund_id = serializers.CharField(source='fund_guid.fund_id', read_only=True)
    fund_name = serializers.CharField(source='fund_guid.fund_name', read_only=True)
    application_id = serializers.SerializerMethodField('get_appid') #serializers.CharField(source='expense_payment_guid.expense_guid.application_id.application_id', read_only=True)
    farm_id = serializers.SerializerMethodField('get_farmid') #serializers.CharField(source='expense_payment_guid.expense_guid.farm_id.farm_id', read_only=True)
    farm_name = serializers.CharField(source='expense_payment_guid.expense_guid.farm_key.farm_name', read_only=True)

    def get_appid(self,fundtrans):
        if fundtrans.expense_payment_guid:
            if fundtrans.expense_payment_guid.expense_guid.application_key:
                return '-'.join(  ['A',str(fundtrans.expense_payment_guid.expense_guid.application_key.application_type_guid.application_type_id),'{:>06d}'.format(fundtrans.expense_payment_guid.expense_guid.application_key.application_key)]  )
        else:
            return None
    def get_farmid(self,fundtrans):
        if fundtrans.expense_payment_guid:
            return '-'.join(  ['F','{:>06d}'.format(fundtrans.expense_payment_guid.expense_guid.farm_key.farm_key)]  )
        else:
            return None

    class Meta:
            model = FundTransaction
            fields = (
                'fund_transaction_guid',
                'fund_guid',
                'transaction_type_desc',
                'transaction_status',
                'amount',
                'description',
                'notes',
                'expense_payment_guid',
                'transaction_date',
                'fund_id',
                'fund_name',
                'application_id',
                'farm_id',
                'farm_name',
                'cancelled_flg'
            )
            read_only_fields = ('fund_transaction_guid',
                'fund_guid',
                'transaction_type_desc',
                'transaction_status',
                'amount',
                'description',
                'expense_payment_guid',
                'transaction_date',
                'fund_id',
                'fund_name',
                'application_id',
                'farm_id',
                'farm_name',
                'cancelled_flg')


    def update(self, instance, validated_data):
        """
        Update and return an existing `Fund_Transaction` instance, given the validated data.
        """
        #print "VALIDATED DATA:", validated_data
        logger.debug( "VALIDATED DATA: %s" % validated_data)
        #print "INSTANCE:", instance
        logger.debug( "INSTANCE: %s" % instance)

        instance.notes = validated_data.get('notes', instance.notes)

        instance.save()
        return instance



class CancelFundTransactionSerializer(serializers.ModelSerializer):

    class Meta:
            model = FundTransaction
            fields = (
                'fund_transaction_guid',
                'fund_guid',
                'transaction_type_desc',
                'transaction_status',
                'amount',
                'description',
                'notes',
                'expense_payment_guid',
                'transaction_date',
                'cancelled_flg'
            )
            read_only_fields = ('fund_transaction_guid',
                'fund_guid',
                'transaction_type_desc',
                'transaction_status',
                'amount',
                'description',
                'notes',
                'expense_payment_guid',
                'transaction_date')

    def update(self, instance, validated_data):
        """
        Cancel (Delete) a `Fund_Transaction` instance
        """
        #print "VALIDATED DATA:", validated_data
        logger.debug( "VALIDATED DATA: %s" % validated_data)
        #print "INSTANCE:", instance
        logger.debug( "INSTANCE: %s" % instance)
        instance.cancelled_flg = validated_data.get('cancelled_flg', instance.cancelled_flg)

        instance.save()
        return instance


# #*************************************************************************************
# # Appropriations
# #*************************************************************************************
class AppropPaymentSerializer(serializers.ModelSerializer): #FlattenMixin
    expense_type = serializers.CharField(source='expense_guid.expense_type.expense_type_desc', read_only=True, required=False)
    municipality = serializers.CharField(source='expense_guid.farm_key.muni_code.name', read_only=True)
    county = serializers.CharField(source='expense_guid.farm_key.muni_code.county', read_only=True)
    application_id = serializers.SerializerMethodField('get_appid') #serializers.CharField(source='expense_guid.application_id.application_id', read_only=True)
    farm_id = serializers.SerializerMethodField('get_farmid') #serializers.CharField(source='expense_guid.farm_id.farm_id', read_only=True)
    farm_name = serializers.CharField(source='expense_guid.farm_key.farm_name', read_only=True)
    partner_guid = serializers.CharField(source='partner_grant_guid.partner_guid.partner_guid', read_only=True)
    partner_name = serializers.CharField(source='partner_grant_guid.partner_guid.partner_name', read_only=True)
    appropriation_fund_id = serializers.CharField(source='appropriation_guid.fund_guid.fund_id', read_only=True)

    def get_appid(self,payment):
        if payment.expense_guid.application_key:
            return '-'.join(  ['A',str(payment.expense_guid.application_key.application_type_guid.application_type_id),'{:>06d}'.format(payment.expense_guid.application_key.application_key)]  )
        else:
            return None
    def get_farmid(self,payment):
        if payment.expense_guid.farm_key:
            return '-'.join(  ['F','{:>06d}'.format(payment.expense_guid.farm_key.farm_key)]  )
        else:
            return None

    class Meta:
        model = ExpensePayment
        fields = (
            'expense_payment_guid',
            'expense_guid',
            'partner_grant_guid',
            'expense_type',
            'partner_guid',
            'partner_name',
            'reappropriation_guid',
            'appropriation_fund_id',
            'payment_status_desc',
            'payment_source_type',
            'payment_amount',
            'payment_comment',
            'created_date',
            'created_user_guid',
            'last_edited_date',
            'last_edited_user_guid',
            'activity_code',
            'object_code',
            'vendor_code',
            'vendor_name',
            'partner_flg',
            'paid_date',
            'municipality',
            'county',
            'application_id',
            'farm_id',
            'farm_name'
        )
        read_only_fields = ('expense_payment_guid',
            'expense_guid',
            'partner_grant_guid',
            'expense_type',
            'partner_guid',
            'partner_name',
            'reappropriation_guid',
            'appropriation_fund_id',
            'payment_status_desc',
            'payment_amount',
            'payment_comment',
            'created_date',
            'created_user_guid',
            'activity_code',
            'object_code',
            'vendor_code',
            'vendor_name',
            'partner_flg',
            'paid_date',
            'municipality',
            'county',
            'application_id',
            'farm_id',
            'farm_name')


class AppReappropSerializer(serializers.ModelSerializer):
    source_appropriation_name = serializers.SerializerMethodField('get_sourcename')
    target_appropriation_name = serializers.SerializerMethodField('get_targetname')
    source_fund_guid = serializers.CharField(source='appropriation_source_guid.fund_guid.fund_guid', read_only=True)
    source_fund_name = serializers.CharField(source='appropriation_source_guid.fund_guid.fund_name', read_only=True)

    def get_sourcename(self,reapprop):
        year = str(reapprop.appropriation_source_guid.year)
        unit = str(reapprop.appropriation_source_guid.appropriation_unit)
        program = str(reapprop.appropriation_source_guid.program_type_guid.program_code)
        grant = str(reapprop.appropriation_source_guid.grant_type_desc.grant_type_desc)
        return '-'.join([str(x) for x in [year,unit,program,grant] if x not in [None,' ','']])
    def get_targetname(self,reapprop):
        year = str(reapprop.appropriation_target_guid.year)
        unit = str(reapprop.appropriation_target_guid.appropriation_unit)
        program = str(reapprop.appropriation_target_guid.program_type_guid.program_code)
        grant = str(reapprop.appropriation_target_guid.grant_type_desc.grant_type_desc)
        return '-'.join([str(x) for x in [year,unit,program,grant] if x not in [None,' ','']])

    class Meta:
        model = Reappropriation
        fields = (
            'reappropriation_guid',
            'source_appropriation_name',
            'target_appropriation_name',
            'source_fund_guid',
            'source_fund_name',
            'transfer_amount',
            'balance',
            'reappropriation_date',
            'status_transfer_desc'
        )
        read_only_fields = ('reappropriation_guid',
            'source_appropriation_name',
            'target_appropriation_name',
            'source_fund_guid',
            'source_fund_name',
            'transfer_amount',
            'balance',
            'reappropriation_date',
            'status_transfer_desc')


class AppropriationSerializer(serializers.ModelSerializer):
    program_name = serializers.CharField(source='program_type_guid.program_name', read_only=True)
    fund_id = serializers.CharField(source='fund_guid.fund_id', read_only=True)
    fund_name = serializers.CharField(source='fund_guid.fund_name', read_only=True)
    appropriation_name = serializers.SerializerMethodField('get_name')
    payments = AppropPaymentSerializer(read_only=True,many=True)
    reappropriations = serializers.SerializerMethodField('get_reappropin')
    reappropriated_in = serializers.SerializerMethodField('get_reappropin')
    reappropriated_out = serializers.SerializerMethodField('get_reappropout')
    reappropriated_in_balance = serializers.SerializerMethodField('get_inbal')
    reappropriated_out_balance = serializers.SerializerMethodField('get_outbal')

    def get_name(self,appropriation):
        year = str(appropriation.year)
        unit = str(appropriation.appropriation_unit)
        program = str(appropriation.program_type_guid.program_code)
        grant = str(appropriation.grant_type_desc.grant_type_desc)
        return '-'.join([str(x) for x in [year,unit,program,grant] if x not in [None,' ','']])

    def get_reappropin(self, appropriation):
        qs = Reappropriation.objects.filter(appropriation_target_guid=appropriation)
        serializer = AppReappropSerializer(instance=qs, many=True)
        return serializer.data
    def get_reappropout(self, appropriation):
        qs = Reappropriation.objects.filter(appropriation_source_guid=appropriation)
        serializer = AppReappropSerializer(instance=qs, many=True)
        return serializer.data
    def get_inbal(self, appropriation):
        qs = Reappropriation.objects.filter(appropriation_target_guid=appropriation,status_transfer_desc='FINAL')
        sum = 0
        for rec in qs:
            sum += rec.balance
        return sum
    def get_outbal(self, appropriation):
        qs = Reappropriation.objects.filter(appropriation_source_guid=appropriation,status_transfer_desc='FINAL')
        sum = 0
        for rec in qs:
            sum += rec.balance
        return sum

    class Meta:
        model = Appropriation
        fields = (
            'appropriation_guid',
            'appropriation_unit',
            'appropriation_name',
            'year',
            'program_type_guid',
            'fund_guid',
            'pl_type',
            'grant_type_desc',
            'initial_amount',
            'balance',
            'pending',
            'appropriation_date',
            'encumbered',
            'spent',
            'reappropriated_out',
            'reappropriated_in',
            'program_name',
            'fund_id',
            'fund_name',
            'payments',
            'reappropriations',
            'reappropriated_in',
            'reappropriated_out',
            'reappropriated_in_balance',
            'reappropriated_out_balance'
        )
        read_only_fields = ('appropriation_guid',
                            'appropriation_name',
                            'year',
                            'program_type_guid',
                            'fund_guid',
                            'grant_type_desc',
                            'initial_amount',
                            'balance',
                            'pending',
                            'encumbered',
                            'spent',
                            'reappropriated_out',
                            'reappropriated_in',
                            'program_name',
                            'fund_id',
                            'fund_name',
                            'payments',
                            'reappropriations',
                            'reappropriated_in',
                            'reappropriated_out',
                            'reappropriated_in_balance',
                            'reappropriated_out_balance')

    def update(self, instance, validated_data):
        """
        Update and return an existing `Appropriation` instance, given the validated data.
        """
        #print "VALIDATED DATA:", validated_data
        logger.debug( "VALIDATED DATA: %s" % validated_data)
        #print "INSTANCE:", instance
        logger.debug( "INSTANCE: %s" % instance)
        #print "INSTANCE APPROP GUID IN UPDATE: ", validated_data.get('appropriation_guid', instance.appropriation_guid)
        logger.debug( "INSTANCE APPROP GUID IN UPDATE: %s " % validated_data.get('appropriation_guid', instance.appropriation_guid))

        instance.appropriation_unit = validated_data.get('appropriation_unit', instance.appropriation_unit)
        #instance.year = validated_data.get('year', instance.year)
        #instance.program_type_guid = validated_data.get('program_type_guid', instance.program_type_guid)
        #instance.fund_guid = validated_data.get('fund_guid', instance.fund_guid)
        instance.pl_type = validated_data.get('pl_type', instance.pl_type)
        #instance.grant_type_desc = validated_data.get('grant_type_desc', instance.grant_type_desc)
        #instance.initial_amount = validated_data.get('initial_amount', instance.initial_amount)
        #instance.balance = validated_data.get('balance', instance.balance)
        instance.appropriation_date = validated_data.get('appropriation_date', instance.appropriation_date)
        #instance.encumbered = validated_data.get('encumbered', instance.encumbered)
        #instance.spent = validated_data.get('spent', instance.spent)

        instance.save()
        return instance


class NewAppropriationSerializer(serializers.ModelSerializer):
    program_name = serializers.CharField(source='program_type_guid.program_name', read_only=True)
    fund_id = serializers.CharField(source='fund_guid.fund_id', read_only=True)
    fund_name = serializers.CharField(source='fund_guid.fund_name', read_only=True)
    appropriation_name = serializers.SerializerMethodField('get_name')
    #payments = AppropPaymentSerializer(read_only=True,many=True)

    def get_name(self,appropriation):
        year = str(appropriation.year)
        unit = str(appropriation.appropriation_unit)
        program = str(appropriation.program_type_guid.program_code)
        grant = str(appropriation.grant_type_desc.grant_type_desc)
        return '-'.join([str(x) for x in [year,unit,program,grant] if x not in [None,' ','']])

    class Meta:
        model = Appropriation
        fields = (
            'appropriation_guid',
            'appropriation_unit',
            'appropriation_name',
            'year',
            'program_type_guid',
            'fund_guid',
            'pl_type',
            'grant_type_desc',
            'initial_amount',
            'balance',
            'pending',
            'appropriation_date',
            'encumbered',
            'spent',
            'program_name',
            'fund_id',
            'fund_name'

        )
        read_only_fields = ('appropriation_guid','appropriation_name','encumbered','spent','balance','pending','program_name','fund_id','fund_name',)


    def create(self, validated_data):
        #print "create function VALIDATED DATA:", validated_data
        logger.debug( "create function VALIDATED DATA: %s" % validated_data)

        try:
            newapprop = Appropriation.objects.create(**validated_data)
            #print "APPROP CREATED:", newapprop
            logger.debug( "APPROP CREATED: %s" % newapprop)
            newapprop.save()
            return newapprop
        except ValidationError: # it's a django Validataion Error
            #print("ERROR CREATING APPROP IN SERIALIZER")
            logger.debug("ERROR CREATING APPROP IN SERIALIZER")

            #raise serializers.ValidationError("Error Creating New User")






# #*************************************************************************************
# # Payments
# #*************************************************************************************


class PaymentInfoSerializer(serializers.ModelSerializer): #FlattenMixin
    appropriation_name = serializers.SerializerMethodField('get_name') #CharField(source='appropriation_guid.appropriation_name', read_only=True)
    expense_type = serializers.CharField(source='expense_guid.expense_type.expense_type_desc', read_only=True, required=False)
    municipality = serializers.CharField(source='expense_guid.farm_key.muni_code.name', read_only=True)
    county = serializers.CharField(source='expense_guid.farm_key.muni_code.county', read_only=True)
    application_id = serializers.SerializerMethodField('get_appid') #serializers.CharField(source='expense_guid.application_id.application_id', read_only=True)
    farm_id = serializers.SerializerMethodField('get_farmid') #serializers.CharField(source='expense_guid.farm_id.farm_id', read_only=True)
    farm_name = serializers.CharField(source='expense_guid.farm_key.farm_name', read_only=True)
    partner_name = serializers.CharField(source='partner_guid.partner_name', read_only=True)
    reapprop_flag = serializers.SerializerMethodField('check_reapprop')
    reapp_balance = serializers.CharField(source='reappropriation_guid.balance', read_only=True)
    appropriation_fund_id = serializers.CharField(source='appropriation_guid.fund_guid.fund_id', read_only=True)
    reapp_approp_guid = serializers.CharField(source='reappropriation_guid.appropriation_source_guid.appropriation_guid', read_only=True)
    reapp_fund_guid = serializers.CharField(source='reappropriation_guid.appropriation_source_guid.fund_guid.fund_guid', read_only=True)
    reapp_fund_id = serializers.CharField(source='reappropriation_guid.appropriation_source_guid.fund_guid.fund_id', read_only=True)
    created_user = serializers.SerializerMethodField('get_createduser')
    last_edited_user = serializers.SerializerMethodField('get_lastuser')


    def get_appid(self,payment):
        if payment.expense_guid.application_key:
            return '-'.join(  ['A',str(payment.expense_guid.application_key.application_type_guid.application_type_id),'{:>06d}'.format(payment.expense_guid.application_key.application_key)]  )
        else:
            return None
    def get_farmid(self,payment):
        if payment.expense_guid.farm_key:
            return '-'.join(  ['F','{:>06d}'.format(payment.expense_guid.farm_key.farm_key)]  )
        else:
            return None

    def get_createduser(self,paymentrec):
        if paymentrec.created_user_guid:
            first = paymentrec.created_user_guid.first_name
            last = paymentrec.created_user_guid.last_name
            return ', '.join([str(x) for x in [last,first] if x not in [None,' ','']])
        else:
            return ''
    def get_lastuser(self,paymentrec):
        if paymentrec.last_edited_user_guid:
            first = paymentrec.last_edited_user_guid.first_name
            last = paymentrec.last_edited_user_guid.last_name
            return ', '.join([str(x) for x in [last,first] if x not in [None,' ','']])
        else:
            return ''

    def check_reapprop(self,paymentrec):
        if paymentrec.reappropriation_guid:
            return 'Y'
        else:
            return 'N'

    def get_name(self,paymentrec):
        if paymentrec.payment_source_type:
            if paymentrec.payment_source_type.payment_source_desc == "SADC":
                year = str(paymentrec.appropriation_guid.year)
                unit = str(paymentrec.appropriation_guid.appropriation_unit)
                program = str(paymentrec.appropriation_guid.program_type_guid.program_code)
                grant = str(paymentrec.appropriation_guid.grant_type_desc.grant_type_desc)
                return '-'.join([str(x) for x in [year,unit,program,grant] if x not in [None,' ','']])

        return ''

    class Meta:
        model = ExpensePayment
        fields = (
            'expense_payment_guid',
            'expense_guid',
            'expense_type',
            'partner_grant_guid',
            'competitive_pool_guid',
            'partner_guid',
            'partner_name',
            'appropriation_guid',
            'appropriation_fund_id',
            'reappropriation_guid',
            'payment_source_type',
            'payment_source_desc',
            'payment_status_desc',
            'payment_amount',
            'payment_comment',
            'created_date',
            'created_user',
            'created_user_guid',
            'last_edited_date',
            'last_edited_user',
            'last_edited_user_guid',
            'activity_code',
            'object_code',
            'vendor_code',
            'vendor_name',
            'partner_flg',
            'paid_date',
            'appropriation_name',
            'application_id',
            'municipality',
            'county',
            'farm_id',
            'farm_name',
            'reapprop_flag',
            'reapp_balance',
            'reapp_approp_guid',
            'reapp_fund_guid',
            'reapp_fund_id'
        )
        read_only_fields = ('expense_payment_guid','partner_grant_guid','partner_guid','partner_name','appropriation_name','expense_guid','expense_type','municipality','county','appropriation_fund_id','application_id',
                            'reapprop_flag','reapp_balance','payment_source_type','reapp_approp_guid','partner_flg','reapp_fund_guid','reapp_fund_id','farm_id','farm_name','created_user','last_edited_user')


    def update(self, instance, validated_data):
        """
        Update and return an existing `Expense_Payment` instance, given the validated data.
        """
        #print "VALIDATED DATA:", validated_data
        logger.debug( "VALIDATED DATA: %s" % validated_data)
        #print "INSTANCE:", instance
        logger.debug( "INSTANCE: %s" % instance)
        #instance.expense_guid = validated_data.get('expense_guid', instance.expense_guid)
        #instance.partner_guid = validated_data.get('partner_guid', instance.partner_guid)
        #instance.appropriation_guid = validated_data.get('appropriation_guid', instance.appropriation_guid)
        instance.payment_status_desc = validated_data.get('payment_status_desc', instance.payment_status_desc)
        instance.activity_code = validated_data.get('activity_code', instance.activity_code)
        instance.payment_source_desc = validated_data.get('payment_source_desc', instance.payment_source_desc)
        instance.object_code = validated_data.get('object_code', instance.object_code)
        instance.payment_amount = validated_data.get('payment_amount', instance.payment_amount)
        instance.payment_comment = validated_data.get('payment_comment', instance.payment_comment)
        instance.paid_date = validated_data.get('paid_date', instance.paid_date)

        instance.save()
        return instance


class NewSADCPaymentSerializer(serializers.ModelSerializer): #FlattenMixin
    appropriation_name = serializers.SerializerMethodField('get_name')
    expense_type = serializers.CharField(source='expense_guid.expense_type.expense_type_desc', read_only=True, required=False)
    municipality = serializers.CharField(source='expense_guid.farm_key.muni_code.name', read_only=True)
    county = serializers.CharField(source='expense_guid.farm_key.muni_code.county', read_only=True)
    application_id = serializers.SerializerMethodField('get_appid') #serializers.CharField(source='expense_guid.application_id.application_id', read_only=True)
    partner_name = serializers.CharField(source='partner_guid.partner_name', read_only=True)
    reapp_approp_guid = serializers.CharField(source='reappropriation_guid.appropriation_source_guid.appropriation_guid', read_only=True)
    reapp_fund_guid = serializers.CharField(source='reappropriation_guid.appropriation_source_guid.fund_guid.fund_guid', read_only=True)
    reapp_fund_id = serializers.CharField(source='reappropriation_guid.appropriation_source_guid.fund_guid.fund_id', read_only=True)
    appropriation_fund_id = serializers.CharField(source='appropriation_guid.fund_guid.fund_id', read_only=True)
    created_user = serializers.SerializerMethodField('get_createduser')
    last_edited_user = serializers.SerializerMethodField('get_lastuser')

    def get_appid(self,payment):
        if payment.expense_guid.application_key:
            return '-'.join(  ['A',str(payment.expense_guid.application_key.application_type_guid.application_type_id),'{:>06d}'.format(payment.expense_guid.application_key.application_key)]  )
        else:
            return None

    def get_createduser(self,paymentrec):
        if paymentrec.created_user_guid:
            first = paymentrec.created_user_guid.first_name
            last = paymentrec.created_user_guid.last_name
            return ', '.join([str(x) for x in [last,first] if x not in [None,' ','']])
        else:
            return ''
    def get_lastuser(self,paymentrec):
        if paymentrec.last_edited_user_guid:
            first = paymentrec.last_edited_user_guid.first_name
            last = paymentrec.last_edited_user_guid.last_name
            return ', '.join([str(x) for x in [last,first] if x not in [None,' ','']])
        else:
            return ''

    def get_name(self,paymentrec):
        year = str(paymentrec.appropriation_guid.year)
        unit = str(paymentrec.appropriation_guid.appropriation_unit)
        program = str(paymentrec.appropriation_guid.program_type_guid.program_code)
        grant = str(paymentrec.appropriation_guid.grant_type_desc.grant_type_desc)
        return '-'.join([str(x) for x in [year,unit,program,grant] if x not in [None,' ','']])

    class Meta:
        model = ExpensePayment
        fields = (
            'expense_payment_guid',
            'expense_guid',
            'partner_grant_guid',
            'competitive_pool_guid',
            'partner_guid',
            'partner_name',
            'appropriation_guid',
            'appropriation_fund_id',
            'reappropriation_guid',
            'payment_status_desc',
            'payment_source_type',
            'payment_source_desc',
            'payment_amount',
            'payment_comment',
            'created_date',
            'created_user',
            'created_user_guid',
            'last_edited_date',
            'last_edited_user',
            'last_edited_user_guid',
            'activity_code',
            'object_code',
            'vendor_code',
            'vendor_name',
            'partner_flg',
            'paid_date',
            'appropriation_name',
            'expense_type',
            'municipality',
            'county',
            'application_id',
            'reapp_approp_guid',
            'reapp_fund_guid',
            'reapp_fund_id'
        )
        read_only_fields = ('expense_payment_guid',
                            'paid_date',
                            'partner_name',
                            'appropriation_name',
                            'appropriation_fund_id',
                            'expense_type',
                            'municipality',
                            'county',
                            'application_id',
                            'reapp_approp_guid',
                            'reapp_fund_guid',
                            'reapp_fund_id',
                            'created_user',
                            'last_edited_user')

    def create(self, validated_data):
        #print "create function VALIDATED DATA:", validated_data
        logger.debug( "create function VALIDATED DATA: %s" % validated_data)
        try:
            newpayment = ExpensePayment.objects.create(**validated_data)
            newpayment.save()
            return newpayment
        except ValidationError: # it's a django Validataion Error
            #print("ERROR CREATING PAYMENT IN SERIALIZER")
            logger.debug("ERROR CREATING PAYMENT IN SERIALIZER")
            #raise serializers.ValidationError("Error Creating New User")



class NewPaymentSerializer(serializers.ModelSerializer): #FlattenMixin
    expense_type = serializers.CharField(source='expense_guid.expense_type.expense_type_desc', read_only=True, required=False)
    municipality = serializers.CharField(source='expense_guid.farm_key.muni_code.name', read_only=True)
    county = serializers.CharField(source='expense_guid.farm_key.muni_code.county', read_only=True)
    application_id = serializers.SerializerMethodField('get_appid') #serializers.CharField(source='expense_guid.application_id.application_id', read_only=True)
    created_user = serializers.SerializerMethodField('get_createduser')
    last_edited_user = serializers.SerializerMethodField('get_lastuser')

    def get_appid(self,payment):
        if payment.expense_guid.application_key:
            return '-'.join(  ['A',str(payment.expense_guid.application_key.application_type_guid.application_type_id),'{:>06d}'.format(payment.expense_guid.application_key.application_key)]  )
        else:
            return None
    def get_createduser(self,paymentrec):
        if paymentrec.created_user_guid:
            first = paymentrec.created_user_guid.first_name
            last = paymentrec.created_user_guid.last_name
            return ', '.join([str(x) for x in [last,first] if x not in [None,' ','']])
        else:
            return ''
    def get_lastuser(self,paymentrec):
        if paymentrec.last_edited_user_guid:
            first = paymentrec.last_edited_user_guid.first_name
            last = paymentrec.last_edited_user_guid.last_name
            return ', '.join([str(x) for x in [last,first] if x not in [None,' ','']])
        else:
            return ''

    def get_name(self,paymentrec):
        year = str(paymentrec.appropriation_guid.year)
        unit = str(paymentrec.appropriation_guid.appropriation_unit)
        program = str(paymentrec.appropriation_guid.program_type_guid.program_code)
        grant = str(paymentrec.appropriation_guid.grant_type_desc.grant_type_desc)
        return '-'.join([str(x) for x in [year,unit,program,grant] if x not in [None,' ','']])

    class Meta:
        model = ExpensePayment
        fields = (
            'expense_payment_guid',
            'expense_guid',
            'payment_source_type',
            'payment_source_desc',
            'payment_amount',
            'payment_comment',
            'created_date',
            'created_user',
            'created_user_guid',
            'last_edited_date',
            'last_edited_user',
            'last_edited_user_guid',
            'expense_type',
            'municipality',
            'county',
            'application_id',

        )
        read_only_fields = ('expense_payment_guid',
                            'expense_type',
                            'municipality',
                            'county',
                            'application_id',
                            'created_user',
                            'last_edited_user')

    def create(self, validated_data):
        #print "create function VALIDATED DATA:", validated_data
        logger.debug( "create function VALIDATED DATA: %s" % validated_data)
        try:
            newpayment = ExpensePayment.objects.create(**validated_data)
            newpayment.save()
            return newpayment
        except ValidationError: # it's a django Validataion Error
            #print("ERROR CREATING PAYMENT IN SERIALIZER")
            logger.debug("ERROR CREATING PAYMENT IN SERIALIZER")
            #raise serializers.ValidationError("Error Creating New User")

# #*************************************************************************************
# # Expenses & Cost Shares
# #*************************************************************************************


class ExpenseCostShareSerializer(serializers.ModelSerializer):

    class Meta:
        model = Expense
        fields = (
            'expense_guid',
            'cost_share_json'
        )
        read_only_fields = ('expense_guid',)

    def update(self, instance, validated_data):
        '''
        Update and return an existing `Expense_Cost_Share` instance, given the validated data.
        '''
        #print "VALIDATED DATA:", validated_data
        logger.debug( "VALIDATED DATA: %s" % validated_data)
        #print "INSTANCE:", instance
        logger.debug( "INSTANCE: %s" % instance)
        instance.cost_share_json = validated_data.get('cost_share_json', instance.cost_share_json)
        instance.save()
        return instance



class ExpenseSerializer(serializers.ModelSerializer):
    municipality = serializers.CharField(source='farm_key.muni_code.name')
    county = serializers.CharField(source='farm_key.muni_code.county')
    farm_name = serializers.CharField(source='farm_key.farm_name')
    expense_payments = PaymentInfoSerializer(many=True, read_only=True)
    farm_id = serializers.SerializerMethodField('get_farmid')
    application_id = serializers.SerializerMethodField('get_appid')

    def get_appid(self,exp):
        if exp.application_key:
            return '-'.join(  ['A',str(exp.application_key.application_type_guid.application_type_id),'{:>06d}'.format(exp.application_key.application_key)]  )
        else:
            return None
    def get_farmid(self,exp):
        if exp.farm_key:
            return '-'.join(  ['F','{:>06d}'.format(exp.farm_key.farm_key)]  )
        else:
            return None

    class Meta:
        model = Expense
        fields = (
            'expense_guid',
            'expense_type',
            'expense_description',
            'expense_status_desc',
            'expense_amount',
            'farm_key',
            'farm_id',
            'farm_name',
            'municipality',
            'county',
            'application_key',
            'application_id',
            'cost_share_json',
            'expense_payments',
            'created_date'
        )
        read_only_fields = ('expense_guid',
                            'municipality',
                            'county',
                            'farm_name',
                            'expense_payments',
                            'created_date',
                            'farm_id',
                            'application_id')

    def update(self, instance, validated_data):
        """
        Update and return an existing `Expense` instance, given the validated data.
        """
        #print "VALIDATED DATA:", validated_data
        logger.debug( "VALIDATED DATA: %s" % validated_data)
        #print "INSTANCE:", instance
        logger.debug( "INSTANCE: %s" % instance)

        instance.expense_type = validated_data.get('expense_type', instance.expense_type)
        instance.expense_description = validated_data.get('expense_description', instance.expense_description)
        instance.expense_status_desc = validated_data.get('expense_status_desc', instance.expense_status_desc)
        instance.expense_amount = validated_data.get('expense_amount', instance.expense_amount)
        #instance.farm_key = validated_data.get('farm_key', instance.farm_key)
        #instance.application_key = validated_data.get('application_key', instance.application_key)
        instance.cost_share_json = validated_data.get('cost_share_json', instance.cost_share_json)

        instance.save()
        return instance


class NewExpenseSerializer(serializers.ModelSerializer):
    farm_name = serializers.CharField(source='farm_key.farm_name',read_only=True)
    farm_id = serializers.SerializerMethodField('get_farmid')
    application_id = serializers.SerializerMethodField('get_appid')

    def get_appid(self,exp):
        if exp.application_key:
            return '-'.join(  ['A',str(exp.application_key.application_type_guid.application_type_id),'{:>06d}'.format(exp.application_key.application_key)]  )
        else:
            return None
    def get_farmid(self,exp):
        if exp.farm_key:
            return '-'.join(  ['F','{:>06d}'.format(exp.farm_key.farm_key)]  )
        else:
            return None


    class Meta:
        model = Expense
        fields = (
            'expense_guid',
            'expense_type',
            'expense_description',
            'expense_status_desc',
            'expense_amount',
            'farm_key',
            'farm_id',
            'farm_name',
            'application_key',
            'application_id',
            'cost_share_json',
            'created_date'
        )
        read_only_fields = ('expense_guid',
                            'created_date',
                            'farm_id',
                            'farm_name',
                            'application_id')


    def create(self, validated_data):
        try:
            newexpense = Expense.objects.create(**validated_data)
            #print "Expense CREATED:", newexpense
            logger.debug( "Expense CREATED: %s" % newexpense)
            newexpense.save()
            return newexpense
        except ValidationError: # it's a django Validataion Error
            #print("ERROR CREATING EXPENSE IN SERIALIZER")
            logger.debug("ERROR CREATING EXPENSE IN SERIALIZER")
            #raise serializers.ValidationError("Error Creating New User")
        except Exception as e:
            #print 'Exception===',e.message
            logger.debug( "Exception=== %s" % e.message)



# #*************************************************************************************
# # Reappropriations
# #*************************************************************************************
class PaymentReappropSerializer(serializers.ModelSerializer):
    source_fund_guid = serializers.CharField(source='appropriation_source_guid.fund_guid.fund_guid', read_only=True)
    source_fund_name = serializers.CharField(source='appropriation_source_guid.fund_guid.fund_name', read_only=True)
    class Meta:
        model = Reappropriation
        fields = (
            'reappropriation_guid',
            'source_fund_guid',
            'source_fund_name',
            'transfer_amount',
            'balance',
            'reappropriation_date'
        )
        read_only_fields = ('reappropriation_guid',
            'source_fund_guid',
            'source_fund_name',
            'transfer_amount',
            'balance',
            'reappropriation_date')

class ReappropDetailSerializer(serializers.ModelSerializer):
    grant_name = serializers.SerializerMethodField('get_grant', read_only=True)
    pool_name = serializers.SerializerMethodField('get_pool', read_only=True)

    def get_grant(self,detail):
        if detail.partner_grant_guid:
            year = str(detail.partner_grant_guid.year)
            partner = str(detail.partner_grant_guid.partner_guid.partner_name)
            program = str(detail.partner_grant_guid.program_type_guid.program_code)
            return '-'.join([str(x) for x in [year,partner,program] if x not in [None,' ','']])
        else:
            return ''

    def get_pool(self,detail):
        if detail.competitive_pool_guid:
            year = str(detail.competitive_pool_guid.year)
            program = str(detail.competitive_pool_guid.program_type_guid.program_code)
            return '-'.join([str(x) for x in [year,program] if x not in [None,' ','']])
        else:
            return ''

    class Meta:
        model = ReappropriationDetail
        fields = (
            'reapprop_detail_guid',
            'reappropriation_guid',
            'partner_grant_guid',
            'grant_name',
            'competitive_pool_guid',
            'pool_name',
            'amount',
            'notes',
            'created_date'
        )
        read_only_fields = ('reapprop_detail_guid','reappropriation_guid','grant_name','pool_name')


    def create(self, validated_data):
        #print "create function VALIDATED DATA:", validated_data
        logger.debug( "create function VALIDATED DATA: %s" % validated_data)
"""
    def update(self, instance, validated_data):

        #print "VALIDATED DATA:", validated_data
        logger.debug( "VALIDATED DATA: %s" % validated_data)
        #print "INSTANCE:", instance
        logger.debug( "INSTANCE: %s" % instance)
        #instance.appropriation_source_guid = validated_data.get('appropriation_source_guid', instance.appropriation_source_guid)
        #instance.appropriation_target_guid = validated_data.get('appropriation_target_guid', instance.appropriation_target_guid)
        #instance.transfer_amount = validated_data.get('transfer_amount', instance.transfer_amount)
        #instance.note = validated_data.get('note', instance.note)
        #instance.status_transfer_desc = validated_data.get('status_transfer_desc', instance.status_transfer_desc)

        instance.save()
        return instance
    """


class NewReappropriationSerializer(serializers.ModelSerializer):
    source_appropriation = serializers.SerializerMethodField('get_source')
    target_appropriation = serializers.SerializerMethodField('get_target')
    detail = ReappropDetailSerializer(many=True,read_only=False)

    def get_target(self,reapprop):
        if reapprop.appropriation_target_guid:
            year = str(reapprop.appropriation_target_guid.year)
            unit = str(reapprop.appropriation_target_guid.appropriation_unit)
            program = str(reapprop.appropriation_target_guid.program_type_guid.program_code)
            grant = str(reapprop.appropriation_target_guid.grant_type_desc.grant_type_desc)
            return '-'.join([str(x) for x in [year,unit,program,grant] if x not in [None,' ','']])
        else:
            return ""

    def get_source(self,reapprop):
        if reapprop.appropriation_source_guid:
            year = str(reapprop.appropriation_source_guid.year)
            unit = str(reapprop.appropriation_source_guid.appropriation_unit)
            program = str(reapprop.appropriation_source_guid.program_type_guid.program_code)
            grant = str(reapprop.appropriation_source_guid.grant_type_desc.grant_type_desc)
            return '-'.join([str(x) for x in [year,unit,program,grant] if x not in [None,' ','']])
        else:
            return ""

    class Meta:
        model = Reappropriation
        fields = (
            'reappropriation_guid',
            'appropriation_source_guid',
            'source_appropriation',
            'appropriation_target_guid',
            'target_appropriation',
            'status_transfer_desc',
            'transfer_amount',
            'balance',
            'note',
            'created_date',
            'reappropriation_date',
            'detail'
        )
        read_only_fields = ('reappropriation_guid','source_appropriation','target_appropriation','balance','created_date')

    def create(self, validated_data):
        #print "create function VALIDATED DATA:", validated_data
        logger.debug( "create function VALIDATED DATA: %s" % validated_data)
        popped_detail_data = validated_data.pop('detail')
        logger.debug( "POPPED DETAIL DATA: %s" % popped_detail_data)
        #print 'POPPED DETAIL DATA: ', popped_detail_data
        try:
            newreapp = Reappropriation.objects.create(**validated_data)

            for item in popped_detail_data:
                ReappropriationDetail.objects.create(reappropriation_guid=newreapp,**item)
                #newdet.save()
            #print "AFTER LOOP"
            logger.debug( "AFTER LOOP")
            newreapp.save()
            #print "AFTER SAVE"
            logger.debug( "AFTER SAVE")
            return newreapp
        except ValidationError: # it's a django Validataion Error
            #print("ERROR CREATING USER IN SERIALIZER")
            logger.debug("ERROR CREATING USER IN SERIALIZER")
            raise serializers.ValidationError("Error Creating New Reappropriation")

    """
    def update(self, instance, validated_data):

        print "VALIDATED DATA:", validated_data
        print "INSTANCE:", instance

        instance.appropriation_source_guid = validated_data.get('appropriation_source_guid', instance.appropriation_source_guid)
        instance.appropriation_target_guid = validated_data.get('appropriation_target_guid', instance.appropriation_target_guid)
        instance.transfer_amount = validated_data.get('transfer_amount', instance.transfer_amount)
        instance.note = validated_data.get('note', instance.note)
        instance.status_transfer_desc = validated_data.get('status_transfer_desc', instance.status_transfer_desc)

        instance.save()
        return instance
    """





class ReappropriationSerializer(serializers.ModelSerializer):
    source_appropriation = serializers.SerializerMethodField('get_source')
    target_appropriation = serializers.SerializerMethodField('get_target')#serializers.CharField(source='appropriation_target_guid.appropriation_name', read_only=True)
    detail = ReappropDetailSerializer(many=True,read_only=True)

    def get_target(self,reapprop):
        if reapprop.appropriation_target_guid:
            year = str(reapprop.appropriation_target_guid.year)
            unit = str(reapprop.appropriation_target_guid.appropriation_unit)
            program = str(reapprop.appropriation_target_guid.program_type_guid.program_code)
            grant = str(reapprop.appropriation_target_guid.grant_type_desc.grant_type_desc)
            return '-'.join([str(x) for x in [year,unit,program,grant] if x not in [None,' ','']])
        else:
            return ""

    def get_source(self,reapprop):
        if reapprop.appropriation_source_guid:
            year = str(reapprop.appropriation_source_guid.year)
            unit = str(reapprop.appropriation_source_guid.appropriation_unit)
            program = str(reapprop.appropriation_source_guid.program_type_guid.program_code)
            grant = str(reapprop.appropriation_source_guid.grant_type_desc.grant_type_desc)
            return '-'.join([str(x) for x in [year,unit,program,grant] if x not in [None,' ','']])
        else:
            return ""

    class Meta:
        model = Reappropriation
        fields = (
            'reappropriation_guid',
            'appropriation_source_guid',
            'source_appropriation',
            'appropriation_target_guid',
            'target_appropriation',
            'status_transfer_desc',
            'transfer_amount',
            'balance',
            'note',
            'created_date',
            'reappropriation_date',
            'detail'
        )
        read_only_fields = ('reappropriation_guid',
                            'appropriation_source_guid',
                            'source_appropriation',
                            'appropriation_target_guid',
                            'target_appropriation',
                            'transfer_amount',
                            'balance',
                            'detail',
                            'created_date')



    def update(self, instance, validated_data):

        #print "VALIDATED DATA:", validated_data
        logger.debug( "VALIDATED DATA: %s" % validated_data)
        #print "INSTANCE:", instance
        logger.debug( "INSTANCE: %s" % instance)
        instance.note = validated_data.get('note', instance.note)
        instance.status_transfer_desc = validated_data.get('status_transfer_desc', instance.status_transfer_desc)
        instance.reappropriation_date = validated_data.get('reappropriation_date', instance.reappropriation_date)
        instance.save()
        return instance



# #*************************************************************************************
# # Partner Grants
# #*************************************************************************************

class PartnerGrantSerializer(serializers.ModelSerializer):
    #appropriation_id = serializers.CharField(source='appropriation_guid.appropriation_id', read_only=True)
    program_name = serializers.CharField(source='program_type_guid.program_name', read_only=True)
    partner_name = serializers.CharField(source='partner_guid.partner_name', read_only=True)
    grant_name = serializers.SerializerMethodField('get_name')
    grant_payments = PaymentInfoSerializer(many=True, read_only=True)

    def get_name(self,grant):
        year = str(grant.year)
        partner = str(grant.partner_guid.partner_name)
        program = str(grant.program_type_guid.program_code)
        return '-'.join([str(x) for x in [year,partner,program] if x not in [None,' ','']])
    class Meta:
        model = PartnerGrant
        fields = (
            'partner_grant_guid',
            'grant_name',
            'program_type_guid',
            'program_name',
            'partner_guid',
            'partner_name',
            'year',
            'initial_award',
            'base_balance',
            'base_spent',
            'base_encumbered',
            'pending',
            'competitive_balance',
            'competitive_spent',
            'competitive_encumbered',
            'reappropriated_out',
            'created_date',
            'created_user_guid',
            'grant_payments'
        )
        read_only_fields = ('partner_grant_guid','grant_name','program_type_guid','partner_guid','year','initial_award','program_name','partner_name','created_date','created_user_guid','grant_payments')

    def update(self, instance, validated_data):
        """
        Update and return an existing `Grant_Partner` instance, given the validated data.
        """
        #print "VALIDATED DATA:", validated_data
        logger.debug( "VALIDATED DATA: %s" % validated_data)
        #print "INSTANCE:", instance
        logger.debug( "INSTANCE: %s" % instance)
        #instance.program_type_guid = validated_data.get('program_type_guid', instance.program_type_guid)
        #instance.partner_guid = validated_data.get('partner_guid', instance.partner_guid)
        #instance.year = validated_data.get('year', instance.year)
        instance.base_balance = validated_data.get('base_balance', instance.base_balance)
        instance.base_spent = validated_data.get('base_spent', instance.base_spent)
        instance.competitive_balance = validated_data.get('competitive_balance', instance.competitive_balance)
        instance.competitive_spent = validated_data.get('competitive_spent', instance.competitive_spent)
        instance.competitive_encumbered = validated_data.get('competitive_encumbered', instance.competitive_encumbered)
        instance.reappropriated_out = validated_data.get('reappropriated_out', instance.reappropriated_out)

        instance.save()
        return instance


class NewPartnerGrantSerializer(serializers.ModelSerializer):
    grant_name = serializers.SerializerMethodField('get_name')

    def get_name(self,grant):
        year = str(grant.year)
        partner = str(grant.partner_guid.partner_name)
        program = str(grant.program_type_guid.program_code)
        return '-'.join([str(x) for x in [year,partner,program] if x not in [None,' ','']])

    class Meta:
        model = PartnerGrant
        fields = (
            'partner_grant_guid',
            'grant_name',
            'program_type_guid',
            'partner_guid',
            'year',
            'initial_award',
            'competitive_balance'

        )
        read_only_fields = ('partner_grant_guid','grant_name',)

    def create(self, validated_data):
        #print "create function VALIDATED DATA:", validated_data
        logger.debug( "create function VALIDATED DATA: %s" % validated_data)
        try:
            newgrant = PartnerGrant.objects.create(**validated_data)
            newgrant.save()
            return newgrant
        except ValidationError: # it's a django Validataion Error
            #print("Invalid data in Grant record")
            logger.debug("Invalid data in Grant record")




# #*************************************************************************************
# # Competitive Pools
# #*************************************************************************************

class PoolPaymentsSerializer(serializers.ModelSerializer):
    def get_name(self,pool):
        year = str(pool.year)
        program = str(pool.program_type_guid.program_code)
        return '-'.join([str(x) for x in [year,program] if x not in [None,' ','']])

    def get_payments(self, pool):
        apps = Appropriation.objects.filter(program_type_guid=pool.program_type_guid, year=pool.year,grant_type_desc='COMPETITIVE')
        serializer = PoolPaymentsSerializer(instance=apps, many=True)
        return serializer.data

    class Meta:
        model = CompetitivePool
        fields = (
            'competitive_pool_guid',
            'pool_name',
            'year',
            'program_type_guid',
            'program_name',
            'initial_award',
            'balance',
            'pending',
            'spent',
            'encumbered',
            'reappropriated_out',
            'competitive_limit',
            'created_date',
            'created_user_guid'
        )
        read_only_fields = ('competitive_pool_guid','pool_name','program_name','year','program_type_guid','reappropriated_out','initial_award','created_date','created_user_guid')


class CompetitivePoolSerializer(serializers.ModelSerializer):
    program_name = serializers.CharField(source='program_type_guid.program_name', read_only=True)
    pool_name = serializers.SerializerMethodField('get_name')
    pool_payments = serializers.SerializerMethodField('get_payments')

    def get_name(self,pool):
        year = str(pool.year)
        program = str(pool.program_type_guid.program_code)
        return '-'.join([str(x) for x in [year,program] if x not in [None,' ','']])

    def get_payments(self, pool):
        apps = ExpensePayment.objects.filter(appropriation_guid__program_type_guid=pool.program_type_guid, appropriation_guid__year=pool.year,appropriation_guid__grant_type_desc='COMPETITIVE')
        serializer = PaymentInfoSerializer(instance=apps, many=True)
        return serializer.data

    class Meta:
        model = CompetitivePool
        fields = (
            'competitive_pool_guid',
            'pool_name',
            'year',
            'program_type_guid',
            'program_name',
            'initial_award',
            'balance',
            'pending',
            'spent',
            'encumbered',
            'reappropriated_out',
            'competitive_limit',
            'created_date',
            'created_user_guid',
            'pool_payments'
        )
        read_only_fields = ('competitive_pool_guid','pool_name','program_name','year','program_type_guid','reappropriated_out','initial_award','created_date','created_user_guid','pool_payments')

    def update(self, instance, validated_data):
        """
        Update and return an existing `CompetitivePool` instance, given the validated data.
        """
        #print "VALIDATED DATA:", validated_data
        logger.debug( "VALIDATED DATA: %s" % validated_data)
        #print "INSTANCE:", instance
        logger.debug( "INSTANCE: %s" % instance)
        #instance.program_type_guid = validated_data.get('program_type_guid', instance.program_type_guid)
        #instance.year = validated_data.get('year', instance.year)
        #instance.initial_award = validated_data.get('initial_award', instance.initial_award)
        instance.balance = validated_data.get('balance', instance.balance)
        instance.spent = validated_data.get('spent', instance.spent)
        instance.encumbered = validated_data.get('encumbered', instance.encumbered)
        instance.competitive_limit = validated_data.get('competitive_limit', instance.competitive_limit)

        instance.save()
        return instance


class NewCompetitivePoolSerializer(serializers.ModelSerializer):
    pool_name = serializers.SerializerMethodField('get_name')

    def get_name(self,pool):
        year = str(pool.year)
        program = str(pool.program_type_guid.program_code)
        return '-'.join([str(x) for x in [year,program] if x not in [None,' ','']])
    class Meta:
        model = CompetitivePool
        fields = (
            'competitive_pool_guid',
            'pool_name',
            'year',
            'program_type_guid',
            'initial_award',
            'balance',
            'pending',
            'spent',
            'encumbered',
            'reappropriated_out',
            'competitive_limit',
            'created_date',
            'created_user_guid'
        )
        read_only_fields = ('competitive_pool_guid','pool_name','pending','spent','encumbered','reappropriated_out')

    def create(self, validated_data):
        #print "create function VALIDATED DATA:", validated_data
        logger.debug( "create function VALIDATED DATA: %s" % validated_data)
        try:
            newpool = CompetitivePool.objects.create(**validated_data)
            newpool.save()
            return newpool
        except ValidationError: # it's a django Validataion Error
            #print("Invalid data in competitive pool record")
            logger.debug("Invalid data in competitive pool record")



# #*************************************************************************************
# # Type Serializers
# #*************************************************************************************

class ExpenseStatusSerializer(serializers.ModelSerializer):
    class Meta:
        model = ExpenseStatus
        fields = (
            'expense_status_desc',
        )
        read_only_fields = ('expense_status_desc',)

class ExpenseTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = ExpenseType
        fields = (
            'expense_type_desc',
        )
        read_only_fields = ('expense_type_desc',)


class TransactionTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = TransactionType
        fields = (
            'transaction_type_desc',
        )
        read_only_fields = ('transaction_type_desc',)


class GrantTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = GrantType
        fields = (
            'grant_type_desc',
        )
        read_only_fields = ('grant_type_desc',)

class PaymentSourceSerializer(serializers.ModelSerializer):
    class Meta:
        model = PaymentSource
        fields = (
            'payment_source_desc',
        )
        read_only_fields = ('payment_source_desc',)

class PaymentStatusSerializer(serializers.ModelSerializer):
    class Meta:
        model = PaymentStatus
        fields = (
            'payment_status_desc',
        )
        read_only_fields = ('payment_status_desc',)

class StatusTransferSerializer(serializers.ModelSerializer):
    class Meta:
        model = StatusTransfer
        fields = (
            'status_transfer_desc',
        )
        read_only_fields = ('status_transfer_desc',)

class TransactionTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = TransactionType
        fields = (
            'transaction_type_desc',
        )
        read_only_fields = ('transaction_type_desc',)