from AG_SADCeFarms import settings
from database.models import (
                            Appropriation,
                            Fund,
                            FundTransaction,
                            Reappropriation,
                            ReappropriationDetail,
                            Expense,
                            ExpensePayment,
                            Partner,
                            PartnerGrant,
                            CompetitivePool,
                            TransactionType,
                            TransactionStatus)

from .finance_serializers import *

from django.db import transaction
from django.db.models import F
from django.db.models import Q
from django.utils import timezone
import traceback
import logging

logger = logging.getLogger(__name__)


class PaymentHandler:
    def __init__(self, data, edittype):
        self.valid = True
        self.data = data
        self.edittype = edittype
        self.paymentrec = False
        self.approp = False
        self.expense = False
        self.paymentstatus = ''
        self.fund = False
        self.fundtrans = False
        self.grant = False
        self.pool = False
        self.granttype = None
        self.reapprop = False
        self.partner = False
        self.statuschange = False
        self.amountchange = False
        self.partnerflag = False
        self.sadcflag = False

        self.fields = ['expense_guid',
                           'partner_guid',
                           'partner_grant_guid',
                           'competitive_pool_guid',
                           'appropriation_guid',
                           'reappropriation_guid',
                           'payment_status_desc',
                           'payment_source_type',
                           'payment_source_desc',
                           'payment_amount',
                           'payment_comment',
                           'partner_flg']

        if self.edittype == 'add':
            if 'payment_source_type' not in self.data:
                self.error = "Missing payment source"
                self.valid = False
                return
            elif self.data['payment_source_type'] != 'SADC':
                self.fields = ['expense_guid',
                               'payment_source_type',
                               'payment_source_desc',
                               'payment_amount',
                               'payment_comment']
            else:
                self.sadcflag = True

            if any(x not in self.data for x in self.fields):
                missing = [x for x in self.fields if x not in self.data]
                self.error = "Missing required attributes: " + ', '.join(missing)
                self.valid = False
                return

            # Check if expense record exists
            try:
                self.expense = Expense.objects.get(expense_guid=self.data['expense_guid'])
            except Expense.DoesNotExist:
                self.error = 'Invalid or non existent expense'
                self.valid = False
                return
            # Check the following only if this payment applies to SADC
            if self.sadcflag:
                self.approp = self.appropExists(self.data['appropriation_guid'])
                self.reapprop = self.reappropExists(self.data['reappropriation_guid'])
                if not self.approp:
                    self.error = 'Invalid or non existent appropriation'
                    self.valid = False
                    return
                if float(self.approp.balance) < float(self.data['payment_amount']):
                        self.error = 'Appropriation has insufficient balance'
                        self.valid = False
                        return
                if self.reapprop:
                    #If reappropriation record exists, source fund should match reappropriation source
                    self.fund = self.reapprop.appropriation_source_guid.fund_guid
                    #Check if reapprop has enough balance remaining
                    if float(self.reapprop.balance) < float(self.data['payment_amount']):
                        self.error = 'Reappropriated fund has insufficient balance'
                        self.valid = False
                        return
                if not self.reapprop:
                    self.fund = self.approp.fund_guid
                if not self.fund:
                    self.error = 'Cannot find source fund'
                    self.valid = False
                    return
                # Status should be PENDING or ENCUMBERED
                self.paymentstatus = self.data['payment_status_desc']
                if self.paymentstatus not in ['ENCUMBERED','PENDING']:
                    self.error = '--'
                    self.valid = False
                    return
                # Check if payment is flagged for a partner grant
                try:
                    self.partnerflag = bool(self.data['partner_flg'])
                except Exception as e:
                    self.error = '--'
                    self.valid = False
                    return
                # Check if partner is valid
                self.partner = self.partnerExists(id=self.data['partner_guid'])
                if self.partnerflag and not self.partner:
                    self.error = 'Missing partner'
                    self.valid = False
                    return
                self.grant = self.grantExists(id=self.data['partner_grant_guid'])
                self.pool = self.poolExists(id=self.data['competitive_pool_guid'])
                self.granttype = self.approp.grant_type_desc.grant_type_desc
                if self.granttype == 'BASE' and self.partnerflag and not self.grant:
                    self.error = 'Missing partner grant information'
                    self.valid = False
                    return
                if self.granttype == 'COMPETITIVE' and self.partnerflag and not self.pool:
                    self.error = 'Missing pool information'
                    self.valid = False
                    return
                if self.partnerflag:
                    # Check if partner matches partner grant
                    if self.granttype == 'BASE':
                        if float(self.grant.base_balance) < float(self.data['payment_amount']):
                            self.error = 'Partner Grant has insufficient funds'
                            self.valid = False
                            return
                    if self.granttype == 'COMPETITIVE':
                        if not self.pool:
                            self.error = 'Missing pool information'
                            self.valid = False
                            return
                        if float(self.pool.balance) < float(self.data['payment_amount']):
                            self.error = 'Competitive Pool has insufficient funds'
                            self.valid = False
                            return
                        try:
                            self.grant = PartnerGrant.objects.get(year=self.pool.year,program_type_guid=self.pool.program_type_guid,partner_guid=self.partner)
                        except PartnerGrant.DoesNotExist:
                            self.error = 'Cannot find associated partner grant for this partner'
                            self.valid = False
                            return
                        if float(self.grant.competitive_balance) < float(self.data['payment_amount']):
                            self.error = 'Exceeded partner competitive limit'
                            self.valid = False
                            return
                    # Check if partner matches partner grant
                    if self.partner:
                        if self.partner.partner_guid != self.grant.partner_guid.partner_guid:
                            self.error = 'Partner/Grant mismatch'
                            self.valid = False
                            return
                if float(self.approp.balance) < float(self.data['payment_amount']):
                    self.error = 'Appropriation has insufficient funds'
                    self.valid = False
                    return

        elif self.edittype == 'update':
            self.fields = ['expense_payment_guid',
                           'payment_status_desc',
                           'payment_source_desc',
                           'payment_amount',
                           'payment_comment',
                           'object_code',
                           'activity_code']
            if any(x not in self.data for x in self.fields):
                missing = [x for x in self.fields if x not in self.data]
                self.error = "Missing required attributes: " + ', '.join(missing)
                self.valid = False
                return
            self.paymentrec = self.paymentExists(self.data['expense_payment_guid'])
            if not self.paymentrec:
                self.error = 'Payment record does not exist'
                self.valid = False
                return
            if self.paymentrec:
                self.expense = self.paymentrec.expense_guid
                if not self.expense:
                    self.error = 'Invalid or non existent expense'
                    self.valid = False
                    return
                # Check if payment status has changed
                self.paymentstatus = self.data['payment_status_desc']
                if self.paymentrec.payment_source_type.payment_source_desc == "SADC":
                    self.sadcflag = True
                # Check the following only if SADC is listed as the payment source
                if self.sadcflag:
                    self.partnerflag = self.paymentrec.partner_flg
                    if self.paymentstatus != self.paymentrec.payment_status_desc.payment_status_desc:
                        self.statuschange = True
                    # Check if payment amount has changed
                    if self.data['payment_amount'] != self.paymentrec.payment_amount:
                        self.amountchange = True
                    self.approp = self.paymentrec.appropriation_guid #self.appropExists(self.data['appropriation_guid'])
                    if not self.approp:
                        self.error = 'Invalid or non existent appropriation'
                        self.valid = False
                        return
                    self.reapprop = self.paymentrec.reappropriation_guid
                    try:
                        self.fundtrans = FundTransaction.objects.get(expense_payment_guid=self.paymentrec)
                    except FundTransaction.DoesNotExist:
                        self.error = 'Missing fund transaction record for payment'
                        self.valid = False
                        return
                    if self.reapprop:
                        #If reappropriation record exists, source fund should match reappropriation source
                        self.fund = self.reapprop.appropriation_source_guid.fund_guid
                        if self.amountchange:
                            if float(self.reapprop.balance) < (float(self.data['payment_amount']) - float(self.paymentrec.payment_amount)):
                                self.error = 'Reappropriated fund has insufficient balance'
                                self.valid = False
                                return
                    if not self.reapprop:
                        self.fund = self.approp.fund_guid
                    if not self.fund:
                        self.error = 'Cannot find source fund'
                        self.valid = False
                        return
                    self.granttype = self.approp.grant_type_desc.grant_type_desc
                    if self.amountchange:
                        if float(self.approp.balance) < (float(self.data['payment_amount']) - float(self.paymentrec.payment_amount)):
                            self.error = 'Appropriation has insufficient balance'
                            self.valid = False
                            return
                    if self.partnerflag:
                        # Only if partner grant is being used
                        self.partner = self.paymentrec.partner_guid
                        self.grant = self.paymentrec.partner_grant_guid
                        self.pool = self.paymentrec.competitive_pool_guid
                        # Check if partner is valid
                        if not self.partner:
                            self.error = 'Cannot find associated partner'
                            self.valid = False
                            return
                        if self.granttype == 'BASE' and not self.grant:
                            self.error = 'Cannot find associated partner grant'
                            self.valid = False
                            return
                        if self.granttype == 'COMPETITIVE' and not self.pool:
                            self.error = 'Cannot find associated pool'
                            self.valid = False
                            return
                        if self.granttype == 'BASE':
                            if self.amountchange:
                                if float(self.grant.base_balance) < (float(self.data['payment_amount']) - float(self.paymentrec.payment_amount)):
                                    self.error = 'Partner Grant has insufficient balance'
                                    self.valid = False
                                    return
                        if self.granttype == 'COMPETITIVE':
                            try:
                                self.grant = PartnerGrant.objects.get(year=self.pool.year,program_type_guid=self.pool.program_type_guid,partner_guid=self.partner)
                                if self.amountchange:
                                    if float(self.grant.competitive_balance) < (float(self.data['payment_amount']) - float(self.paymentrec.payment_amount)):
                                        self.error = 'Partner Grant has insufficient balance'
                                        self.valid = False
                                        return
                                    if float(self.pool.balance) < (float(self.data['payment_amount']) - float(self.paymentrec.payment_amount)):
                                        self.error = 'Competitive Pool has insufficient balance'
                                        self.valid = False
                                        return
                            except PartnerGrant.DoesNotExist:
                                self.error = 'Cannot find associated partner grant'
                                self.valid = False
                                return

        elif self.edittype == 'delete':
            self.fields = ['expense_payment_guid']
            if any(x not in self.data for x in self.fields):
                self.error = 'Missing expense payment'
                self.valid = False
                return
            self.paymentrec = self.paymentExists(self.data['expense_payment_guid'])
            if not self.paymentrec:
                self.error = 'Payment record does not exist'
                self.valid = False
                return
            if self.paymentrec:
                if self.paymentrec.payment_source_type.payment_source_desc == "SADC":
                    #print 'SADC!!!'
                    logger.debug("SADC!!!")
                    self.sadcflag = True
                # Check the following only if SADC is listed as the payment source
                if self.sadcflag:
                    self.partnerflag = self.paymentrec.partner_flg
                    self.approp = self.paymentrec.appropriation_guid #self.appropExists(self.data['appropriation_guid'])
                    if not self.approp:
                        self.error = 'Invalid or non existent appropriation'
                        self.valid = False
                        return
                    self.paymentstatus = self.paymentrec.payment_status_desc.payment_status_desc
                    self.reapprop = self.paymentrec.reappropriation_guid
                    try:
                        self.fundtrans = FundTransaction.objects.get(expense_payment_guid=self.paymentrec)
                    except FundTransaction.DoesNotExist:
                        self.error = 'Missing fund transaction record for payment'
                        self.valid = False
                        return
                    if self.reapprop:
                        #If reappropriation record exists, source fund should match reappropriation source
                        self.fund = self.reapprop.appropriation_source_guid.fund_guid
                    if not self.reapprop:
                        self.fund = self.approp.fund_guid
                    if not self.fund:
                        self.error = 'Cannot find source fund'
                        self.valid = False
                        return
                    self.expense = self.paymentrec.expense_guid
                    if not self.expense:
                        self.error = 'Invalid or non existent expense'
                        self.valid = False
                        return
                    self.granttype = self.approp.grant_type_desc.grant_type_desc
                    if self.partnerflag:
                        self.partner = self.paymentrec.partner_guid
                        self.grant = self.paymentrec.partner_grant_guid
                        self.pool = self.paymentrec.competitive_pool_guid
                        if self.granttype == 'BASE' and not self.grant:
                            self.error = 'An error occurred during validation'
                            self.valid = False
                            return
                        if self.granttype == 'COMPETITIVE' and not self.pool:
                            self.error = 'An error occurred during validation'
                            self.valid = False
                            return
                        if self.granttype == 'COMPETITIVE':
                            self.pool = self.getPool(year=self.approp.year,programtype=self.expense.application_key.program_type_guid.program_type_guid)
                            if not self.pool:
                                self.error = 'Cannot find associated competitive pool'
                                self.valid = False
                                return
                            try:
                                self.grant = PartnerGrant.objects.get(year=self.pool.year,program_type_guid=self.pool.program_type_guid,partner_guid=self.partner)
                            except PartnerGrant.DoesNotExist:
                                self.error = 'Cannot find associated partner grant'
                                self.valid = False
                                return

    def paymentExists(self, guid):
        try:
            exprec = ExpensePayment.objects.get(expense_payment_guid=guid)
            return exprec
        except ExpensePayment.DoesNotExist:
            return False

    def appropExists(self, guid):
        try:
            approp = Appropriation.objects.get(appropriation_guid=guid)
            return approp
        except Appropriation.DoesNotExist:
            return False

    def grantExists(self, id):
        try:
            grant = PartnerGrant.objects.get(partner_grant_guid=id)
            return grant
        except PartnerGrant.DoesNotExist:
            return

    def poolExists(self, id):
        try:
            pool = CompetitivePool.objects.get(competitive_pool_guid=id)
            return pool
        except CompetitivePool.DoesNotExist:
            return False

    def partnerExists(self, id):
        try:
            partnerrec = Partner.objects.get(partner_guid=id)
            return partnerrec
        except Partner.DoesNotExist:
            return False

    def reappropExists(self, guid):
        try:
            reapprop = Reappropriation.objects.get(reappropriation_guid=guid)
            return reapprop
        except Reappropriation.DoesNotExist:
            return False

    def getGrant(self,partner,year,programtype):
        try:
            grant = PartnerGrant.objects.get(partner_type_guid=partner,year=year,program_type_guid=programtype)
            return grant
        except PartnerGrant.DoesNotExist:
            return False
        except PartnerGrant.MultipleObjectsReturned:
            return False

    def getPool(self,programtype,year):
        try:
            pool = CompetitivePool.objects.get(year=year,program_type_guid=programtype)
            return pool
        except CompetitivePool.DoesNotExist:
            return False
        except CompetitivePool.MultipleObjectsReturned:
            return False

    def addRecord(self):
        if self.sadcflag:
            serializer = NewSADCPaymentSerializer(data=self.data)
            if serializer.is_valid():
                if self.paymentstatus == 'PENDING':
                    try:
                        with transaction.atomic():
                            #self.expense.expense_status_desc = 'ENCUMBERED'
                            self.fund.balance = F('balance') - float(self.data['payment_amount'])
                            self.fund.encumbered = F('encumbered') + float(self.data['payment_amount'])
                            self.fund.save()
                            #print 'FUND IS GOOD'
                            logger.debug( "FUND IS GOOD")
                            self.approp.balance = F('balance') - float(self.data['payment_amount'])
                            self.approp.pending = F('pending') + float(self.data['payment_amount'])
                            self.approp.save()
                            #print 'APPROP IS GOOD'
                            logger.debug( "APPROP IS GOOD")
                            if self.reapprop:
                                #print 'Trans- FOUND REAPPROP'
                                logger.debug( "Trans- FOUND REAPPROP")
                                self.reapprop.balance = F('balance') - float(self.data['payment_amount'])
                                self.reapprop.save()
                            if self.partnerflag:
                                if self.granttype == 'BASE':
                                    self.grant.base_balance = F('base_balance') - float(self.data['payment_amount'])
                                    self.grant.pending = F('pending') + float(self.data['payment_amount'])
                                    self.grant.save()
                                    #print 'GRANT IS GOOD'
                                    logger.debug( "GRANT IS GOOD")
                                elif self.granttype == 'COMPETITIVE':
                                    self.pool.balance = F('balance') - float(self.data['payment_amount'])
                                    self.pool.pending = F('pending') + float(self.data['payment_amount'])
                                    self.pool.save()
                                    self.grant.competitive_balance = F('competitive_balance') - float(self.data['payment_amount'])
                                    self.grant.competitive_encumbered = F('competitive_encumbered') + float(self.data['payment_amount'])
                                    self.grant.save()

                            payment = serializer.save()
                            #print 'PAYMENT IS GOOD'
                            logger.debug( "PAYMENT IS GOOD")
                            self.fundtrans = FundTransaction(fund_guid = self.fund,
                                         transaction_type_desc='WITHDRAWAL',
                                         transaction_status='PENDING',
                                         transaction_date=timezone.now(),
                                         amount=self.data['payment_amount'],
                                         description='Expense Payment',
                                         notes='',
                                         cancelled_flg=False,
                                         expense_payment_guid=payment)
                            self.fundtrans.save()
                        return serializer.data
                    except Exception as e:
                        print traceback.print_exc()
                        #print 'EXCEPTION2!====',e.message
                        logger.debug("Could not add payment record %s" % e.message)
                        #logger(e.message)
                        self.error = "Could not add payment record"
                        return False

                elif self.paymentstatus == 'ENCUMBERED':
                    try:
                        with transaction.atomic():
                            #self.expense.expense_status_desc = 'ENCUMBERED'
                            self.fund.balance = F('balance') - float(self.data['payment_amount'])
                            self.fund.encumbered = F('encumbered') + float(self.data['payment_amount'])
                            self.fund.save()

                            self.approp.balance = F('balance') - float(self.data['payment_amount'])
                            self.approp.encumbered = F('encumbered') + float(self.data['payment_amount'])
                            self.approp.save()
                            if self.reapprop:
                                #print 'Trans- FOUND REAPPROP'
                                logger.debug("Trans- FOUND REAPPROP")
                                self.reapprop.balance = F('balance') - float(self.data['payment_amount'])
                                self.reapprop.save()
                            if self.partnerflag:
                                if self.granttype == 'BASE':
                                    self.grant.base_balance = F('base_balance') - float(self.data['payment_amount'])
                                    self.grant.base_encumbered = F('base_encumbered') + float(self.data['payment_amount'])
                                    self.grant.save()
                                elif self.granttype == 'COMPETITIVE':
                                    self.pool.balance = F('balance') - float(self.data['payment_amount'])
                                    self.pool.encumbered = F('encumbered') + float(self.data['payment_amount'])
                                    self.pool.save()
                                    self.grant.competitive_balance = F('competitive_balance') - float(self.data['payment_amount'])
                                    self.grant.competitive_encumbered = F('competitive_encumbered') + float(self.data['payment_amount'])
                                    self.grant.save()

                            payment = serializer.save()
                            self.fundtrans = FundTransaction(fund_guid = self.fund,
                                         transaction_type_desc='WITHDRAWAL',
                                         transaction_status='PENDING',
                                         transaction_date=timezone.now(),
                                         amount=self.data['payment_amount'],
                                         description='Expense Payment',
                                         notes='',
                                         cancelled_flg=False,
                                         expense_payment_guid=payment)
                            self.fundtrans.save()
                        return serializer.data
                    except Exception as e:
                        #print e.message
                        logger.debug("Could not add payment record %s" % e.message)
                        #logger(e.message)
                        self.error = "Could not add payment record"
                        return False
            else:
                error = "Payment data not valid"
                return False

        else:  # if the payment is NOT from SADC, then we don't have to validate FUND/APPROP/GRANT/POOL balances
            try:
                serializer = NewPaymentSerializer(data=self.data)
                if serializer.is_valid():
                    payment = serializer.save()
                    return serializer.data
                else:
                    self.error = serializer.errors()
                    return False
            except Exception as e:
                        #print e.message
                        logger.debug("Could not add payment record %s" % e.message)
                        #logger(e.message)
                        self.error = "Could not add payment record"
                        return False

    def updateRecord(self):
        oldAmount = float(self.paymentrec.payment_amount)
        newAmount = float(self.data['payment_amount'])
        origStatus = self.paymentrec.payment_status_desc.payment_status_desc
        newStatus = self.data['payment_status_desc']
        if origStatus == 'PAID' and self.data['payment_status_desc'] != 'PAID':
            self.data['paid_date'] = None
        elif origStatus != 'PAID' and self.data['payment_status_desc'] == 'PAID':
            self.data['paid_date'] = timezone.now()

        serializer = PaymentInfoSerializer(self.paymentrec,data=self.data)

        if serializer.is_valid():
            if self.sadcflag:
                try:
                    with transaction.atomic():
                        if origStatus == 'PENDING' and newStatus == 'PENDING':
                            self.fund.balance = F('balance') - (float(newAmount) - float(oldAmount))
                            self.fund.encumbered = F('encumbered') + (float(newAmount) - float(oldAmount))
                            self.fund.save()
                            self.approp.balance = F('balance') - (float(newAmount) - float(oldAmount))
                            self.approp.pending = F('pending') + (float(newAmount) - float(oldAmount))
                            self.approp.save()
                            self.fundtrans.amount = float(newAmount)
                            self.fundtrans.save()

                            if self.reapprop:
                                self.reapprop.balance = F('balance') - (float(newAmount) - float(oldAmount))
                                self.reapprop.save()
                            if self.partnerflag:
                                if self.granttype == 'BASE':
                                    self.grant.base_balance = F('base_balance') - (float(newAmount) - float(oldAmount))
                                    self.grant.pending = F('pending') + (float(newAmount) - float(oldAmount))
                                    self.grant.save()
                                elif self.granttype == 'COMPETITIVE':
                                    self.pool.balance = F('balance') - (float(newAmount) - float(oldAmount))
                                    self.pool.pending = F('pending') + (float(newAmount) - float(oldAmount))
                                    self.pool.save()
                                    self.grant.competitive_balance = F('competitive_balance') - (float(newAmount) - float(oldAmount))
                                    self.grant.competitive_encumbered = F('competitive_encumbered') + (float(newAmount) - float(oldAmount))
                                    self.grant.save()

                        elif origStatus == 'PENDING' and newStatus == 'ENCUMBERED':
                            self.fund.balance = F('balance') - (float(newAmount) - float(oldAmount))
                            self.fund.encumbered = F('encumbered') + (float(newAmount) - float(oldAmount))
                            self.fund.save()
                            self.approp.balance = F('balance') - (float(newAmount) - float(oldAmount))
                            self.approp.pending = F('pending') - float(oldAmount)
                            self.approp.encumbered = F('encumbered') + float(newAmount)
                            self.approp.save()
                            self.fundtrans.amount = float(newAmount)
                            self.fundtrans.save()
                            if self.reapprop:
                                self.reapprop.balance = F('balance') - (float(newAmount) - float(oldAmount))
                                self.reapprop.save()
                            if self.partnerflag:
                                if self.granttype == 'BASE':
                                    self.grant.base_balance = F('base_balance') - (float(newAmount) - float(oldAmount))
                                    self.grant.pending = F('pending') - float(oldAmount)
                                    self.grant.base_encumbered = F('base_encumbered') + float(newAmount)
                                    self.grant.save()
                                elif self.granttype == 'COMPETITIVE':
                                    self.pool.balance = F('balance') - (float(newAmount) - float(oldAmount))
                                    self.pool.pending = F('pending') - float(oldAmount)
                                    self.pool.encumbered = F('encumbered') + float(newAmount)
                                    self.pool.save()
                                    self.grant.competitive_balance = F('competitive_balance') - (float(newAmount) - float(oldAmount))
                                    self.grant.competitive_encumbered = F('competitive_encumbered') + (float(newAmount) - float(oldAmount))
                                    self.grant.save()

                        elif origStatus == 'PENDING' and newStatus == 'PAID':
                            self.fund.balance = F('balance') - (float(newAmount) - float(oldAmount))
                            self.fund.encumbered = F('encumbered') - float(oldAmount)
                            self.fund.spent = F('spent') + float(newAmount)
                            self.fund.save()
                            self.approp.balance = F('balance') - (float(newAmount) - float(oldAmount))
                            self.approp.pending = F('pending') - float(oldAmount)
                            self.approp.spent = F('spent') + float(newAmount)
                            self.approp.save()
                            self.fundtrans.amount = float(newAmount)
                            self.fundtrans.transaction_status = 'FINAL'
                            self.fundtrans.save()

                            if self.reapprop:
                                self.reapprop.balance = F('balance') - (float(newAmount) - float(oldAmount))
                                self.reapprop.save()
                            if self.partnerflag:
                                if self.granttype == 'BASE':
                                    self.grant.base_balance = F('base_balance') - (float(newAmount) - float(oldAmount))
                                    self.grant.pending = F('pending') - float(oldAmount)
                                    self.grant.base_spent = F('base_spent') + float(newAmount)
                                    self.grant.save()
                                elif self.granttype == 'COMPETITIVE':
                                    self.pool.balance = F('balance') - (float(newAmount) - float(oldAmount))
                                    self.pool.pending = F('pending') - float(oldAmount)
                                    self.pool.spent = F('spent') + float(newAmount)
                                    self.pool.save()
                                    self.grant.competitive_balance = F('competitive_balance') - (float(newAmount) - float(oldAmount))
                                    self.grant.competitive_encumbered = F('competitive_encumbered')  - float(oldAmount)
                                    self.grant.competitive_spent = F('competitive_spent')  + float(newAmount)
                                    self.grant.save()

                        elif origStatus == 'ENCUMBERED' and newStatus == 'ENCUMBERED':
                            self.fund.balance = F('balance') - (float(newAmount) - float(oldAmount))
                            self.fund.encumbered = F('encumbered') + (float(newAmount) - float(oldAmount))
                            self.fund.save()
                            self.approp.balance = F('balance') - (float(newAmount) - float(oldAmount))
                            self.approp.encumbered = F('encumbered') + (float(newAmount) - float(oldAmount))
                            self.approp.save()
                            self.fundtrans.amount = float(newAmount)
                            self.fundtrans.save()

                            if self.reapprop:
                                self.reapprop.balance = F('balance') - (float(newAmount) - float(oldAmount))
                                self.reapprop.save()
                            if self.partnerflag:
                                if self.granttype == 'BASE':
                                    self.grant.base_balance = F('base_balance') - (float(newAmount) - float(oldAmount))
                                    self.grant.base_encumbered = F('base_encumbered') + (float(newAmount) - float(oldAmount))
                                    self.grant.save()
                                elif self.granttype == 'COMPETITIVE':
                                    self.pool.balance = F('balance') - (float(newAmount) - float(oldAmount))
                                    self.pool.encumbered = F('encumbered') + (float(newAmount) - float(oldAmount))
                                    self.pool.save()
                                    self.grant.competitive_balance = F('competitive_balance') - (float(newAmount) - float(oldAmount))
                                    self.grant.competitive_encumbered = F('competitive_encumbered') + (float(newAmount) - float(oldAmount))
                                    self.grant.save()

                        elif origStatus == 'ENCUMBERED' and newStatus == 'PENDING':
                            self.fund.balance = F('balance') - (float(newAmount) - float(oldAmount))
                            self.fund.encumbered = F('encumbered') + (float(newAmount) - float(oldAmount))
                            self.fund.save()
                            self.approp.balance = F('balance') - (float(newAmount) - float(oldAmount))
                            self.approp.pending = F('pending') + float(newAmount)
                            self.approp.encumbered = F('encumbered') - float(oldAmount)
                            self.approp.save()
                            self.fundtrans.amount = float(newAmount)
                            self.fundtrans.save()

                            if self.reapprop:
                                self.reapprop.balance = F('balance') - (float(newAmount) - float(oldAmount))
                                self.reapprop.save()
                            if self.partnerflag:
                                if self.granttype == 'BASE':
                                    self.grant.base_balance = F('base_balance') - (float(newAmount) - float(oldAmount))
                                    self.grant.pending = F('pending') + float(newAmount)
                                    self.grant.base_encumbered = F('base_encumbered') - float(oldAmount)
                                    self.grant.save()
                                elif self.granttype == 'COMPETITIVE':
                                    self.pool.balance = F('balance') - (float(newAmount) - float(oldAmount))
                                    self.pool.pending = F('pending') + float(newAmount)
                                    self.pool.encumbered = F('encumbered') - float(oldAmount)
                                    self.pool.save()
                                    self.grant.competitive_balance = F('competitive_balance') - (float(newAmount) - float(oldAmount))
                                    self.grant.competitive_encumbered = F('competitive_encumbered') + (float(newAmount) - float(oldAmount))
                                    self.grant.save()

                        elif origStatus == 'ENCUMBERED' and newStatus == 'PAID':
                            self.fund.balance = F('balance') - (float(newAmount) - float(oldAmount))
                            self.fund.encumbered = F('encumbered') - float(oldAmount)
                            self.fund.spent = F('spent') + float(newAmount)
                            self.fund.save()
                            self.approp.balance = F('balance') - (float(newAmount) - float(oldAmount))
                            self.approp.encumbered = F('encumbered') - float(oldAmount)
                            self.approp.spent = F('spent') + float(newAmount)
                            self.approp.save()
                            self.fundtrans.amount = float(newAmount)
                            self.fundtrans.transaction_status = 'FINAL'
                            self.fundtrans.save()

                            if self.reapprop:
                                self.reapprop.balance = F('balance') - (float(newAmount) - float(oldAmount))
                                self.reapprop.save()
                            if self.partnerflag:
                                if self.granttype == 'BASE':
                                    self.grant.base_balance = F('base_balance') - (float(newAmount) - float(oldAmount))
                                    self.grant.base_encumbered = F('base_encumbered') - float(oldAmount)
                                    self.grant.base_spent = F('base_spent') + float(newAmount)
                                    self.grant.save()
                                elif self.granttype == 'COMPETITIVE':
                                    self.pool.balance = F('balance') - (float(newAmount) - float(oldAmount))
                                    self.pool.encumbered = F('encumbered') - float(oldAmount)
                                    self.pool.spent = F('spent') + float(newAmount)
                                    self.pool.save()
                                    self.grant.competitive_balance = F('competitive_balance') - (float(newAmount) - float(oldAmount))
                                    self.grant.competitive_encumbered = F('competitive_encumbered')  - float(oldAmount)
                                    self.grant.competitive_spent = F('competitive_spent')  + float(newAmount)
                                    self.grant.save()


                        elif origStatus == 'PAID' and newStatus == 'ENCUMBERED':
                            self.fund.balance = F('balance') - (float(newAmount) - float(oldAmount))
                            self.fund.encumbered = F('encumbered') + float(newAmount)
                            self.fund.spent = F('spent') - float(oldAmount)
                            self.fund.save()
                            self.approp.balance = F('balance') - (float(newAmount) - float(oldAmount))
                            self.approp.encumbered = F('encumbered') + float(newAmount)
                            self.approp.spent = F('spent') - float(oldAmount)
                            self.approp.save()
                            self.fundtrans.amount = float(newAmount)
                            self.fundtrans.transaction_status = 'PENDING'
                            self.fundtrans.save()

                            if self.reapprop:
                                self.reapprop.balance = F('balance') - (float(newAmount) - float(oldAmount))
                                self.reapprop.save()
                            if self.partnerflag:
                                if self.granttype == 'BASE':
                                    self.grant.base_balance = F('base_balance') - (float(newAmount) - float(oldAmount))
                                    self.grant.base_encumbered = F('base_encumbered') + float(newAmount)
                                    self.grant.base_spent = F('base_spent') - float(oldAmount)
                                    self.grant.save()
                                elif self.granttype == 'COMPETITIVE':
                                    self.pool.balance = F('balance') - (float(newAmount) - float(oldAmount))
                                    self.pool.encumbered = F('encumbered') + float(newAmount)
                                    self.pool.spent = F('spent') - float(oldAmount)
                                    self.pool.save()
                                    self.grant.competitive_balance = F('competitive_balance') - (float(newAmount) - float(oldAmount))
                                    self.grant.competitive_encumbered = F('competitive_encumbered')  + float(newAmount)
                                    self.grant.competitive_spent = F('competitive_spent')  - float(oldAmount)
                                    self.grant.save()


                        elif origStatus == 'PAID' and newStatus == 'PENDING':
                            self.fund.balance = F('balance') - (float(newAmount) - float(oldAmount))
                            self.fund.encumbered = F('encumbered') + float(newAmount)
                            self.fund.spent = F('spent') - float(oldAmount)
                            self.fund.save()
                            self.approp.balance = F('balance') - (float(newAmount) - float(oldAmount))
                            self.approp.pending = F('pending') + float(newAmount)
                            self.approp.spent = F('spent') - float(oldAmount)
                            self.approp.save()
                            self.fundtrans.amount = float(newAmount)
                            self.fundtrans.transaction_status = 'PENDING'
                            self.fundtrans.save()

                            if self.reapprop:
                                self.reapprop.balance = F('balance') - (float(newAmount) - float(oldAmount))
                                self.reapprop.save()
                            if self.partnerflag:
                                if self.granttype == 'BASE':
                                    self.grant.base_balance = F('base_balance') - (float(newAmount) - float(oldAmount))
                                    self.grant.pending = F('pending') + float(newAmount)
                                    self.grant.base_spent = F('base_spent') - float(oldAmount)
                                    self.grant.save()
                                elif self.granttype == 'COMPETITIVE':
                                    self.pool.balance = F('balance') - (float(newAmount) - float(oldAmount))
                                    self.pool.pending = F('pending') + float(newAmount)
                                    self.pool.spent = F('spent') - float(oldAmount)
                                    self.pool.save()
                                    self.grant.competitive_balance = F('competitive_balance') - (float(newAmount) - float(oldAmount))
                                    self.grant.competitive_encumbered = F('competitive_encumbered')  + float(newAmount)
                                    self.grant.competitive_spent = F('competitive_spent')  - float(oldAmount)
                                    self.grant.save()

                        elif origStatus == 'PAID' and newStatus == 'PAID':
                            self.fund.balance = F('balance') - (float(newAmount) - float(oldAmount))
                            self.fund.spent = F('spent') + (float(newAmount) - float(oldAmount))
                            self.fund.save()
                            self.approp.balance = F('balance') - (float(newAmount) - float(oldAmount))
                            self.approp.spent = F('spent') + (float(newAmount) - float(oldAmount))
                            self.approp.save()
                            self.fundtrans.amount = float(newAmount)
                            self.fundtrans.save()

                            if self.reapprop:
                                self.reapprop.balance = F('balance') - (float(newAmount) - float(oldAmount))
                                self.reapprop.save()
                            if self.partnerflag:
                                if self.granttype == 'BASE':
                                    self.grant.base_balance = F('base_balance') - (float(newAmount) - float(oldAmount))
                                    self.grant.base_spent = F('base_spent') + (float(newAmount) - float(oldAmount))
                                    self.grant.save()
                                elif self.granttype == 'COMPETITIVE':
                                    self.pool.balance = F('balance') - (float(newAmount) - float(oldAmount))
                                    self.pool.spent = F('spent') + (float(newAmount) - float(oldAmount))
                                    self.pool.save()
                                    self.grant.competitive_balance = F('competitive_balance') - (float(newAmount) - float(oldAmount))
                                    self.grant.competitive_spent = F('competitive_spent') + (float(newAmount) - float(oldAmount))
                                    self.grant.save()

                        serializer.save()
                    return serializer.data
                except Exception as e:
                    #print e.message
                    logger.debug("Could not update payment record %s" % e.message)
                    #logger(e.message)
                    self.error = "Could not update payment record"
                    return False

            else: #payment not associated with SADC, no transactional logic needed
                try:
                    serializer.save()
                    return serializer.data
                except Exception as e:
                        #print e.message
                        logger.debug("Could not update payment record %s" % e.message)
                        #logger(e.message)
                        self.error = "Could not update payment record"
                        return False
        else:
            #print '===========',serializer.errors
            logger.debug("Could not update payment record %s" % serializer.errors)
            self.error = "Could not update payment record"
            return False



    def deleteRecord(self):
        origStatus = self.paymentrec.payment_status_desc.payment_status_desc
        paymentAmount = self.paymentrec.payment_amount

        if self.sadcflag:
            if origStatus == 'PENDING':
                try:
                    with transaction.atomic():

                        self.fund.balance = F('balance') + float(paymentAmount)
                        self.fund.encumbered = F('encumbered') - float(paymentAmount)
                        self.fund.save()
                        self.approp.balance = F('balance') + float(paymentAmount)
                        self.approp.pending = F('pending') - float(paymentAmount)
                        self.approp.save()
                        if self.reapprop:
                            self.reapprop.balance = F('balance') + float(paymentAmount)
                            self.reapprop.save()
                        if self.partnerflag:
                            if self.granttype == 'BASE':
                                self.grant.base_balance = F('base_balance') + float(paymentAmount)
                                self.grant.pending = F('pending') - float(paymentAmount)
                                self.grant.save()
                            elif self.granttype == 'COMPETITIVE':
                                self.pool.balance = F('balance') + float(paymentAmount)
                                self.pool.pending = F('pending') - float(paymentAmount)
                                self.pool.save()
                                self.grant.competitive_balance = F('competitive_balance') + float(paymentAmount)
                                self.grant.competitive_encumbered = F('competitive_encumbered') - float(paymentAmount)
                                self.grant.save()
                        self.paymentrec.delete()
                        self.fundtrans.delete()
                    return {"status":"success"}

                except Exception as e:
                    #print 'PENDING^^^^^^^^^^^^^^^^^^^',e.message
                    logger.debug("Could not delete payment record %s" % e.message)
                    #logger(e.message)
                    self.error = "Could not delete payment record"
                    return False
            elif origStatus == 'ENCUMBERED':
                try:
                    with transaction.atomic():

                        self.fund.balance = F('balance') + float(paymentAmount)
                        self.fund.encumbered = F('encumbered') - float(paymentAmount)
                        self.fund.save()
                        self.approp.balance = F('balance') + float(paymentAmount)
                        self.approp.encumbered = F('encumbered') - float(paymentAmount)
                        self.approp.save()
                        if self.reapprop:
                            self.reapprop.balance = F('balance') + float(paymentAmount)
                            self.reapprop.save()
                        if self.partnerflag:
                            if self.granttype == 'BASE':
                                self.grant.base_balance = F('base_balance') + float(paymentAmount)
                                self.grant.base_encumbered = F('base_encumbered') - float(paymentAmount)
                                self.grant.save()
                            elif self.granttype == 'COMPETITIVE':
                                self.pool.balance = F('balance') + float(paymentAmount)
                                self.pool.encumbered = F('encumbered') - float(paymentAmount)
                                self.pool.save()
                                self.grant.competitive_balance = F('competitive_balance') + float(paymentAmount)
                                self.grant.competitive_encumbered = F('competitive_encumbered') - float(paymentAmount)
                                self.grant.save()
                        self.paymentrec.delete()
                        self.fundtrans.delete()
                    return {"status":"success"}

                except Exception as e:
                    #print 'E^^^^^^^^^^^^^^^^^^^',e.message
                    logger.debug("Could not delete payment record %s" % e.message)
                    #logger(e.message)
                    self.error = "Could not delete payment record"
                    return False

            elif origStatus == 'PAID':
                try:
                    with transaction.atomic():

                        self.fund.balance = F('balance') + float(paymentAmount)
                        self.fund.spent = F('spent') - float(paymentAmount)
                        self.fund.save()
                        self.approp.balance = F('balance') + float(paymentAmount)
                        self.approp.spent = F('spent') - float(paymentAmount)
                        self.approp.save()
                        if self.reapprop:
                            self.reapprop.balance = F('balance') + float(paymentAmount)
                            self.reapprop.save()
                        if self.partnerflag:
                            if self.granttype == 'BASE':
                                self.grant.base_balance = F('base_balance') + float(paymentAmount)
                                self.grant.base_spent = F('base_spent') - float(paymentAmount)
                                self.grant.save()
                            elif self.granttype == 'COMPETITIVE':
                                self.pool.balance = F('balance') + float(paymentAmount)
                                self.pool.spent = F('spent') - float(paymentAmount)
                                self.pool.save()
                                self.grant.competitive_balance = F('competitive_balance') + float(paymentAmount)
                                self.grant.competitive_spent = F('competitive_spent') - float(paymentAmount)
                                self.grant.save()
                        self.paymentrec.delete()
                        self.fundtrans.delete()
                    return {"status":"success"}

                except Exception as e:
                    #print 'PAID^^^^^^^^^^^^^^^^^^^',e.message
                    logger.debug("Could not delete payment record %s" % e.message)
                    #logger(e.message)
                    self.error = "Could not delete payment record"
                    return False

        else: #payment not associated with SADC, no transactional logic needed
                try:
                    self.paymentrec.delete()
                    return {"status":"success"}
                except Exception as e:
                        #print e.message
                        logger.debug("Could not delete payment record %s" % e.message)
                        #logger(e.message)
                        self.error = "Could not delete payment record"
                        return False













