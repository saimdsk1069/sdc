from django.conf.urls import url
import views_types
import views_fund
import views_approp
import views_expense
import views_payment
import views_grantpools

'''
URLs/API for Finance Portal
-Funds, Transactions, Partner Grants, Competitive Pools, Appropriations, Reappropriations, Expenses and Payments
'''
urlpatterns = [
    # Types and Lists for Dropdowns (views_types.py)
    url(r'^expensestatus$', views_types.ExpenseStatusTypeItem.as_view(), name="expensestatus"),
    url(r'^expensetype$', views_types.ExpenseTypeItem.as_view(), name="expensetype"),
    url(r'^transactiontype$', views_types.TransactionTypeItem.as_view(), name="transactiontype"),
    url(r'^granttype$', views_types.GrantTypeItem.as_view(), name="granttype"),
    url(r'^paymentsource$', views_types.PaymentSourceTypeItem.as_view(), name="paymentsource"),
    url(r'^paymentstatus$', views_types.PaymentStatusTypeItem.as_view(), name="paymentstatus"),
    url(r'^transferstatus$', views_types.TransferStatusTypeItem.as_view(), name="statustransfer"),
    url(r'^transactiontype$', views_types.TransactionTypeItem.as_view(), name="transactiontype"),

    # Funds and Transactions (views_fund.py)
    url(r'^fund$', views_fund.FundItem.as_view(), name="fund"),
    url(r'^fund/(?P<fund_guid>.*)$', views_fund.FundItem.as_view(), name="fund"),
    url(r'^fund/\?(fund_guid=.*)$', views_fund.FundItem.as_view(), name="fund"),
    url(r'^fundtrans$', views_fund.FundTransItem.as_view(), name="fundtrans"),
    url(r'^fundtrans/(?P<fund_transaction_guid>.*)$', views_fund.FundTransItem.as_view(), name="fundtrans"),

    # Appropriations and Reappropriations (views_approp.py)
    url(r'^appropriation$', views_approp.AppropriationItem.as_view(), name="appropriation"),
    url(r'^appropriation/(?P<appropriation_guid>.*)$', views_approp.AppropriationItem.as_view(), name="appropriation"),
    url(r'^appropriation\?(fund_guid=.*)$', views_approp.AppropriationItem.as_view(),name="appropriation"),
    url(r'^appropriation\?(program_type_guid=.*)$', views_approp.AppropriationItem.as_view(),name="appropriation"),
    url(r'^reappropriation$', views_approp.ReappropriationItem.as_view(), name="reappropriation"),
    url(r'^reappropriation/(?P<reappropriation_guid>.*)$', views_approp.ReappropriationItem.as_view(), name="reappropriation"),
    url(r'^reappropriation\?(reappropriation_guid=.*)$', views_approp.ReappropriationItem.as_view(), name="reappropriation"),
    url(r'^reappropriation\?(appropriation_target_guid=.*)$', views_approp.ReappropriationItem.as_view(), name="reappropriation"),

    # Expenses and Cost Share (views_expense.py)
    url(r'^expense$', views_expense.ExpenseItem.as_view(), name="expense"),
    url(r'^expense/(?P<expense_guid>.*)$', views_expense.ExpenseItem.as_view(), name="expense"),
    url(r'^expense/\?(expense_guid=.*)$', views_expense.ExpenseItem.as_view(), name="expense"),
    url(r'^expense/\?(farm_id=.*)$', views_expense.ExpenseItem.as_view(), name="expense"),
    url(r'^expense/\?(application_id=.*)$', views_expense.ExpenseItem.as_view(), name="expense"),
    url(r'^costshare/\?(expense_guid=.*)$', views_expense.ExpenseCostShareItem.as_view(), name="costshare"),

    # Expense Payments (views_payment.py)
    url(r'^payment$', views_payment.PaymentItem.as_view(), name="payment"),
    url(r'^payment/(?P<expense_payment_guid>.*)$', views_payment.PaymentItem.as_view(), name="payment"),
    url(r'^payment\?(appropriation_guid=.*)$', views_payment.PaymentItem.as_view()),
    url(r'^payment\?(expense_guid=.*)$', views_payment.PaymentItem.as_view()),
    url(r'^payment\?(fund_guid=.*)$', views_payment.PaymentItem.as_view()),

    # Grants and Pools (views_grantpools.py)
    url(r'^partnergrant$', views_grantpools.GrantItem.as_view(), name="grant"),
    url(r'^partnergrant/(?P<partner_grant_guid>.*)$', views_grantpools.GrantItem.as_view(), name="grant"),
    url(r'^partnergrant/\?(partner_grant_guid=.*)$', views_grantpools.GrantItem.as_view(), name="grant"),
    url(r'^partnergrant/\?(program_type_guid=.*)$', views_grantpools.GrantItem.as_view(), name="grant"),
    url(r'^partnergrant/\?(partner_guid=.*)$', views_grantpools.GrantItem.as_view(), name="grant"),
    url(r'^competitivepool$', views_grantpools.PoolItem.as_view(), name="pool"),
    url(r'^competitivepool/(?P<competitive_pool_guid>.*)$', views_grantpools.PoolItem.as_view(), name="pool"),
    url(r'^competitivepool\?(competitive_pool_guid=.*)$', views_grantpools.PoolItem.as_view(), name="pool"),
    url(r'^competitivepool\?(program_type_guid=.*)(year=.*)$', views_grantpools.PoolItem.as_view(), name="pool")

]
