from AG_SADCeFarms import settings

from django.db import transaction
from django.db.models import F
from django.db.models import Q
from django.utils import timezone
import traceback

"""
    THIS FILE NO LONGER USED
    -Most of the validations Handler logic is within each of the finance views, with the exception of payment_validations.py
"""













