from AG_SADCeFarms import settings

from django.http import Http404, HttpResponse, JsonResponse
from django.core.exceptions import PermissionDenied, ObjectDoesNotExist
from django.middleware.csrf import get_token
from django.db import IntegrityError
from security import Authenticate

from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

#
import logging
import traceback
import sys
import json

import hashlib
from datetime import datetime
from django.db.models import Q

logger = logging.getLogger(__name__)


"""
    THIS FILE NO LONGER USED

    -See views_approp.py, views_expense.py, views_fund.py, views_grantpools.py, views_payment.py, views_types.py
"""



