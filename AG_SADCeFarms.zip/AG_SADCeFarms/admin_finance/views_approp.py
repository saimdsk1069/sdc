from AG_SADCeFarms import settings
from database.models import (
    Appropriation,
    Fund,
    FundTransaction,
    Reappropriation,
    ReappropriationDetail,
    Expense,
    ExpensePayment,
    Partner,
    PartnerGrant,
    CompetitivePool,
    TransactionType,
    TransactionStatus)

from .finance_serializers import *

from django.http import Http404, HttpResponse, JsonResponse
from django.core.exceptions import PermissionDenied, ObjectDoesNotExist
from django.middleware.csrf import get_token
from django.db import IntegrityError
from security import Authenticate

from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

#
import logging
import traceback
import sys
import json

import hashlib
from datetime import datetime
from django.db import transaction
from django.db.models import F
from django.db.models import Q
from django.utils import timezone

logger = logging.getLogger(__name__)



class AppropriationHandler:
    """Handler for Appropriation records edits"""
    def __init__(self, data, edittype):
        self.valid = True
        self.data = data
        self.edittype = edittype
        self.approprec = False
        self.approps = False
        self.reapprops = False

        if self.edittype == 'delete':
            self.fields = ['appropriation_guid']
            if any(x not in self.data for x in self.fields):
                self.error = 'Missing appropriation'
                self.valid = False
                return
            try:
                self.approprec = Appropriation.objects.get(appropriation_guid=self.data['appropriation_guid'])
            except Appropriation.DoesNotExist:
                self.error = 'Appropriation record does not exist'
                self.valid = False
                return
            try:
                self.reapprops = Reappropriation.objects.filter(Q(appropriation_source_guid=self.data['appropriation_guid']) | Q(appropriation_target_guid=self.data['appropriation_guid']))
                #print 'Reapprops-- ',self.reapprops
                logger.debug("Appropriation record cannot be deleted %s" % self.reapprops)
                if len(self.reapprops) > 0:
                    self.error = 'Appropriation record cannot be deleted'
                    self.valid = False
                    return
            except Reappropriation.DoesNotExist:
                return
            #TODO:  What other limitations do we need on delete?

    def deleteRecord(self):
        try:
            self.approprec.delete()
            return {"status":"success"}
        except Exception as e:
            #print e.message
            logger.debug("Could not delete appropriation record %s" % e.message)
            #logger(e.message)
            self.error = "Could not delete appropriation record"
            return False

#######################################################################################################################################

class ReappropHandler:
    """Handler for Reappropriation records edits logic"""
    def __init__(self, data, edittype):
        self.valid = True
        self.data = data
        self.edittype = edittype
        self.reapproprec = False
        self.sourcefundtrans = False
        self.sourceFund = False
        self.sourceApprop = False
        self.targetFund = False
        self.targetApprop = False
        self.partnerGrant = False
        self.competitivePool = False
        self.fundDiff = False
        self.details = []

        if self.edittype == 'add':
            self.fields = ['appropriation_source_guid','appropriation_target_guid','status_transfer_desc','transfer_amount','detail']
        elif self.edittype == 'update':
            self.fields = []
        elif  self.edittype == 'delete':
            self.fields = ['reappropriation_guid']

        if any(x not in self.data for x in self.fields):
            missing = [x for x in self.fields if x not in self.data]
            self.error = "Missing required attributes: " + ', '.join(missing)
            self.valid = False
            return

        if self.edittype == 'add':
            self.sourceApprop = self.appropExists( self.data['appropriation_source_guid'])
            self.targetApprop = self.appropExists( self.data['appropriation_target_guid'])
            if not self.sourceApprop:
                self.error = 'Source appropriation does not exist'
                self.valid = False
                return
            if not self.targetApprop:
                self.error = 'Target appropriation does not exist'
                self.valid = False
                return
            self.sourceFund = self.sourceApprop.fund_guid
            self.targetFund = self.targetApprop.fund_guid
            if not self.sourceFund:
                self.error = 'Source fund does not exist'
                self.valid = False
                return
            if not self.targetFund:
                self.error = 'Target fund does not exist'
                self.valid = False
                return
            if self.sourceFund.fund_guid != self.targetFund.fund_guid:
                self.fundDiff = True
            if self.data['status_transfer_desc'] != 'PENDING':
                self.error = 'Incorrect transfer status'
                self.valid = False
                return
            if self.sourceApprop.grant_type_desc.grant_type_desc == 'BASE':
                self.grantType = 'BASE'
            else:
                self.grantType = 'COMPETITIVE'
            if not self.minAppropBalance(self.sourceApprop, self.data['transfer_amount']):
                self.error = 'Source appropriation does not have enough funds'
                self.valid = False
                return
            # Check if all reapprop details all add up to total reapprop amount
            # Check if all reapprop details match grant type of source appropriation
            try:
                total = 0.0
                for det in self.data['detail']:
                    if 'amount' in det:
                        total+=float(det['amount'])
                if total != float(self.data['transfer_amount']):
                    self.error = 'Reappropriation details do not cover reappropriation amount'
                    self.valid = False
                    return
                if self.grantType == 'BASE':
                    if any(det.get('partner_grant_guid',None ) is None for det in self.data['detail']):
                        self.error = 'Reappropriation details missing partner grant information'
                        self.valid = False
                        return
                if self.grantType == 'COMPETITIVE':
                    if any(det.get('competitive_pool_guid',None ) is None for det in self.data['detail']):
                        self.error = 'Reappropriation details missing competitive pool information'
                        self.valid = False
                        return
            except:
                self.error = 'Missing reapprop details'
                self.valid = False
                return


        if self.edittype == 'update':
            self.reapproprec = self.reAppropExists(self.data['reappropriation_guid'])
            if self.reapproprec:

                self.sourceApprop= self.reapproprec.appropriation_source_guid
                self.targetApprop = self.reapproprec.appropriation_target_guid
                if not self.sourceApprop:
                    self.error = 'Source appropriation does not exist'
                    self.valid = False
                    return
                if not self.targetApprop:
                    self.error = 'Target appropriation does not exist'
                    self.valid = False
                    return
                self.sourceFund = self.sourceApprop.fund_guid
                self.targetFund = self.targetApprop.fund_guid

                if not self.sourceFund:
                    self.error = 'Source fund does not exist'
                    self.valid = False
                    return
                if not self.targetFund:
                    self.error = 'Target fund does not exist'
                    self.valid = False
                    return
                if self.sourceApprop.grant_type_desc.grant_type_desc == 'BASE':
                    self.grantType = 'BASE'
                else:
                    self.grantType = 'COMPETITIVE'
            else:
                self.error = 'Cant find reappropriation record'
                self.valid = False
                return


        if self.edittype == 'delete':
            self.reapproprec = self.reAppropExists(self.data['reappropriation_guid'])
            if self.reapproprec:
                self.sourceApprop= self.reapproprec.appropriation_source_guid
                self.targetApprop = self.reapproprec.appropriation_target_guid
                if not self.sourceApprop:
                    self.error = 'Source appropriation does not exist'
                    self.valid = False
                    return
                if not self.targetApprop:
                    self.error = 'Target appropriation does not exist'
                    self.valid = False
                    return
                self.sourceFund = self.sourceApprop.fund_guid
                self.targetFund = self.targetApprop.fund_guid
                if not self.sourceFund:
                    self.error = 'Source fund does not exist'
                    self.valid = False
                    return
                if not self.targetFund:
                    self.error = 'Target fund does not exist'
                    self.valid = False
                    return
                if not self.minAppropBalance(self.targetApprop, self.reapproprec.transfer_amount):
                    self.error = 'Cannot undo reappropriation. Target appropriation does not have enough funds'
                    self.valid = False
                    return
                if self.sourceApprop.grant_type_desc.grant_type_desc == 'BASE':
                    self.grantType = 'BASE'
                else:
                    self.grantType = 'COMPETITIVE'
                payments = ExpensePayment.objects.filter(reappropriation_guid=self.data['reappropriation_guid'])
                if len(payments) > 0:
                    self.error = 'Cannot undo reappropriation associated with payments'
                    self.valid = False
                    return
                self.details = ReappropriationDetail.objects.filter(reappropriation_guid=self.reapproprec.reappropriation_guid)
            else:
                self.error = 'Cant find reappropriation record'
                self.valid = False
                return

    def reAppropExists(self, guid):
        try:
            reapprop = Reappropriation.objects.get(reappropriation_guid=guid)
            return reapprop
        except Reappropriation.DoesNotExist:
            return False

    def appropExists(self, guid):
        try:
            approp = Appropriation.objects.get(appropriation_guid=guid)
            return approp
        except Appropriation.DoesNotExist:
            return False

    def fundExists(self, guid):
        try:
            fund = Fund.objects.get(fund_guid=guid)
            return fund
        except Fund.DoesNotExist:
            return False

    def tranExists(self,reapprop,fund):
        try:
            trans = FundTransaction.objects.get(reappropriation_guid=reapprop,fund_guid=fund)
            return trans
        except FundTransaction.DoesNotExist:
            return False

    def partnergrantExists(self, guid):
        try:
            grant = PartnerGrant.objects.get(partner_grant_guid=guid)
            return grant
        except PartnerGrant.DoesNotExist:
            return False

    def competitivepoolExists(self, guid):
        try:
            pool = CompetitivePool.objects.get(year=self.sourceApprop.year,program_type_guid=self.sourceApprop.program_type_guid)
            return pool
        except CompetitivePool.DoesNotExist:
            return False

    def minFundBalance(self, incfund, amount):
        fltbal = incfund.balance
        if (float(incfund.balance) < float(amount)):
            return False
        else:
            return True

    def minAppropBalance(self, approp, amount):
        if (float(approp.balance) < float(amount)):
            return False
        else:
            return True

    def addRecord(self):
        self.data['reappropriation_date'] = timezone.now()
        serializer = NewReappropriationSerializer(data=self.data)
        if serializer.is_valid():
            try:
                with transaction.atomic():
                    self.sourceApprop.balance = F('balance') - float(self.data['transfer_amount'])
                    self.sourceApprop.reappropriated_out = F('reappropriated_out') + float(self.data['transfer_amount'])
                    self.sourceApprop.save()
                    if self.grantType == 'BASE':
                        for rec in self.data['detail']:
                            grant = PartnerGrant.objects.get(partner_grant_guid=rec['partner_grant_guid'])
                            if grant:
                                grant.base_balance = F('base_balance') - float(rec['amount'])
                                grant.reappropriated_out = F('reappropriated_out') + float(rec['amount'])
                                grant.save()
                    elif self.grantType == 'COMPETITIVE':
                        for rec in self.data['detail']:
                            pool = CompetitivePool.objects.get(competitive_pool_guid=rec['competitive_pool_guid'])
                            if pool:
                                pool.balance = F('balance') - float(rec['amount'])
                                pool.reappropriated_out = F('reappropriated_out') + float(rec['amount'])
                                pool.save()
                    serializer.save()
                return serializer.data
            except Exception as e:
                #print e.message
                logger.debug("Could not add reappropriation record %s" % e.message)
                #logger(e.message)
                #self.error = "Could not add reappropriation record"
                self.error = e.message
                return False
        else:
            self.error = "Reappropriation Data not valid"
            return False

    def updateRecord(self):
        serializer = ReappropriationSerializer(self.reapproprec,data=self.data,partial=True)
        if serializer.is_valid():
            try:
                with transaction.atomic():
                    self.targetApprop.balance = F('balance') + float(self.reapproprec.transfer_amount)
                    self.targetApprop.reappropriated_in = F('reappropriated_in') + float(self.reapproprec.transfer_amount)
                    self.targetApprop.save()
                    serializer.save()
                return serializer.data
            except Exception as e:
                #logger(e.message)
                self.error = "Could not update status of reappropriation record"
                return False
        else:
            self.error = "Reappropriation Data not valid"
            return False

    def deleteRecord(self):
        if self.reapproprec.status_transfer_desc.status_transfer_desc == 'PENDING':
            try:
                with transaction.atomic():
                    self.sourceApprop.reappropriated_out = F('reappropriated_out') - float(self.reapproprec.transfer_amount)
                    self.sourceApprop.balance = F('balance') + float(self.reapproprec.transfer_amount)
                    self.sourceApprop.save()
                    if self.grantType == 'BASE':
                        for rec in self.details:
                            grant = rec.partner_grant_guid
                            if grant:
                                grant.base_balance = F('base_balance') + float(rec.amount)
                                grant.reappropriated_out = F('reappropriated_out') - float(rec.amount)
                                grant.save()
                            rec.delete()
                    elif self.grantType == 'COMPETITIVE':
                        for rec in self.details:
                            pool = rec.competitive_pool_guid
                            if pool:
                                pool.balance = F('balance') + float(rec.amount)
                                pool.reappropriated_out = F('reappropriated_out') - float(rec.amount)
                                pool.save()
                            rec.delete()
                    self.reapproprec.delete()
                return {"status":"success"}
            except Exception as e:
                #print e.message
                logger.debug("Could not delete reappropriation record %s" % e.message)
                #logger(e.message)
                self.error = "Could not delete reappropriation record"
                return False
        elif self.reapproprec.status_transfer_desc.status_transfer_desc == 'FINAL':
            try:
                with transaction.atomic():
                    self.sourceApprop.reappropriated_out = F('reappropriated_out') - float(self.reapproprec.transfer_amount)
                    self.sourceApprop.balance = F('balance') + float(self.reapproprec.transfer_amount)
                    self.sourceApprop.save()
                    self.targetApprop.reappropriated_in = F('reappropriated_in') - float(self.reapproprec.transfer_amount)
                    self.targetApprop.balance = F('balance') - float(self.reapproprec.transfer_amount)
                    self.targetApprop.save()
                    if self.grantType == 'BASE':
                        for rec in self.details:
                            grant = rec.partner_grant_guid
                            if grant:
                                grant.base_balance = F('base_balance') + float(rec.amount)
                                grant.reappropriated_out = F('reappropriated_out') - float(rec.amount)
                                grant.save()
                            rec.delete()
                    elif self.grantType == 'COMPETITIVE':
                        for rec in self.details:
                            pool = rec.competitive_pool_guid
                            if pool:
                                pool.balance = F('balance') + float(rec.amount)
                                pool.reappropriated_out = F('reappropriated_out') - float(rec.amount)
                                pool.save()
                            rec.delete()
                    self.reapproprec.delete()
                return {"status":"success"}
            except Exception as e:
                #print e.message
                logger.debug("Could not delete reappropriation record %s" % e.message)
                #logger(e.message)
                self.error = "Could not delete reappropriation record"
                return False

##########################################################################################################################

class AppropriationItem(APIView):
    """
        Get Appropriation for the Finance Manager
    """
    def get(self, request, appropriation_guid=None, format=None):
        sadcflg = Authenticate.get_user_sadc(request)
        if sadcflg:
            fundguid = self.request.query_params.get('fund_guid', None)
            program = self.request.query_params.get('program', None)
            year = self.request.query_params.get('year', None)
            granttype = self.request.query_params.get('granttype',None)
            if program and year and granttype:
                try:
                    approps = Appropriation.objects.filter(program_type_guid=program,year=year,grant_type_desc=granttype)
                    serializer = AppropriationSerializer(approps,many=True)
                except Appropriation.DoesNotExist:
                    raise Http404
            elif fundguid:
                try:
                    approps = Appropriation.objects.filter(fund_guid=fundguid)
                    serializer = AppropriationSerializer(approps,many=True)
                except Appropriation.DoesNotExist:
                    raise Http404
            elif program:
                if year:
                    try:
                        approps = Appropriation.objects.filter(program_type_guid=program,year=year)
                        serializer = AppropriationSerializer(approps,many=True)
                    except Appropriation.DoesNotExist:
                        raise Http404
                else:
                    try:
                        approps = Appropriation.objects.filter(program_type_guid=program)
                        serializer = AppropriationSerializer(approps,many=True)
                    except Appropriation.DoesNotExist:
                        raise Http404
            elif appropriation_guid is not None:
                try:
                    selapprop = Appropriation.objects.get(appropriation_guid=appropriation_guid)
                    serializer = AppropriationSerializer(selapprop)
                except Appropriation.DoesNotExist:
                    raise Http404
            else:
                approps = Appropriation.objects.all().order_by('appropriation_unit')
                serializer = AppropriationSerializer(approps, many=True)
            return JsonResponse(serializer.data, safe=False) #Response(serializer.data)
        else:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

    def put(self, request, appropriation_guid=None,format=None):
        #TODO: Check user permission- DONE
        sadcflg = Authenticate.get_user_sadc(request)

        if sadcflg:
            if appropriation_guid == None:
                error = "No Appropriation ID provided"
                #logger.debug(authAdminErrors[error]['d_msg'])
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            try:
                approp_item = Appropriation.objects.get(appropriation_guid=appropriation_guid)
                serializer = AppropriationSerializer(approp_item, data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return JsonResponse(serializer.data, safe=False)
                return Response({"result":"error","message":serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
            except Appropriation.DoesNotExist:
                error = "Appropriation Does Not Exist, Can't be Updated"
                #logger.debug(authAdminErrors[error]['d_msg'])
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except IntegrityError as e:
                return Response({"result":"error","message":'Not valid JSON'}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

    def post(self, request, format=None):
        #TODO: Check user permission- DONE
        sadcflg = Authenticate.get_user_sadc(request)

        if sadcflg:
            # Make sure Appropriation Unit and Name are not empty
            if any(x not in request.data for x in ['appropriation_unit','year','fund_guid','grant_type_desc','initial_amount']):
                missing = [x for x in ['appropriation_unit','year','fund_guid','grant_type_desc','initial_amount'] if x not in request.data ]
                error = "Missing required attributes: " + ', '.join(missing)
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            else:
                # check to see if Appropriation with that YEAR/UNIT/FUND/PROGRAMTYPE/GRANT_TYPE already exists
                try:
                    approp_item = Appropriation.objects.get(appropriation_unit=request.data['appropriation_unit'],year=request.data['year'],fund_guid=request.data['fund_guid'],program_type_guid=request.data['program_type_guid'],grant_type_desc=request.data['grant_type_desc'])
                    # If exception isn't thrown, that means approp already exists.  So error out.
                    error = "Appropriation by the same UNIT/FUND/PROGRAM/YEAR already exists"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                except Exception as e:
                    # We are good to create a new Appropriation
                    serializer = NewAppropriationSerializer(data=request.data)
                    if serializer.is_valid():
                        serializer.save()
                        return JsonResponse(serializer.data, safe=False)
                    else:
                        #print serializer.errors
                        logger.debug("Appropriation Data not valid %s" % serializer.errors)
                        error = "Appropriation Data not valid"
                        return Response({"result":"error","message":serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

    #TODO: Need to review whether we should have this-->maybe just allow for disabling/enabling
    def delete(self, request, appropriation_guid=None, format=None):
        #TODO: Check user permission- DONE
        try:
            sadcflg = Authenticate.get_user_sadc(request)

            if sadcflg:
                if not appropriation_guid:
                    error = "No appropriation_guid given"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

                else:
                    AppropInst = AppropriationHandler({'appropriation_guid':appropriation_guid},'delete')
                    if not AppropInst.valid:
                        return Response({"result":"error","message":AppropInst.error}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        # Everything is valid, perform the del operation
                        delapp = AppropInst.deleteRecord()
                        if not delapp:
                            return Response({"result":"error","message":AppropInst.error}, status=status.HTTP_400_BAD_REQUEST)
                        else:
                            return Response({"result":"success","message":delapp}, status=status.HTTP_200_OK )
            else:
                return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)
        except Exception as e:
            error = "Could not delete appropriation record"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)


#########################################################################################################################################

class ReappropriationItem(APIView):
    """
        Get Reappropriations for the Finance Manager
    """
    def get(self, request, reappropriation_guid=None,format=None):
        sadcflg = Authenticate.get_user_sadc(request)

        if sadcflg:
            reappropguid = self.request.query_params.get('reappropriation_guid', None)
            approptarget = self.request.query_params.get('appropriation_target_guid', None)
            if reappropguid:
            #TODO: User permissions - DONE
                try:
                    reapprecord = Reappropriation.objects.get(reappropriation_guid=reappropguid)
                    serializer = NewReappropriationSerializer(reapprecord)
                except Reappropriation.DoesNotExist:
                    error = "Reappropriation does not exist"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

            elif reappropriation_guid is not None:
                try:
                    reapprecord = Reappropriation.objects.get(reappropriation_guid=reappropriation_guid)
                    serializer = ReappropriationSerializer(reapprecord)
                except Reappropriation.DoesNotExist:
                    error = "Reappropriation does not exist"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            elif approptarget:
                try:
                    reapprecords = Reappropriation.objects.filter(appropriation_target_guid=approptarget)
                    serializer = PaymentReappropSerializer(reapprecords,many=True)
                except:
                    error = "Reappropriations error"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            else:
                reapprecords = Reappropriation.objects.all().order_by('created_date')
                serializer = ReappropriationSerializer(reapprecords, many=True)
            return JsonResponse(serializer.data, safe=False)
        else:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

    def put(self, request, reappropriation_guid=None,format=None):
        '''
        Reappropriations in FINAL status cannot be changed to PENDING (see Reapprop
        class validations). Reappropriation transfer amounts CANNOT be changed (see Reapprop
        class validations). Changing from PENDING to FINAL and all other updates allowed
        '''
        sadcflg = Authenticate.get_user_sadc(request)

        if sadcflg:
            if reappropriation_guid is None:
                return Response({"result":"error","message":"Cannot find record"}, status=status.HTTP_400_BAD_REQUEST)
            #TODO: Check user permission- DONE
            request.data['reappropriation_guid'] = reappropriation_guid
            Reapprop = ReappropHandler(request.data,'update')
            if not Reapprop.valid:
                return Response({"result":"error","message":Reapprop.error}, status=status.HTTP_400_BAD_REQUEST)
            else:
                # Everything is valid, perform the update operation
                newreapprop = Reapprop.updateRecord()
                if not newreapprop:
                    return Response({"result":"error","message":Reapprop.error}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return JsonResponse(newreapprop, safe=False)
        else:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

    def post(self, request, format=None):
        #TODO: Check user permission- DONE
        sadcflg = Authenticate.get_user_sadc(request)

        if sadcflg:
            Reapprop = ReappropHandler(request.data,'add')

            if not Reapprop.valid:
                return Response({"result":"error","message":Reapprop.error}, status=status.HTTP_400_BAD_REQUEST)
            else:
                # Everything is valid, perform the add operations
                newreapprop = Reapprop.addRecord()
                if not newreapprop:
                    return Response({"result":"error","message":Reapprop.error}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return JsonResponse(newreapprop, safe=False)
                    # TODO: Serialize Reapprop here or in class?
                    #serializer = ReappropriationSerializer(data=request.data)
                    #print "SERIALIZED REAPPROP:", serializer
                    #if serializer.is_valid():
                    #    serializer.save()
                    #    return JsonResponse(serializer.data, safe=False)
        else:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

    def delete(self, request, reappropriation_guid=None,format=None):
        #TODO: Check user permission- DONE
        try:
            sadcflg = Authenticate.get_user_sadc(request)

            if sadcflg:
                if reappropriation_guid is not None:
                    delData =  {'reappropriation_guid': reappropriation_guid}
                else:
                    delData = request.data
                Reapprop = ReappropHandler(delData,'delete')
                if not Reapprop.valid:
                    return Response({"result":"error","message":Reapprop.error}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    # Everything is valid, perform the del operation
                    delreapprop = Reapprop.deleteRecord()
                    if not delreapprop:
                        return Response({"result":"error","message":Reapprop.error}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        return Response(delreapprop, status=status.HTTP_200_OK)
            else:
                return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)
        except Exception as e:
            error = "Could not delete reappropriation record"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)