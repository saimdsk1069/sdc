from AG_SADCeFarms import settings
from database.models import (
    Application,
    Appropriation,
    CompetitivePool,
    Expense,
    ExpensePayment,
    Fund,
    FundTransaction,
    Partner,
    PartnerGrant,
    Reappropriation,
    ReappropriationDetail,
    TransactionType,
    TransactionStatus)

from .finance_serializers import *

from django.http import Http404, HttpResponse, JsonResponse
from django.core.exceptions import PermissionDenied, ObjectDoesNotExist
from django.middleware.csrf import get_token
from django.db import IntegrityError
from security import Authenticate

from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

#
import logging
import traceback
import sys
import json

import hashlib
from datetime import datetime
from django.db import transaction
from django.db.models import F
from django.db.models import Q
from django.utils import timezone

logger = logging.getLogger(__name__)




class ExpenseHandler:
    def __init__(self, data, edittype):
        self.valid = True
        self.data = data
        self.edittype = edittype
        self.expenserec = False    #self.reapproprec = False
        self.costshares = False
        self.payments = False

        if self.edittype == 'delete':
            self.fields = ['expense_guid']

        if any(x not in self.data for x in self.fields):
            missing = [x for x in self.fields if x not in self.data]
            self.error = "Missing required attributes: " + ', '.join(missing)
            self.valid = False
            return

        if self.edittype == 'delete':
            self.expenserec = self.expenseExists(self.data['expense_guid'])
            if self.expenserec:
                try:
                    self.payments = ExpensePayment.objects.get(expense_guid=self.data['expense_guid'])
                    self.error = 'Cannot delete, related payments exist for expense record'
                    self.valid = False
                except ExpensePayment.DoesNotExist:
                    pass
            else:
                self.error = 'Expense record does not exist'
                self.valid = False

    def expenseExists(self, guid):
        try:
            exprec = Expense.objects.get(expense_guid=guid)
            return exprec
        except Expense.DoesNotExist:
            return False

    def deleteRecord(self):
        if self.valid:
            try:
                with transaction.atomic():
                    self.expenserec.delete()
                return {"status":"success"}
            except Exception as e:
                #print e.message
                logger.debug("Could not delete expense record %s" % e.message)
                #logger(e.message)
                self.error = "Could not delete expense record"
                return False
        else:
            self.error = "Could not delete expense record"


################################################################################################################################


class ExpenseItem(APIView):
    """
        Get Expense  for the Finance Manager
    """

    def get(self, request, expense_guid=None, format=None):
        expenseguid = self.request.query_params.get('expense_guid', None)
        farmid = self.request.query_params.get('farm_id', None)
        appid = self.request.query_params.get('application_id', None)
        if expenseguid:
            try:
                exps = Expense.objects.get(expense_guid=expenseguid)
                serializer = ExpenseSerializer(exps)
            except Expense.DoesNotExist:
                raise Http404
        elif farmid:
            try:
                farmkey = int(str(farmid).split('-')[1])
                exps = Expense.objects.filter(farm_key=farmkey)
                serializer = ExpenseSerializer(exps, many=True)
            except Expense.DoesNotExist:
                raise Http404
        elif appid:
            try:
                appkey =  int(str(appid).split('-')[2])
                exps = Expense.objects.filter(application_key=appkey)
                serializer = ExpenseSerializer(exps, many=True)
            except Expense.DoesNotExist:
                raise Http404
        elif expense_guid is not None:
            try:
                exps = Expense.objects.get(expense_guid=expense_guid)
                serializer = ExpenseSerializer(exps)
            except Expense.DoesNotExist:
                raise Http404

        else:
            exps = Expense.objects.all().order_by('expense_guid')
            serializer = ExpenseSerializer(exps, many=True)
        return Response(serializer.data) #Response(serializer.data)

    def put(self, request, expense_guid=None,format=None):
        #TODO: Need to check user permission?-
        if expense_guid == None:
            error = "No Expense ID provided"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        try:
            expense_item = Expense.objects.get(expense_guid=expense_guid)
            serializer = ExpenseSerializer(expense_item, data=request.data,partial=True)

            if serializer.is_valid():
                serializer.save()
                return JsonResponse(serializer.data, safe=False)
            return Response({"result":"error","message":serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        except Expense.DoesNotExist:
            error = "Expense item does not exist"
            #logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        except IntegrityError as e:
            return Response({"result":"error","message":'Not valid JSON'}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        #TODO: Need to check user permission?-
        try:
            if 'farm_id' not in request.data:
                error = "Missing associated farm information"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

            else:
                farmkey = int(str(request.data['farm_id']).split('-')[1])
                request.data['farm_key'] = farmkey
                if not request.data['application_id']:
                    #print request.data['application_id']
                    logger.debug(request.data['application_id'])
                    appkey = None;
                    request.data['application_key'] = ''
                else:
                    appkey = int(str(request.data['application_id']).split('-')[2])
                    apps = Application.objects.filter(application_key=appkey)
                    if apps:
                        request.data['application_key'] = appkey
                        if not int(apps[0].farm_key.farm_key) == farmkey:
                            error = "Application provided is not associated with this farm"
                            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

                # We are good to create a new Expense
                serializer = NewExpenseSerializer(data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return JsonResponse(serializer.data, safe=False)
                else:
                    error = "Expense Data not valid"
                    return Response({"result":"error", "message":serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            #print e.message
            logger.debug("Error with creating new expense %s" % e.message)
            error = "Error with creating new expense"
            return Response({"error": error}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, expense_guid=None, format=None):
        try:
            sadcflg = Authenticate.get_user_sadc(request)

            if sadcflg:
                if not expense_guid:
                    error = "No expense_guid given"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

                else:
                    expensehandler = ExpenseHandler({'expense_guid':expense_guid},'delete')
                    if not expensehandler.valid:
                        return Response({"result":"error","message":ExpenseHandler.error}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        # Everything is valid, perform the del operation
                        delexpense = expensehandler.deleteRecord()
                        if not delexpense:
                            return Response({"result":"error","message":ExpenseHandler.error}, status=status.HTTP_400_BAD_REQUEST)
                        else:
                            return Response({"result":"success","message":delexpense}, status=status.HTTP_200_OK )
            else:
                return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)
        except Expense.DoesNotExist:
            error = "Expense record does not exist"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)


class ExpenseCostShareItem(APIView):
    """
        Get Update Cost_Share information for an Expense record
    """

    def get(self, request, expense_guid=None, format=None):
        expenseguid = self.request.query_params.get('expense_guid', None)
        if not expenseguid and not expense_guid:
            error = "No expense_guid given"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            if expense_guid:
                guid = expense_guid
            elif expenseguid:
                guid = expenseguid
            try:
                exps = Expense.objects.get(expense_guid=guid)
                serializer = ExpenseCostShareSerializer(exps)
            except Expense.DoesNotExist:
                raise Http404
        return Response(serializer.data) #Response(serializer.data)

    def put(self, request, expense_guid=None,format=None):
        #TODO: Need to check user permission.
        expenseguid = self.request.query_params.get('expense_guid', None)
        if not expenseguid and not expense_guid:
            error = "No expense_guid given"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            if expense_guid:
                guid = expense_guid
            elif expenseguid:
                guid = expenseguid
            try:
                expense_item = Expense.objects.get(expense_guid=guid)
                serializer = ExpenseCostShareSerializer(expense_item, data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return JsonResponse(serializer.data, safe=False)

                return Response({"result":"error","message":serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
            except Expense.DoesNotExist:
                raise Http404
            except IntegrityError as e:
                return Response({"result":"error","message":"Not valid JSON"}, status=status.HTTP_400_BAD_REQUEST)