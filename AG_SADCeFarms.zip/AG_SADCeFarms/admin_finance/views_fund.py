from AG_SADCeFarms import settings
from database.models import (
    Appropriation,
    Fund,
    FundTransaction,
    Reappropriation,
    ReappropriationDetail,
    Expense,
    ExpensePayment,
    Partner,
    PartnerGrant,
    CompetitivePool,
    TransactionType,
    TransactionStatus)

from .finance_serializers import *

from django.http import Http404, HttpResponse, JsonResponse
from django.core.exceptions import PermissionDenied, ObjectDoesNotExist
from django.middleware.csrf import get_token
from django.db import IntegrityError
from security import Authenticate

from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

#
import logging
import traceback
import sys
import json

import hashlib
from datetime import datetime
from django.db import transaction
from django.db.models import F
from django.db.models import Q
from django.utils import timezone


logger = logging.getLogger(__name__)




class FundHandler:
    """Handler for Fund records edits"""
    def __init__(self, data, edittype):
        self.valid = True
        self.data = data
        self.edittype = edittype
        self.fundrec = False
        self.approps = False
        self.payments = False

        if self.edittype == 'add':
            self.fields = ['fund_id','fund_name','fund_description','balance']
            if any(x not in self.data for x in self.fields):
                missing = [x for x in self.fields if x not in self.data]
                self.error = "Missing required attributes: " + ', '.join(missing)
                self.valid = False
                return
            try:
                funditem = Fund.objects.get(fund_id=self.data['fund_id'])
                # If exception isn't thrown, that means fund already exists.  So error out.
                self.error = "Fund by the same ID already exists"
                self.valid = False
                return
            except Fund.DoesNotExist:
                pass

        if self.edittype == 'delete':
            self.fields = ['fund_guid']
            if any(x not in self.data for x in self.fields):
                self.error = 'Missing fund'
                self.valid = False
                return
            try:
                self.fundrec = Fund.objects.get(fund_guid=self.data['fund_guid'])
            except Fund.DoesNotExist:
                self.error = 'Fund record does not exist'
                self.valid = False
                return
            try:
                self.approps = Appropriation.objects.filter(fund_guid=self.data['fund_guid'])
                if len(self.approps) > 0:
                    self.error = 'Fund record cannot be deleted'
                    #print self.error
                    logger.debug("Fund record cannot be deleted %s" % self.error)
                    self.valid = False
                    return
            except Appropriation.DoesNotExist:
                return
            #TODO:  What other limitations do we need on delete?

    def addRecord(self):
        serializer = NewFundSerializer(data=self.data)
        if serializer.is_valid():
            try:
                with transaction.atomic():
                    fund = serializer.save()
                    if 'fund_guid' in serializer.data:
                        newtrans = FundTransaction(fund_guid = fund,
                                     transaction_type_desc='DEPOSIT',
                                     transaction_status='FINAL',
                                     transaction_date=timezone.now(),
                                     amount=serializer.data['balance'],
                                     description='Initial Deposit/Balance',
                                     cancelled_flg=False,
                                     notes='')#FundTransaction.objects.create(transdata)
                        newtrans.save()
                return serializer.data
            except Exception as e:
                #logger(e.message)
                self.error = "Could not add new fund record"
                return False
        else:
            self.error = "Fund data not valid"
            return False

    def deleteRecord(self):
        try:
            self.fundrec.delete()
            return {"status":"success"}
        except Exception as e:
            #print e.message
            logger.debug("Could not delete fund record %s" % e.message)
            #logger(e.message)
            self.error = "Could not delete fund record"
            return False

################################################################################################


class FundTransHandler:
    def __init__(self, data, edittype):
        self.valid = True
        self.data = data
        self.edittype = edittype
        self.fund = None
        self.transrec = None
        self.error = ''
        self.transtype = False

        if self.edittype == 'add':
            self.fields = ['transaction_type_desc','fund_guid','amount','notes']
            if any(x not in self.data for x in self.fields):
                missing = [x for x in self.fields if x not in self.data]
                self.error = "Missing required attributes: " + ', '.join(missing)
                self.valid = False
                return
            if self.data['transaction_type_desc'] not in ['DEPOSIT','WITHDRAWAL']:
                self.error = 'Transaction must be DEPOSIT or WITHDRAWAL'
                self.valid = False
                return
            self.fund = self.fundExists(self.data['fund_guid'])
            if not self.fund:
                self.error = 'Fund cannot be found'
                self.valid = False
                return

        if self.edittype == 'update':
            self.fields = ['fund_transaction_guid','notes']
            self.transrec = self.transrecExists(self.data['fund_transaction_guid'])
            if not self.transrec:
                self.error = 'Transaction record does not exist'
                self.valid = False
                return
            self.transtype = self.transrec.transaction_type_desc

        elif  self.edittype == 'delete':
            self.fields = ['fund_transaction_guid']
            if any(x not in self.data for x in self.fields):
                self.error = 'Missing fund transaction'
                self.valid = False
                return
            self.transrec = self.transrecExists(self.data['fund_transaction_guid'])
            if not self.transrec:
                self.error = 'Transaction record does not exist'
                self.valid = False
                return
            if self.transrec.expense_payment_guid:
                self.error = 'Cannot cancel a transaction record tied to a payment'
                self.valid = False
                return
            self.fund = self.transrec.fund_guid

    def exprecExists(self,guid):
        try:
            payment = ExpensePayment.objects.get(expense_payment_guid=guid)
            return payment
        except ExpensePayment.DoesNotExist:
            return False

    def transrecExists(self,trans_guid):
        try:
            trans = FundTransaction.objects.get(fund_transaction_guid=trans_guid)
            return trans
        except FundTransaction.DoesNotExist:
            return False

    def fundExists(self, guid):
        try:
            fund = Fund.objects.get(fund_guid=guid)
            return fund
        except Fund.DoesNotExist:
            return False

    def addRecord(self):
        self.data['expense_payment_guid'] = None
        self.data['cancelled_flg'] = False
        self.data['transaction_date'] = timezone.now()
        self.data['transaction_status'] = 'FINAL'
        if self.data['transaction_type_desc'] == 'DEPOSIT':
            self.data['description'] ='Adjust Balance- Deposit'
        elif self.data['transaction_type_desc'] == 'WITHDRAWAL':
            self.data['description'] ='Adjust Balance-Withdrawal'
        serializer = NewFundTransactionSerializer(data=self.data)
        if serializer.is_valid():
            try:
                with transaction.atomic():
                    if self.data['transaction_type_desc'] == 'DEPOSIT':
                        self.fund.balance = F('balance') + float(self.data['amount'])
                        self.fund.save()
                    elif self.data['transaction_type_desc'] == 'WITHDRAWAL':
                        self.fund.balance = F('balance') - float(self.data['amount'])
                        self.fund.save()
                    serializer.save()
                return serializer.data
            except Exception as e:
                #print e.message
                logger.debug(e.message)
                self.error = e.message
                return False
        else:
            self.error = "Fund transaction not valid"
            return False

    def updateRecord(self):
        serializer = FundTransactionSerializer(self.transrec,data=self.data, partial=True)
        if serializer.is_valid():
            try:
                with transaction.atomic():
                    serializer.save()
                return serializer.data
            except Exception as e:
                #print e.message
                logger.debug("Could not update transaction record %s" % e.message)
                #logger(e.message)
                self.error = "Could not update transaction record"
                return False
        else:
            error = "Could not update transaction record"
            return False

    def deleteRecord(self):
        serializer = CancelFundTransactionSerializer(self.transrec,data={'cancelled_flg':True})
        if serializer.is_valid():
            try:
                with transaction.atomic():
                    if self.transrec.transaction_type_desc == 'DEPOSIT':
                        if self.transrec.transaction_status == 'FINAL':
                            self.fund.balance = F('balance') - float(self.transrec.amount)
                            self.fund.save()
                    elif self.transrec.transaction_type_desc == 'WITHDRAWAL':
                        if self.transrec.transaction_status == 'FINAL':
                            self.fund.balance = F('balance') + float(self.transrec.amount)
                            self.fund.save()
                    serializer.save()
                return {"status":"success"}
            except Exception as e:
                #print e.message
                logger.debug(e.message)
                #logger(e.message)
                self.error = ""
                return False

################################################################################################


class FundItem(APIView):
    """
        Get Funds for the Finance Manager
    """
    def get(self, request, fund_guid=None,format=None):
        fundguid = self.request.query_params.get('fund_guid', None)
        if fundguid:
            try:
                selfund = Fund.objects.get(fund_guid=fundguid)
                serializer = FundSerializer(selfund)
            except Fund.DoesNotExist:
                raise Http404

        elif fund_guid is not None:
            try:
                selfund = Fund.objects.get(fund_guid=fund_guid)
                serializer = FundSerializer(selfund)
            except Fund.DoesNotExist:
                raise Http404
        else:
            funds = Fund.objects.all().order_by('fund_name')

            serializer = FundSerializer(funds, many=True)
        return JsonResponse(serializer.data, safe=False) #Response(serializer.data)


    def put(self, request, fund_guid=None,format=None):
        #TODO: Need to check user permission. Updates can only be made to balance- DONE
        sadcflg = Authenticate.get_user_sadc(request)

        if sadcflg:
            if fund_guid == None:
                error = "No Fund ID provided"
                #logger.debug(authAdminErrors[error]['d_msg'])
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            try:
                fund_item = Fund.objects.get(fund_guid=fund_guid)
                serializer = FundSerializer(fund_item, data=request.data)

                if serializer.is_valid():
                    serializer.save()
                    return JsonResponse(serializer.data, safe=False)
                return Response({"result":"error","message":serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
            except Fund.DoesNotExist:
                error = "Fund Item Does Not Exist, Can't be Updated"
                #logger.debug(authAdminErrors[error]['d_msg'])
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except IntegrityError as e:
                return Response({"result":"error","message":'Not valid JSON'}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

    def post(self, request, format=None):
        try:
            sadcflg = Authenticate.get_user_sadc(request)

            if sadcflg:
                FundInst = FundHandler(request.data,'add')
                if not FundInst.valid:
                    return Response({"result":"error","message":FundInst.error}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    # Everything is valid, perform the add operation
                    addfund = FundInst.addRecord()
                    if not addfund:
                        return Response({"result":"error","message":FundInst.error}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        return JsonResponse(addfund, safe=False)
            else:
                return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)
        except Exception as e:
            error = "Could not add fund record"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, fund_guid=None, format=None):
        #TODO: Check SADC user permission- DONE
        try:
            sadcflg = Authenticate.get_user_sadc(request)

            if sadcflg:
                if not fund_guid:
                    error = "No fund_guid given"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

                else:
                    FundInst = FundHandler({'fund_guid':fund_guid},'delete')
                    if not FundInst.valid:
                        return Response({"result":"error","message":FundInst.error}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        # Everything is valid, perform the del operation
                        delfund = FundInst.deleteRecord()
                        if not delfund:
                            return Response({"result":"error","message":FundInst.error}, status=status.HTTP_400_BAD_REQUEST)
                        else:
                            return Response({"result":"success","message":delfund}, status=status.HTTP_200_OK )
            else:
                return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)
        except Exception as e:
            error = "Could not delete fund record"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)




class FundTransItem(APIView):
    """
        Get Fund Transactions for the Finance Manager
    """
    def get(self, request, fund_transaction_guid=None, format=None):
        sadcflg = Authenticate.get_user_sadc(request)

        if sadcflg:
            if fund_transaction_guid is not None:
                try:
                    fundtrans = FundTransaction.objects.get(fund_transaction_guid=fund_transaction_guid)
                    serializer = FundTransactionSerializer(fundtrans)
                except FundTransaction.DoesNotExist:
                    raise Http404
            else:
                fundtrans = FundTransaction.objects.all().order_by('fund_guid')
                serializer = FundTransactionSerializer(fundtrans, many=True)
            return Response(serializer.data)
        else:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

    def post(self, request, format=None):
        '''
        Create a Fund Transaction
        (only allowed for Transaction_Type_Desc of DEPOSIT or WITHDRAWAL)
        Added Fund Transactions must update fund balances

        '''
        #TODO: Check user permission- DONE
        sadcflg = Authenticate.get_user_sadc(request)

        if sadcflg:
            TransInst = FundTransHandler(request.data,'add')

            if not TransInst.valid:
                return Response({"result":"error","message":TransInst.error}, status=status.HTTP_400_BAD_REQUEST)
            else:
                # Everything is valid, perform the add operations
                newtrans = TransInst.addRecord()
                if not newtrans:
                    return Response({"result":"error","message":TransInst.error}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return JsonResponse(newtrans, safe=False)
        else:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

    def put(self, request, fund_transaction_guid=None, format=None):
        '''
        Update a Fund Transaction's Notes
        '''
        #TODO: Check user permission- DONE
        try:
            sadcflg = Authenticate.get_user_sadc(request)

            if sadcflg:
                if not fund_transaction_guid:
                    error = "No fund_transaction_guid given"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                elif 'notes' not in request.data:
                    error = "Could not update transaction record"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    TransInst = FundTransHandler({'fund_transaction_guid':fund_transaction_guid, 'notes':request.data['notes']},'update')
                    if not TransInst.valid:
                        return Response({"result":"error","message":TransInst.error}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        # Everything is valid, perform the upd operation
                        updtrans = TransInst.updateRecord()
                        if not updtrans:
                            return Response({"result":"error","message":TransInst.error}, status=status.HTTP_400_BAD_REQUEST)
                        else:
                            return Response(updtrans, status=status.HTTP_200_OK )
            else:
                return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

        except Exception as e:
            error = "Could not update transaction record"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, fund_transaction_guid=None, format=None):
        '''
        Delete a Fund Transaction (only allowed for Transaction_Type_Desc of DEPOSIT or WITHDRAWAL)
        Removed Fund Transactions must reverse balance changes
        '''
        #TODO: Check user permission- DONE
        try:
            sadcflg = Authenticate.get_user_sadc(request)

            if sadcflg:
                if not fund_transaction_guid:
                    error = "No fund_transaction_guid given"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

                else:
                    TransInst = FundTransHandler({'fund_transaction_guid':fund_transaction_guid},'delete')
                    if not TransInst.valid:
                        return Response({"result":"error","message":TransInst.error}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        # Everything is valid, perform the del operation
                        deltrans = TransInst.deleteRecord()
                        if not deltrans:
                            return Response({"result":"error","message":TransInst.error}, status=status.HTTP_400_BAD_REQUEST)
                        else:
                            return Response(deltrans, status=status.HTTP_200_OK )
            else:
                return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

        except Exception as e:
            error = "Could not delete transaction record"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)