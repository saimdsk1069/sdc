from AG_SADCeFarms import settings
from database.models import (
    Appropriation,
    Fund,
    FundTransaction,
    Reappropriation,
    ReappropriationDetail,
    Expense,
    ExpensePayment,
    Partner,
    PartnerGrant,
    CompetitivePool,
    TransactionType,
    TransactionStatus)

from .finance_serializers import *

from django.http import Http404, HttpResponse, JsonResponse
from django.core.exceptions import PermissionDenied, ObjectDoesNotExist
from django.middleware.csrf import get_token
from django.db import IntegrityError
from security import Authenticate

from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

#
import logging
import traceback
import sys
import json

import hashlib
from datetime import datetime
from django.db import transaction
from django.db.models import F
from django.db.models import Q
from django.utils import timezone

logger = logging.getLogger(__name__)




class GrantHandler:
    """Handler for Partner Grant records edits"""
    def __init__(self, data, edittype):
        self.valid = True
        self.data = data
        self.edittype = edittype
        self.grantrec = False
        self.programtype = False
        self.partner = False

        if self.edittype == 'add':
            self.fields = ['partner_guid','program_type_guid','year','initial_award']
            if any(x not in self.data for x in self.fields):
                missing = [x for x in self.fields if x not in self.data]
                self.error = "Missing required attributes: " + ', '.join(missing)
                self.valid = False
                return
            #Check if there is already an existing grant by the same year, program, partner
            try:
                existingGrant = PartnerGrant.objects.get(partner_guid=self.data['partner_guid'],program_type_guid=self.data['program_type_guid'],year=self.data['year'])
                self.error = 'A grant already exists for the same partner-year'
                self.valid = False
                return
            except PartnerGrant.DoesNotExist:
                pass

        if self.edittype == 'update':
            self.fields = ['partner_grant_guid']
            if any(x not in self.data for x in self.fields):
                missing = [x for x in self.fields if x not in self.data]
                self.error = "Missing required attributes: " + ', '.join(missing)
                self.valid = False
                return
            self.grantrec = self.grantExists(self.data['partner_grant_guid'])
            if not self.grantrec:
                self.error = 'Grant record does not exist'
                self.valid = False

        if self.edittype == 'delete':
            self.fields = ['partner_grant_guid']
            if any(x not in self.data for x in self.fields):
                self.error = 'Missing grant partner'
                self.valid = False
                return
            self.grantrec = self.grantExists(self.data['partner_grant_guid'])
            if not self.grantrec:
                self.error = 'Grant record does not exist'
                self.valid = False
                return
            if float(self.grantrec.base_balance) != float(self.grantrec.initial_award):
                self.error = 'Cannot delete a grant record with active transactions'
                self.valid = False
                return

            #TODO:  What other limitations do we need on delete?

    def grantExists(self, guid):
        try:
            grant = PartnerGrant.objects.get(partner_grant_guid=guid)
            return grant
        except PartnerGrant.DoesNotExist:
            return False

    def addRecord(self):
        serializer = NewPartnerGrantSerializer(data=self.data)
        #print "SERIALIZED Grant:", serializer
        logger.debug("SERIALIZED Grant: %s" % serializer)
        if serializer.is_valid():
            try:
                with transaction.atomic():
                    serializer.save()
                return serializer.data
            except Exception as e:
                #print e.message
                logger.debug("Could not add grant record %s" % e.message)
                #logger(e.message)
                self.error = "Could not add grant record"
                return False
        else:
            error = "Grant data not valid"
            return False

    def updateRecord(self):
        serializer = PartnerGrantSerializer(self.grantrec, data=self.data)
        #print "SERIALIZED Grant:", serializer
        logger.debug("SERIALIZED Grant: %s" % serializer)
        if serializer.is_valid():
            try:
                with transaction.atomic():
                    serializer.save()
                return serializer.data
            except Exception as e:
                #print e.message
                logger.debug("Could not update grant record %s" % e.message)
                #logger(e.message)
                self.error = "Could not update grant record"
                return False
        else:
            error = "Grant data not valid"
            return False

    def deleteRecord(self):
        try:
            self.grantrec.delete()
            return {"status-success"}
        except Exception as e:
            #print e.message
            logger.debug("Could not delete grant record %s" % e.message)
            #logger(e.message)
            self.error = "Could not delete grant record"
            return False



class PoolHandler:
    """Handler for Competitive Pool records edits"""
    def __init__(self, data, edittype):
        self.valid = True
        self.data = data
        self.edittype = edittype
        self.poolrec = False
        self.programtype = False

        if self.edittype == 'add':
            self.fields = ['program_type_guid','year','initial_award','competitive_limit']
            if any(x not in self.data for x in self.fields):
                missing = [x for x in self.fields if x not in self.data]
                self.error = "Missing required attributes: " + ', '.join(missing)
                self.valid = False
                return
            #Check if there is already an existing pool by the same year, program
            try:
                existingPool = CompetitivePool.objects.get(program_type_guid=self.data['program_type_guid'],year=self.data['year'])
                self.error = 'A competitive pool already exists for the same program-year'
                self.valid = False
                return
            except CompetitivePool.DoesNotExist:
                pass

        if self.edittype == 'update':
            self.fields = ['competitive_pool_guid']
            if any(x not in self.data for x in self.fields):
                missing = [x for x in self.fields if x not in self.data]
                self.error = "Missing required attributes: " + ', '.join(missing)
                self.valid = False
                return
            self.poolrec = self.poolExists(self.data['competitive_pool_guid'])
            if not self.poolrec:
                self.error = 'Competitive Pool record does not exist'
                self.valid = False

        if self.edittype == 'delete':
            self.fields = ['competitive_pool_guid']
            if any(x not in self.data for x in self.fields):
                self.error = 'Missing competitive pool'
                self.valid = False
                return
            self.poolrec = self.poolExists(self.data['competitive_pool_guid'])
            if not self.poolrec:
                self.error = 'Competitive Pool record does not exist'
                self.valid = False
                return
            if float(self.poolrec.balance) != float(self.poolrec.initial_award):
                self.error = 'Cannot delete a pool record with active payments'
                self.valid = False
                return
            #TODO:  What other limitations do we need on delete?

    def poolExists(self, guid):
        try:
            pool = CompetitivePool.objects.get(competitive_pool_guid=guid)
            return pool
        except CompetitivePool.DoesNotExist:
            return False

    def addRecord(self):
        serializer = NewCompetitivePoolSerializer(data=self.data)
        #print "SERIALIZED Pool:", serializer
        logger.debug("SERIALIZED Pool: %s" % serializer)
        if serializer.is_valid():
            try:
                with transaction.atomic():
                    serializer.save()
                return serializer.data
            except Exception as e:
                #print e.message
                logger.debug("Could not add competitive pool record %s" % e.message)
                #logger(e.message)
                self.error = "Could not add competitive pool record"
                return False
        else:
            error = "Competitive pool data not valid"
            return False

    def updateRecord(self):
        serializer = CompetitivePoolSerializer(self.poolrec, data=self.data)
        #print "SERIALIZED Pool:", serializer
        logger.debug("SERIALIZED Pool: %s" % serializer)
        if serializer.is_valid():
            try:
                with transaction.atomic():
                    serializer.save()
                return serializer.data
            except Exception as e:
                #print e.message
                logger.debug("Could not update competitive pool record %s" % e.message)
                #logger(e.message)
                self.error = "Could not update competitive pool record"
                return False
        else:
            error = "Competitive pool not valid"
            return False

    def deleteRecord(self):
        try:
            self.poolrec.delete()
            return {"status":"success"}
        except Exception as e:
            #print e.message
            logger.debug("Could not delete competitive pool record %s" % e.message)
            #logger(e.message)
            self.error = "Could not delete competitive pool record"
            return False


################################################################################################################################




class GrantItem(APIView):
    """
        Partner Grants for the Finance Manager
    """
    def get(self, request, partner_grant_guid=None, format=None):
        sadcflg = Authenticate.get_user_sadc(request)

        if sadcflg:
            grantguid = self.request.query_params.get('partner_grant_guid', None)
            programguid = self.request.query_params.get('program_type_guid', None)
            partnerguid = self.request.query_params.get('partner_guid', None)
            year = self.request.query_params.get('year', None)
            if grantguid:
                try:
                    grant = PartnerGrant.objects.get(partner_grant_guid=grantguid)
                    serializer = PartnerGrantSerializer(grant)
                except PartnerGrant.DoesNotExist:
                    raise Http404
            elif partnerguid and programguid and year:
                try:
                    grants = PartnerGrant.objects.get(program_type_guid=programguid,year=year,partner_guid=partnerguid)
                    serializer = PartnerGrantSerializer(grants)
                except PartnerGrant.DoesNotExist:
                    raise Http404
            elif programguid and year:
                try:
                    grants = PartnerGrant.objects.filter(program_type_guid=programguid,year=year)
                    serializer = PartnerGrantSerializer(grants, many=True)
                except PartnerGrant.DoesNotExist:
                    raise Http404
            elif programguid and not year:
                try:
                    grants = PartnerGrant.objects.filter(program_type_guid=programguid)
                    serializer = PartnerGrantSerializer(grants, many=True)
                except PartnerGrant.DoesNotExist:
                    raise Http404
            elif year and not programguid:
                try:
                    grants = PartnerGrant.objects.filter(year=year)
                    serializer = PartnerGrantSerializer(grants, many=True)
                except PartnerGrant.DoesNotExist:
                    raise Http404
            elif partnerguid:
                try:
                    grants = PartnerGrant.objects.filter(partner_guid=partnerguid)
                    serializer = PartnerGrantSerializer(grants, many=True)
                except PartnerGrant.DoesNotExist:
                    raise Http404
            elif partner_grant_guid is not None:
                try:
                    grant = PartnerGrant.objects.get(partner_grant_guid=partner_grant_guid)
                    serializer = PartnerGrantSerializer(grant)
                except PartnerGrant.DoesNotExist:
                    raise Http404
            else:
                grants = PartnerGrant.objects.all().order_by('partner_grant_guid')
                serializer = PartnerGrantSerializer(grants, many=True)
            return Response(serializer.data) #Response(serializer.data)
        else:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

    def put(self, request, partner_grant_guid=None,format=None):
        '''PartnerGrant update'''

        #TODO: Check user permission- DONE
        sadcflg = Authenticate.get_user_sadc(request)

        if sadcflg:
            PartnerGrantInst = GrantHandler(request.data,'update')
            if not PartnerGrantInst.valid:
                return Response({"result":"error","message":PartnerGrantInst.error}, status=status.HTTP_400_BAD_REQUEST)
            else:
                # Everything is valid, perform the update operation
                updgrant = PartnerGrantInst.updateRecord()
                if not updgrant:
                    return Response({"result":"error","message":PartnerGrantInst.error}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return JsonResponse(updgrant, safe=False)
        else:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

    def post(self, request, format=None):
        '''
        Grant Partner Add
        '''
        #TODO: Check user permission- DONE
        sadcflg = Authenticate.get_user_sadc(request)

        if sadcflg:
            PartnerGrantInst = GrantHandler(request.data,'add')

            if not PartnerGrantInst.valid:
                return Response({"result":"error","message":PartnerGrantInst.error}, status=status.HTTP_400_BAD_REQUEST)
            else:
                # Everything is valid, perform the add operations
                newgrant = PartnerGrantInst.addRecord()
                if not newgrant:
                    return Response({"result":"error","message":PartnerGrantInst.error}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return JsonResponse(newgrant, safe=False)
        else:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

    def delete(self, request, partner_grant_guid=None, format=None):
        '''
        Delete Partner Grant
        '''
        #TODO: Check user permission- DONE
        try:
            sadcflg = Authenticate.get_user_sadc(request)

            if sadcflg:
                if not partner_grant_guid:
                    error = "No partner_grant_guid given"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

                else:
                    PartnerGrantInst = GrantHandler({'partner_grant_guid':partner_grant_guid},'delete')
                    if not PartnerGrantInst.valid:
                        return Response({"result":"error","message":PartnerGrantInst.error}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        # Everything is valid, perform the del operation
                        delgrant = PartnerGrantInst.deleteRecord()
                        if not delgrant:
                            return Response({"result":"error","message":PartnerGrantInst.error}, status=status.HTTP_400_BAD_REQUEST)
                        else:
                            return Response({"result":"success","message":delgrant}, status=status.HTTP_200_OK )
            else:
                return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)
        except Exception as e:
            error = "Could not delete partner grant record"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)



class PoolItem(APIView):
    """
        Competitive Pools for the Finance Manager
    """
    def get(self, request, competitive_pool_guid=None, format=None):
        sadcflg = Authenticate.get_user_sadc(request)

        if sadcflg:
            poolguid = self.request.query_params.get('competitive_pool_guid', None)
            programguid = self.request.query_params.get('program_type_guid', None)
            year = self.request.query_params.get('year', None)

            if poolguid:
                try:
                    pool = CompetitivePool.objects.get(competitive_pool_guid=poolguid)
                    serializer = CompetitivePoolSerializer(pool)
                except CompetitivePool.DoesNotExist:
                    raise Http404
            elif programguid and year:
                try:
                    pools = CompetitivePool.objects.filter(program_type_guid=programguid,year=year)
                    serializer = CompetitivePoolSerializer(pools, many=True)
                except CompetitivePool.DoesNotExist:
                    raise Http404
            elif programguid and not year:
                try:
                    pools = CompetitivePool.objects.filter(program_type_guid=programguid)
                    serializer = CompetitivePoolSerializer(pools, many=True)
                except CompetitivePool.DoesNotExist:
                    raise Http404
            elif year and not programguid:
                try:
                    pools = CompetitivePool.objects.filter(year=year)
                    serializer = CompetitivePoolSerializer(pools, many=True)
                except CompetitivePool.DoesNotExist:
                    raise Http404
            elif competitive_pool_guid is not None:
                try:
                    pool = CompetitivePool.objects.get(competitive_pool_guid=competitive_pool_guid)
                    serializer = CompetitivePoolSerializer(pool)
                except CompetitivePool.DoesNotExist:
                    raise Http404
            else:
                pools = CompetitivePool.objects.all().order_by('program_type_guid')
                serializer = CompetitivePoolSerializer(pools, many=True)
            return Response(serializer.data) #Response(serializer.data)
        else:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

    def put(self, request, competitive_pool_guid=None,format=None):
        '''Update Competitive Pool'''

        #TODO: Check user permission- DONE
        sadcflg = Authenticate.get_user_sadc(request)

        if sadcflg:
            PoolInstance = PoolHandler(request.data,'update')
            if not PoolInstance.valid:
                return Response({"result":"error","message":PoolInstance.error}, status=status.HTTP_400_BAD_REQUEST)
            else:
                # Everything is valid, perform the update operation
                updpool = PoolInstance.updateRecord()
                if not updpool:
                    return Response({"result":"error","message":PoolInstance.error}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return JsonResponse(updpool, safe=False)
        else:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

    def post(self, request, format=None):
        '''
         Add Competitive Pool
        '''
        #TODO: Check user permission- DONE
        sadcflg = Authenticate.get_user_sadc(request)

        if sadcflg:
            PoolInstance = PoolHandler(request.data,'add')

            if not PoolInstance.valid:
                return Response({"result":"error","message":PoolInstance.error}, status=status.HTTP_400_BAD_REQUEST)
            else:
                # Everything is valid, perform the add operations
                newpool = PoolInstance.addRecord()
                if not newpool:
                    return Response({"result":"error","message":PoolInstance.error}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return JsonResponse(newpool, safe=False)
        else:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

    def delete(self, request, competitive_pool_guid=None, format=None):
        '''
        Delete Competitive Pool
        '''
        #TODO: Check user permission- DONE
        try:
            sadcflg = Authenticate.get_user_sadc(request)

            if sadcflg:
                if not competitive_pool_guid:
                    error = "No competitive_pool_guid given"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

                else:
                    PoolInstance = PoolHandler({'competitive_pool_guid':competitive_pool_guid},'delete')
                    if not PoolInstance.valid:
                        return Response({"result":"error","message":PoolInstance.error}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        # Everything is valid, perform the del operation
                        delpool = PoolInstance.deleteRecord()
                        if not delpool:
                            return Response({"result":"error","message":PoolInstance.error}, status=status.HTTP_400_BAD_REQUEST)
                        else:
                            return Response({"result":"success","message":delpool}, status=status.HTTP_200_OK )
            else:
                return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)
        except Exception as e:
            error = "Could not delete competitive pool record"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)



