from AG_SADCeFarms import settings
from database.models import (
    ExpensePayment,)

from .finance_serializers import *
import payment_validations

from django.http import Http404, HttpResponse, JsonResponse
from django.core.exceptions import PermissionDenied, ObjectDoesNotExist
from django.middleware.csrf import get_token
from django.db import IntegrityError
from security import Authenticate

from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

#
import logging
import traceback
import sys
import json

import hashlib
from datetime import datetime
from django.db.models import Q

logger = logging.getLogger(__name__)






class PaymentItem(APIView):
    """
        Get Expense Payments for the Finance Manager
    """
    def get(self, request, expense_payment_guid=None, format=None):
        #TODO: Check if user is logged in/authenticated- DONE
        sadcflg = Authenticate.get_user_sadc(request)

        if sadcflg:
            appropguid = self.request.query_params.get('appropriation_guid', None)
            expenseguid = self.request.query_params.get('expense_guid', None)
            fundguid = self.request.query_params.get('fund_guid', None)
            if appropguid:
                try:
                    payments = ExpensePayment.objects.all().filter(appropriation_guid=appropguid)
                    serializer = PaymentInfoSerializer(payments, many=True)
                except ExpensePayment.DoesNotExist:
                    error = "Item cannot be found"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            elif expenseguid:
                try:
                    payments = ExpensePayment.objects.filter(expense_guid=expenseguid)
                    serializer = PaymentInfoSerializer(payments, many=True)
                except ExpensePayment.DoesNotExist:
                    error = "Item cannot be found"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                #TODO : Need to add advanced query to find all payments against base appropriation fund and reappropriation fund
                """

                elif fundguid:
                    try:
                        payments = ExpensePayment.objects.filter(expense_guid=expenseguid)
                        serializer = PaymentInfoSerializer(payments, many=True)
                    except ExpensePayment.DoesNotExist:
                        raise Http404
            """
            elif expense_payment_guid is not None:
                try:
                    payment = ExpensePayment.objects.get(expense_payment_guid=expense_payment_guid)
                    serializer = PaymentInfoSerializer(payment)
                except ExpensePayment.DoesNotExist:
                    error = "Item cannot be found"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            else:
                payments = ExpensePayment.objects.all().order_by('appropriation_guid')
                serializer = PaymentInfoSerializer(payments, many=True)
            return JsonResponse(serializer.data, safe=False)
        else:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

    def put(self, request, expense_payment_guid=None,format=None):
        '''
        On Update, use the PaymentHandler class
        Update only allows changes to:
            -payment_status
            -payment_amount
            -payment_comment
            -object_code
            -activity_code
        '''
        #TODO: Check user permission- DONE
        sadcflg = Authenticate.get_user_sadc(request)

        if sadcflg:
            PaymentInst = payment_validations.PaymentHandler(request.data,'update')
            if not PaymentInst.valid:
                return Response({"result":"error","message":PaymentInst.error}, status=status.HTTP_400_BAD_REQUEST)
            else:
                # Everything is valid, perform the update operation
                updpayment = PaymentInst.updateRecord()
                if not updpayment:
                    return Response({"result":"error","message":PaymentInst.error}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return JsonResponse(updpayment, safe=False)
        else:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

    def post(self, request, format=None):
        '''
        New payments must validate-check for required appropriation,reappropriation, grant, & fund amounts available
        and must encumber amounts / balances on these associated records!!

        '''
        #TODO: Check user permission- DONE
        sadcflg = Authenticate.get_user_sadc(request)

        if sadcflg:
            PaymentInst = payment_validations.PaymentHandler(request.data,'add')

            if not PaymentInst.valid:
                return Response({"result":"error","message":PaymentInst.error}, status=status.HTTP_400_BAD_REQUEST)
            else:
                # Everything is valid, perform the add operations
                #print 'payment is valid'
                newpayment = PaymentInst.addRecord()
                if not newpayment:
                    return Response({"result":"error","message":PaymentInst.error}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return JsonResponse(newpayment, safe=False)

        else:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

    def delete(self, request, expense_payment_guid=None, format=None):
        '''
        Payment reversals must free up appropriation, grant, & fund amounts (ie reverse encumbered/spent)
        Can payments be deleted if payment status is final?
        '''
        #TODO: Check user permission- DONE
        try:
            sadcflg = Authenticate.get_user_sadc(request)

            if sadcflg:
                if not expense_payment_guid:
                    error = "No expense_payment_guid given"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

                else:
                    PaymentInst = payment_validations.PaymentHandler({'expense_payment_guid':expense_payment_guid},'delete')
                    if not PaymentInst.valid:
                        return Response({"result":"error","message":PaymentInst.error}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        # Everything is valid, perform the del operation
                        delpayment = PaymentInst.deleteRecord()
                        if not delpayment:
                            return Response({"result":"error","message":PaymentInst.error}, status=status.HTTP_400_BAD_REQUEST)
                        else:
                            return Response({"result":"success","message":delpayment}, status=status.HTTP_200_OK )
            else:
                return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)
        except Exception as e:
            error = "Could not delete payment record"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)




