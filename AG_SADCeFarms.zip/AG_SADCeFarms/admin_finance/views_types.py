from AG_SADCeFarms import settings
from database.models import (
    ExpenseType,
    ExpenseStatus,
    ExpenseType,
    GrantType,
    PaymentSource,
    PaymentStatus,
    StatusTransfer,
    TransactionType)

from .finance_serializers import *
import validations

from django.http import Http404, HttpResponse, JsonResponse
from django.core.exceptions import PermissionDenied, ObjectDoesNotExist
from django.middleware.csrf import get_token
from django.db import IntegrityError
from security import Authenticate

from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

#
import logging
import traceback
import sys
import json

import hashlib
from datetime import datetime
from django.db.models import Q

logger = logging.getLogger(__name__)




class ExpenseStatusTypeItem(APIView):
    """
        Expense Status types for the Finance Manager
        expense_status_desc
    """
    def get(self, request,format=None):
        recs = ExpenseStatus.objects.all()
        serializer = ExpenseStatusSerializer(recs, many=True)
        return Response(serializer.data)

class ExpenseTypeItem(APIView):
    """
        Expense Types for the Finance Manager
        expense_type_desc
    """
    def get(self, request,format=None):
        recs = ExpenseType.objects.all()
        serializer = ExpenseTypeSerializer(recs, many=True)
        return Response(serializer.data)

class TransactionTypeItem(APIView):
    """
        Transaction Types for the Finance Manager
        transaction_type_desc
    """
    def get(self, request,format=None):
        recs = TransactionType.objects.all()
        serializer = TransactionTypeSerializer(recs, many=True)
        return Response(serializer.data)


class GrantTypeItem(APIView):
    """
        Grant Types for the Finance Manager
        grant_type_desc
    """
    def get(self, request,format=None):
        recs = GrantType.objects.all()
        serializer = GrantTypeSerializer(recs, many=True)
        return Response(serializer.data)

class PaymentSourceTypeItem(APIView):
    """
        Payment Source types for the Finance Manager
        payment_source_desc
    """
    def get(self, request,format=None):
        recs = PaymentSource.objects.all()
        serializer = PaymentSourceSerializer(recs, many=True)
        return Response(serializer.data)

class PaymentStatusTypeItem(APIView):
    """
        Payment Status types for the Finance Manager
        payment_status_desc
    """
    def get(self, request,format=None):
        recs = PaymentStatus.objects.all()
        serializer = PaymentStatusSerializer(recs, many=True)
        return Response(serializer.data)

class TransferStatusTypeItem(APIView):
    """
        Status Transfer types for the Finance Manager
        status_transfer_desc
    """
    def get(self, request,format=None):
        recs = StatusTransfer.objects.all()
        serializer = StatusTransferSerializer(recs, many=True)
        return Response(serializer.data)


class TransactionTypeItem(APIView):
    """
        Transaction types for the Finance Manager
        transaction_type_desc
    """
    def get(self, request,format=None):
        recs = TransactionType.objects.all()
        serializer = TransactionTypeSerializer(recs, many=True)
        return Response(serializer.data)
