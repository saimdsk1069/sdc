from django.conf.urls import url
import views

urlpatterns = [
    url(r'^todolist$', views.TodoListItem.as_view(), name="todolist"),
    url(r'^todolist/(?P<todo_list_guid>.*)$', views.TodoListItem.as_view(), name="todolist")
]
