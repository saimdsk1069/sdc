from AG_SADCeFarms import settings
from database.models import Application, TodoList
from .todo_serializers import TodoListSerializer, TodoListUpdateSerializer

from django.http import Http404, HttpResponse, JsonResponse
from django.core.exceptions import PermissionDenied, ObjectDoesNotExist
from django.middleware.csrf import get_token
from django.db import IntegrityError
from django.db.models import Q
from security import Authenticate

from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

#
import logging
import traceback
import sys
import json

import hashlib
from datetime import datetime


logger = logging.getLogger(__name__)



class TodoListItem(APIView):
    """
        Get TodoLists for dashboards
    """
    def get(self, request, todo_list_guid=None, format=None):
        #TODO: Check if user has proper SADC permissions- DONE
        sadcflg = Authenticate.get_user_sadc(request)

        if sadcflg:
            appid = self.request.query_params.get('application_id', None)
            if todo_list_guid is not None:
                #print ' todo by id'
                logger.debug("todo by id")
                try:
                    todolists = TodoList.objects.get(todo_list_guid=todo_list_guid)
                    serializer = TodoListSerializer(todolists)
                except TodoList.DoesNotExist:
                    return Response({"result":"error","message":"Item not found"}, status=status.HTTP_400_BAD_REQUEST)
            elif appid:
                #print ' todo by app'
                logger.debug("todo by app")
                try:
                    appkey = int(str(appid).split('-')[2])
                    applic = Application.objects.get(application_key=appkey)
                    todolists = TodoList.objects.filter(Q(application_type_guid=applic.application_type_guid) | Q(application_type_guid__isnull=True))
                    serializer = TodoListSerializer(todolists, many=True)
                except Application.DoesNotExist:
                    return Response({"result":"error","message":"Application not found"}, status=status.HTTP_400_BAD_REQUEST)
                except Exception as e:
                    return Response({"result":"error","message":e.message}, status=status.HTTP_400_BAD_REQUEST)
            else:
                todolists = TodoList.objects.all().order_by('todo_list_title')

                serializer = TodoListSerializer(todolists, many=True)
            #print serializer.data
            return JsonResponse(serializer.data, safe=False) #Response(serializer.data)
        else:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)
    """
        Update TodoList (add,update,delete) for the Todo List Managaer
    """

    def put(self, request, todo_list_guid=None):
        #TODO Check user role/perm- DONE
        sadcflg = Authenticate.get_user_sadc(request)

        if sadcflg:
            if not todo_list_guid:
                error = "No Todo List ID provided"
                #logger.debug(authAdminErrors[error]['d_msg'])
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            #print"TODOLIST PUT REQUEST:", request.data
            logger.debug("TODOLIST PUT REQUEST: %s" % request.data)
            try:
                todolist_item = TodoList.objects.get(todo_list_guid=todo_list_guid)
                #print(">> REQUEST DATA IN:", request.data)
                logger.debug(">> REQUEST DATA IN: %s" % request.data)
                #if not isinstance(request.data['todo_list_json'], basestring):
                #print '>>>>>', type(request.data['todo_list_json'])
                logger.debug(" >>>>> %s" % type(request.data['todo_list_json']))
                #request.data['todo_list_json'] = str(request.data['todo_list_json'])

                serializer = TodoListUpdateSerializer(todolist_item, data=request.data)
                #print ">>> AFTER USER SERIALIZER"
                logger.debug(">>> AFTER USER SERIALIZER")
                if serializer.is_valid():
                    serializer.save()
                    #print ">>VALID SERIALIZER FOR TODOLIST", serializer.data
                    logger.debug(">>VALID SERIALIZER FOR TODOLIST %s" % serializer.data)
                    return JsonResponse(serializer.data, safe=False)
                #print ">> SERIALIZER MUST BE BAD", serializer.errors
                logger.debug(">> SERIALIZER MUST BE BAD %s" % serializer.errors)
                return Response({"result":"error","message":serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
            except TodoList.DoesNotExist:
                error = "Todo List Item Does Not Exist"
                #logger.debug(authAdminErrors[error]['d_msg'])
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except IntegrityError as e:
                #print e
                logger.debug(e)
                #logger.debug(authAdminErrors[error]['d_msg'])
                return Response({"result":"error","message":"Not valid JSON"}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

    def post(self, request, format=None):
        #TODO Check user role/perm- DONE
        sadcflg = Authenticate.get_user_sadc(request)

        if sadcflg:
            if 'todo_list_title' not in request.data:
                error = "Missing Todo List Title"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            if request.data['todo_list_title'] == '':
                error = "Missing Todo List Title"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            else:
                # check to see if TodoList with that Title already exists
                try:
                    todolistitem = TodoList.objects.get(todo_list_title=request.data['todo_list_title'])
                    # If exception isn't thrown, that means todolist title already exists.  So error out.
                    error = "ToDo List by the same title already exists"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                except TodoList.DoesNotExist:
                    # We are good to create a new todolist
                    # Set status to created
                    #if not isinstance(request.data['todo_list_json'], basestring):
                    #    print '>>>>>', type(request.data['todo_list_json'])
                    #    request.data['todo_list_json'] = json.dumps(request.data['todo_list_json'])
                    serializer = TodoListUpdateSerializer(data=request.data)
                    #print "SERIALIZED TODOLIST:", serializer
                    logger.debug(" SERIALIZED TODOLIST: %s" % serializer)
                    if serializer.is_valid():
                        serializer.save()
                        print ">>VALID SERIALIZER FOR TODOLIST", serializer.data
                        logger.debug(">>VALID SERIALIZER FOR TODOLIST %s" % serializer.data)
                        return JsonResponse(serializer.data, safe=False)
                    else:
                        error = "err-a006"
                        return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

    def delete(self, request, todo_list_guid=None, format=None):
        sadcflg = Authenticate.get_user_sadc(request)

        if sadcflg:
            try:
                todolistitem = TodoList.objects.get(todo_list_guid=todo_list_guid)
                todolistitem.delete()
                return Response({"result":"success","message":""}, status=status.HTTP_200_OK )
            except TodoList.DoesNotExist:
                error = "Todo List Item Does Not Exist"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)






