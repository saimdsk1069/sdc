from django.conf.urls import url

from . import views

urlpatterns = [
    url(r'^bs_map_planning/', views.bs_map_planning, name='bs_map_planning'),
    #url(r'^bs_map/slackbot_handler/', views.slackbot_handler, name='slackbot_handler'),

]
