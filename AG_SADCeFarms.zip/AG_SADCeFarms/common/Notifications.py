from AG_SADCeFarms import settings
from database.models import (
    Application,
    AuthUrl,
    AuthUserSadc,
    AuthRoleSadc,
    Farm,
    Notification
)
import urllib2
import smtplib
from email.mime.text import MIMEText
import traceback
import logging

logger = logging.getLogger(__name__)



class Notifier:
    """Handler for generating notifications"""
    def __init__(self,notify_text, sendemail=False, users=None, roles=None,farm_key=None,application_key=None):
        self.notify_text = notify_text
        self.sendemail = sendemail
        self.users = users
        self.roles = roles
        self.notifyusers = []
        self.valid = True
        self.error = 'Default'
        self.farm = None
        self.application = None
        try:
            if application_key:
                self.application = Application.objects.get(application_key=application_key)
                self.applicationid = '-'.join(  ['A',str(self.application.application_type_guid.application_type_id),'{:>06d}'.format(self.application.application_key)]  )
            if farm_key:
                self.farm = Farm.objects.get(farm_key=farm_key)
                self.farmid = '-'.join(  ['F','{:>06d}'.format(self.farm.farm_key)]  )
            if self.users:
                if not all([isinstance(useritem, AuthUserSadc) for useritem in self.users]):
                    self.valid = False
                    self.error = 'User(s) not valid'
                else:
                    #print 'trying to concatentate users'
                    logger.debug("trying to concatentate users")
                    self.notifyusers = self.notifyusers + self.users
            if self.roles:
                if not all([isinstance(roleitem, AuthRoleSadc) for roleitem in self.roles]):
                    self.valid = False
                    self.error = 'Role(s) not valid'
                else:
                    #print self.notifyusers
                    logger.debug("Self notify users %s" % self.notifyusers)
                    #print 'trying to concatentate roleusers'
                    logger.debug("trying to concatentate roleusers")
                    for roleitem in self.roles:
                        roleusers = AuthUserSadc.objects.filter(role=roleitem)
                        #print 'roleusers',roleusers
                        logger.debug("roleusers %s" % roleusers)
                        self.notifyusers += roleusers
                    for userrec in self.notifyusers:
                        #print userrec.last_name
                        logger.debug("userrec last name %s" % userrec.last_name)

        except Exception as e:
            self.valid = False
            self.error = e.message


    def send_notification(self):
        '''
        Sends a Notification
        '''
        try:
            #TODO: Create notifications
            for person in self.notifyusers:
                newnotify = Notification(notify_text=self.notify_text,
                                         notify_user=person,
                                         application_key=self.application,
                                         farm_key=self.farm,
                                         deleted_flg=False
                                         )
                newnotify.save()


            useremails = [user.email_primary for user in self.notifyusers]
            #print 'USEREMAILS',useremails
            logger.debug("USEREMAILS %s" % useremails)
            if self.sendemail:
                emailaddys = []
                #useremails = self.notifyusers.values_list('email_primary', flat=True)
                emailbody = 'SADC Notification: \n \n '
                emailbody+= self.notify_text + '\n'
                if self.application:
                    emailbody+= '   Application: ' + self.applicationid + '\n'
                if self.farm:
                    emailbody+= '   Farm: ' + self.farmid + ' - ' + self.farm.farm_name + '\n'
                msg = MIMEText(emailbody)
                msg['Subject'] = 'eFarms Notification'
                fromemail = 'do-not-reply@oit.nj.gov'  #oit-gis-alerts@oit.nj.gov
                msg['From'] = fromemail
                try:
                    s = smtplib.SMTP('appmail.state.nj.us')
                    s.sendmail(fromemail, useremails, msg.as_string())
                    s.quit()
                except smtplib.SMTPConnectError as e:
                    #print("Error sending email to %s" % useremails )
                    logger.debug("Error sending email to %s" % useremails)
                except smtplib.SMTPDataError as e:
                    #print("SMTP DATA ERROR:" + e.message )
                    logger.debug("SMTP DATA ERROR: %s" % e.message)

        except Exception as e:
            self.valid = True
            self.error = 'Issue with sending notification'
            print traceback.print_exc()




