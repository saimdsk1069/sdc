from rest_framework import serializers

from database.models import (Application,
                             ApplicationType,
                             ContactType,
                             CmsContent,
                             County,
                             Document,
                             DocumentTag,
                             DocumentType,
                             DocumentTagType,
                             Farm,
                             FarmParcel,
                             Municipality,
                             Note,
                             NoteGroup,
                             NoteGroupTag,
                             NoteGroupTagType,
                             Partner,
                             ProgramType,
                             ReportViews)

from django.core.exceptions import ValidationError
from rest_framework.renderers import JSONRenderer
from rest_framework.parsers import JSONParser

import json
import cgi
import logging

logger = logging.getLogger(__name__)




# #*************************************************************************************
# # Application Types
# #*************************************************************************************
class ApplicationTypeSerializer(serializers.ModelSerializer):
    program_category_desc = serializers.CharField(source='program_category_code.program_category_desc', read_only=True)
    application_type_label = serializers.SerializerMethodField('get_label', read_only=True)

    def get_label(self,rec):
        if rec.program_category_code:
            return ' - '.join([str(x) for x in [rec.program_category_code.program_category_code,rec.application_name] if x not in [None,' ','']])
        else:
            return str(rec.application_name)

    class Meta:
        model = ApplicationType
        fields = (
            'application_type_guid',
            'application_type_id',
            'application_description',
            'application_name',
            'application_type_label',
            'fiscal_reports_id',
            'program_category_code',
            'program_category_desc'
        )

        read_only_fields = ('application_type_guid',
            'application_type_id',
            'application_description',
            'application_name',
            'application_type_label',
            'fiscal_reports_id',
            'program_category_code',
            'program_category_desc')



class CmsContentSerializer(serializers.ModelSerializer):
    class Meta:
            model = CmsContent
            fields = (
                'content_id','content_page','content_markdown'
            )
            read_only_fields = ('content_id','content_page','content_markdown')


# #*************************************************************************************
# # County / Municipality List
# #*************************************************************************************
class CountySerializer(serializers.ModelSerializer):
    class Meta:
            model = County
            fields = (
                'county_code','county_label'
            )
            read_only_fields = ('county_code','county_label')

class MunSerializer(serializers.ModelSerializer):
    class Meta:
            model = Municipality
            fields = (
                'muni_code','name','county'
            )
            read_only_fields = ('muni_code','name','county')

class CountyMunSerializer(serializers.ModelSerializer):
    munilist = MunSerializer(read_only=True, many=True)
    class Meta:
            model = County
            fields = (
                'county_code','county_label','munilist'
            )
            read_only_fields = ('county_code','county_label')


# #*************************************************************************************
# # Document Types
# #*************************************************************************************
class DocumentTypeSerializer(serializers.ModelSerializer):
    class Meta:
            model = DocumentType
            fields = (
                'document_type_desc',
            )
            read_only_fields = ('document_type_desc',)



# #*************************************************************************************
# # Document Tags
# #*************************************************************************************
class DocumentTagSerializer(serializers.ModelSerializer):
    class Meta:
            model = DocumentTag
            fields = (
                'document_guid',
                'doc_tag_desc',
            )
            #read_only_fields = ('doc_tag_desc',)

    def create(self, validated_data):
        try:
            newtag = DocumentTag.objects.create(**validated_data)
            newtag.save()
            return newtag
        except ValidationError:
            #print("Validation error")
            logger.debug("Validation error")


# #*************************************************************************************
# # Documents
# #*************************************************************************************
class DocSerializer(serializers.ModelSerializer):
    tags = DocumentTagSerializer(many=True)
    created_user = serializers.SerializerMethodField('get_createduser')
    last_edited_user = serializers.SerializerMethodField('get_lastuser')

    def get_createduser(self,doc):
        if doc.created_user_guid:
            first = doc.created_user_guid.first_name
            last = doc.created_user_guid.last_name
            return ', '.join([str(x) for x in [last,first] if x not in [None,' ','']])
        else:
            return ''
    def get_lastuser(self,doc):
        if doc.last_edited_user_guid:
            first = doc.last_edited_user_guid.first_name
            last = doc.last_edited_user_guid.last_name
            return ', '.join([str(x) for x in [last,first] if x not in [None,' ','']])
        else:
            return ''

    class Meta:
            model = Document
            fields = (
                'document_guid',
                'document_name',
                'document_fileext',
                'document_content_type',
                'document_type_desc',
                'document_status_desc',
                'public_access_flg',
                'active_flg',
                'tags',
                'created_date',
                'created_user',
                'last_edited_date',
                'last_edited_user'
            )
            read_only_fields = ('document_guid',
                                'document_name',
                                'document_fileext',
                                'document_content_type',
                                'document_type_desc',
                                'document_status_desc',
                                'public_access_flg',
                                'active_flg',
                                'tags',
                                'created_date',
                                'created_user',
                                'last_edited_date',
                                'last_edited_user')


class DocUpdateSerializer(serializers.ModelSerializer):
    tags = DocumentTagSerializer(many=True,read_only=True)
    created_user = serializers.SerializerMethodField('get_createduser')
    last_edited_user = serializers.SerializerMethodField('get_lastuser')

    def get_createduser(self,doc):
        if doc.created_user_guid:
            first = doc.created_user_guid.first_name
            last = doc.created_user_guid.last_name
            return ', '.join([str(x) for x in [last,first] if x not in [None,' ','']])
        else:
            return ''
    def get_lastuser(self,doc):
        if doc.last_edited_user_guid:
            first = doc.last_edited_user_guid.first_name
            last = doc.last_edited_user_guid.last_name
            return ', '.join([str(x) for x in [last,first] if x not in [None,' ','']])
        else:
            return ''

    class Meta:
            model = Document
            fields = (
                'document_guid',
                'document_name',
                'document_fileext',
                'document_content_type',
                'document_size',
                'document_type_desc',
                'document_status_desc',
                'public_access_flg',
                'active_flg',
                'tags',
                'created_date',
                'created_user',
                'last_edited_date',
                'last_edited_user'
            )
            read_only_fields = ('document_guid',
                                'document_fileext',
                                'document_content_type',
                                'document_size',
                                'tags',
                                'created_date',
                                'created_user',
                                'last_edited_date',
                                'last_edited_user')

    def update(self, instance, validated_data):
        instance.document_name = validated_data.get('document_name', instance.document_name)
        instance.document_type_desc = validated_data.get('document_type_desc', instance.document_type_desc)
        instance.document_status_desc = validated_data.get('document_status_desc', instance.document_status_desc)
        instance.public_access_flg = validated_data.get('public_access_flg', instance.public_access_flg)
        instance.active_flg = validated_data.get('active_flg', instance.active_flg)
        #instance.tags = validated_data.get('tags', instance.tags)
        instance.save()
        return instance

# #*************************************************************************************
# # Note Group Tag Types
# #*************************************************************************************
class NoteGroupTagTypeSerializer(serializers.ModelSerializer):
    class Meta:
            model = NoteGroupTagType
            fields = (
                'tag_desc','tag_category'
            )
            read_only_fields = ('tag_desc','tag_category')


# #*************************************************************************************
# # Note Group Tags
# #*************************************************************************************
class NoteGroupTagSerializer(serializers.ModelSerializer):
    class Meta:
            model = NoteGroupTag
            fields = (
                'seq_id',
                'note_group_guid',
                'tag_desc'
            )
            read_only_fields = ('seq_id',)


    def create(self, validated_data):
        #print "create function VALIDATED DATA:", validated_data
        logger.debug( "create function VALIDATED DATA: %s" % validated_data)

        try:
            newtag = NoteGroupTag.objects.create(**validated_data)
            newtag.save()
            return newtag
        except ValidationError as e:
            #print("Validation error")
            logger.debug("Validation error")



# #*************************************************************************************
# # Notes
# #*************************************************************************************
class NewNoteSerializer(serializers.ModelSerializer):
    note_group_title = serializers.CharField(source='note_group_guid.note_group_title', read_only=True)
    created_user = serializers.SerializerMethodField('get_createduser')
    last_edited_user = serializers.SerializerMethodField('get_edituser')


    def get_createduser(self,noterec):
        if noterec.created_user_guid:
            first = noterec.created_user_guid.first_name
            last = noterec.created_user_guid.last_name
            return ', '.join([str(x) for x in [last,first] if x not in [None,' ','']])
        else:
            return ''
    def get_edituser(self,noterec):
        if noterec.last_edited_user_guid:
            first = noterec.last_edited_user_guid.first_name
            last = noterec.last_edited_user_guid.last_name
            return ', '.join([str(x) for x in [last,first] if x not in [None,' ','']])
        else:
            return ''


    class Meta:
        model = Note
        fields = (
            'note_guid',
            'note_group_guid',
            'note_text',
            'created_date',
            'created_user_guid',
            'created_user',
            'last_edited_date',
            'last_edited_user_guid',
            'last_edited_user',
            'note_group_title'
        )
        read_only_fields = ('note_guid',
                            'created_user',
                            'created_date',
                            'last_edited_user',
                            'last_edited_date',
                            'note_group_title')

    def create(self, validated_data):
        #print "create note function VALIDATED DATA:", validated_data
        logger.debug ("create note function VALIDATED DATA: %s" % validated_data)
        try:
            newnote = Note.objects.create(**validated_data)
            newnote.save()
            return newnote
        except ValidationError:
            #print("Validation error")
            logger.debug("Validation error")


class NoteSerializer(serializers.ModelSerializer):
    created_user = serializers.SerializerMethodField('get_createduser')
    last_edited_user = serializers.SerializerMethodField('get_edituser')
    note_group_title = serializers.CharField(source='note_group_guid.note_group_title', read_only=True)

    def get_createduser(self,noterec):
        if noterec.created_user_guid:
            first = noterec.created_user_guid.first_name
            last = noterec.created_user_guid.last_name
            return ', '.join([str(x) for x in [last,first] if x not in [None,' ','']])
        else:
            return ''
    def get_edituser(self,noterec):
        if noterec.last_edited_user_guid:
            first = noterec.last_edited_user_guid.first_name
            last = noterec.last_edited_user_guid.last_name
            return ', '.join([str(x) for x in [last,first] if x not in [None,' ','']])
        else:
            return ''

    class Meta:
        model = Note
        fields = (
            'note_guid',
            'note_group_guid',
            'note_text',
            'created_date',
            'created_user_guid',
            'created_user',
            'last_edited_date',
            'last_edited_user_guid',
            'last_edited_user',
            'note_group_title'
        )
        read_only_fields = ('note_guid',
                            'note_group_guid',
                            'created_user',
                            'last_edited_user',
                            'last_edited_date',
                            'note_group_title')

    def create(self, validated_data):
        #print "create note function VALIDATED DATA:", validated_data
        logger.debug ("create note function VALIDATED DATA: %s" % validated_data)
        try:
            newnote = Note.objects.create(**validated_data)
            newnote.save()
            return newnote
        except ValidationError:
            #print("Validation error")
            logger.debug("Validation error")

    def update(self, instance, validated_data):
        instance.last_edited_user_guid = validated_data.get('last_edited_user_guid', instance.last_edited_user_guid)
        instance.note_text = validated_data.get('note_text', instance.note_text)
        instance.save()
        return instance


# #*************************************************************************************
# # NoteGroups
# #*************************************************************************************
class NoteGroupSerializer(serializers.ModelSerializer):
    notes = NoteSerializer(many=True, read_only=False)
    tags = NoteGroupTagSerializer(many=True, read_only=True)
    last_edited_user = serializers.SerializerMethodField('get_username')

    def get_username(self,group):
        if group.last_edited_user_guid:
            first = group.last_edited_user_guid.first_name
            last = group.last_edited_user_guid.last_name
            return ', '.join([str(x) for x in [last,first] if x not in [None,' ','']])
        else:
            return ''
    class Meta:
        model = NoteGroup
        fields = (
            'note_group_guid',
            'note_group_title',
            'sadc_flg',
            'last_edited_date',
            'last_edited_user_guid',
            'last_edited_user',
            'notes',
            'tags'
        )
        read_only_fields = ('note_group_guid',
                            'last_edited_user',
                            'last_edited_date',
                            'last_edited_user_guid',
                            'tags'
                            )

    def create(self, validated_data):
        #print "create notegroup function VALIDATED DATA:", validated_data
        logger.debug ("create notegroup function VALIDATED DATA: %s" % validated_data)
        try:
            notes_data = validated_data.pop('notes')
            #tags_data = validated_data.pop('tags')
            newgroup = NoteGroup.objects.create(**validated_data)

            for note_data in notes_data:
                #print note_data
                logger.debug("note data %s" % note_data)
                Note.objects.create(note_group_guid=newgroup, **note_data)
            #for tag_data in tags_data:
            #    NoteGroupTag.objects.create(note_group_guid=newgroup, **tag_data)
            newgroup.save()

            return newgroup
        except ValidationError:
            #print("Validation error")

            logger.debug("Validation error")
    def update(self, instance, validated_data):

        instance.note_group_title = validated_data.get('note_group_title', instance.note_group_title)
        instance.sadc_flg = validated_data.get('sadc_flg', instance.sadc_flg)
        instance.save()
        return instance



# #*************************************************************************************
# # Partners
# #*************************************************************************************
class PartnerSerializer(serializers.ModelSerializer):
    partner_label = serializers.SerializerMethodField('get_label', read_only=True)

    def get_label(self,rec):
        if rec.partner_type_desc:
            return ' - '.join([str(x) for x in [rec.partner_type_desc.partner_type_desc,rec.partner_name] if x not in [None,' ','']])
        else:
            return str(rec.partner_name)
    class Meta:
        model = Partner
        fields = (
            'partner_guid',
            'partner_name',
            'partner_label',
            'partner_type_desc'
        )



# #*************************************************************************************
# # Program Types
# #*************************************************************************************
class ProgramTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProgramType
        fields = (
            'program_type_guid',
            'program_category_desc',
            'program_name',
            'program_code'
        )



# #*************************************************************************************
# # Report Types
# #*************************************************************************************
class ReportViewsSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReportViews
        fields = (
            'report_guid',
            'report_label',
            'module_type'
        )




# #*************************************************************************************
# # Farm Parcels
# #*************************************************************************************
class FarmParcelSerializer(serializers.ModelSerializer):
    municipality = serializers.CharField(source='muni_code.name', read_only=True)
    class Meta:
            model = FarmParcel
            fields = (
                'municipality',
                'muni_code',
                'pcl_block',
                'pcl_lot',
                'pclqcode'
            )
            read_only_fields = ('municipality','muni_code','pcl_block','pcl_lot','pclqcode')

# #*************************************************************************************
# # Farm Search
# #*************************************************************************************
class FarmSearchSerializer(serializers.ModelSerializer):
    partner = serializers.CharField(source='partner_guid.partner_name', read_only=True)
    municipality = serializers.CharField(source='muni_code.name', read_only=True)
    county = serializers.CharField(source='muni_code.county', read_only=True)
    farm_parcels = FarmParcelSerializer(read_only=True, many=True)
    farm_id = serializers.SerializerMethodField('get_farmid')


    def get_farmid(self,farm):
        return '-'.join(  ['F','{:>06d}'.format(farm.farm_key)]  )


    class Meta:
            model = Farm
            fields = (
                'farm_id',
                'farm_name',
                'address',
                'current_flg',
                'municipality',
                'county',
                'active_program_guid',
                'preserved_program_guid',
                'status_preserved_desc',
                'preserved_date',
                'partner',
                'farm_parcels',

            )
            read_only_fields = (
                'farm_id',
                'farm_name',
                'address',
                'current_flg',
                'municipality',
                'county',
                'active_program_guid',
                'preserved_program_guid',
                'status_preserved_desc',
                'preserved_date',
                'partner',
                'farm_parcels',)


# #*************************************************************************************
# # Application Search
# #*************************************************************************************
class AppSearchSerializer(serializers.ModelSerializer):
    application_id = serializers.SerializerMethodField('get_appid')
    application_type = serializers.CharField(source='application_type_guid.application_name', read_only=True)
    application_phase = serializers.CharField(source='application_phase_guid.application_phase_name', read_only=True)
    application_category = serializers.CharField(source='application_type_guid.program_category_desc.program_category_desc', read_only=True)
    partner_name = serializers.CharField(source='partner_guid.partner_name', read_only=True)
    program_type = serializers.CharField(source='program_type_guid.program_name', read_only=True)
    farm_id = serializers.SerializerMethodField('get_farmid')

    def get_farmid(self,record):
        if record.farm_key:
          return '-'.join(  ['F','{:>06d}'.format(record.farm_key.farm_key)]  )
        else:
          return ''

    def get_appid(self,app):
        return '-'.join(  ['A',str(app.application_type_guid.application_type_id),'{:>06d}'.format(app.application_key)]  )


    class Meta:
            model = Application
            fields = (
                'application_id',
                'farm_id',
                'application_type',
                'application_category',
                'application_phase',
                'application_status',
                'application_date',
                'partner_name',
                'program_type',
                'last_edited_date'
            )
            read_only_fields = (
                'application_id',
                'farm_id',
                'application_type',
                'application_category',
                'application_phase',
                'application_status',
                'application_date',
                'partner_name',
                'program_type',
                'last_edited_date')


# #*************************************************************************************
# # Farm Parcels
# #*************************************************************************************
class ParcelSerializer(serializers.ModelSerializer):
    municipality = serializers.CharField(source='muni_code.name', read_only=True)
    class Meta:
            model = FarmParcel
            fields = (
                'municipality',
                'muni_code',
                'pcl_block',
                'pcl_lot',
                'pclqcode',
                'oid',
                'shape'
            )
            read_only_fields = ('municipality','muni_code','pcl_block','pcl_lot','pclqcode','oid','shape')
