from rest_framework.response import Response
# Error codes and messages for AuthAdmin
#  Value is entered
authAdminErrors = {
    # User Status Related
    'err-s001': {'d_msg': 'User status Unregistered not found.', 'ui_msg': ''},
    'err-s002': {'d_msg': 'User status Deactivated not found.', 'ui_msg': ''},
    'err-s003': {'d_msg': 'User status Invited not found', 'ui_msg': ''},
    'err-s005': {'d_msg': 'User status Preregistered not found.', 'ui_msg': ''},
    'err-s006': {'d_msg': 'User status Registered not found.', 'ui_msg': ''},
    'err-s007': {'d_msg': 'User session has expired.', 'ui_msg': ''},

    # User admin related
    'err-a001': {'d_msg': 'Missing Auth User GUID', 'ui_msg': ''},
    'err-a002': {'d_msg': 'User does not exist.', 'ui_msg': ''},
    'err-a003': {'d_msg': 'Email field missing', 'ui_msg': ''},
    'err-a004': {'d_msg': 'Email is empty', 'ui_msg': ''},
    'err-a005': {'d_msg': 'User already exists.', 'ui_msg': ''},
    'err-a006': {'d_msg': 'Error Serializing User.', 'ui_msg': ''},
    # 'err-a007': {'d_msg': 'User is already registered.', 'ui_msg': ''},
    # 'err-a008': {'d_msg': 'Error creating proxy client from WSDL.', 'ui_msg': ''},
    # 'err-a009': {'d_msg': 'Error granting role to user.', 'ui_msg': ''},
    # 'err-a010': {'d_msg': 'Error resuming registration.', 'ui_msg': ''},
    # 'err-a011': {'d_msg': 'Unknown (other) registration error.', 'ui_msg': ''},
    'err-a012': {'d_msg': 'Error while saving user.', 'ui_msg': ''},

    'err-a013': {'d_msg': 'Error creating a new URL.', 'ui_msg': ''},
    'err-a014': {'d_msg': 'Missing URL GUID', 'ui_msg': ''},
    'err-a015': {'d_msg': 'URL with that address does not exist', 'ui_msg': ''},
    'err-a016': {'d_msg': 'URL with that address already exists.', 'ui_msg': ''},
    'err-a017': {'d_msg': 'Error updating URL', 'ui_msg': ''},
    'err-a018': {'d_msg': 'Error updating permissions. Unmatched url_guids', 'ui_msg': ''},
    'err-a019': {'d_msg': 'Error updating permissions. Delete failed.', 'ui_msg': ''},
    'err-a020': {'d_msg': 'Error getting role for update permission.', 'ui_msg': ''},
    'err-a021': {'d_msg': 'Error updating permission. Save failed.', 'ui_msg': ''},

    'err-a023': {'d_msg': 'UI component does not exist', 'ui_msg': ''},
    'err-a024': {'d_msg': 'UI component with that address already exists.', 'ui_msg': ''},
    'err-a025': {'d_msg': 'Error updating UI component', 'ui_msg': ''},
    'err-a026': {'d_msg': 'Error updating UI permissions. Unmatched ui compoent guids', 'ui_msg': ''},
    'err-a027': {'d_msg': 'Error updating UI permissions. Delete failed.', 'ui_msg': ''},
    'err-a028': {'d_msg': 'Error creating a new UI component.', 'ui_msg': ''},
    'err-a029': {'d_msg': 'Missing UI component GUID', 'ui_msg': ''},

    # registration related messages
    'err-r001': {'d_msg': 'User is already registered.', 'ui_msg': ''},
    'err-r002': {'d_msg': 'Error creating proxy client from WSDL.', 'ui_msg': ''},
    'err-r003': {'d_msg': 'Error granting role to user.', 'ui_msg': ''},
    'err-r004': {'d_msg': 'Error resuming registration.', 'ui_msg': ''},
    'err-r005': {'d_msg': 'Unknown (other) registration error.', 'ui_msg': ''},
    'err-r006': {'d_msg': 'User is not registered.', 'ui_msg': ''},
    'err-r006': {'d_msg': 'Error resetting registration for user.', 'ui_msg': ''},

    # workflow related messages.
    'err-w001': {'d_msg': 'Invalid request. Missing workflow id or task id.', 'ui_msg': ''},
    'err-w002': {'d_msg': 'Invalid request workflow question.', 'ui_msg': ''},
    'err-w003': {'d_msg': 'No match for workflow guid and task id.', 'ui_msg': ''},
    'err-w004': {'d_msg': 'No match for workflow guid, task id, and question type.', 'ui_msg': ''}


}
