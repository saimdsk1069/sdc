from django.conf.urls import url
from AG_SADCeFarms import settings
import views




urlpatterns = [
    url(r'^applicationtype$', views.ApplicationTypeItem.as_view(), name="applicationtype"),
    #url(r'^test1/?(garg=.*)$', views.PageContentItem.as_view(), name="test1"),
    url(r'^pagecontent$', views.PageContentItem.as_view(), name="pagecontent"),
    url(r'^county$', views.CountyItem.as_view(), name="county"),
    url(r'^countymun$', views.CountyMunItem.as_view(), name="countymun"),
    url(r'^countymun/(?P<county_code>.*)$', views.CountyMunItem.as_view(), name="countymun"),
    url(r'^documenttype$', views.DocumentTypeItem.as_view(), name="documenttype"),
    url(r'^documentstatus$', views.DocumentStatusItem.as_view(), name="documentstatus"),
    url(r'^documenttagtype$', views.DocumentTagTypeItem.as_view(), name="documenttagtype"),
    url(r'^partner$', views.PartnerItem.as_view(), name="partner"),
    url(r'^preservationtype$', views.PreservationStatusItem.as_view(), name="preservationtype"),
    url(r'^programtype$', views.ProgramTypeItem.as_view(), name="programtype"),
    url(r'^programtype/(?P<program_type_guid>.*)$', views.ProgramTypeItem.as_view(), name="programtype"),
    url(r'^programtype/\?(program_type_guid=.*)$', views.ProgramTypeItem.as_view(), name="programtype"),
    url(r'^scorestatus$', views.ScoreStatusItem.as_view(), name="scorestatus"),
    url(r'^note$', views.NotesView.as_view(), name="notes"),
    url(r'^note/(?P<note_guid>.*)$', views.NotesView.as_view(), name="notes"),
    url(r'^notegroup$', views.NoteGroupView.as_view(), name="notegroups"),
    url(r'^notegroup/(?P<note_group_guid>.*)$', views.NoteGroupView.as_view(), name="notegroups"),
    url(r'^notegroup/?(application_id=.*)$', views.NoteGroupView.as_view(), name="notegroups"),
    url(r'^notegroup/?(farm_id=.*)$', views.NoteGroupView.as_view(), name="notegroups"),
    url(r'^notetagtypes$', views.NoteTagTypes.as_view(), name="notetags"),
    url(r'^notegrouptags$', views.NoteTagItem.as_view(), name="notegrouptag"),
    url(r'^notegrouptags/(?P<note_group_guid>.*)$', views.NoteTagItem.as_view(), name="notegrouptag"),
    url(r'^report/(?P<report_guid>.*)/(?P<report_format>.*)$', views.ReportItem.as_view(), name="report"),
    url(r'^reporttype$', views.ReportTypeItem.as_view(), name="reporttype"),
    url(r'^reporttype/(?P<module_type>.*)$', views.ReportTypeItem.as_view(), name="reporttype"),
    url(r'^document$', views.DocumentItem.as_view(), name="document"),
    url(r'^document/(?P<document_guid>.*)$', views.DocumentItem.as_view(), name="document"),
    url(r'^doc$', views.DocItem.as_view(), name="docs"),
    url(r'^doc/(?P<document_guid>.*)$', views.DocItem.as_view(), name="docs"),

    url(r'^search/farm$', views.SearchFarmView.as_view(), name="searchfarm"),
    url(r'^search/application$', views.SearchAppView.as_view(), name="searchapp")


]