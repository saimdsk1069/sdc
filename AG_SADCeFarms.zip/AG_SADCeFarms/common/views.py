from AG_SADCeFarms import settings
from database.models import (Application,
                             ApplicationType,
                             AuthUserSadc,
                             AuthRoleSadc,
                             CmsContent,
                             County,
                             Document,
                             DocumentStatus,
                             DocumentTag,
                             DocumentTagType,
                             DocumentType,
                             Farm,
                             FarmParcel,
                             Fund,
                             Note,
                             NoteGroup,
                             NoteGroupTag,
                             NoteGroupTagType,
                             Partner,
                             ProgramType,
                             ReportViews,
                             ScoreStatus,
                             StatusPreserved,
                             WxApplicationDocument,
                             WxApplicationNote,
                             WxFarmDocument,
                             WxFarmNote)
from .common_serializers import (ApplicationTypeSerializer,
                                 AppSearchSerializer,
                                 CmsContentSerializer,
                                 CountySerializer,
                                 CountyMunSerializer,
                                 DocSerializer,
                                 DocUpdateSerializer,
                                 DocumentTagSerializer,
                                 DocumentTypeSerializer,
                                 FarmSearchSerializer,
                                 NoteSerializer,
                                 NewNoteSerializer,
                                 NoteGroupSerializer,
                                 NoteGroupTagSerializer,
                                 PartnerSerializer,
                                 ProgramTypeSerializer,
                                 NoteGroupTagTypeSerializer,
                                 ReportViewsSerializer,
                                 ParcelSerializer)

import Notifications
from django.http import Http404, HttpResponse, JsonResponse, HttpResponseForbidden
from django.core.exceptions import PermissionDenied, ObjectDoesNotExist, ValidationError
from django.middleware.csrf import get_token
from django.db import IntegrityError, connection, transaction
from django.db.models import Q
from django.contrib.contenttypes.models import ContentType
from django.apps import apps
from django.core import serializers
from django.http import QueryDict


from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView
from rest_framework.parsers import FormParser,JSONParser, FileUploadParser,MultiPartParser
from security import Authenticate


#
import logging
import traceback
import sys
import json
import requests
#import magic

import hashlib
from datetime import datetime
from collections import OrderedDict

logger = logging.getLogger(__name__)


class ApplicationTypeItem(APIView):
    """
        Get Application Type information
    """
    def get(self, request, application_type_guid=None, format=None):
        apptypeguid = self.request.query_params.get('application_type_guid', None)
        if apptypeguid:
            try:
                apptype = ApplicationType.objects.get(application_type_guid=apptypeguid)
                serializer = ApplicationTypeSerializer(apptype)
            except ApplicationType.DoesNotExist:
                raise Http404

        elif application_type_guid is not None:
            try:
                apptype = ApplicationType.objects.get(application_type_guid=application_type_guid)
                serializer = ApplicationTypeSerializer(apptype)
            except ApplicationType.DoesNotExist:
                raise Http404
        else:
            apptypes = ApplicationType.objects.exclude(Q(application_name='ANY') | Q(application_name='NOT IN PROGRAM')).order_by('application_name')
            serializer = ApplicationTypeSerializer(apptypes, many=True)
        return JsonResponse(serializer.data, safe=False) #Response(serializer.data)


class CountyItem(APIView):
    """
        Get list of counties
    """
    def get(self, request, format=None):
        try:
            counties = County.objects.all()
            serializer = CountySerializer(counties, many=True)
            return JsonResponse(serializer.data, safe=False) #Response(serializer.data)
        except:
            raise Http404


class CountyMunItem(APIView):
    """
        Get County & Municipal List
    """
    def get(self, request, county_code=None, format=None):
        try:
            if county_code is not None:
                try:
                    counties = County.objects.get(county_code=county_code)
                    serializer = CountyMunSerializer(counties)
                    return JsonResponse(serializer.data, safe=False) #Response(serializer.data)
                except County.DoesNotExist:
                    error = "Could not complete request"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            else:
                counties = County.objects.all()
                serializer = CountyMunSerializer(counties, many=True)
                return JsonResponse(serializer.data, safe=False) #Response(serializer.data)
        except:
            raise Http404


class DocumentStatusItem(ListAPIView):
    """
        Get Document Status types
    """
    def get(self, request, format=None):
        returndata = DocumentStatus.objects.all().values_list('document_status_desc', flat=True)
        return Response(returndata)



class DocumentTypeItem(ListAPIView):
    """
        Get Document Types
    """
    def get(self, request, format=None):

        #types = DocumentType.objects.all()
        returndata = DocumentType.objects.all().values_list('document_type_desc', flat=True)
        #serializer = DocumentTypeSerializer(types, many=True)
        return Response(returndata)


class DocumentTagTypeItem(ListAPIView):
    """
        Get Document Tag Types
    """
    def get(self, request, format=None):
        returndata = DocumentTagType.objects.all().values_list('doc_tag_desc', flat=True)
        #serializer = DocumentTypeSerializer(types, many=True)
        return Response(returndata)


class NoteTagTypes(APIView):
    """
        Get NoteGroup Tag Type information
    """
    def get(self, request, format=None):
        tagtypes = NoteGroupTagType.objects.all().order_by('tag_category')
        serializer = NoteGroupTagTypeSerializer(tagtypes, many=True)
        return JsonResponse(serializer.data, safe=False) #Response(serializer.data)


class NoteTagItem(APIView):
    """
        Get/Edit Note Group Tags
    """
    def get(self, request, note_group_guid=None, format=None):
        logger.debug("note group guid %s" %note_group_guid)
        if note_group_guid is not None:
            try:

                tags = NoteGroupTag.objects.filter(note_group_guid=note_group_guid)
                serializer = NoteGroupTagSerializer(tags, many=True)
            except:
                error = "Could not complete request"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            error = "No note group id provided"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

        return JsonResponse(serializer.data, safe=False)


    def post(self, request, format=None):
        #TODO: Check if user has SADC role(s)- DONE
        logger.debug("whats requested %s" % request)
        cred = Authenticate.get_session_credentials(request)
        if not cred:
            return Response({"result": "error", "message": "User not authenticated"}, status=status.HTTP_403_FORBIDDEN)
        if cred:
        #
            sadcflg = Authenticate.get_user_sadc(request)
            logger.debug("Authentication user request %s" % sadcflg)
            if not sadcflg:
                return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)
            if sadcflg:
                #userguid = cred['user_guid']
                #seluser = AuthUserSadc.objects.get(auth_user_guid=userguid)

                if any(x not in request.data for x in ('note_group_guid','tag_desc')):
                    error = "Missing required attribute information"

                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            else:
                try:
                    serializer = NoteGroupTagSerializer(data=request.data)
                    if serializer.is_valid():
                        serializer.save()
                        return JsonResponse(serializer.data, safe=False)
                    else:
                        error = "Cannot add tag"
                        return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                except Exception as e:
                    error = str(e.message)
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, format=None):
        #TODO: Check if user has SADC role(s)- DONE
        sadcflg = Authenticate.get_user_sadc(request)
        if not sadcflg:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)
        if sadcflg:
            if any(x not in request.data for x in ('note_group_guid','tag_desc')):
                error = "Missing required tag information"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            else:
                try:
                    tag = NoteGroupTag.objects.get(note_group_guid=request.data['note_group_guid'],tag_desc=request.data['tag_desc'])
                    tag.delete()
                    return Response({"result":"success","message":""}, status=status.HTTP_200_OK)
                except NoteGroupTag.DoesNotExist:
                    error = "Tag does not exist"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                except Exception as e:
                    #print e.message
                    logger.debug("Could not complete request %s" % e.message)
                    return Response({"result":"error","message":"Could not complete request"}, status=status.HTTP_400_BAD_REQUEST)


class NotesView(APIView):
    """
        Get/Update Notes
    """
    """
    # DO NOT NEED 'GET' FUNCTIONALITY FOR INDIVIDUAL NOTES

    def get(self, request, note_guid=None, format=None):

        #TODO Check user role/perm
        # If not SADC, only get Public Notes, SADC can see all
        # PUBLIC note groups for applications can only be seen by users with role access to application of interest
        # PUBLIC users can not access applications or see application notes
        sadcflg = False
        publicflg = True

        if not note_guid:
            error = "Invalid request"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

        if sadcflg:
            '''SADC can see all notes '''
            try:
                noterec = Note.objects.get(note_guid=note_guid)
                serializer = NoteSerializer(noterec)
                return Response(serializer.data, status=status.HTTP_200_OK) #return Response({"result":"success","message":""}, status=status.HTTP_200_OK )
            except Note.DoesNotExist:
                error = "Item cannot be found"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)


        elif not publicflg and not sadcflg:
            '''If not SADC but a registered user, check whether they have access to the application or farm'''
            try:
                #TODO: Check if user has access to the application! HOW do we do this?
                userapp = True


                app = Application.objects.get(application_id=appid)
                notegroups = NoteGroup.objects.filter(wxapplicationnote__application_id=appid,sadc_flg=False)
                print 'NOTES===',notegroups
                serializer = NoteGroupSerializer(notegroups, many=True)
                return Response(serializer.data, status=status.HTTP_200_OK) #return Response({"result":"success","message":""}, status=status.HTTP_200_OK )
            except Application.DoesNotExist:
                raise Http404

        elif publicflg:
            print 'GET PUBLIC notes!'
            '''If Public, they can only see notes that are made public on a Farm that is PRESERVED'''
            try:
                noterec = Note.objects.filter(note_guid=note_guid,note_group_guid__sadc_flg=False,note_group_guid__wxfarmnote__farm_id__status_preserved_desc='PRESERVED')
                print 'noterec was FOUND ',noterec
                #Note rec was found

                #farms = Farm.objects.filter(wxfarmnote__note_group_guid__note_guid=note_guid,status_preserved_desc='PRESERVED')
                #if len(farms) > 0:
                #    print 'FARMS!!! ',farms
                if noterec:
                    serializer = NoteSerializer(noterec[0])
                    return Response(serializer.data, status=status.HTTP_200_OK) #return Response({"result":"success","message":""}, status=status.HTTP_200_OK )
                else:
                    error = "Item cannot be found"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except Note.DoesNotExist:
                error = "Item cannot be found"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
    """

    def put(self, request, note_guid=None):
        #TODO- User must be user that created the note - DONE
        if not note_guid:
            error = "Invalid request"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

        # User must be authenticated, user must also be original creator of the note
        cred = Authenticate.get_session_credentials(request)
        if not cred:
            return Response({"result": "error", "message": "User not authenticated"}, status=status.HTTP_403_FORBIDDEN)
        if cred:
            try:
                userguid = cred['user_guid']
                seluser = AuthUserSadc.objects.get(auth_user_guid=userguid)
                noterec = Note.objects.get(note_guid=note_guid)
                if noterec.created_user_guid == seluser:
                    request.data['last_edited_user_guid'] = userguid
                    serializer = NoteSerializer(noterec, data=request.data, partial=True)
                    if serializer.is_valid():
                        serializer.save()
                        return JsonResponse(serializer.data, safe=False)
                    return Response({"result":"error","message":""}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"result": "error", "message": "User not authenticated"}, status=status.HTTP_403_FORBIDDEN)
            except AuthUserSadc.DoesNotExist:
                error = "User not found"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except Note.DoesNotExist:
                error = "Item cannot be found"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except Exception as e:
                return Response({"result":"error","message":"Could not complete request"}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        #TODO Only SADC can create new notes - DONE
        # If not SADC, cannot add notes?
        cred = Authenticate.get_session_credentials(request)
        if not cred:
            return Response({"result": "error", "message": "User not authenticated"}, status=status.HTTP_403_FORBIDDEN)
        if cred:
            userguid = cred['user_guid']
        sadcflg = Authenticate.get_user_sadc(request)

        if sadcflg:
            try:
                recid = request.data.get('note_group_guid','blank')
                notegrouprec = NoteGroup.objects.get(note_group_guid=recid)
                request.data['created_user_guid'] = userguid
                request.data['last_edited_user_guid'] = userguid
                serializer = NewNoteSerializer(data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return JsonResponse(serializer.data, safe=False)
                else:
                    error = "Invalid request"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except NoteGroup.DoesNotExist:
                error = "Invalid request"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except Exception as e:
                return Response({"result":"error","message":"Could not complete request"}, status=status.HTTP_400_BAD_REQUEST)
        else:
            raise PermissionDenied


    def delete(self, request,note_guid=None, format=None):
        #TODO Only SADC users can delete notes - DONE
        if not note_guid:
            error = "Invalid request"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

        # If user is not SADC, user can only delete their own notes
        cred = Authenticate.get_session_credentials(request)
        if not cred:
            return Response({"result": "error", "message": "User not authenticated"}, status=status.HTTP_403_FORBIDDEN)
        if cred:
            userguid = cred['user_guid']
        sadcflg = Authenticate.get_user_sadc(request)
        if sadcflg:
            try:
                noterec = Note.objects.get(note_guid=note_guid)
                noterec.delete()
                return Response({"result":"success","message":""}, status=status.HTTP_200_OK )
            except Note.DoesNotExist:
                error = "Item cannot be found"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except Exception as e:
                return Response({"result":"error","message":"Could not complete request"}, status=status.HTTP_400_BAD_REQUEST)
        else:
            try:
                if cred:
                    userguid = cred['user_guid']
                    seluser = AuthUserSadc.objects.get(auth_user_guid=userguid)
                    noterec = Note.objects.get(note_guid=note_guid)
                    if noterec.created_user_guid == seluser:
                        noterec = Note.objects.get(note_guid=note_guid)
                        noterec.delete()
                        return Response({"result":"success","message":""}, status=status.HTTP_200_OK )
                    else:
                        return Response({"result": "error", "message": "Permission Denied"}, status=status.HTTP_403_FORBIDDEN)
            except Note.DoesNotExist:
                error = "Item cannot be found"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except Exception as e:
                return Response({"result":"error","message":"Could not complete request"}, status=status.HTTP_400_BAD_REQUEST)


class NoteGroupView(APIView):
    """
        Get/Update NoteGroups for an Application or Farm
    """
    def get(self, request, note_group_guid=None, format=None):
        appid = self.request.query_params.get('application_id', None)
        farmid = self.request.query_params.get('farm_id', None)

        #TODO - DONE
        # If not SADC, only get Public Notes, SADC can see all
        # PUBLIC note groups for applications can only be seen by users with role access to application of interest
        # PUBLIC users can not access applications or see application notes

        cred = Authenticate.get_session_credentials(request)
        if not cred:
            publicflg = True
        if cred:
            userguid = cred['user_guid']
            publicflg = False

        sadcflg = Authenticate.get_user_sadc(request)

        if sadcflg:
            if appid:
                '''SADC can see all for application notes'''
                try:
                    appkey = int(str(appid).split('-')[2])
                    app = Application.objects.get(application_key=appkey)
                    notegroups = NoteGroup.objects.filter(wxapplicationnote__application_key=appkey)
                    serializer = NoteGroupSerializer(notegroups, many=True)
                    return Response(serializer.data, status=status.HTTP_200_OK) #return Response({"result":"success","message":""}, status=status.HTTP_200_OK )
                except Application.DoesNotExist:
                    error = "Item cannot be found"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                except Exception as e:
                    #print e.message
                    logger.debug("Could not complete request %s" % e.message)
                    return Response({"result":"error","message":"Could not complete request"}, status=status.HTTP_400_BAD_REQUEST)
            elif farmid:
                '''SADC can see all for farm notes'''
                try:
                    farmkey = int(str(farmid).split('-')[1])
                    farm = Farm.objects.get(farm_key=farmkey)
                    notegroups = NoteGroup.objects.filter(wxfarmnote__farm_key=farmkey)
                    serializer = NoteGroupSerializer(notegroups, many=True)
                    #print serializer.data
                    logger.debug("serializer data %s" % serializer.data)
                    return Response(serializer.data, status=status.HTTP_200_OK) #return Response({"result":"success","message":""}, status=status.HTTP_200_OK )
                except Farm.DoesNotExist:
                    error = "Item cannot be found"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                except Exception as e:
                    #print e.message
                    logger.debug("Could not complete request %s" % e.message)
                    return Response({"result":"error","message":"Could not complete request"}, status=status.HTTP_400_BAD_REQUEST)

        elif not publicflg and not sadcflg:
            '''Registered users can see notes for applications that they have access permissions to'''
            if appid:
                try:
                    #TODO: Check if user has access to the application! Should we use Application Contacts as a guide?
                    appkey = int(str(appid).split('-')[2])
                    app = Application.objects.get(application_key=appkey)
                    notegroups = NoteGroup.objects.filter(wxapplicationnote__application_key=appkey,sadc_flg=False)
                    serializer = NoteGroupSerializer(notegroups, many=True)
                    return Response(serializer.data, status=status.HTTP_200_OK) #return Response({"result":"success","message":""}, status=status.HTTP_200_OK )
                except Application.DoesNotExist:
                    error = "Item cannot be found"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                except Exception as e:
                    #print e.message
                    logger.debug("Could not complete request %s" % e.message)
                    return Response({"result":"error","message":"Could not complete request"}, status=status.HTTP_400_BAD_REQUEST)
            elif farmid:
                try:
                    farmkey = int(str(farmid).split('-')[1])
                    farm = Farm.objects.get(farm_key=farmkey)
                    if farm.status_preserved_desc == 'PRESERVED':
                        notegroups = NoteGroup.objects.filter(wxfarmnote__farm_key=farmkey,sadc_flg=False)

                        serializer = NoteGroupSerializer(notegroups, many=True)
                        return Response(serializer.data, status=status.HTTP_200_OK) #return Response({"result":"success","message":""}, status=status.HTTP_200_OK )
                    else:
                        #TODO: Check if user has access to the farm that is not preserved! Need to determine if this is tied to farm contacts?
                        pass
                except Farm.DoesNotExist:
                    error = "Item cannot be found"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                except Exception as e:
                    #print e.message
                    logger.debug("Could not complete request %s" % e.message)
                    return Response({"result":"error","message":"Could not complete request"}, status=status.HTTP_400_BAD_REQUEST)
        elif publicflg:
            '''Only allow public to view notes for 'PRESERVED' Farms, not applications'''
            if appid:
                raise PermissionDenied
            elif farmid:
                try:
                    farmkey = int(str(farmid).split('-')[1])
                    farm = Farm.objects.get(farm_key=farmkey,status_preserved_desc='PRESERVED')
                    #Only allow public to view notes for visible (preserved farms)
                    notegroups = NoteGroup.objects.filter(wxfarmnote__farm_key=farmkey,sadc_flg=False)

                    serializer = NoteGroupSerializer(notegroups, many=True)
                    return Response(serializer.data, status=status.HTTP_200_OK) #return Response({"result":"success","message":""}, status=status.HTTP_200_OK )
                except Farm.DoesNotExist:
                    error = "Item cannot be found"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                except Exception as e:
                    #print e.message
                    logger.debug("Could not complete request %s" % e.message)
                    return Response({"result":"error","message":"Could not complete request"}, status=status.HTTP_400_BAD_REQUEST)


    def put(self, request, note_group_guid=None):
        #TODO Check user role/perm
        '''All SADC users can edit/delete notes by default'''

        # TODO:If not SADC, only get Public Notes, if SADC, can see all
        sadcflg = True

        if not note_group_guid:
            error = "Invalid request"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

        if sadcflg:
            tags = False
            try:

                notegrouprec = NoteGroup.objects.get(note_group_guid=note_group_guid)
                #print request.data
                logger.debug("request data %s" % request.data)

                if 'tags' in request.data:
                    NoteGroupTag.objects.filter(note_group_guid=note_group_guid).delete()
                    for tagitem in dict(request.data)['tags']:
                        newTag = NoteGroupTag(note_group_guid=notegrouprec,tag_desc=tagitem['tag_desc'])
                        newTag.save()
                serializer = NoteGroupSerializer(notegrouprec, data=request.data, partial=True)
                if serializer.is_valid():
                    serializer.save()
                    return JsonResponse(serializer.data, safe=False)

                return Response({"result":"error","message":""}, status=status.HTTP_400_BAD_REQUEST)
            except NoteGroup.DoesNotExist:
                error = "Item cannot be found"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except Exception as e:
                #print e.message
                logger.debug("Could not complete request %s" % e.message)

                return Response({"result":"error","message":"Could not complete request"}, status=status.HTTP_400_BAD_REQUEST)
        else:
            '''Non-SADC users are not permitted'''
            error = "Insufficient permissions"
            #return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            #return HttpResponseForbidden()
            raise PermissionDenied

    def post(self, request, format=None):
        appid = self.request.query_params.get('application_id', None)
        farmid = self.request.query_params.get('farm_id', None)

        #TODO Check user role/perm
        # Only SADC can post notes
        sadcflg = True

        if not appid and not farmid:
            # Notes must be associated with a farm or application
            error = "Notes must be associated with a farm or application"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

        if sadcflg:
            try:
                if appid:
                    appkey = int(str(appid).split('-')[2])
                    app = Application.objects.get(application_key=appkey)
                    if 'tags' in request.data:
                        newtags = request.data.pop('tags')
                    serializer = NoteGroupSerializer(data=request.data)

                    if serializer.is_valid():
                        serializer.save()
                        notegroup = NoteGroup.objects.get(note_group_guid=serializer.data['note_group_guid'])
                        newWxApplicationNote = WxApplicationNote(application_key=app,note_group_guid=notegroup)
                        newWxApplicationNote.save()
                        for item in newtags:
                            newTag = NoteGroupTag(note_group_guid=notegroup,tag_desc=item['tag_desc'])
                            newTag.save()
                        serializer = NoteGroupSerializer(notegroup)
                        return JsonResponse(serializer.data, safe=False)
                    else:
                        #print 'ERRORS:== ',serializer.errors
                        logger.debug("ERRORS:== %s" % serializer.errors)
                        error = "NoteGroup data not valid"
                        return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                elif farmid:
                    farmkey = int(str(farmid).split('-')[1])
                    farm = Farm.objects.get(farm_key=farmkey)
                    if 'tags' in request.data:
                        newtags = request.data.pop('tags')
                    serializer = NoteGroupSerializer(data=request.data)

                    if serializer.is_valid():
                        serializer.save()
                        notegroup = NoteGroup.objects.get(note_group_guid=serializer.data['note_group_guid'])
                        newWxFarmNote = WxFarmNote(farm_key=farm,note_group_guid=notegroup)
                        newWxFarmNote.save()
                        for item in newtags:
                            newTag = NoteGroupTag(note_group_guid=notegroup,tag_desc=item['tag_desc'])
                            newTag.save()
                        serializer = NoteGroupSerializer(notegroup)
                        return JsonResponse(serializer.data, safe=False)
                    else:
                        #print 'ERRORS:== ',serializer.errors
                        logger.debug("ERRORS:== %s" % serializer.errors)
                        error = "NoteGroup data not valid"
                        return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except Application.DoesNotExist:
                error = "Application not valid"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except Farm.DoesNotExist:
                error = "Farm not valid"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except NoteGroup.DoesNotExist:
                error = "Data not valid"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except Exception as e:
                #print e.message
                logger.debug("Could not complete request %s" % e.message)
                return Response({"result":"error","message":"Could not complete request"}, status=status.HTTP_400_BAD_REQUEST)

        else:
            '''Non-SADC users are not permitted'''
            error = "Insufficient permissions"
            #return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            #return HttpResponseForbidden()
            raise PermissionDenied


    def delete(self, request,note_group_guid=None, format=None):
        #TODO Check user role/perm
        # If not SADC, only get Public Notes, if SADC, can see all
        sadcflg = True

        if not note_group_guid:
            error = "Invalid request"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        if sadcflg:
            '''All SADC users can edit/delete notes by default'''
            try:
                notegrouprec = NoteGroup.objects.get(pk=note_group_guid)
                notegrouprec.delete()
                return Response({"result":"success","message":""}, status=status.HTTP_200_OK )
            except NoteGroup.DoesNotExist:
                error = "Item cannot be found"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except Exception as e:
                #print e.message
                logger.debug("Could not complete request %s" % e.message)
                return Response({"result":"error","message":"Could not complete request"}, status=status.HTTP_400_BAD_REQUEST)
        else:
            '''Non-SADC users are not permitted'''
            raise PermissionDenied


class PartnerItem(APIView):
    """
        Get Partner information
    """
    def get(self, request, partner_guid=None, format=None):

        if partner_guid is not None:
            try:
                partnerrec = Partner.objects.get(partner_guid=partner_guid).order_by('partner_name')
                serializer = PartnerSerializer(partnerrec)
                #ordering = ('partner_name',)
            except Partner.DoesNotExist:
                raise Http404
            except Exception as e:
                #print e.message
                logger.debug("Could not complete request %s" % e.message)
                return Response({"result":"error","message":"Could not complete request"}, status=status.HTTP_400_BAD_REQUEST)
        else:
            partners = Partner.objects.all()
            serializer = PartnerSerializer(partners, many=True)
        return JsonResponse(serializer.data, safe=False) #Response(serializer.data)



class ProgramTypeItem(APIView):
    """
        Get Program Type information
    """
    def get(self, request, program_type_guid=None, format=None):
        progguid = self.request.query_params.get('program_type_guid', None)
        if progguid:
            try:
                progtype = ProgramType.objects.get(program_type_guid=progguid)
                serializer = ProgramTypeSerializer(progtype)
            except ProgramType.DoesNotExist:
                raise Http404
            except Exception as e:
                #print e.message
                logger.debug("Could not complete request %s" % e.message)
                return Response({"result":"error","message":"Could not complete request"}, status=status.HTTP_400_BAD_REQUEST)

        elif program_type_guid is not None:
            try:
                progtype = ProgramType.objects.get(program_type_guid=program_type_guid)
                serializer = ProgramTypeSerializer(progtype)
            except ProgramType.DoesNotExist:
                raise Http404
            except Exception as e:
                #print e.message
                logger.debug("Could not complete request %s" % e.message)

                return Response({"result":"error","message":"Could not complete request"}, status=status.HTTP_400_BAD_REQUEST)
        else:
            progtypes = ProgramType.objects.exclude(Q(program_name='ANY') | Q(program_name='NOT IN PROGRAM')).order_by('program_name')
            serializer = ProgramTypeSerializer(progtypes, many=True)
        return JsonResponse(serializer.data, safe=False) #Response(serializer.data)


class ReportItem(APIView):
    """
        Get a report in CSV or XLSX format
    """
    def get(self, request, report_guid=None,report_format=None, format=None):
        if report_guid and report_format:
            try:
                reportrec = ReportViews.objects.get(report_guid=report_guid)
                viewname = reportrec.view_name
                reportlab = reportrec.report_label
                cursor = connection.cursor()
                """Safe to use string formatting because we are not using user parameters!"""
                qry = "SELECT * from %s;" % viewname
                cursor.execute(qry)
                col_names = [desc[0] for desc in cursor.description]

                #rows = [ OrderedDict(zip([col for col in col_names], row))
                #         for row in cursor.fetchall() ]
                rows = [row for row in cursor.fetchall()]
                return JsonResponse([col_names] + rows, safe=False)

            except Exception as e:
                #print e.message
                logger.debug("Could not complete request %s" % e.message)

                error = "Could not complete request"
                return Response({"result":"error","message":e.message}, status=status.HTTP_400_BAD_REQUEST)
            except ReportViews.DoesNotExist as e:
                error = "Could not complete request"
                return Response({"result":"error","message":e.message}, status=status.HTTP_400_BAD_REQUEST)
        else:
            error = "No report id provided"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)


class PageContentItem(APIView):

    def get(self, request, format=None):
        contentpage = self.request.query_params.get('content_page', None)
        if contentpage is not None:
            #print contentpage
            logger.debug("Content page %s" % contentpage)
            try:
                pagecontents = CmsContent.objects.filter(content_page=contentpage)
                serializer = CmsContentSerializer(pagecontents, many=True)
                return JsonResponse(serializer.data, safe=False)
            except:
                error = ""
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            error = "Missing page info"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, format=None):
        contentid = self.request.query_params.get('content_id', None)
        if contentid:
            #print contentid
            logger.debug("Content id %s" % contentid)
            try:
                pagecontent = CmsContent.objects.get(content_id=contentid)
                #serializer = CmsContentSerializer(pagecontent)
                if 'content_markdown' in request.data:
                    pagecontent.content_markdown = request.data['content_markdown']
                    pagecontent.save()
                    serializer = CmsContentSerializer(pagecontent)
                    return JsonResponse(serializer.data, safe=False)
                else:
                    error = "Missing content markdown"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except CmsContent.DoesNotExist:
                error = "No content found"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            error = "Missing content page and/or content id"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)


class ReportTypeItem(APIView):
    """
        Get a list of Report types for each module type
    """
    def get(self, request, module_type=None, format=None):
        if not module_type:
            try:
                reports = ReportViews.objects.all()
                serializer = ReportViewsSerializer(reports, many=True)
                return JsonResponse(serializer.data, safe=False)
            except:
                raise Http404
        if module_type:
            try:
                reports = ReportViews.objects.filter(module_type=module_type)
                serializer = ReportViewsSerializer(reports, many=True)
                return JsonResponse(serializer.data, safe=False)
            except:
                raise Http404


class DocumentItem(APIView):
    """
        Get document information (!filedata)
    """
    def get(self, request, document_guid=None, format=None):
        #TODO: Bolt in security for requests
        appid = self.request.query_params.get('application_id', None)
        appkey = None
        farmid = self.request.query_params.get('farm_id', None)
        farmkey = None
        if document_guid:
            try:
                doc = Document.objects.get(document_guid=document_guid)
                serializer = DocSerializer(doc)
                return JsonResponse(serializer.data, safe=False)
            except Document.DoesNotExist:
                return Response({"result":"error","message":'Cannot find document'}, status=status.HTTP_400_BAD_REQUEST)
        else:
            try:
                if appid:
                    docs = Document.objects.filter(wxapplicationdocument__application_key=int(str(appid).split('-')[2]))
                elif farmid:
                    docs = Document.objects.filter(wxfarmdocument__farm_key=int(str(farmid).split('-')[1]))
                else:
                    docs = Document.objects.all()
                serializer = DocSerializer(docs,many=True)
                return JsonResponse(serializer.data, safe=False)
            except Exception as e:
                #print e.message
                logger.debug("Cannot find document %s" % e.message)
                return Response({"result":"error","message":'Cannot find document'}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, document_guid=None,format=None):
        #TODO: Check user permission
        if document_guid == None:
            error = "No Document provided"
            #logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        try:

            #tagserializer = DocumentTagSerializer(data=tags_data,many=True)
            #if tagserializer.is_valid():
            #    tagserializer.save()
            doc_item = Document.objects.get(document_guid=document_guid)
            tags_data = request.data.pop('tags')
            DocumentTag.objects.filter(document_guid=document_guid).delete()
            for newtag in tags_data:
                tagtype = DocumentTagType.objects.get(doc_tag_desc=newtag['doc_tag_desc'])
                newtag = DocumentTag(doc_tag_desc=tagtype,document_guid=doc_item)
                newtag.save()
            serializer = DocUpdateSerializer(doc_item, data=request.data)
            if serializer.is_valid():
                serializer.save()
                return JsonResponse(serializer.data, safe=False)
            return Response({"result":"error","message":serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        except Document.DoesNotExist:
            error = "Document can't be found"
            #logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        except IntegrityError as e:
            return Response({"result":"error","message":'Not valid JSON'}, status=status.HTTP_400_BAD_REQUEST)


    def delete(self,request,document_guid=None,format=None):
        #TODO: Bolt in security for requests, need to check if SADC role and
        #TODO: if user was the one who created document, they can delete

        appid = request.data.get('application_id', None)
        appkey = None
        farmid = request.data.get('farm_id', None)
        farmkey = None
        if document_guid is None:
            error = "Cannot find document"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        try:
            doc_item = Document.objects.get(document_guid=document_guid)

            if appid: # If user provided an application id, delete association in WxApplicationDocument
                appkey = int(str(appid).split('-')[2])
                appdoc = WxApplicationDocument.objects.filter(document_guid=document_guid,application_key=appkey).delete()
                #appdoc.delete()
            if farmid: # If user provided a farm id, delete association in WxFarmDocument
                farmkey = int(str(farmid).split('-')[1])
                farmdoc = WxFarmDocument.objects.get(document_guid=document_guid,farm_key=farmkey)
                farmdoc.delete()
            # If there are no associations for the document, it can safely be deleted
            appdocs = WxApplicationDocument.objects.filter(document_guid=document_guid)
            farmdocs = WxFarmDocument.objects.filter(document_guid=document_guid)
            if not appdocs and not farmdocs:
                doctags = DocumentTag.objects.filter(document_guid=document_guid)
                if doctags: doctags.delete()
                doc_item.delete()
            return Response({"result":"success","message":""}, status=status.HTTP_200_OK )

        except Document.DoesNotExist:
            error = "Document can't be found"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            #print e.message
            logger.debug("Cannot remove document %s" % e.message)
            traceback.print_exc()
            error = "Cannot remove document"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

class DocItem(APIView):
    """
        Get a document file
    """
    parser_classes = (FormParser, MultiPartParser)
    def get(self, request, document_guid=None, format=None):
        #TODO: Bolt in security for requests
        if document_guid:
            try:
                doc = Document.objects.get(document_guid=document_guid)
                response = HttpResponse(doc.document_blob, content_type=doc.document_content_type)#content_type='application/force-download'
                response['Content-Disposition'] = 'attachment; filename="%s"' % '.'.join([doc.document_name,doc.document_fileext])
                return response
            except Document.DoesNotExist:
                return Response({"result":"error","message":'Cannot find document'}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"result":"error","message":'Cannot find document'}, status=status.HTTP_400_BAD_REQUEST)

    """
        Upload a new document file
    """
    def post(self, request, format=None):
        #print request.META['CONTENT_TYPE']
        logger.debug("Upload file %s" % request.META['CONTENT_TYPE'])
        #TODO: Bolt in security for requests
        try:
            appid = self.request.query_params.get('application_id', None)
            appkey = None
            farmid = self.request.query_params.get('farm_id', None)
            farmkey = None

            if not 'file' in request.FILES:
                return Response({"result":"error","message":'Missing associated file content'}, status=status.HTTP_400_BAD_REQUEST)
            if any(x not in request.data for x in ['document_status_desc','document_type_desc','public_access_flg']):
                return Response({"result":"error","message":'Missing one of the following required attributes: document status /document type/public flag'}, status=status.HTTP_400_BAD_REQUEST)
            if appid:
                appkey = int(str(appid).split('-')[2])
            elif farmid:
                farmkey = int(str(farmid).split('-')[1])
            else:
                return Response({"result":"error","message":'Missing farm or application id'}, status=status.HTTP_400_BAD_REQUEST)


            stat = DocumentStatus.objects.get(document_status_desc=request.data['document_status_desc'])
            doctype = DocumentType.objects.get(document_type_desc=request.data['document_type_desc'])
            with transaction.atomic():
                #print 'FILES: ',request.FILES
                logger.debug("FILES: %s" % request.FILES)
                newfile = request.FILES['file']
                newdoc = Document()
                newdoc.document_name = str(newfile.name).rsplit('.', 1)[0]
                newdoc.document_fileext = str(newfile.name).rsplit('.', 1)[1]
                newdoc.document_size = str(newfile.size)
                newdoc.document_content_type = newfile.content_type
                newdoc.document_status_desc = stat
                newdoc.document_type_desc = doctype
                newdoc.public_access_flg = int(request.data['public_access_flg'])
                # Need to insert with small byte before passing complete file bytes on update
                # Issue with ORA-01461
                newdoc.document_blob = b''.join([chunk for chunk in newfile.chunks()])[:2]
                newdoc.save()

                newdoc.document_blob = b''.join([chunk for chunk in newfile.chunks()])
                newdoc.save()

                tags_data = request.data.pop('tags')[0]
                newtags = json.loads(tags_data)
                #print type(newtags)
                for newtag in newtags:
                    tagtype = DocumentTagType.objects.get(doc_tag_desc=newtag)
                    newtag = DocumentTag(doc_tag_desc=tagtype,document_guid=newdoc)
                    newtag.save()
                if appkey:
                    app = Application.objects.get(application_key=appkey)
                    wxappdoc = WxApplicationDocument(application_key=app,document_guid=newdoc)
                    wxappdoc.save()
                if farmkey:
                    farm = Farm.objects.get(farm_key=farmkey)
                    wxfarmdoc = WxFarmDocument(farm_key=farm,document_guid=newdoc)
                    wxfarmdoc.save()
            return Response({"result":"success","message":""}, status=status.HTTP_200_OK )

        except DocumentType.DoesNotExist:
            return Response({"result":"error","message":'Document type not valid'}, status=status.HTTP_400_BAD_REQUEST)
        except DocumentStatus.DoesNotExist:
            return Response({"result":"error","message":'Document Status type not valid'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            #print 'ERR',e.message
            logger.debug("ERR %s" % e.message)
            return Response({"result":"error","message":e.message}, status=status.HTTP_400_BAD_REQUEST)



class PreservationStatusItem(ListAPIView):
    """
        Get StatusPreserved types
    """
    def get(self, request, format=None):

            returndata = StatusPreserved.objects.all().values_list('status_preserved_desc', flat=True)
            return Response(returndata)


class ScoreStatusItem(ListAPIView):
    """
        Get Score Status types
    """
    def get(self, request, format=None):
        returndata = ScoreStatus.objects.all().values_list('score_status_desc', flat=True)

        return Response(returndata)


class SearchFarmView(APIView):
    """
        Search for Farm records
    """
    def get(self, request, format=None):
        #TODO:Check user permissions!- Public users should only see preserved farms (current), everyone else should be
        # able to query all farms
        cred = Authenticate.get_session_credentials(request)
        farm_id = self.request.query_params.get('farm_id', None)
        farm_name = self.request.query_params.get('farm_name', None)
        partner = self.request.query_params.get('partner', None)
        address = self.request.query_params.get('address', None)
        #check users credentials before loading query

        preservation_status = self.request.query_params.get('status_preserved_desc', None)

        county = self.request.query_params.get('county', None)
        municipality = self.request.query_params.get('municipality', None)
        block = self.request.query_params.get('block', None)
        lot = self.request.query_params.get('lot', None)
        landowner_last = self.request.query_params.get('landowner_last', None)
        landowner_first = self.request.query_params.get('landowner_first', None)
        tagsstring = self.request.query_params.get('tags', None)
        tags = None

        # Check for tags query param with comma delimited string of tags



        if tagsstring:
            # Separate tags into a list
            tags = str(tagsstring).split(',')
        try:
            if farm_id:

                logger.debug("Checking Farm ID")
                # Filter based on a farm_id
                farmres = None
                if farm_id.count('-') != 1: # There must be one and only one dash in the farm id
                    logger.debug('Multiple dashes found in Farm ID')
                    return Response({"result":"error","message":"Invalid Farm ID"}, status=status.HTTP_400_BAD_REQUEST)
                dash_pos = farm_id.find('-')
                farm_num_str = farm_id[dash_pos+1:]
                # try to 'int' the farm number string
                try: # try to 'int' the farm number string. If fails, return message.
                    farmkey = int(farm_num_str)
                except ValueError:
                    logger.debug('Could not convert "%s" to integer' % farm_num_str)
                    return Response({"result":"error","message":"Invalid Farm ID"}, status=status.HTTP_400_BAD_REQUEST)
                if cred:
                    farmres = Farm.objects.filter(farm_key=farmkey)
                else:
                    farmres = Farm.objects.filter(farm_key=farmkey,status_preserved_desc = "PRESERVED")

                serializer = FarmSearchSerializer(farmres,many=True)
                return JsonResponse(serializer.data, safe=False)
            else:
                #Check for minimum filters
                #if all(x is None for x in [farm_name,partner,address,preservation_status,county,municipality,block,lot]):
                #    error = "Missing minimum search attributes"
                #    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                farmres = None

                if farm_name:
                    print 'hey farm name'
                    logger.debug("hey farm name")
                    if farmres:
                        farmres = farmres.filter(farm_name__icontains=farm_name)
                    else:
                        farmres = Farm.objects.filter(farm_name__icontains=farm_name)
                if partner:
                    #print 'hey partner'
                    logger.debug("hey partner")
                    if farmres:
                        farmres = farmres.filter(partner_guid=partner)
                    else:
                        farmres = Farm.objects.filter(partner_guid=partner)
                if address:
                    #print 'hey address'
                    logger.debug("hey address")
                    if farmres:
                        farmres = farmres.filter(address__icontains=address)
                    else:
                        farmres = Farm.objects.filter(address__icontains=address)
                #Only authorized users have access to Unpreserved farms
                if cred:

                    if preservation_status:
                        logger.debug("hey preserved status")
                        if farmres:
                            farmres = farmres.filter(status_preserved_desc=preservation_status)
                        else:
                            farmres = Farm.objects.filter(status_preserved_desc=preservation_status)
                else:
                #if public user, only allow access to preserved farms
                    logger.debug("preservation status %s" %preservation_status)
                    preservation_status = "PRESERVED"
                    logger.debug("Preserved")
                    if farmres:
                        farmres = farmres.filter(status_preserved_desc=preservation_status)
                    else:
                        farmres = Farm.objects.filter(status_preserved_desc=preservation_status)




                if municipality:
                    #print 'hey muni'
                    logger.debug("hey muni")
                    if farmres:
                        farmres = farmres.filter(farm_parcels__muni_code=municipality).distinct()
                    else:
                        farmres = Farm.objects.filter(farm_parcels__muni_code=municipality).distinct()
                elif county:
                    #print 'hey county'
                    logger.debug("hey county")
                    if farmres:
                        farmres = farmres.filter(farm_parcels__muni_code__muni_code__startswith=county).distinct()
                    else:
                        farmres = Farm.objects.filter(farm_parcels__muni_code__muni_code__startswith=county).distinct()
                if block:
                    #print 'hey block'
                    logger.debug("hey block")

                    if farmres:
                        #print 'filter further'
                        logger.debug("filter further")
                        farmres = farmres.filter(farm_parcels__pcl_block=block).distinct()
                    else:
                        farmres = Farm.objects.filter(farm_parcels__pcl_block=block).distinct()

                if lot:
                    #print 'hey lot'
                    logger.debug("hey lot")
                    if farmres:
                        farmres = farmres.filter(farm_parcels__pcl_lot=lot).distinct()
                    else:
                        farmres = Farm.objects.filter(farm_parcels__pcl_lot=lot).distinct()
                if landowner_last:
                    #print 'hey landowner_last'
                    logger.debug("hey landowner_last")
                    if farmres:
                        farmres = farmres.filter(farm_contacts__contact_type_desc__contact_type_desc='Landowner',farm_contacts__auth_user_guid__last_name__icontains=landowner_last).distinct()
                    else:
                        farmres = Farm.objects.filter(farm_contacts__contact_type_desc__contact_type_desc='Landowner',farm_contacts__auth_user_guid__last_name__icontains=landowner_last).distinct()
                if landowner_first:
                    #print 'hey landowner_first'
                    logger.debug("hey landowner_first")
                    if farmres:
                        farmres = farmres.filter(farm_contacts__contact_type_desc__contact_type_desc='Landowner',farm_contacts__auth_user_guid__first_name__icontains=landowner_first).distinct()
                    else:
                        farmres = Farm.objects.filter(farm_contacts__contact_type_desc__contact_type_desc='Landowner',farm_contacts__auth_user_guid__first_name__icontains=landowner_first).distinct()
                if tags:
                    for tag in tags:
                        if farmres:
                            farmres = farmres.filter(farm_tags__farm_tag_desc__farm_tag_desc=tag).distinct()
                        else:
                            farmres = Farm.objects.filter(farm_tags__farm_tag_desc__farm_tag_desc=tag).distinct()
                serializer = FarmSearchSerializer(farmres,many=True)
                return JsonResponse(serializer.data, safe=False)

        except Exception as e:
            #print e.message
            logger.debug("message %s" % e.message)
            return Response({"result":"error","message":e.message}, status=status.HTTP_400_BAD_REQUEST)


class SearchAppView(APIView):
    """
        Search for App records
    """
    def get(self, request, format=None):
        #TODO:Check user permissions!
        application_id = self.request.query_params.get('application_id', None)
        farm_id = self.request.query_params.get('farm_id', None)
        partner = self.request.query_params.get('partner', None)
        application_type = self.request.query_params.get('application_type', None)
        program_type = self.request.query_params.get('program_type', None)
        year = self.request.query_params.get('year', None)

        try:
            if application_id:
                # Filter based on a application_id
                appres = None
                appkey = int(str(application_id).split('-')[2])
                appres = Application.objects.filter(application_key=appkey)
                serializer = AppSearchSerializer(appres,many=True)
                return JsonResponse(serializer.data, safe=False)

            else:
                #Check for minimum filters
                #if all(x is None for x in [farm_id,partner,application_type,program_type,year]):
                #    error = "Missing minimum search attributes"
                #    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)


                appres = None
                if farm_id:
                    #print 'hey farm id'
                    logger.debug("hey farm id")
                    farmkey = int(str(farm_id).split('-')[1])
                    if appres:
                        appres = appres.filter(farm_key=farmkey)
                    else:
                        appres = Application.objects.filter(farm_key=farmkey)
                if partner:
                    #print 'hey partner'
                    logger.debug("hey partner")
                    if appres:
                        appres = appres.filter(partner_guid=partner)
                    else:
                        appres = Application.objects.filter(partner_guid=partner)
                if application_type:
                    #print 'hey application_type'
                    logger.debug("hey application_type")
                    if appres:
                        appres = appres.filter(application_type_guid=application_type)
                    else:
                        appres = Application.objects.filter(application_type_guid=application_type)
                if program_type:
                    #print 'hey program_type'
                    logger.debug("hey program_type")
                    if appres:
                        appres = appres.filter(program_type_guid=program_type)
                    else:
                        appres = Application.objects.filter(program_type_guid=program_type)
                if year:
                    #print 'hey year'
                    logger.debug("hey year")
                    if appres:
                        appres = appres.filter(created_date__year=year)
                    else:
                        appres = Application.objects.filter(created_date__year=year)

                serializer = AppSearchSerializer(appres,many=True)
                return JsonResponse(serializer.data, safe=False)

        except Exception as e:
            #print e.message
            logger.debug("error %s" % e.message)
            return Response({"result":"error","message":e.message}, status=status.HTTP_400_BAD_REQUEST)


