from AG_SADCeFarms import settings
from database.models import (
                            Application,AppQuestionAnswer)
from .appdash_serializers import (
                            AnswerUpdateSerializer)
from django.db import transaction
from django.db.models import F
from django.db.models import Q
import logging

logger = logging.getLogger(__name__)

class AnswerHandler:
    """Handler for updating questionnaire answers"""
    def __init__(self, data):
        self.valid = True
        self.data = data
        self.appkey = None
        try:
            # Validations
            self.appkey = int(str(self.data['application_id']).split('-')[2])
            app = Application.objects.get(application_key=self.appkey)

            #1) Check if questions object has required information
            for question in self.data['questions']:
                if any(x not in question for x in ['answer_json','question_guid']):
                    self.error = 'Missing required attributes'
                    self.valid = False
                    return
            #2) Check if user has permissions to update application questionnaire answers
            #3) Check questionnaire json for question guid?
        except Application.DoesNotExist:
            self.error = 'Could not find application'
            self.valid = False
            return


    def updateRecs(self):
        answerrecs = []
        for question in self.data['questions']:
            try:
                answer = AppQuestionAnswer.objects.get(application_key=self.appkey,question_guid=question['question_guid'],active_flg=1)
                serializer = AnswerUpdateSerializer(answer, data={'application_key':self.appkey,
                                                          'question_guid':question['question_guid'],
                                                          'answer_json':question['answer_json']})
                if serializer.is_valid():
                    serializer.save()
                    #return JsonResponse(serializer.data, safe=False)
                else:
                    #print '=== update error on question ',question['question_guid']
                    logger.debug( "=== update error on question %s" % question['question_guid'])
                    self.error = 'Could not update answers'
                    self.valid = False
                    return
            except AppQuestionAnswer.DoesNotExist:
                serializer = AnswerUpdateSerializer(data={'application_key':self.appkey,
                                                          'question_guid':question['question_guid'],
                                                          'answer_json':question['answer_json']})
                if serializer.is_valid():
                    serializer.save()
                    #return JsonResponse(serializer.data, safe=False)
                else:
                    #print '=== Add error on question ',question['question_guid']
                    logger.debug( "=== Add error on question %s" % question['question_guid'])
                    self.error = 'Could not update answers'
                    self.valid = False
                    return
            answerrecs.append(serializer.data)

        #print '===  all answers good'
        logger.debug("===  all answers good")
        return {"result":"success","answers":answerrecs}
