from rest_framework import serializers

from database.models import (
    AuthUserSadc,
    AuthRoleSadc,
    Application,
    ApplicationContact,
    ApplicationContactType,
    ApplicationMap,
    ApplicationMapLayer,
    AppQuestionAnswer,
    AppQuestionDocument,
    ApplicationPhase,
    ApplicationQuestionnaire,
    Layer,
    Score,
    ScoreType,
    TodoItem,
    WxRoleTodo,
    WxUserTodo,
    TodoList)

from django.core.exceptions import ValidationError
from rest_framework.renderers import JSONRenderer
from rest_framework.parsers import JSONParser

import json
import cgi
import logging

logger = logging.getLogger(__name__)



class FlattenMixin(object):
    """Flatens the specified related objects in this representation"""
    def to_representation(self, obj):
        assert hasattr(self.Meta, 'flatten'), (
            'Class {serializer_class} missing "Meta.flatten" attribute'.format(
                serializer_class=self.__class__.__name__
            )
        )
        # Get the current object representation
        rep = super(FlattenMixin, self).to_representation(obj)
        # Iterate the specified related objects with their serializer
        for field, serializer_class in self.Meta.flatten:
            serializer = serializer_class(context = self.context)
            objrep = serializer.to_representation(getattr(obj, field))
            #Include their fields, prefixed, in the current   representation
            for key in objrep:
                rep[field + "_" + key] = objrep[key]
        return rep


# #*************************************************************************************
# # Application Contact Type
# #*************************************************************************************
class AppContactTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = ApplicationContactType
        fields = (
            'contact_type_desc',
        )


class UserSerializer(serializers.ModelSerializer):
    name = serializers.SerializerMethodField('get_username')

    def get_username(self,user):
        salutation = user.salutation
        first = user.first_name
        last = user.last_name
        return ', '.join([str(x) for x in [last,first] if x not in [None,' ','']])

    class Meta:
        model = AuthUserSadc
        fields = ("name",)
        read_only_fields = ("name",)


class ApplicationInfoSerializer(FlattenMixin,serializers.ModelSerializer):
    application_category = serializers.CharField(source='application_type_guid.program_category_code.program_category_desc', read_only=True)
    application_type = serializers.CharField(source='application_type_guid.application_name', read_only=True)
    program_type = serializers.CharField(source='program_type_guid.program_name', read_only=True)
    application_phase = serializers.CharField(source='application_phase_guid.application_phase_name', read_only=True)
    application_phase_seq = serializers.CharField(source='application_phase_guid.phase_seq', read_only=True)
    farm_address = serializers.CharField(source='farm_key.address', read_only=True)
    farm_name = serializers.CharField(source='farm_key.farm_name', read_only=True)
    farm_id = serializers.SerializerMethodField('get_farmid')
    municipality = serializers.CharField(source='muni_code.name', read_only=True)
    county = serializers.CharField(source='county_code.county_label', read_only=True)
    completed_tasks = serializers.SerializerMethodField('get_tasks')
    application_id = serializers.SerializerMethodField('get_appid')

    def get_appid(self,app):
        return '-'.join(  ['A',str(app.application_type_guid.application_type_id),'{:>06d}'.format(app.application_key)]  )

    def get_farmid(self,record):
        if record.farm_key:
            return '-'.join(  ['F','{:>06d}'.format(record.farm_key.farm_key)]  )
        else:
            return ''
    def get_user(self,app):
        salutation = app.created_user_guid.salutation
        first = app.created_user_guid.first_name
        last = app.created_user_guid.last_name
        return ' '.join([str(x) for x in [salutation,first,last] if x not in [None,' ','']])

    def get_tasks(self,app):
        #TODO: Need to roll in completed workflow tasks!!!!!!!!!!!!!!
        return [{"task_id":"1a","task_name":"Initiate_Application","task_status":"Complete","task_date":"4/8/17","completed_by":"H.Smith"},
                {"task_id":"2","task_name":"Complete Questionnaire","task_status":"In Progress","task_date":"","completed_by":""}]
    class Meta:
        model = Application
        fields = (
            'application_key',
            'application_id',
            'application_type_guid',
            'application_type',
            'application_category',
            'program_type_guid',
            'program_type',
            'application_phase_guid',
            'application_phase',
            'application_phase_seq',
            'application_date',
            'application_status',
            'farm_key',
            'farm_id',
            'farm_address',
            'farm_name',
            'municipality',
            'county',
            'partner_guid',
            'name_auth',
            'wp_tracker_guid',
            'created_date',
            'created_user_guid',
            'last_edited_date',
            'last_edited_user_guid',
            'completed_tasks'

        )
        flatten = [ ('created_user_guid', UserSerializer),
                    ('last_edited_user_guid', UserSerializer) ]
        read_only_fields = (
            'application_key',
            'application_id',
            'application_type_guid',
            'application_type',
            'application_category',
            'program_type_guid',
            'program_type',
            'application_phase_guid',
            'application_phase',
            'application_phase_seq',
            'application_date',
            'application_status',
            'farm_key',
            'farm_id',
            'farm_address',
            'farm_name',
            'municipality',
            'county',
            'partner_guid',
            'name_auth',
            'wp_tracker_guid',
            'created_date',
            'created_user_guid',
            'last_edited_date',
            'last_edited_user_guid',
            'completed_tasks')

class ApplicationSerializer(serializers.ModelSerializer):
    application_id = serializers.SerializerMethodField('get_appid')
    farm_id = serializers.SerializerMethodField('get_farmid')

    def get_appid(self,app):
        return '-'.join(  ['A',str(app.application_type_guid.application_type_id),'{:>06d}'.format(app.application_key)]  )
    def get_farmid(self,record):
        if record.farm_key:
            return '-'.join(  ['F','{:>06d}'.format(record.farm_key.farm_key)]  )
        else:
            return ''

    class Meta:
        model = Application
        fields = (
            'application_key',
            'application_id',
            'application_type_guid',
            'application_phase_guid',
            'application_date',
            'farm_key',
            'farm_id',
            'muni_code',
            'county_code',
            'partner_guid',
            'program_type_guid',
            'name_auth',
            'wp_tracker_guid',
            'created_date',
            'created_user_guid',
            'last_edited_date',
            'last_edited_user_guid',
            'questionnaire_json'

        )
        read_only_fields = (
                            'application_key',
                            'application_id',
                            'application_type_guid',
                            'farm_key',
                            'farm_id',
                            'created_date',
                            'created_user_guid',
                            'last_edited_date',
                            'last_edited_user_guid')


class ApplicationPhaseSerializer(serializers.ModelSerializer):

    class Meta:
        model = ApplicationPhase
        fields = (
            'application_phase_guid',
            'application_phase_name',
            'phase_seq'
        )


class AppQuestionAnswerSerializer(serializers.ModelSerializer):
    application_id = serializers.SerializerMethodField('get_appid')

    def get_appid(self,ques):
        return '-'.join(  ['A',str(ques.application_key.application_type_guid.application_type_id),'{:>06d}'.format(ques.application_key.application_key)]  )

    class Meta:
        model = AppQuestionAnswer
        fields = (
            'app_question_answer_guid',
            'application_key',
            'application_id',
            'question_guid',
            'answer_json'
        )
        read_only_fields = ('application_id',)


class AnswerUpdateSerializer(serializers.ModelSerializer):
    application_id = serializers.SerializerMethodField('get_appid')

    def get_appid(self,record):
        return '-'.join(  ['A',str(record.application_key.application_type_guid.application_type_id),'{:>06d}'.format(record.application_key.application_key)]  )

    class Meta:
        model = AppQuestionAnswer
        fields = (
            'app_question_answer_guid',
            'application_key',
            'application_id',
            'question_guid',
            'answer_json'
        )
        read_only_fields = ('app_question_answer_guid','application_id')


    def create(self, validated_data):
        #print "create SERIALIZER:", validated_data
        logger.debug( "create SERIALIZER: %s" % validated_data)
        try:
            newanswer = AppQuestionAnswer.objects.create(**validated_data)
            newanswer.save()
            #print "AFTER SAVE"
            logger.debug( "AFTER SAVE")
            return newanswer
        except ValidationError: # it's a django Validataion Error
            #print("ERROR CREATING ANSWER IN SERIALIZER")
            logger.debug("ERROR CREATING ANSWER IN SERIALIZER")

            #raise serializers.ValidationError("Error Creating New User")

    def update(self, instance, validated_data):
        #print 'UPDATE SERIALIZER'
        logger.debug( "UPDATE SERIALIZER")

        instance.answer_json = validated_data.get('answer_json', instance.answer_json)

        instance.save()
        return instance

class TodoListSerializer(serializers.ModelSerializer):

    class Meta:
        model = TodoList
        fields = (
            'todo_list_guid',
            'todo_list_title',
            'todo_list_desc',
            'application_type_guid',
            'todo_list_json'

        )
        read_only_fields = ('todo_list_guid',
            'todo_list_title',
            'todo_list_desc',
            'application_type_guid',
            'todo_list_json')


"""
 #  SEE https://medium.com/django-rest-framework/limit-related-data-choices-with-django-rest-framework-c54e96f5815e
 #  or SEE WxUserRole  and AuthUserSADC-->roles
class AttrPKField(serializers.PrimaryKeyRelatedField):
    def get_queryset(self):
        user = self.context['request'].user
        queryset = Attribute.objects.filter(user=user)
        return queryset
"""
class UsersLimitedSerializer(serializers.ModelSerializer):
    auth_user_guid = serializers.CharField(max_length=36)
    class Meta:
        model = AuthUserSadc
        fields = ('auth_user_guid',
                  'salutation',
                  'first_name',
                  'last_name',
                  'title',
                  'organization')


class RolesLimitedSerializer(serializers.ModelSerializer):
    auth_role_guid = serializers.CharField(max_length=36)
    class Meta:
        model = AuthRoleSadc
        fields = ('auth_role_guid',
                  'auth_role_name')


class ScoreTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = ScoreType
        fields = ('score_type_guid',
                  'score_type_desc')


class TodoItemSerializer(serializers.ModelSerializer):
    application_phase = serializers.CharField(source='application_phase_guid.application_phase_name', read_only=True)
    assigner = serializers.SerializerMethodField('get_name')
    completed_user = serializers.SerializerMethodField('get_compuser')
    users = UsersLimitedSerializer(many=True)
    roles = RolesLimitedSerializer(many=True)
    application_id = serializers.SerializerMethodField('get_appid')
    farm_id = serializers.SerializerMethodField('get_farmid')
    def get_appid(self,record):
        if record.application_key:
            return '-'.join(  ['A',str(record.application_key.application_type_guid.application_type_id),'{:>06d}'.format(record.application_key.application_key)]  )
        else:
            return ''
    def get_farmid(self,record):
        if record.farm_key:
            return '-'.join(  ['F','{:>06d}'.format(record.farm_key.farm_key)]  )
        else:
            return ''

    def get_name(self,item):
        if item.created_user_guid:
            lastnm = item.created_user_guid.last_name
            firstnm = item.created_user_guid.first_name
            return ', '.join([str(x) for x in [lastnm,firstnm] if x not in [None,' ','']])
        else:
            return ''
    def get_compuser(self,item):
        if item.completed_user_guid:
            lastnm = item.completed_user_guid.last_name
            firstnm = item.completed_user_guid.first_name
            return ', '.join([str(x) for x in [lastnm,firstnm] if x not in [None,' ','']])
        else:
            return ''

    class Meta:
        model = TodoItem
        fields = ('todo_item_guid',
                  'todo_item_title',
                  'todo_item_desc',
                  'todo_item_due_date',
                  'todo_item_conditional_flg',
                  'todo_item_completed_flg',
                  'farm_key',
                  'application_key',
                  'farm_id',
                  'application_id',
                  'application_phase_guid',
                  'application_phase',
                  'created_user_guid',
                  'created_date',
                  'completed_date',
                  'completed_user_guid',
                  'completed_user',
                  'assigner',
                  'users',
                  'roles')
        read_only_fields = ('todo_item_guid',
                            'application_phase',
                            'application_id',
                            'farm_id',
                            'assigner',
                            'roles',
                            'users',
                            'created_date',
                            'completed_date',
                            'completed_user_guid',
                            'completed_user')

    def create(self, validated_data):
        #print "create function VALIDATED DATA:", validated_data
        logger.debug( "create function VALIDATED DATA: %s" % validated_data)
        try:
            popped_role_data = validated_data.pop('roles')
            #print 'roles===: ',popped_role_data
            logger.debug( "roles===: %s" % popped_role_data)
            popped_user_data = validated_data.pop('users')
            #print 'users===: ',popped_user_data
            logger.debug( "users===: %s" % popped_user_data)
            newitem = TodoItem.objects.create(**validated_data)
            for role in popped_role_data:
                #print role
                logger.debug( "role %s" % role)
                auth_role_guid = role.get('auth_role_guid')
                try:
                    the_role = AuthRoleSadc.objects.get(pk=auth_role_guid)
                except AuthRoleSadc.DoesNotExist:
                    raise serializers.ValidationError('Invalid role.')
                todorole = WxRoleTodo(todo_item_guid=newitem, auth_role_guid=the_role)
                #print todorole
                logger.debug( "todorole %s" % todorole)
                todorole.save()
            for user in popped_user_data:
                auth_user_guid = user.get('auth_user_guid')
                try:
                    the_user = AuthUserSadc.objects.get(pk=auth_user_guid)
                except AuthUserSadc.DoesNotExist:
                    raise serializers.ValidationError('Invalid user.')
                todouser = WxUserTodo(todo_item_guid=newitem, auth_user_guid=the_user)
                todouser.save()
            #print 'NEWITEM: ',newitem
            logger.debug( "NEWITEM: %s" % newitem)
            newitem.save()
            return newitem
        except ValidationError as e: # it's a django Validataion Error
            #print e
            logger.debug( "Invalid data in todoitem %s" % e)

            #print "Invalid data in todoitem"

    def update(self, instance, validated_data):

        role_ord_dict = validated_data.get('roles', instance.roles)
        instance.roles.clear()
        user_ord_dict = validated_data.get('users', instance.users)
        instance.users.clear()

        for role in role_ord_dict:
            auth_role_guid = role.get('auth_role_guid')
            try:
                the_role = AuthRoleSadc.objects.get(pk=auth_role_guid)
            except AuthRoleSadc.DoesNotExist:
                raise serializers.ValidationError("Invalid role.")
            todorole = WxRoleTodo(todo_item_guid=instance, auth_role_guid=the_role)
            todorole.save()

        for user in user_ord_dict:
            auth_user_guid = user.get('auth_user_guid')
            try:
                the_user = AuthUserSadc.objects.get(pk=auth_user_guid)
            except AuthUserSadc.DoesNotExist:
                raise serializers.ValidationError("Invalid user.")
            todouser = WxUserTodo(todo_item_guid=instance, auth_user_guid=the_user)
            todouser.save()

        instance.todo_item_title = validated_data.get('todo_item_title', instance.todo_item_title)
        instance.todo_item_desc = validated_data.get('todo_item_desc', instance.todo_item_desc)
        instance.todo_item_due_date = validated_data.get('todo_item_due_date', instance.todo_item_due_date)
        instance.todo_item_conditional_flg = validated_data.get('todo_item_conditional_flg', instance.todo_item_conditional_flg)
        instance.todo_item_completed_flg = validated_data.get('todo_item_completed_flg', instance.todo_item_completed_flg)
        #instance.farm_id = validated_data.get('farm_id', instance.farm_id)
        #instance.application_id = validated_data.get('application_id', instance.application_id)
        instance.application_phase_guid = validated_data.get('application_phase_guid', instance.application_phase_guid)

        instance.save()
        return instance



class TodoCompleteSerializer(serializers.ModelSerializer):
    application_phase = serializers.CharField(source='application_phase_guid.application_phase_name', read_only=True)
    assigner = serializers.SerializerMethodField('get_name')
    completed_user = serializers.SerializerMethodField('get_compuser')
    users = UsersLimitedSerializer(many=True)
    roles = RolesLimitedSerializer(many=True)
    application_id = serializers.SerializerMethodField('get_appid')
    farm_id = serializers.SerializerMethodField('get_farmid')

    def get_appid(self,record):
        if record.application_key:
            return '-'.join(  ['A',str(record.application_key.application_type_guid.application_type_id),'{:>06d}'.format(record.application_key.application_key)]  )
        else:
            return ''
    def get_farmid(self,record):
        if record.farm_key:
            return '-'.join(  ['F','{:>06d}'.format(record.farm_key.farm_key)]  )
        else:
            return ''

    def get_name(self,item):
        if item.created_user_guid:
            lastnm = item.created_user_guid.last_name
            firstnm = item.created_user_guid.first_name
            return ', '.join([str(x) for x in [lastnm,firstnm] if x not in [None,' ','']])
        else:
            return ''
    def get_compuser(self,item):
        if item.completed_user_guid:
            lastnm = item.completed_user_guid.last_name
            firstnm = item.completed_user_guid.first_name
            return ', '.join([str(x) for x in [lastnm,firstnm] if x not in [None,' ','']])
        else:
            return ''

    class Meta:
        model = TodoItem
        fields = ('todo_item_guid',
                  'todo_item_title',
                  'todo_item_desc',
                  'todo_item_due_date',
                  'todo_item_conditional_flg',
                  'todo_item_completed_flg',
                  'farm_id',
                  'application_id',
                  'application_phase_guid',
                  'application_phase',
                  'created_user_guid',
                  'created_date',
                  'completed_date',
                  'completed_user_guid',
                  'completed_user',
                  'assigner',
                  'users',
                  'roles')
        read_only_fields = ('todo_item_guid',
                  'todo_item_title',
                  'todo_item_desc',
                  'todo_item_due_date',
                  'todo_item_conditional_flg',
                  'farm_id',
                  'application_id',
                  'application_phase_guid',
                  'application_phase',
                  'created_user_guid',
                  'created_date',
                  'completed_user',
                  'assigner',
                  'users',
                  'roles')



    def update(self, instance, validated_data):

        instance.todo_item_completed_flg = validated_data.get('todo_item_completed_flg', instance.todo_item_completed_flg)
        instance.completed_user_guid = validated_data.get('completed_user_guid', instance.completed_user_guid)
        instance.completed_date = validated_data.get('completed_date', instance.completed_date)

        instance.save()
        return instance


class AppScoreSerializer(serializers.ModelSerializer):
    score_type = serializers.CharField(source='score_type_guid.score_type_desc', read_only=True)
    score = serializers.SerializerMethodField('get_scoreval')
    score_name = serializers.SerializerMethodField('get_scorename')
    created_user = serializers.SerializerMethodField('get_createduser')
    last_edited_user = serializers.SerializerMethodField('get_lastuser')
    application_id = serializers.SerializerMethodField('get_appid')

    def get_appid(self,record):
        if record.application_key:
            return '-'.join(  ['A',str(record.application_key.application_type_guid.application_type_id),'{:>06d}'.format(record.application_key.application_key)]  )
        else:
            return ''

    def get_createduser(self,scorerec):
        if scorerec.created_user_guid:
            first = scorerec.created_user_guid.first_name
            last = scorerec.created_user_guid.last_name
            return ', '.join([str(x) for x in [last,first] if x not in [None,' ','']])
        else:
            return ''
    def get_lastuser(self,scorerec):
        if scorerec.last_edited_user_guid:
            first = scorerec.last_edited_user_guid.first_name
            last = scorerec.last_edited_user_guid.last_name
            return ', '.join([str(x) for x in [last,first] if x not in [None,' ','']])
        else:
            return ''
    def get_scoreval(self,scorerec):
        try:
            return scorerec.score_json['final_score']['score']
        except Exception as e:
            return e.message
    def get_scorename(self,scorerec):
        try:
            return scorerec.score_json['final_score']['scorename']
        except Exception as e:
            return e.message


    class Meta:
            model = Score
            fields = (
                'score_guid',
                'application_key',
                'application_id',
                'score_type_guid',
                'name',
                'description',
                'score_name',
                'score_type',
                'score_status',
                'score',
                'created_date',
                'created_user',
                'created_user_guid',
                'last_edited_date',
                'last_edited_user',
                'last_edited_user_guid',
                'active_flg',
                'current_flg'
            )
            read_only_fields = (
                'application_key',
                'application_id',
                'score_guid',
                'score_type',
                'name',
                'description',
                'score_name',
                'score',
                'created_user_guid',
                'last_edited_date',
                'last_edited_user',
                'last_edited_user_guid',
                'active_flg')


# #*************************************************************************************
# # Application Contacts
# #*************************************************************************************
class AppContactSerializer(serializers.ModelSerializer):
    salutation = serializers.CharField(source='auth_user_guid.salutation', read_only=True)
    first_name = serializers.CharField(source='auth_user_guid.first_name', read_only=True)
    last_name = serializers.CharField(source='auth_user_guid.last_name', read_only=True)
    title = serializers.CharField(source='auth_user_guid.title', read_only=True)
    organization = serializers.CharField(source='auth_user_guid.organization', read_only=True)
    address = serializers.CharField(source='auth_user_guid.address', read_only=True)
    city = serializers.CharField(source='auth_user_guid.city', read_only=True)
    state = serializers.CharField(source='auth_user_guid.state', read_only=True)
    zip = serializers.CharField(source='auth_user_guid.zip', read_only=True)
    phone_primary = serializers.CharField(source='auth_user_guid.phone_primary', read_only=True)
    phone_primary_ext = serializers.CharField(source='auth_user_guid.phone_primary_ext', read_only=True)
    phone_alternate = serializers.CharField(source='auth_user_guid.phone_alternate', read_only=True)
    phone_alternate_ext = serializers.CharField(source='auth_user_guid.phone_alternate_ext', read_only=True)
    email_primary = serializers.CharField(source='auth_user_guid.email_primary', read_only=True)
    email_alternate = serializers.CharField(source='auth_user_guid.email_alternate', read_only=True)
    zip4 = serializers.CharField(source='auth_user_guid.zip4', read_only=True)
    auth_user_status_desc = serializers.CharField(source='auth_user_guid.auth_user_status_desc.auth_user_status_sadc_desc', read_only=True)
    person_type_desc = serializers.CharField(source='auth_user_guid.person_type_desc.person_type_desc', read_only=True)
    application_id = serializers.SerializerMethodField('get_appid')

    def get_appid(self,record):
        if record.application_key:
            return '-'.join(  ['A',str(record.application_key.application_type_guid.application_type_id),'{:>06d}'.format(record.application_key.application_key)]  )
        else:
            return ''

    class Meta:
            model = ApplicationContact
            fields = (
                'application_contact_guid',
                'application_key',
                'application_id',
                'auth_user_guid',
                'contact_type_desc',
                'salutation',
                'first_name',
                'last_name',
                'title',
                'organization',
                'address',
                'city',
                'state',
                'zip',
                'phone_primary',
                'phone_primary_ext',
                'phone_alternate',
                'phone_alternate_ext',
                'email_primary',
                'email_alternate',
                'zip4',
                'auth_user_status_desc',
                'person_type_desc',
                'note'
            )
            read_only_fields = ('application_contact_guid',
                                'application_id',
                                'salutation',
                                'first_name',
                                'last_name',
                                'title',
                                'organization',
                                'address',
                                'city',
                                'state',
                                'zip',
                                'phone_primary',
                                'phone_primary_ext',
                                'phone_alternate',
                                'phone_alternate_ext',
                                'email_primary',
                                'email_alternate',
                                'zip4',
                                'auth_user_status_desc',
                                'person_type_desc')


    def create(self, validated_data):
        #print "create function VALIDATED DATA:", validated_data
        logger.debug( "create function VALIDATED DATA: %s" % validated_data)
        try:
            newcontact = ApplicationContact.objects.create(**validated_data)
            newcontact.save()
            return newcontact
        except ValidationError as e:
            #print 'APPLICATION CONTACT ERROR----------',e.message
            #print("Validation error")
            logger.debug("Validation error %s" % e.message)

class LayerSerializer(serializers.ModelSerializer):

    class Meta:
        model = Layer
        fields = (
            'layer_title',
            'layer_id',
            'service_id',
            'service_url',
            'service_type',
            'layer_type',
            'layer_description',
            'metadata_url',
            'layer_rank',
            'source_layer',
            'active_flg',
            'layer_info_json'
        )
        read_only_fields = (

                            'layer_title',
                            'layer_id',
                            'service_id',
                            'service_url',
                            'service_type',
                            'layer_type',
                            'layer_description',
                            'metadata_url',
                            'layer_rank',
                            'source_layer',
                            'active_flg',
                            'layer_info_json')



class AppMapSerializer(serializers.ModelSerializer):

    class Meta:
        model = ApplicationMap
        fields = (
            'application_map_guid',
            'application_key',
            'map_name',
            'default_map_flg',
            'map_description'
        )
        read_only_fields = (
            'application_map_guid',
            'application_key',
            'map_name',
            'default_map_flg',
            'map_description')
