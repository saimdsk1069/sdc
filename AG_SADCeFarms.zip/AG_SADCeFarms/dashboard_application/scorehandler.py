from AG_SADCeFarms import settings

from common.json_logic import jsonLogic
from copy import deepcopy
import os
import json
import collections
import traceback
import logging

logger = logging.getLogger(__name__)


class ScoreFormula(object):
    def __init__(self, scoreobj=None):
        self.scoreobj = scoreobj
        self.error = ''
        self.valid = self.check_obj()
        self.inputs = []
        self.itemdata = {}

    def check_obj(self):
        if self.scoreobj:
            return True
        else:
            self.error = 'The score obj is not valid'
            return False

    def update_scores(self):
        #print 'update scores----------------'
        logger.debug( "update scores----------------")
        newScores = self.scoreobj['scores']
        inputs = self.scoreobj['inputs']
        #print 'INPUTS',inputs['inp_statevaluation']
        logger.debug( "INPUTS %s" % inputs['inp_statevaluation'])
        try:
            for score in newScores:
                #print '--\n'
                #print 'score',score
                score['score'] = jsonLogic(score['formula'],{k: float(v['score']) for k, v in self.scoreobj['inputs'].iteritems()})
            self.scoreobj['scores'] = newScores

            finalScore = self.scoreobj['final_score']
            finalScore['score'] = jsonLogic(finalScore['formula'],{k: float(v['score']) for k, v in self.scoreobj['inputs'].iteritems()})
            self.scoreobj['final_score'] = finalScore
            return True
        except Exception as e:
            #print e.message
            logger.debug( "Error with updating scores %s" % e.message)
            print traceback.print_exc()
            self.error = 'Error with updating scores'
            return False

    def score_obj(self):
        return self.scoreobj

    def check_valtype(self,val,typeval,choices=None):
        if typeval in ['proportion','currency','float']:
            try:
                float(val)
                return True
            except ValueError:
                return False
        if typeval == 'integer':
            if isinstance(val,int):
                return True
            else:
                return False
        if typeval == 'choice':
            if val in choices:
                return True
            else:
                return False

    def update_inputs(self,inputref=None):
        scoreInputs = self.scoreobj['inputs']

        try:
            inputvals = inputref
            if type(inputvals) is dict:
                if all(id in scoreInputs.keys() for id in inputvals.keys()):
                    for inputid,inputvalue in inputvals.iteritems():
                        inputItem = scoreInputs[inputid]
                        if self.check_valtype(inputvalue,inputItem['inputtype'],inputItem.get('choices',None)):
                            if inputItem['inputtype'] in ['float','currency','integer','proportion']:
                                inputItem['value'] = float(inputvalue)
                                inputItem['score'] = float(jsonLogic(inputItem['formula'],{'val':float(inputvalue)}))
                            else:
                                inputItem['value'] = inputvalue
                                inputItem['score'] = float(jsonLogic(inputItem['formula'],{'val':inputvalue}))
                            scoreInputs[inputid] = inputItem
                        else:
                            raise ValueError('An input value has the wrong type')

                    self.scoreobj['inputs'] = scoreInputs

                    return True
                else:
                    raise ValueError('Input reference not found in scoreobject')
            else:
                raise ValueError('Missing inputs reference')

        except ValueError as err:
            #print(err.args)
            logger.debug("Incorrect input value types %s" % err.args)
            self.valid = False
            self.error = 'Incorrect input value types'
            return False
        except:
            self.valid = False
            self.error = 'Incorrect input value types'
            return False

    #@staticmethod
    def update_nested_dict(self,d, other):
        for k, v in other.iteritems():
            if isinstance(v, collections.Mapping):
                d_v = d.get(k)
                if isinstance(d_v, collections.Mapping):
                    self.update_nested_dict(d_v, v)
                elif isinstance(d_v, list):
                    d[k] = (d[k] + v)
                else:
                    d[k] = v.copy()
            elif isinstance(v, list):
                    d[k] = (d[k] + v)
            else:
                d[k] = v

    def build_output(self):
        try:
            scorefactors = self.scoreobj['factors']
            #print 'FACTORS',scorefactors
            scoreinputs = self.scoreobj['inputs']
            #print 'INPUTS',scoreinputs
            scorecategories = self.scoreobj['categories']
            #print 'CATEGORIES',scorecategories
            scores = {}
            outputDict = {"categories":scorecategories,
                          "finalscore":{"scorename":self.scoreobj['final_score']['scorename'],
                                        "score":self.scoreobj['final_score']['score']}
                          }
            #print 'OUTPUT DICT',outputDict
            for k,v in scorefactors.iteritems():
                for ik,iv in scoreinputs.iteritems():
                    if iv['factorid'] == v['factorid']:
                        self.update_nested_dict(outputDict,{"categories":
                                                              {v["categoryid"]:
                                                                 {"factors":
                                                                    {v["factorid"]:
                                                                       {"factorname":v["factorname"],
                                                                        "description":v["description"],
                                                                        "inputs":[{ "id":iv["id"],
                                                                                    "name":iv["name"],
                                                                                    "value":iv["value"],
                                                                                    "inputtype":iv["inputtype"],
                                                                                    "choices":iv.get("choices",[]),
                                                                                    "score":iv["score"]}],
                                                                        "scores":[]
                                                                        }
                                                                     }
                                                                  }
                                                               }
                                                            })

            """
            for k,v in self.scoreobj['inputs'].iteritems():
                self.update_nested_dict(outputDict,{"categories":
                                                      {v["categoryid"]:
                                                         {"categoryname":v["category"],
                                                          "factors":
                                                            {v["factorid"]:
                                                               {"factorname":v["factorname"],
                                                                "inputs":[{ "id":v["id"],
                                                                            "name":v["name"],
                                                                            "value":v["value"],
                                                                            "inputtype":v["inputtype"],
                                                                            "choices":v.get("choices",[]),
                                                                            "score":v["score"]}],
                                                                "scores":[]
                                                                }
                                                             }
                                                          }
                                                       }
                                                    })

            """
            for score in self.scoreobj['scores']:
                self.update_nested_dict(outputDict,{"categories":
                                                      {str(score["categoryid"]):
                                                         {
                                                          "factors":
                                                                    {score["factorid"]:
                                                                                        {"scores":[
                                                                                                      {"scorename":score["scorename"],"score":score["score"]}
                                                                                                  ]
                                                                                        }
                                                                    }
                                                         }
                                                      }
                                                    })

            #print 'finsihed updating score return object'
            logger.debug( "finsihed updating score return object")
            return outputDict

        except Exception as e:
            self.valid = False
            self.error = 'Could not build score output'
            #print 'SCORE HANDLER EXCEPTION',e.message
            logger.debug("SCORE HANDLER EXCEPTION %s" % e.message)
            return False
