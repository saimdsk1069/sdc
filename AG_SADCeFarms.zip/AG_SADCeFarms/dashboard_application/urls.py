from django.conf.urls import url
import views

urlpatterns = [
        #url(r'^questionnaire/(?P<application_type_guid>.*)$', views.QuestionnaireTemplateItem.as_view(), name="questionnaire"),
        #url(r'^questionnaire/\?(application_type_guid=.*)$', views.QuestionnaireTemplateItem.as_view(), name="questionnaire"),
        url(r'^appinfo/(?P<application_id>.*)$', views.ApplicationInfoItem.as_view(), name="appinfo"),
        url(r'^appcontact$', views.AppContactItem.as_view(), name="appcontact"),
        url(r'^appcontact/(?P<application_id>.*)$', views.AppContactItem.as_view(), name="appcontact"),
        url(r'^appcontacttype$', views.AppContactTypeView.as_view(), name="appcontacttype"),
        url(r'^applist$', views.AppListItem.as_view(), name="applist"),
        url(r'^application/\?(application_id=.*)$', views.ApplicationItem.as_view(), name="application"),
        url(r'^application/(?P<application_id>.*)$', views.ApplicationItem.as_view(), name="application"),
        url(r'^todo$', views.TodoView.as_view(), name="todo"),
        url(r'^todo/(?P<todo_item_guid>.*)$', views.TodoView.as_view(), name="todo"),
        #url(r'^todo/(?P<todo_item_guid>.*)/complete', views.TodoCompleteView.as_view(), name="todocomplete"),
        url(r'^phase$', views.AppPhaseView.as_view(), name="phase"),
        url(r'^phase/(?P<application_id>.*)$', views.AppPhaseView.as_view(), name="phase"),
        url(r'^appanswer$', views.ApplicationAnswer.as_view(), name="appanswer"),
        url(r'^appanswer/(?P<application_id>[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$', views.ApplicationAnswer.as_view(), name="appanswer"),
        url(r'^appanswer/(?P<application_id>[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/(?P<question_guid>[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$', views.ApplicationAnswer.as_view(), name="appanswer"),
        url(r'^appscore$', views.AppScoreItem.as_view(), name="appscore"),
        url(r'^appscore/(?P<application_id>.*)$', views.AppScoreItem.as_view(), name="appscore"),
        url(r'^score/(?P<score_guid>.*)$', views.ScoreItem.as_view(), name="score"),
        url(r'^scoretype$', views.AppScoreType.as_view(), name="scoretype"),
        url(r'^scoretype/(?P<application_id>.*)$', views.AppScoreType.as_view(), name="scoretype"),
        url(r'^appmap/(?P<application_id>.*)$', views.ApplicationMapInfo.as_view(), name="appmap")
        ]
