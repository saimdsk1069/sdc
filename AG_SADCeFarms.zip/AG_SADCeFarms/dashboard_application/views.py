from AG_SADCeFarms import settings
from database.models import (
    Application,
    ApplicationMap,
    ApplicationMapLayer,
    ApplicationPhaseMap,
    Layer,
    ApplicationContact,
    ApplicationContactType,
    AppQuestionAnswer,
    AppQuestionDocument,
    ApplicationPhase,
    ApplicationQuestionnaire,
    Score,
    ScoreStatus,
    ScoreType,
    TodoItem,
    TodoList)
from .appdash_serializers import *
from security import Authenticate
import scorehandler
from django.http import Http404, HttpResponse, JsonResponse
from django.core.exceptions import PermissionDenied, ObjectDoesNotExist
from django.middleware.csrf import get_token
from django.db import IntegrityError
from django.db.models import Q
from django.utils import timezone
from common import Notifications

from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
import app_validations
#
import logging
import traceback
import sys
import json

import hashlib
from datetime import datetime

logger = logging.getLogger(__name__)



"""
TODO: Need to determine the series of events that must happen when initializing an application:
-1- Check User Credentials & Open Period for Application Type
-2- Create Program_Application record - Update with questionnaire data and program phase (Possibly FARM_ID)
-3- Application Contacts (Update)
-4- Workflow Instantiation
-5- ?
a
"""

class AppContactItem(APIView):
    """
        Get/Set Application Contacts
    """
    def get(self, request, application_id=None, format=None):
        cred = Authenticate.get_session_credentials(request)
        userGUID = cred['user_guid']
        if application_id is not None:
            try:
                appkey = int(str(application_id).split('-')[2])
                contacts = ApplicationContact.objects.filter(application_key=appkey)
                c = contacts.filter(auth_user_guid=userGUID)
                if c:

                    # con = ApplicationContact.objects.filter(application_key=appkey)
                    serializer = AppContactSerializer(contacts,many=True)
                else:
                   return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)
            except ApplicationContact.DoesNotExist:
                error = "Application contacts not found"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            error = "No application id provided"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        return JsonResponse(serializer.data, safe=False)


    def put(self, request, format=None):
        if 'application_contact_guid' not in request.data:
            error = "Missing required information"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            try:
                appcontact = ApplicationContact.objects.get(application_contact_guid=request.data['application_contact_guid'])
                serializer = AppContactSerializer(appcontact,data=request.data,partial=True)
                if serializer.is_valid():
                    serializer.save()
                    return JsonResponse(serializer.data, safe=False)
                else:
                    error = "Cannot update contact"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except ApplicationContact.DoesNotExist:
                error = "Application contacts not found"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        if any(x not in request.data for x in ('application_id', 'contact_type_desc', 'auth_user_guid')):
            error = "Missing required contact information"
            return Response({"result": "error", "message": error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            try:
                appkey = int(str(request.data['application_id']).split('-')[2])
                request.data['application_key'] = appkey

                serializer = AppContactSerializer(data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    userrec = AuthUserSadc.objects.get(auth_user_guid=request.data['auth_user_guid'])
                    notification_text = "You have been added as a contact to " + request.data['application_id'] + ""
                    testnot = Notifications.Notifier(notification_text, sendemail=False, users=[userrec], roles=None,
                                                     application_key=appkey, farm_key=None)
                    if testnot.valid:
                        testnot.send_notification()
                    return JsonResponse(serializer.data, safe=False)
                else:
                    error = "Cannot add contact"
                    return Response({"result": "error", "message": error}, status=status.HTTP_400_BAD_REQUEST)
            except Exception as e:
                # print 'ERROR+++++++++++++ ',e.message
                logger.debug("Cannot post new application contact %s" % e.message)
                error = "Cannot post new application contact"
                return Response({"result": "error", "message": error}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, format=None):
        if 'application_contact_guid' not in request.data:
            error = "Missing required information"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        #TODO: Check if user has permissions to manage contacts
        #TODO: NEED TO CHECK whether application_contact is involved with anything
        else:
            try:
                contact = ApplicationContact.objects.get(application_contact_guid=request.data['application_contact_guid'])
                contact.delete()
                return Response({"result":"success","message":""}, status=status.HTTP_200_OK)
            except ApplicationContact.DoesNotExist:
                error = "Contact does not exist"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)



class AppContactTypeView(APIView):
    """
        Application Contact Types
    """
    def get(self, request, format=None):
        try:
            contact_types = ApplicationContactType.objects.all()
            serializer = AppContactTypeSerializer(contact_types, many=True)
            return Response(serializer.data)
        except:
            raise Http404


class AppPhaseView(APIView):
    """
        Get General Application Phases for an Application
    """
    def get(self, request, application_id=None, format=None):
        apptyp = self.request.query_params.get('application_type_guid', None)
        if application_id is not None:
            try:
                appkey = int(str(application_id).split('-')[2])
                app = Application.objects.get(application_key=appkey)
                phases = ApplicationPhase.objects.filter(application_type_guid=app.application_type_guid)
                serializer = ApplicationPhaseSerializer(phases,many=True)
            except ApplicationPhase.DoesNotExist:
                raise Http404
            except Application.DoesNotExist:
                raise Http404
        elif apptyp:
            try:
                phases = ApplicationPhase.objects.filter(application_type_guid=apptyp)
                serializer = ApplicationPhaseSerializer(phases,many=True)
            except:
                raise Http404
        else:
            return Response({"result":"error","message":""}, status=status.HTTP_400_BAD_REQUEST)
        #print serializer.data
        logger.debug( "Serializer data %s" % serializer.data)
        return JsonResponse(serializer.data, safe=False) #Response(serializer.data)



class AppScoreType(APIView):
    """
        Get allowed score types for an application
    """
    #TODO: Need to filter score types by walk across table between application types and scoretypes
    def get(self, request, application_id=None, format=None):
        if application_id is not None:
            try:
                appkey = int(str(application_id).split('-')[2])
                app = Application.objects.get(application_key=appkey)

                scoretypes = ScoreType.objects.filter(active_flg=True)
                serializer = ScoreTypeSerializer(scoretypes,many=True)
            except ScoreType.DoesNotExist:
                raise Http404
            except Application.DoesNotExist:
                raise Http404
        else:
            return Response({"result":"error","message":""}, status=status.HTTP_400_BAD_REQUEST)
        return JsonResponse(serializer.data, safe=False) #Response(serializer.data)


class ApplicationInfoItem(APIView):
    """
        Get General Application Info
    """
    def get(self, request, application_id=None, format=None):
        if application_id is not None:
            try:
                appkey = int(str(application_id).split('-')[2])
                selapp = Application.objects.get(application_key=appkey)

                serializer = ApplicationInfoSerializer(selapp)
            except Application.DoesNotExist:
                raise Http404
        else:
            return Response({"result":"error","message":"No application could be found"}, status=status.HTTP_400_BAD_REQUEST)
        #print serializer.data
        logger.debug("Serializer data %s" % serializer.data)
        return JsonResponse(serializer.data, safe=False) #Response(serializer.data)



class ApplicationItem(APIView):
    """
        Get General Application Info
    """
    def get(self, request, application_id=None, format=None):
        appid = self.request.query_params.get('application_id', None)
        if appid:
        #TODO: User permissions?
            try:
                appkey = int(str(appid).split('-')[2])
                selapp = Application.objects.get(application_key=appkey)
                serializer = ApplicationSerializer(selapp)
            except Application.DoesNotExist:
                raise Http404

        elif application_id is not None:
            try:
                appkey = int(str(application_id).split('-')[2])
                selapp = Application.objects.get(application_key=appkey)
                serializer = ApplicationSerializer(selapp)
            except Application.DoesNotExist:
                raise Http404
        else:
            apps = Application.objects.all().order_by('application_key')

            serializer = ApplicationSerializer(apps, many=True)
        return JsonResponse(serializer.data, safe=False) #Response(serializer.data)

def appid(app):
    return '-'.join(  ['A',str(app.application_type_guid.application_type_id),'{:>06d}'.format(app.application_key)]  )

class AppListItem(APIView):
    """
        Get AppID List
    """
    def get(self, request, format=None):
        #TODO: Need to filter based on role access
        returndata = Application.objects.filter(active_flg=True)
        returnlist = [appid(x) for x in returndata]
        return Response(returnlist)


class ApplicationAnswer(APIView):
    """
        Get / Set Specific Application Answer
    """
    def get(self, request, application_id=None, question_guid=None, format=None):
        if application_id is not None:
            if question_guid is not None:
                try:
                    appkey = int(str(application_id).split('-')[2])
                    selans = AppQuestionAnswer.objects.get(application_key=appkey,question_guid=question_guid)
                    serializer = AppQuestionAnswerSerializer(selans)
                except AppQuestionAnswer.DoesNotExist:
                    raise Http404
            else:
                try:
                    appkey = int(str(application_id).split('-')[2])
                    selans = AppQuestionAnswer.objects.filter(application_key=appkey)
                    serializer = AppQuestionAnswerSerializer(selans, many=True)
                except AppQuestionAnswer.DoesNotExist:
                    raise Http404
        else:
            error = "No record could be found"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        return JsonResponse(serializer.data, safe=False) #Response(serializer.data)


    def put(self, request,format=None):
        if any(x not in request.data for x in ('application_id','questions')):
            error = "Missing required answer information"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        answerinst = app_validations.AnswerHandler(request.data)
        if not answerinst.valid:
            return Response({"result":"error","message":answerinst.error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            # Everything is valid, perform the update operation
            updanswer = answerinst.updateRecs()
            if not updanswer:
                return Response({"result":"error","message":answerinst.error}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return JsonResponse(updanswer, safe=False)

    def post(self, request, format=None):
        if any(x not in request.data for x in ('application_id','questions')):
            error = "Missing required answer information"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        answerinst = app_validations.AnswerHandler(request.data)
        if not answerinst.valid:
            return Response({"result":"error","message":answerinst.error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            # Everything is valid, perform the update operation
            updanswer = answerinst.updateRecs()
            if not updanswer:
                return Response({"result":"error","message":answerinst.error}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return JsonResponse(updanswer, safe=False)
            #We're good to create objects
            #TODO: Need to validate:
            '''1: User Permissions
               2: Application Exists
               3: For each question, validate answer object
            '''





class TodoView(APIView):
    """
        Get Todos for an application
    """
    def get(self, request, todo_item_guid=None, format=None):
        app_id = self.request.query_params.get('application_id', None)
        cred = Authenticate.get_session_credentials(request)
        if not cred:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

        if cred:
            sadcflg = Authenticate.get_user_sadc(request)
            userGUID = cred['user_guid']
            userROLES = [item['role_guid'] for item in cred['roles']]
            publicflg = False
            if todo_item_guid is not None:
                try:

                    if sadcflg:
                        # SADC User- Can get item
                        todos = TodoItem.objects.get(todo_item_guid=todo_item_guid)
                        serializer = TodoItemSerializer(todos)
                    else: # If user is not from SADC, show only assigned todos for user
                        todos = TodoItem.objects.filter(Q(todo_item_guid=todo_item_guid,users__auth_user_guid=userGUID) | Q(todo_item_guid=todo_item_guid,roles__auth_role_guid__in=userROLES))
                        if len(todos) != 1:
                            return Response({"result":"error","message":"No todo item found"}, status=status.HTTP_400_BAD_REQUEST)
                        else:
                            serializer = TodoItemSerializer(todos[0])
                    return JsonResponse(serializer.data, safe=False) #Response(serializer.data)
                except TodoItem.DoesNotExist:
                    # TODO: Need to standardize error code for when user should not have access to TODOs
                    return Response({"result":"error","message":"No todo item found"}, status=status.HTTP_400_BAD_REQUEST)
            elif app_id:
                try:

                    appkey = int(str(app_id).split('-')[2])
                    if sadcflg:
                        # SADC User
                        todos = TodoItem.objects.filter(application_key=appkey)
                        serializer = TodoItemSerializer(todos,many=True)
                    else: # If user is not from SADC, show only assigned todos for user
                        todos = TodoItem.objects.filter(Q(application_key=appkey,users__auth_user_guid=userGUID) | Q(application_key=appkey,roles__auth_role_guid__in=userROLES))
                        serializer = TodoItemSerializer(todos,many=True)
                    return JsonResponse(serializer.data, safe=False) #Response(serializer.data)
                except Exception as e:
                    return Response({"result":"error","message":""}, status=status.HTTP_403_FORBIDDEN)
            else:
                return Response({"result":"error","message":"No todo item found"}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, todo_item_guid=None):
        # TODO: Check whether user role is SADC- DONE
        cred = Authenticate.get_session_credentials(request)
        if not cred:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

        if cred:
            sadcflg = Authenticate.get_user_sadc(request)
            userGUID = cred['user_guid']
            userROLES = [item['role_guid'] for item in cred['roles']]
            publicflg = False

            if 'complete_todo' in request.data:
                if request.data['complete_todo']:
                    try:
                        todoitem = TodoItem.objects.get(todo_item_guid=todo_item_guid)

                        assigneduser = todoitem.created_user_guid.auth_user_guid
                        todousers = [user.auth_user_guid for user in todoitem.users.all()]
                        todoroles = [role.auth_role_guid for role in todoitem.roles.all()]

                        if todoitem.todo_item_completed_flg == True:
                            return Response({"result":"error","message":"Todo already completed"}, status=status.HTTP_400_BAD_REQUEST)
                        # If the user is the assigned or assigner, they can complete the To Do, if not, they can't
                        userPermission = False
                        if any([userGUID==assigneduser,userGUID in todousers]):
                            userPermission = True
                        if any([userrole in todoroles for userrole in userROLES]):
                            userPermission = True
                        if userPermission:
                            serializer = TodoCompleteSerializer(todoitem, data={'completed_user_guid':userGUID,'completed_date':timezone.now(),'todo_item_completed_flg': True },partial=True)
                            if serializer.is_valid():
                                serializer.save()
                                return JsonResponse(serializer.data, safe=False)
                            return Response({"result":"error","message":"Request data not valid"}, status=status.HTTP_400_BAD_REQUEST)
                        else:
                            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)
                    except TodoItem.DoesNotExist:
                        return Response({"result":"error","message":"No todo item could be found"}, status=status.HTTP_400_BAD_REQUEST)

                elif request.data['complete_todo'] == False:
                    try:
                        todoitem = TodoItem.objects.get(todo_item_guid=todo_item_guid)

                        assigneduser = todoitem.created_user_guid.auth_user_guid
                        todousers = [user.auth_user_guid for user in todoitem.users.all()]
                        todoroles = [role.auth_role_guid for role in todoitem.roles.all()]


                        # If the user is the assigned or assigner, they can complete the To Do, if not, they can't
                        userPermission = False
                        if any([userGUID==assigneduser,userGUID in todousers]):
                            userPermission = True
                        if any([userrole in todoroles for userrole in userROLES]):
                            userPermission = True
                        if userPermission:
                            serializer = TodoCompleteSerializer(todoitem, data={'completed_user_guid':None,'completed_date':None,'todo_item_completed_flg': False },partial=True)
                            if serializer.is_valid():
                                serializer.save()
                                return JsonResponse(serializer.data, safe=False)
                            return Response({"result":"error","message":"Request data not valid"}, status=status.HTTP_400_BAD_REQUEST)
                        else:
                            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)
                    except TodoItem.DoesNotExist:
                        return Response({"result":"error","message":"No todo item could be found"}, status=status.HTTP_400_BAD_REQUEST)
            else:
                if not sadcflg:
                    return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)
                if sadcflg:
                    todoguid = None
                    if todo_item_guid is not None:
                        todoguid = todo_item_guid
                    elif self.request.query_params.get('todo_item_guid', None) is not None:
                        todoguid = self.request.query_params.get('todo_item_guid', None)
                    if todoguid is None:
                        return Response({"result":"error","message":"No item exists by that id"}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        try:
                            todoitem = TodoItem.objects.get(todo_item_guid=todoguid)
                            serializer = TodoItemSerializer(todoitem, data=request.data)
                            if serializer.is_valid():
                                serializer.save()
                                return JsonResponse(serializer.data, safe=False)
                            return Response({"result":"error","message":"Request data not valid"}, status=status.HTTP_400_BAD_REQUEST)
                        except TodoItem.DoesNotExist:
                            return Response({"result":"error","message":"No todo item could be found"}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        '''
        Only accepts requests with application_id in query param
        '''
        app_id = self.request.query_params.get('application_id', None)
        if app_id:
            try:
                cred = Authenticate.get_session_credentials(request)
                if not cred:
                    return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

                if cred:
                    sadcflg = Authenticate.get_user_sadc(request)
                    userGUID = cred['user_guid']
                    userROLES = [item['role_guid'] for item in cred['roles']]
                    publicflg = False
                    if not sadcflg:
                        return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)
                    if sadcflg:
                        appkey = int(str(app_id).split('-')[2])
                        apprec = Application.objects.get(application_key=appkey)
                        if type(request.data) == list:
                            try:
                                for item in request.data:
                                    item['application_key'] = appkey
                                    item['farm_key'] = ''

                                serializer = TodoItemSerializer(data=request.data,many=True)
                                if serializer.is_valid():
                                    serializer.save()
                                    for item in request.data:
                                        for user in item['users']:
                                            userrec = AuthUserSadc.objects.get(auth_user_guid=user['auth_user_guid'])
                                            notification_text = "You have been assigned a To-Do item-\n     To-Do: " + item['todo_item_title']
                                            testnote = Notifications.Notifier(notification_text, sendemail=True,users=[userrec], roles=None,application_key=appkey,farm_key=None)
                                            if testnote.valid:
                                                testnote.send_notification()
                                    return JsonResponse(serializer.data, safe=False)
                                else:
                                    #print 'error!',serializer.errors
                                    logger.debug("Request data not valid %s" % serializer.errors)
                                    return Response({"result":"error","message":"Request data not valid"}, status=status.HTTP_400_BAD_REQUEST)
                            except Exception as e:
                                #print 'Exception! ',e.message
                                logger.debug( "Exception! %s" % e.message)
                                return Response({"result":"error","message":""}, status=status.HTTP_400_BAD_REQUEST)

                        else: # Single Item
                            try:
                                request.data['application_key'] = appkey
                                request.data['farm_key'] = ''
                                if request.data['farm_id']:
                                    request.data['farm_key'] = int(str(request.data['farm_id']).split('-')[1])
                                serializer = TodoItemSerializer(data=request.data,partial=True)
                                if serializer.is_valid():
                                    serializer.save()
                                    for user in request.data['users']:
                                        userrec = AuthUserSadc.objects.get(auth_user_guid=user['auth_user_guid'])
                                        notification_text = "You have been assigned a To-Do item-\n     To-Do: " + \
                                                                                request.data['todo_item_title']
                                        testnot = Notifications.Notifier(notification_text, sendemail=False,
                                                                         users=[userrec], roles=None, application_key=appkey,
                                                                         farm_key=None)
                                        if testnot.valid:
                                            testnot.send_notification()
                                    return JsonResponse(serializer.data, safe=False)
                                else:
                                    #print 'ERRORS ', serializer.errors
                                    logger.debug("Request data not valid %s" % serializer.errors)
                                    return Response({"result":"error","message":"Request data not valid"}, status=status.HTTP_400_BAD_REQUEST)
                            except Exception as e:
                                #print 'ERRORMESSAGE ', e.message
                                logger.debug( "ERRORMESSAGE %s" % e.message)
                                return Response({"result":"error","message":e.message}, status=status.HTTP_400_BAD_REQUEST)

            except Exception as e:
                return Response({"result":"error","message":"Cannot find associated application"}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"result":"error","message":"Cannot find associated application"}, status=status.HTTP_400_BAD_REQUEST)


    def delete(self, request,todo_item_guid=None, format=None):
        # TODO: Check whether user role is SADC- DONE
        try:
            cred = Authenticate.get_session_credentials(request)
            if not cred:
                return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

            if cred:
                sadcflg = Authenticate.get_user_sadc(request)
                userguid = cred['user_guid']
                publicflg = False
                if not sadcflg:
                    return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)
                if sadcflg:
                    if not todo_item_guid:
                        error = "No todo_item given"
                        return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        try:
                            todo = TodoItem.objects.get(todo_item_guid=todo_item_guid)
                            todo.users.clear()
                            todo.roles.clear()
                            todo.delete()
                            return Response({"result":"success","message":""}, status=status.HTTP_200_OK )
                        except TodoItem.DoesNotExist:
                            error = "No todo item could be found"
                            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                        return Response({"result":"success","message":""}, status=status.HTTP_200_OK )
        except Expense.DoesNotExist:
            error = "No todo item could be found"
            return Response({"result":"error","message":""}, status=status.HTTP_400_BAD_REQUEST)




class AppScoreItem(APIView):
    """
        Get Scores for a Application
    """
    #TODO: NEED TO INCORPORATE ROLE PERMISSIONS IN FILTERING SCORES to VIEW
    #TODO: SADC should see all, including historic and preliminary
    #TODO: Others may only see current
    def get(self, request, application_id=None, format=None):
        if application_id is not None:
            try:
                appkey = int(str(application_id).split('-')[2])
                #print 'appkey',appkey
                logger.debug( "appkey %s" % appkey)
                #farmkey = int(str(farm_id).split('-')[1])
                scores = Score.objects.filter(application_key=appkey)
                #print scores
                logger.debug("scores %s" % scores)
                serializer = AppScoreSerializer(scores, many=True)
            except Exception as e:
                #print e.message
                logger.debug("Cannot complete request %s" % e.message)
                error = "Cannot complete request"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            error = "Application Id not provided"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

        return JsonResponse(serializer.data, safe=False)

    def post(self, request, format=None):
        if any(x not in request.data for x in ('score_type_guid','application_id','name','description')):
            error = "Missing required attributes: score type, application id, name or description"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            try:
                appkey = int(str(request.data['application_id']).split('-')[2])
                request.data['application_key'] = appkey
                app = Application.objects.get(application_key=appkey)
                scoretype = ScoreType.objects.get(score_type_guid=request.data['score_type_guid'])
                scorestatus = ScoreStatus.objects.get(score_status_desc='DRAFT')
                #TODO: check if user has permissions to create a new score item for this farm
                userAllowed = True
                if userAllowed:
                    newscore = Score(application_key=app,
                                     score_type_guid=scoretype,
                                     name = request.data['name'],
                                     description = request.data['description'],
                                     score_status=scorestatus,
                                     created_date=timezone.now(),
                                     last_edited_date=timezone.now(),
                                     score_json = scoretype.score_type_json,
                                     active_flg = True,
                                     current_flg=False)
                    newscore.save()
                    serializer = AppScoreSerializer(newscore)
                    return JsonResponse(serializer.data, safe=False)
                else:
                    error = "Insufficient permissions"
                    raise PermissionDenied #return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

            except ScoreType.DoesNotExist:
                error = "Not a valid score type"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except Application.DoesNotExist:
                error = "Application record does not exist"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

            except Exception as e:
                #print 'ERROR+++++++++++++ ',e.message
                logger.debug("Cannot create new score %s" % e.message)
                error = "Cannot create new score"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)



class ScoreItem(APIView):
    """
        Get Score information
    """
    #TODO: NEED TO INCORPORATE ROLE PERMISSIONS IN VIEWING/EDITING SCORE DETAILS

    def get(self, request, score_guid=None, format=None):

        if score_guid is not None:
            try:
                scorerec = Score.objects.get(score_guid=score_guid)
                scoreinst = scorehandler.ScoreFormula(scoreobj=scorerec.score_json)
                if not scoreinst.valid:
                    return Response({"result":"error","message":scoreinst.error}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    # Everything is valid, Get the score obj inputs and scores
                    scoreinfo = scoreinst.build_output()
                    if scoreinfo:
                        return JsonResponse({"score_guid":score_guid,"score_json":scoreinfo}, safe=False)
                    else: # Build was not successful, send error message back to client
                        return Response({"result":"error","message":scoreinst.error}, status=status.HTTP_400_BAD_REQUEST)
            except Score.DoesNotExist:
                error = "Score record does not exist"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except Exception as e:
                #print e.message
                logger.debug("Cannot complete request %s" % e.message)
                error = "Cannot complete request"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            error = "No score record id provided"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)


    def put(self, request, score_guid=None, format=None):
        if score_guid is not None:
            try:
                scorerec = Score.objects.get(score_guid=score_guid)
                scoreinst = scorehandler.ScoreFormula(scoreobj=scorerec.score_json)
                if not scoreinst.valid:
                    return Response({"result":"error","message":scoreinst.error}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    # Everything is valid, Proceed with updating the score obj inputs and scores

                    scoreupd = scoreinst.update_inputs(request.data['inputs'])
                    if scoreupd: #Update of inputs was successful
                        scorerecalc = scoreinst.update_scores()
                        if scorerecalc: #Recalculation of scores was successful
                            # Save new score obj in scores table
                            if request.data['name']:
                                scorerec.name = request.data['name']
                            if request.data['description']:
                                scorerec.description = request.data['description']
                            if request.data['score_status']:
                                scorestatus = ScoreStatus.objects.get(score_status_desc=request.data['score_status'])
                                scorerec.score_status = scorestatus
                            scorerec.score_json = scoreinst.score_obj()
                            scorerec.save()
                            # Newscore saved, Get the score obj inputs and scores
                            scoreinfo = scoreinst.build_output()
                            if scoreinfo:
                                return JsonResponse({"score_guid":score_guid,"score_json":scoreinfo}, safe=False)
                            else: # Build was not successful, send error message back to client
                                return Response({"result":"error","message":scoreinst.error}, status=status.HTTP_400_BAD_REQUEST)

                        else: #Recalculation of scores was not successful, send error message back to client and bail out
                            return Response({"result":"error","message":scoreinst.error}, status=status.HTTP_400_BAD_REQUEST)
                        return JsonResponse({"score_guid":score_guid,"score_json":scoreinfo}, safe=False)
                    else: # Update was not successful, send error message back to client and bail out
                        return Response({"result":"error","message":scoreinst.error}, status=status.HTTP_400_BAD_REQUEST)
            except Score.DoesNotExist:
                error = "Score record does not exist"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except ScoreStatus.DoesNotExist:
                error = "Score status does not exist"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except Exception as e:
                #print e.message
                logger.debug("Cannot complete request %s" % e.message)
                error = "Cannot complete request"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            error = "No score record id provided"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, score_guid=None, format=None):
        #TODO: NEED TO INCORPORATE ROLE PERMISSIONS DELETING SCORES- ONLY SADC ADMIN
        #TODO: How do we handle deletions of scores that are official/current?

        if score_guid is not None:
            try:
                scorerec = Score.objects.get(score_guid=score_guid)
                #TODO: Check if scorerec is current and FINAL
                if scorerec.current_flg and scorerec.score_status.score_status_desc == 'FINAL':
                    error = "Cannot delete final/current scores"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                scorerec.delete()
                return Response({"result":"success","message":""}, status=status.HTTP_200_OK )

            except Score.DoesNotExist:
                error = "Score record does not exist"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except Exception as e:
                #print e.message
                logger.debug("Cannot complete request %s" % e.message)
                error = "Cannot complete request"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            error = "No score record id provided"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)


class ApplicationMapInfo(APIView):
    """
        Get General Application Map Info
    """
    def get(self, request, application_id=None, format=None):

        cred = Authenticate.get_session_credentials(request)
        if not cred:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

        if cred:
            sadcflg = Authenticate.get_user_sadc(request)
            userGUID = cred['user_guid']
            userROLES = [item['role_guid'] for item in cred['roles']]

            if application_id is not None:
                try:
                    appkey = int(str(application_id).split('-')[2])
                    selapp = Application.objects.get(application_key=appkey)

                    #TODO: Queries to build mapinfo object
                    #TODO: Check user credentials- DONE
                    #TODO: Get Map Token - Need a class
                    #TODO: Query Basic Map Info- Need a class-where to house reference/basemap layers?
                    #TODO: Map Note Data - hardcoded?
                    #TODO: Query for operational layers and Application Maps-DONE
                    mapedit = True#selapp.application_phase_guid.map_edit
                    #print 'MAPEDIT',mapedit
                    logger.debug("MAPEDIT %s" % mapedit)
                    #TODO:
                    referencelayers = {'url':'',
                                       'layersinfo':[]}
                    basemaplayers = [{},{},{}] #TODO:

                    typelayers = ApplicationMapLayer.objects.filter(application_type_guid=selapp.application_type_guid).values_list('layer_guid', flat=True)
                    oplayers = Layer.objects.filter(layer_guid__in=typelayers)
                    layerserializer = LayerSerializer(oplayers, many=True)
                    operationallayers = layerserializer.data

                    appmaps = ApplicationMap.objects.filter(application_key=selapp)
                    mapserializer = AppMapSerializer(appmaps,many=True)
                    maps = mapserializer.data

                    token = '' #TODO:
                    return JsonResponse({'referencelayers':referencelayers,
                                         'basemaplayers':basemaplayers,
                                         'operationallayers':operationallayers,
                                         'maps':maps,
                                         'mapedit':mapedit,
                                         'token':token}, safe=False) #Response(serializer.data)
                except Application.DoesNotExist:
                    return Response({"result":"error","message":"No application could be found"}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"result":"error","message":"No application could be found"}, status=status.HTTP_400_BAD_REQUEST)

