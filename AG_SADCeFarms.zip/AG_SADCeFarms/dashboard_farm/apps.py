from __future__ import unicode_literals

from django.apps import AppConfig


class DashboardFarmConfig(AppConfig):
    name = 'dashboard_farm'
