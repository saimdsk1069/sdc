from rest_framework import serializers

from database.models import (
    Application,
    AuthUserSadc,
    AuthRoleSadc,
    Farm,
    FarmContact,
    FarmContactType,
    FarmDivision,
    FarmParcel,
    FarmLineage,
    FarmTag,
    Score,
    ScoreType,
    FarmTagType,
    TodoItem,
    WxRoleTodo,
    WxUserTodo)


from django.core.exceptions import ValidationError
from rest_framework.renderers import JSONRenderer
from rest_framework.parsers import JSONParser

import json
import cgi
import logging

logger = logging.getLogger(__name__)

# #*************************************************************************************
# # Farm Contact Type
# #*************************************************************************************
class FarmContactTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = FarmContactType
        fields = (
            'contact_type_desc',
        )

# #*************************************************************************************
# # Farm Applications
# #*************************************************************************************
class FarmAppSerializer(serializers.ModelSerializer):
    application_id = serializers.SerializerMethodField('get_appid')
    application_type = serializers.CharField(source='application_type_guid.application_name', read_only=True)
    application_phase = serializers.CharField(source='application_phase_guid.application_phase_name', read_only=True)
    application_category = serializers.CharField(source='application_type_guid.program_category_desc.program_category_desc', read_only=True)
    partner_name = serializers.CharField(source='partner_guid.partner_name', read_only=True)
    program_type = serializers.CharField(source='program_type_guid.program_name', read_only=True)

    def get_appid(self,app):
        return '-'.join(  ['A',str(app.application_type_guid.application_type_id),'{:>06d}'.format(app.application_key)]  )


    class Meta:
            model = Application
            fields = (
                'application_id',
                'application_type',
                'application_category',
                'application_phase',
                'application_status',
                'application_date',
                'partner_name',
                'program_type',
                'last_edited_date'
            )
            read_only_fields = (
                'application_id',
                'application_type',
                'application_category',
                'application_phase',
                'application_status',
                'application_date',
                'partner_name',
                'program_type',
                'last_edited_date')



# #*************************************************************************************
# # Farm Scores
# #*************************************************************************************
class FarmScoreSerializer(serializers.ModelSerializer):
    score_type = serializers.CharField(source='score_type_guid.score_type_desc', read_only=True)
    score = serializers.SerializerMethodField('get_scoreval')
    score_name = serializers.SerializerMethodField('get_scorename')
    created_user = serializers.SerializerMethodField('get_createduser')
    last_edited_user = serializers.SerializerMethodField('get_lastuser')
    application_id = serializers.SerializerMethodField('get_appid')


    def get_appid(self,record):
        if record.application_key:
            return '-'.join(  ['A',str(record.application_key.application_type_guid.application_type_id),'{:>06d}'.format(record.application_key.application_key)]  )
        else:
            return ''

    def get_createduser(self,scorerec):
        if scorerec.created_user_guid:
            first = scorerec.created_user_guid.first_name
            last = scorerec.created_user_guid.last_name
            return ', '.join([str(x) for x in [last,first] if x not in [None,' ','']])
        else:
            return ''
    def get_lastuser(self,scorerec):
        if scorerec.last_edited_user_guid:
            first = scorerec.last_edited_user_guid.first_name
            last = scorerec.last_edited_user_guid.last_name
            return ', '.join([str(x) for x in [last,first] if x not in [None,' ','']])
        else:
            return ''
    def get_scoreval(self,scorerec):
        try:
            return scorerec.score_json['final_score']['score']
        except Exception as e:
            return e.message
    def get_scorename(self,scorerec):
        try:
            return scorerec.score_json['final_score']['scorename']
        except Exception as e:
            return e.message


    class Meta:
            model = Score
            fields = (
                'score_guid',
                'application_id',
                'score_type_guid',
                'score_name',
                'score_type',
                'name',
                'description',
                'score_status',
                'score',
                'created_date',
                'created_user',
                'created_user_guid',
                'last_edited_date',
                'last_edited_user',
                'last_edited_user_guid',
                'active_flg',
                'current_flg'
            )
            read_only_fields = (
                'score_guid',
                'application_id',
                'score_type_guid',
                'score_name',
                'score_type',
                'name',
                'description',
                'score_status',
                'score',
                'created_date',
                'created_user',
                'created_user_guid',
                'last_edited_date',
                'last_edited_user',
                'last_edited_user_guid',
                'active_flg',
                'current_flg')


# #*************************************************************************************
# # Farm Tag Types
# #*************************************************************************************
class FarmTagTypeSerializer(serializers.ModelSerializer):
    class Meta:
            model = FarmTagType
            fields = (
                'farm_tag_desc','tag_category'
            )
            read_only_fields = ('farm_tag_desc','tag_category')


# Farm ID
class FarmIDSerializer(serializers.ModelSerializer):
    farm_id = serializers.SerializerMethodField('get_farmid')

    def get_farmid(self,farm):
        return '-'.join(  ['F','{:>06d}'.format(farm.farm_key)]  )
    class Meta:
        model = Farm
        fields = (
            'farm_id',
            'farm_name',
        )
        read_only_fields = ('farm_id','farm_name',)




# #*************************************************************************************
# # Farm Parcels
# #*************************************************************************************
class FarmParcelSerializer(serializers.ModelSerializer):
    municipality = serializers.CharField(source='muni_code.name', read_only=True)
    class Meta:
            model = FarmParcel
            fields = (
                'municipality',
                'muni_code',
                'pcl_block',
                'pcl_lot',
                'pclqcode'
            )
            read_only_fields = ('municipality','muni_code','pcl_block','pcl_lot','pclqcode')


# #*************************************************************************************
# # Farm Contacts
# #*************************************************************************************
class FarmContactSerializer(serializers.ModelSerializer):
    salutation = serializers.CharField(source='auth_user_guid.salutation', read_only=True)
    first_name = serializers.CharField(source='auth_user_guid.first_name', read_only=True)
    last_name = serializers.CharField(source='auth_user_guid.last_name', read_only=True)
    title = serializers.CharField(source='auth_user_guid.title', read_only=True)
    organization = serializers.CharField(source='auth_user_guid.organization', read_only=True)
    address = serializers.CharField(source='auth_user_guid.address', read_only=True)
    city = serializers.CharField(source='auth_user_guid.city', read_only=True)
    state = serializers.CharField(source='auth_user_guid.state', read_only=True)
    zip = serializers.CharField(source='auth_user_guid.zip', read_only=True)
    phone_primary = serializers.CharField(source='auth_user_guid.phone_primary', read_only=True)
    phone_primary_ext = serializers.CharField(source='auth_user_guid.phone_primary_ext', read_only=True)
    phone_alternate = serializers.CharField(source='auth_user_guid.phone_alternate', read_only=True)
    phone_alternate_ext = serializers.CharField(source='auth_user_guid.phone_alternate_ext', read_only=True)
    email_primary = serializers.CharField(source='auth_user_guid.email_primary', read_only=True)
    email_alternate = serializers.CharField(source='auth_user_guid.email_alternate', read_only=True)
    zip4 = serializers.CharField(source='auth_user_guid.zip4', read_only=True)
    auth_user_status_desc = serializers.CharField(source='auth_user_guid.auth_user_status_desc.auth_user_status_sadc_desc', read_only=True)
    person_type_desc = serializers.CharField(source='auth_user_guid.person_type_desc.person_type_desc', read_only=True)
    farm_id = serializers.SerializerMethodField('get_farmid')

    def get_farmid(self,record):
        return '-'.join(  ['F','{:>06d}'.format(record.farm_key.farm_key)]  )

    class Meta:
            model = FarmContact
            fields = (
                'farm_contact_guid',
                'farm_key',
                'farm_id',
                'auth_user_guid',
                'contact_type_desc',
                'salutation',
                'first_name',
                'last_name',
                'title',
                'organization',
                'address',
                'city',
                'state',
                'zip',
                'phone_primary',
                'phone_primary_ext',
                'phone_alternate',
                'phone_alternate_ext',
                'email_primary',
                'email_alternate',
                'zip4',
                'auth_user_status_desc',
                'person_type_desc',
                'note'
            )
            read_only_fields = ('farm_id',
                                'farm_contact_guid',
                                'salutation',
                                'first_name',
                                'last_name',
                                'title',
                                'organization',
                                'address',
                                'city',
                                'state',
                                'zip',
                                'phone_primary',
                                'phone_primary_ext',
                                'phone_alternate',
                                'phone_alternate_ext',
                                'email_primary',
                                'email_alternate',
                                'zip4',
                                'auth_user_status_desc',
                                'person_type_desc')


    def create(self, validated_data):
        #print "create function VALIDATED DATA:", validated_data

        try:
            newcontact = FarmContact.objects.create(**validated_data)
            newcontact.save()
            return newcontact
        except ValidationError as e:
            #print 'FARM CONTACT ERROR----------',e.message
            #print("Validation error")
            pass



# #*************************************************************************************
# # Farm Tags
# #*************************************************************************************
class FarmTagSerializer(serializers.ModelSerializer):
    farm_id = serializers.SerializerMethodField('get_farmid')

    def get_farmid(self,record):
        return '-'.join(  ['F','{:>06d}'.format(record.farm_key.farm_key)]  )

    class Meta:
            model = FarmTag
            fields = (
                'seq_id',
                'farm_key',
                'farm_id',
                'farm_tag_desc'
            )
            read_only_fields = ('seq_id','farm_id')


    def create(self, validated_data):
        #print "create function VALIDATED DATA:", validated_data

        try:
            newtag = FarmTag.objects.create(**validated_data)
            newtag.save()
            return newtag
        except ValidationError as e:
            #print 'FARMTAG ERROR----------',e.message
            #print("Validation error")
            pass


# #*************************************************************************************
# # Farm Info
# #*************************************************************************************
class FarmInfoSerializer(serializers.ModelSerializer):
    partner = serializers.CharField(source='partner_guid.partner_name', read_only=True)
    municipality = serializers.CharField(source='muni_code.name', read_only=True)
    county = serializers.CharField(source='muni_code.county', read_only=True)
    farm_tags = FarmTagSerializer(read_only=True, many=True)
    farm_parcels = FarmParcelSerializer(read_only=True, many=True)
    farm_lineage = serializers.SerializerMethodField('get_lineage')
    farm_id = serializers.SerializerMethodField('get_farmid')

    def get_farmid(self,farm):
        return '-'.join(  ['F','{:>06d}'.format(farm.farm_key)]  )

    def get_currency(self,farm):
        if farm.parent_id not in [None,'','None']:
            return False
        else:
            return True

    def get_lineage(self,farm):
        try:
            parents = FarmLineage.objects.filter(child_farm=farm).values_list('parent_farm','division_guid')
            childs = FarmLineage.objects.filter(parent_farm=farm).values_list('child_farm','division_guid')
            parents = [{'parent':'-'.join(  ['F','{:>06d}'.format(f[0])]  ),'division_id':f[1]}  for f in parents]
            childs = [{'child':'-'.join(  ['F','{:>06d}'.format(f[0])]  ),'division_id':f[1]}  for f in childs]
            linnea = {'parents':parents,'children':childs}
            return linnea
        except:
            return {'parents':[],'children':[]}


    #quality_scores = ['127.5','100.4']
    class Meta:
            model = Farm
            fields = (
                'farm_id',
                'farm_name',
                'address',
                'current_flg',
                'municipality',
                'county',
                'active_program_guid',
                'preserved_program_guid',
                'status_preserved_desc',
                'preserved_date',
                'preserved_acres',
                'paid_acres',
                'federal_funding_involved',
                'non_contiguous_parcels',
                'partner',
                'farm_tags',
                'farm_parcels',
                'farm_lineage'

            )
            read_only_fields = (
                'farm_id',
                'farm_name',
                'address',
                'current_flg',
                'municipality',
                'county',
                'active_program_guid',
                'preserved_program_guid',
                'status_preserved_desc',
                'preserved_date',
                'preserved_acres',
                'paid_acres',
                'federal_funding_involved',
                'non_contiguous_parcels',
                'partner',
                'farm_tags',
                'farm_parcels',
                'farm_lineage')
    '''
    def quality_scores(self, obj):
        print 'QUALITY SCORE FOR: ',obj.farm_id
        #scores = Score.objects.filter(farm_id=obj.farm_id,score_type_guid='482bf065-ebd3-4a8c-9ffa-77000525d7f3')
        return obj.farm_id
    '''

#####################################################################################################################
# To-Do Serializers
#####################################################################################################################
class UsersLimitedSerializer(serializers.ModelSerializer):
    auth_user_guid = serializers.CharField(max_length=36)
    class Meta:
        model = AuthUserSadc
        fields = ('auth_user_guid',
                  'salutation',
                  'first_name',
                  'last_name',
                  'title',
                  'organization')


class RolesLimitedSerializer(serializers.ModelSerializer):
    auth_role_guid = serializers.CharField(max_length=36)
    class Meta:
        model = AuthRoleSadc
        fields = ('auth_role_guid',
                  'auth_role_name')



class TodoItemSerializer(serializers.ModelSerializer):
    #application_phase = serializers.CharField(source='application_phase_guid.application_phase_name', read_only=True)
    assigner = serializers.SerializerMethodField('get_name')
    completed_user = serializers.SerializerMethodField('get_compuser')
    users = UsersLimitedSerializer(many=True)
    roles = RolesLimitedSerializer(many=True)
    application_id = serializers.SerializerMethodField('get_appid')
    farm_id = serializers.SerializerMethodField('get_farmid')
    def get_appid(self,record):
        if record.application_key:
            return '-'.join(  ['A',str(record.application_key.application_type_guid.application_type_id),'{:>06d}'.format(record.application_key.application_key)]  )
        else:
            return ''
    def get_farmid(self,record):
        if record.farm_key:
            return '-'.join(  ['F','{:>06d}'.format(record.farm_key.farm_key)]  )
        else:
            return ''

    def get_name(self,item):
        if item.created_user_guid:
            lastnm = item.created_user_guid.last_name
            firstnm = item.created_user_guid.first_name
            return ', '.join([str(x) for x in [lastnm,firstnm] if x not in [None,' ','']])
        else:
            return ''
    def get_compuser(self,item):
        if item.completed_user_guid:
            lastnm = item.completed_user_guid.last_name
            firstnm = item.completed_user_guid.first_name
            return ', '.join([str(x) for x in [lastnm,firstnm] if x not in [None,' ','']])
        else:
            return ''

    class Meta:
        model = TodoItem
        fields = ('todo_item_guid',
                  'todo_item_title',
                  'todo_item_desc',
                  'todo_item_due_date',
                  'todo_item_completed_flg',
                  'farm_key',
                  'application_key',
                  'farm_id',
                  'application_id',
                  'created_user_guid',
                  'created_date',
                  'completed_date',
                  'completed_user_guid',
                  'completed_user',
                  'assigner',
                  'users',
                  'roles')
        read_only_fields = ('todo_item_guid',
                            'application_id',
                            'farm_id',
                            'assigner',
                            'roles',
                            'users',
                            'created_date',
                            'completed_date',
                            'completed_user_guid',
                            'completed_user')

    def create(self, validated_data):
        #print "create function VALIDATED DATA:", validated_data
        try:
            popped_role_data = validated_data.pop('roles')
            #print 'roles===: ',popped_role_data
            popped_user_data = validated_data.pop('users')
            #print 'users===: ',popped_user_data
            newitem = TodoItem.objects.create(**validated_data)
            for role in popped_role_data:
                #print role
                auth_role_guid = role.get('auth_role_guid')
                try:
                    the_role = AuthRoleSadc.objects.get(pk=auth_role_guid)
                except AuthRoleSadc.DoesNotExist:
                    raise serializers.ValidationError('Invalid role.')
                todorole = WxRoleTodo(todo_item_guid=newitem, auth_role_guid=the_role)
                #print todorole
                todorole.save()
            for user in popped_user_data:
                auth_user_guid = user.get('auth_user_guid')
                try:
                    the_user = AuthUserSadc.objects.get(pk=auth_user_guid)

                except AuthUserSadc.DoesNotExist:
                    raise serializers.ValidationError('Invalid user.')
                todouser = WxUserTodo(todo_item_guid=newitem, auth_user_guid=the_user)
                todouser.save()
            #print 'NEWITEM: ',newitem
            newitem.save()
            return newitem
        except ValidationError as e: # it's a django Validataion Error
            #print e
            #print "Invalid data in todoitem"
            pass


    def update(self, instance, validated_data):

        role_ord_dict = validated_data.get('roles', instance.roles)
        instance.roles.clear()
        user_ord_dict = validated_data.get('users', instance.users)
        instance.users.clear()

        for role in role_ord_dict:
            auth_role_guid = role.get('auth_role_guid')
            try:
                the_role = AuthRoleSadc.objects.get(pk=auth_role_guid)
            except AuthRoleSadc.DoesNotExist:
                raise serializers.ValidationError("Invalid role.")
            todorole = WxRoleTodo(todo_item_guid=instance, auth_role_guid=the_role)
            todorole.save()

        for user in user_ord_dict:
            auth_user_guid = user.get('auth_user_guid')
            try:
                the_user = AuthUserSadc.objects.get(pk=auth_user_guid)
            except AuthUserSadc.DoesNotExist:
                raise serializers.ValidationError("Invalid user.")
            todouser = WxUserTodo(todo_item_guid=instance, auth_user_guid=the_user)
            todouser.save()

        instance.todo_item_title = validated_data.get('todo_item_title', instance.todo_item_title)
        instance.todo_item_desc = validated_data.get('todo_item_desc', instance.todo_item_desc)
        instance.todo_item_due_date = validated_data.get('todo_item_due_date', instance.todo_item_due_date)
        instance.todo_item_completed_flg = validated_data.get('todo_item_completed_flg', instance.todo_item_completed_flg)
        #instance.farm_id = validated_data.get('farm_id', instance.farm_id)
        #instance.application_id = validated_data.get('application_id', instance.application_id)
        #instance.application_phase_guid = validated_data.get('application_phase_guid', instance.application_phase_guid)

        instance.save()
        return instance



class TodoCompleteSerializer(serializers.ModelSerializer):
    #application_phase = serializers.CharField(source='application_phase_guid.application_phase_name', read_only=True)
    assigner = serializers.SerializerMethodField('get_name')
    completed_user = serializers.SerializerMethodField('get_compuser')
    users = UsersLimitedSerializer(many=True)
    roles = RolesLimitedSerializer(many=True)
    application_id = serializers.SerializerMethodField('get_appid')
    farm_id = serializers.SerializerMethodField('get_farmid')

    def get_appid(self,record):
        if record.application_key:
            return '-'.join(  ['A',str(record.application_key.application_type_guid.application_type_id),'{:>06d}'.format(record.application_key.application_key)]  )
        else:
            return ''
    def get_farmid(self,record):
        if record.farm_key:
            return '-'.join(  ['F','{:>06d}'.format(record.farm_key.farm_key)]  )
        else:
            return ''

    def get_name(self,item):
        if item.created_user_guid:
            lastnm = item.created_user_guid.last_name
            firstnm = item.created_user_guid.first_name
            return ', '.join([str(x) for x in [lastnm,firstnm] if x not in [None,' ','']])
        else:
            return ''
    def get_compuser(self,item):
        if item.completed_user_guid:
            lastnm = item.completed_user_guid.last_name
            firstnm = item.completed_user_guid.first_name
            return ', '.join([str(x) for x in [lastnm,firstnm] if x not in [None,' ','']])
        else:
            return ''

    class Meta:
        model = TodoItem
        fields = ('todo_item_guid',
                  'todo_item_title',
                  'todo_item_desc',
                  'todo_item_due_date',
                  'todo_item_completed_flg',
                  'farm_id',
                  'application_id',
                  'created_user_guid',
                  'created_date',
                  'completed_date',
                  'completed_user_guid',
                  'completed_user',
                  'assigner',
                  'users',
                  'roles')
        read_only_fields = ('todo_item_guid',
                  'todo_item_title',
                  'todo_item_desc',
                  'todo_item_due_date',
                  'farm_id',
                  'application_id',
                  'created_user_guid',
                  'created_date',
                  'completed_user',
                  'assigner',
                  'users',
                  'roles')



    def update(self, instance, validated_data):

        instance.todo_item_completed_flg = validated_data.get('todo_item_completed_flg', instance.todo_item_completed_flg)
        instance.completed_user_guid = validated_data.get('completed_user_guid', instance.completed_user_guid)
        instance.completed_date = validated_data.get('completed_date', instance.completed_date)

        instance.save()
        return instance