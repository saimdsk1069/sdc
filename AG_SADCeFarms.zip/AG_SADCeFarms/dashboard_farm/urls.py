from django.conf.urls import url
import views

urlpatterns = [
        url(r'^farmcontacttype$', views.FarmContactTypeView.as_view(), name="farmcontacttype" ),
        url(r'^farmtagtype$', views.TagTypeItem.as_view(), name="farmtagtype"),
        url(r'^farmlist$', views.FarmListItem.as_view(), name="farmlist"),
        url(r'^farminfo/(?P<farm_id>.*)$', views.FarmInfoItem.as_view(), name="farminfo"),
        url(r'^farminfo/\?(farm_id=.*)$', views.FarmInfoItem.as_view(), name="farminfo"),
        url(r'^farmtag$', views.FarmTagItem.as_view(), name="farmtag"),
        url(r'^farmtag/(?P<farm_id>.*)$', views.FarmTagItem.as_view(), name="farmtag"),
        url(r'^farmcontact$', views.FarmContactItem.as_view(), name="farmcontact"),
        url(r'^farmcontact/(?P<farm_id>.*)$', views.FarmContactItem.as_view(), name="farmcontact"),
        url(r'^farmcontact/\?(farm_id=.*)$', views.FarmContactItem.as_view(), name="farmcontact"),
        url(r'^farmapp/(?P<farm_id>.*)$', views.FarmAppItem.as_view(), name="farmapp"),
        url(r'^farmapp\?(farm_id=.*)$', views.FarmAppItem.as_view(), name="farmapp"),
        url(r'^farmscore/(?P<farm_id>.*)$', views.FarmScoreItem.as_view(), name="farmscore"),
        url(r'^farmtodo$', views.FarmTodoView.as_view(), name="farmtodo"),
        url(r'^farmtodo/(?P<todo_item_guid>.*)$', views.FarmTodoView.as_view(), name="farmtodo")
        ]
