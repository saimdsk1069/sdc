from AG_SADCeFarms import settings
from database.models import (
    Application,
    Farm,
    FarmContactType,
    FarmDivision,
    FarmLineage,
    FarmParcel,
    FarmTag,
    Score,
    ScoreStatus,
    ScoreType,
    FarmTagType,
    TodoItem,
    TodoList,
    WxRoleTodo,
    WxUserTodo)
from .farm_serializers import *
from security import Authenticate
from common import Notifications

from django.http import Http404, HttpResponse, JsonResponse
from django.core.exceptions import PermissionDenied, ObjectDoesNotExist
from django.middleware.csrf import get_token
from django.db import IntegrityError
from django.utils import timezone
from django.db.models import Q

from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

#
import logging
import traceback
import sys
import json


import hashlib
from datetime import datetime

logger = logging.getLogger(__name__)



class TagTypeItem(APIView):
    """
        Get Farm Tag Type information
    """
    def get(self, request, format=None):
        tagtypes = FarmTagType.objects.all().order_by('tag_category')
        serializer = FarmTagTypeSerializer(tagtypes, many=True)
        return JsonResponse(serializer.data, safe=False) #Response(serializer.data)

class FarmListItem(APIView):
    """
        Get Farm List
    """
    def get(self, request, format=None):
        farmidlist = Farm.objects.all()
        serializer = FarmIDSerializer(farmidlist, many=True)
        return JsonResponse(serializer.data, safe=False) #Response(serializer.data)



class FarmInfoItem(APIView):
    """
        Get Farm Info
    """

    def get(self, request, farm_id=None, format=None):
        farmid = self.request.query_params.get('farm_id', None)
        if farm_id is not None:
            try:
                farmkey = int(str(farm_id).split('-')[1])
                farms = Farm.objects.get(farm_key=farmkey)
                serializer = FarmInfoSerializer(farms)
            except Farm.DoesNotExist:
                error = "Farm does not exist"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        elif farmid:
            try:
                farmkey = int(str(farmid).split('-')[1])
                farms = Farm.objects.get(farm_key=farmkey)
                serializer = FarmInfoSerializer(farms)
            except Farm.DoesNotExist:
                error = "Farm does not exist"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            error = "Farm Id not provided"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

        return JsonResponse(serializer.data, safe=False)


class FarmScoreItem(APIView):
    """
        Get Scores for a Farm
    """
    #TODO: NEED TO INCORPORATE ROLE PERMISSIONS IN FILTERING SCORES to VIEW
    #TODO: SADC should see all, including historic and preliminary
    #TODO: Others may only see current
    def get(self, request, farm_id=None, format=None):
        if farm_id is not None:
            try:
                farmkey = int(str(farm_id).split('-')[1])
                scores = Score.objects.filter(application_key__farm_key=farmkey)
                serializer = FarmScoreSerializer(scores, many=True)
            except:
                error = "Cannot complete request"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            error = "Farm Id not provided"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

        return JsonResponse(serializer.data, safe=False)


class FarmAppItem(APIView):
    """
        Get Applications for a Farm
    """
    #TODO: NEED TO INCORPORATE ROLE PERMISSIONS IN FILTERING ACTIVE APPLICATIONS
    def get(self, request, farm_id=None, format=None):
        farmid = self.request.query_params.get('farm_id', None)
        if farm_id is not None:
            try:
                farmkey = int(str(farm_id).split('-')[1])
                apps = Application.objects.filter(farm_key=farmkey,active_flg=1)
                serializer = FarmAppSerializer(apps, many=True)
            except Application.DoesNotExist:
                error = "No applications found"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        elif farmid:
            try:
                farmkey = int(str(farmid).split('-')[1])
                apps = Application.objects.filter(farm_key=farmkey,active_flg=1)
                serializer = FarmAppSerializer(apps, many=True)
            except Application.DoesNotExist:
                error = "No applications found"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            error = "Farm Id not provided"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

        return JsonResponse(serializer.data, safe=False)


class FarmContactItem(APIView):
    """
        Get Farm Contacts
    """
    def get(self, request, farm_id=None, format=None):
        farmid = self.request.query_params.get('farm_id', None)
        cred = Authenticate.get_session_credentials(request)
        userGUID = cred['user_guid']
        if farm_id is not None:
            try:
                farmkey = int(str(farm_id).split('-')[1])
                contacts = FarmContact.objects.filter(farm_key=farmkey)
                c = contacts.filter(auth_user_guid=userGUID)
                if c:
                    serializer = FarmContactSerializer(contacts, many=True)
                else:
                    return Response({"result": "error", "message": "Insufficient Permissions"},
                                status=status.HTTP_403_FORBIDDEN)
            except FarmContact.DoesNotExist:
                error = "Farm Contact does not exist"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        elif farmid:
            try:
                farmkey = int(str(farmid).split('-')[1])
                contacts = FarmContact.objects.get(farm_key=farmkey)
                c = contacts.filter(auth_user_guid=userGUID)
                if c:
                    serializer = FarmContactSerializer(contacts, many=True)
                else:
                    return Response({"result": "error", "message": "Insufficient Permissions"},
                                    status=status.HTTP_403_FORBIDDEN)
            except FarmContact.DoesNotExist:
                error = "Farm Contact does not exist"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            error = "No farm provided"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        return JsonResponse(serializer.data, safe=False)

    def put(self, request, format=None):
        if 'farm_contact_guid' not in request.data:
            error = "Missing required information"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            try:
                farmcont = FarmContact.objects.get(farm_contact_guid=request.data['farm_contact_guid'])
                serializer = FarmContactSerializer(farmcont,data=request.data,partial=True)
                if serializer.is_valid():
                    serializer.save()
                    return JsonResponse(serializer.data, safe=False)
                else:
                    error = "Cannot update contact"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except FarmContact.DoesNotExist:
                error = "Farm contact record not found"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        if any(x not in request.data for x in ('farm_id','contact_type_desc','auth_user_guid')):
            error = "Missing required contact information"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            try:
                farmkey = int(str(request.data['farm_id']).split('-')[1])
                request.data['farm_key'] = farmkey
                serializer = FarmContactSerializer(data=request.data)
                if serializer.is_valid():
                    serializer.save()

                    userrec = AuthUserSadc.objects.get(auth_user_guid=request.data['auth_user_guid'])
                    notification_text = "You have been added as a contact to " + request.data['farm_id'] + ""
                    testnot = Notifications.Notifier(notification_text, sendemail=False, users=[userrec], roles=None,farm_key=farmkey,application_key=None)
                    if testnot.valid:
                        testnot.send_notification()
                    return JsonResponse(serializer.data, safe=False)
                else:
                    error = "Cannot add contact"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except Exception as e:
                #print 'ERROR+++++++++++++ ',e.message
                error = "Cannot post new farm contact"
                logger.debug("Cannot post new farm contact %s" %  e.message)
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, format=None):
        if 'farm_contact_guid' not in request.data:
            error = "Missing required information"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        #TODO: Check if user has permissions to manage contacts
        #TODO: NEED TO CHECK whether farm_contact is involved with anything
        else:
            try:
                contact = FarmContact.objects.get(farm_contact_guid=request.data['farm_contact_guid'])
                contact.delete()
                return Response({"result":"success","message":""}, status=status.HTTP_200_OK)
            except FarmContact.DoesNotExist:
                error = "Contact does not exist"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)



class FarmContactTypeView(APIView):
    """
        Farm Contact Types
    """
    def get(self, request, format=None):
        try:
            contact_types = FarmContactType.objects.all()
            serializer = FarmContactTypeSerializer(contact_types, many=True)
            return Response(serializer.data)
        except:
            raise Http404


class FarmTagItem(APIView):
    """
        Get Farm Tags
    """
    def get(self, request, farm_id=None, format=None):
        if farm_id is not None:
            try:
                farmkey = int(str(farm_id).split('-')[1])
                tags = FarmTag.objects.filter(farm_key=farmkey)
                serializer = FarmTagSerializer(tags, many=True)
            except FarmTag.DoesNotExist:
                error = "Farm Tag does not exist"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            error = "No farm provided"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

        return JsonResponse(serializer.data, safe=False)


    def post(self, request, format=None):
        if any(x not in request.data for x in ('farm_id','farm_tag_desc')):
            error = "Missing required answer information"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            try:
                #tag = FarmTag.objects.get(farm_id=request.data['farm_id'],tag_desc=request.data['tag_desc'])
                #error = "Tag already exists"
                #return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                farmkey = int(str(request.data['farm_id']).split('-')[1])
                serializer = FarmTagSerializer(data={'farm_key':farmkey,'farm_tag_desc':request.data['farm_tag_desc']})
                if serializer.is_valid():
                    serializer.save()
                    return JsonResponse(serializer.data, safe=False)
                else:
                    error = "Cannot add tag"
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            except Exception as e:
                #print e.message
                error = "Cannot post new farm tag"
                logger.debug( "Cannot post new farm tag %s" % e.message)
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, format=None):
        if any(x not in request.data for x in ('farm_id','farm_tag_desc')):
            error = "Missing required tag information"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            try:
                farmkey = int(str(request.data['farm_id']).split('-')[1])
                tag = FarmTag.objects.get(farm_key=farmkey,farm_tag_desc=request.data['farm_tag_desc'])
                tag.delete()
                return Response({"result":"success","message":""}, status=status.HTTP_200_OK)
            except FarmTag.DoesNotExist:
                error = "Tag does not exist"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

class FarmTodoView(APIView):
    """
        Get Todos for a Farm
    """
    def get(self, request, todo_item_guid=None, format=None):
        farm_id = self.request.query_params.get('farm_id', None)
        cred = Authenticate.get_session_credentials(request)
        if not cred:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

        if cred:
            sadcflg = Authenticate.get_user_sadc(request)
            userGUID = cred['user_guid']
            userROLES = [item['role_guid'] for item in cred['roles']]
            publicflg = False
            if todo_item_guid is not None:
                try:

                    if sadcflg:
                        # SADC User- Can get item
                        todos = TodoItem.objects.get(todo_item_guid=todo_item_guid)
                        serializer = TodoItemSerializer(todos)
                    else: # If user is not from SADC, show only assigned todos for user
                        todos = TodoItem.objects.filter(Q(todo_item_guid=todo_item_guid,users__auth_user_guid=userGUID) | Q(todo_item_guid=todo_item_guid,roles__auth_role_guid__in=userROLES))
                        if len(todos) != 1:
                            return Response({"result":"error","message":"No todo item found"}, status=status.HTTP_400_BAD_REQUEST)
                        else:
                            serializer = TodoItemSerializer(todos[0])
                    return JsonResponse(serializer.data, safe=False) #Response(serializer.data)
                except TodoItem.DoesNotExist:
                    # TODO: Need to standardize error code for when user should not have access to TODOs
                    return Response({"result":"error","message":"No todo item found"}, status=status.HTTP_400_BAD_REQUEST)
            elif farm_id:
                try:

                    farmkey = int(str(farm_id).split('-')[1])
                    if sadcflg:
                        # SADC User
                        todos = TodoItem.objects.filter(farm_key=farmkey)
                        serializer = TodoItemSerializer(todos,many=True)
                    else: # If user is not from SADC, show only assigned todos for user
                        todos = TodoItem.objects.filter(Q(farm_key=farmkey,users__auth_user_guid=userGUID) | Q(farm_key=farmkey,roles__auth_role_guid__in=userROLES))
                        serializer = TodoItemSerializer(todos,many=True)
                    return JsonResponse(serializer.data, safe=False) #Response(serializer.data)
                except Exception as e:
                    return Response({"result":"error","message":""}, status=status.HTTP_403_FORBIDDEN)
            else:
                return Response({"result":"error","message":"No todo item found"}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, todo_item_guid=None):
        # TODO: Check whether user role is SADC- DONE
        cred = Authenticate.get_session_credentials(request)
        if not cred:
            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

        if cred:
            sadcflg = Authenticate.get_user_sadc(request)
            userGUID = cred['user_guid']
            userROLES = [item['role_guid'] for item in cred['roles']]
            publicflg = False

            if 'complete_todo' in request.data:
                if request.data['complete_todo']:
                    try:
                        todoitem = TodoItem.objects.get(todo_item_guid=todo_item_guid)

                        assigneduser = todoitem.created_user_guid.auth_user_guid
                        todousers = [user.auth_user_guid for user in todoitem.users.all()]
                        todoroles = [role.auth_role_guid for role in todoitem.roles.all()]

                        if todoitem.todo_item_completed_flg == True:
                            return Response({"result":"error","message":"Todo already completed"}, status=status.HTTP_400_BAD_REQUEST)
                        # If the user is the assigned or assigner, they can complete the To Do, if not, they can't
                        userPermission = False
                        if any([userGUID==assigneduser,userGUID in todousers]):
                            userPermission = True
                        if any([userrole in todoroles for userrole in userROLES]):
                            userPermission = True
                        if userPermission:
                            serializer = TodoCompleteSerializer(todoitem, data={'completed_user_guid':userGUID,'completed_date':timezone.now(),'todo_item_completed_flg': True },partial=True)
                            if serializer.is_valid():
                                serializer.save()
                                return JsonResponse(serializer.data, safe=False)
                            #print 'ERRORS:',serializer.errors
                            logger.debug("Request data not valid %s" % serializer.errors)
                            return Response({"result":"error","message":"Request data not valid"}, status=status.HTTP_400_BAD_REQUEST)
                        else:
                            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)
                    except TodoItem.DoesNotExist:
                        return Response({"result":"error","message":"No todo item could be found"}, status=status.HTTP_400_BAD_REQUEST)
                elif request.data['complete_todo'] == False:
                    try:
                        todoitem = TodoItem.objects.get(todo_item_guid=todo_item_guid)

                        assigneduser = todoitem.created_user_guid.auth_user_guid
                        todousers = [user.auth_user_guid for user in todoitem.users.all()]
                        todoroles = [role.auth_role_guid for role in todoitem.roles.all()]


                        # If the user is the assigned or assigner, they can complete the To Do, if not, they can't
                        userPermission = False
                        if any([userGUID==assigneduser,userGUID in todousers]):
                            userPermission = True
                        if any([userrole in todoroles for userrole in userROLES]):
                            userPermission = True
                        if userPermission:
                            serializer = TodoCompleteSerializer(todoitem, data={'completed_user_guid':None,'completed_date':None,'todo_item_completed_flg': False },partial=True)
                            if serializer.is_valid():
                                serializer.save()
                                return JsonResponse(serializer.data, safe=False)
                            return Response({"result":"error","message":"Request data not valid"}, status=status.HTTP_400_BAD_REQUEST)
                        else:
                            return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)
                    except TodoItem.DoesNotExist:
                        return Response({"result":"error","message":"No todo item could be found"}, status=status.HTTP_400_BAD_REQUEST)
            else:
                if not sadcflg:
                    return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)
                if sadcflg:
                    todoguid = None
                    if todo_item_guid is not None:
                        todoguid = todo_item_guid
                    elif self.request.query_params.get('todo_item_guid', None) is not None:
                        todoguid = self.request.query_params.get('todo_item_guid', None)
                    if todoguid is None:
                        return Response({"result":"error","message":"No item exists by that id"}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        try:
                            todoitem = TodoItem.objects.get(todo_item_guid=todoguid)
                            serializer = TodoItemSerializer(todoitem, data=request.data)
                            if serializer.is_valid():
                                serializer.save()
                                return JsonResponse(serializer.data, safe=False)
                            return Response({"result":"error","message":"Request data not valid"}, status=status.HTTP_400_BAD_REQUEST)
                        except TodoItem.DoesNotExist:
                            return Response({"result":"error","message":"No todo item could be found"}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        '''
        Only accepts requests with farm_id in query param
        '''
        #print 'POST FARM To-Do'
        logger.debug( "POST FARM To-Do")
        farm_id = self.request.query_params.get('farm_id', None)
        if farm_id:
            try:
                cred = Authenticate.get_session_credentials(request)
                if not cred:
                    return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

                if cred:
                    #print 'has cred'
                    logger.debug( "has cred")
                    sadcflg = Authenticate.get_user_sadc(request)
                    userGUID = cred['user_guid']
                    userROLES = [item['role_guid'] for item in cred['roles']]
                    publicflg = False
                    if not sadcflg:
                        return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)
                    if sadcflg:
                        # print 'has SADC perm'
                        logger.debug( "has SADC perm")
                        farmkey = int(str(farm_id).split('-')[1])
                        farmrec = Farm.objects.get(farm_key=farmkey)
                        if type(request.data) == list:
                            try:
                                for item in request.data:
                                    item['application_key'] = ''
                                    item['farm_key'] = farmkey

                                serializer = TodoItemSerializer(data=request.data,many=True)
                                if serializer.is_valid():
                                    serializer.save()

                                    for item in request.data:
                                        for user in item['users']:
                                            userrec = AuthUserSadc.objects.get(auth_user_guid=user['auth_user_guid'])
                                            notification_text = "You have been assigned a To-Do item-\n     To-Do: " + item['todo_item_title']
                                            testnote = Notifications.Notifier(notification_text, sendemail=True, users=[userrec], roles=None,farm_key=item['farm_key'],application_key=None)
                                            if testnote.valid:
                                                testnote.send_notification()

                                    return JsonResponse(serializer.data, safe=False)
                                else:
                                    #print 'error!',serializer.errors
                                    logger.debug( "error! %s" % serializer.errors)
                                    return Response({"result":"error","message":"Request data not valid"}, status=status.HTTP_400_BAD_REQUEST)
                            except Exception as e:
                                #print 'Exception! ',e.message
                                logger.debug("Exception! %s" % e.message)
                                return Response({"result":"error","message":""}, status=status.HTTP_400_BAD_REQUEST)

                        else: # Single Item
                            #print 'POST SINGLE'
                            logger.debug( "POST SINGLE")
                            try:
                                request.data['application_key'] = ''
                                request.data['farm_key'] = farmkey
                                #if request.data['farm_id']:
                                #    request.data['farm_key'] = int(str(request.data['farm_id']).split('-')[1])
                                serializer = TodoItemSerializer(data=request.data,partial=True)
                                if serializer.is_valid():
                                    serializer.save()

                                    for user in request.data['users']:
                                        userrec = AuthUserSadc.objects.get(auth_user_guid=user['auth_user_guid'])
                                        notification_text = "You have been assigned a To-Do item-\n     To-Do: " + request.data['todo_item_title']
                                        testnot = Notifications.Notifier(notification_text, sendemail=False, users=[userrec], roles=None,farm_key=farmkey,application_key=None)
                                        if testnot.valid:
                                            testnot.send_notification()
                                    return JsonResponse(serializer.data, safe=False)
                                else:
                                    #print 'ERRORS ', serializer.errors
                                    logger.debug("Request data not valid %s" % serializer.errors)
                                    return Response({"result":"error","message":"Request data not valid"}, status=status.HTTP_400_BAD_REQUEST)
                            except Exception as e:
                                #print 'ERRORMESSAGE ', e.message
                                logger.debug( "ERRORMESSAGE %s" % e.message)
                                return Response({"result":"error","message":e.message}, status=status.HTTP_400_BAD_REQUEST)

            except Exception as e:
                return Response({"result":"error","message":"Cannot find associated Farm"}, status=status.HTTP_400_BAD_REQUEST)

        else:
            #print 'NO FARM ID FOUND'
            logger.debug( "NO FARM ID FOUND")
            return Response({"result":"error","message":"No farm id provided"}, status=status.HTTP_400_BAD_REQUEST)


    def delete(self, request,todo_item_guid=None, format=None):
        # TODO: Check whether user role is SADC- DONE
        try:
            cred = Authenticate.get_session_credentials(request)
            if not cred:
                return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)

            if cred:
                sadcflg = Authenticate.get_user_sadc(request)
                userguid = cred['user_guid']
                publicflg = False
                if not sadcflg:
                    return Response({"result": "error", "message": "Insufficient Permissions"}, status=status.HTTP_403_FORBIDDEN)
                if sadcflg:
                    if not todo_item_guid:
                        error = "No todo_item given"
                        return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        try:
                            todo = TodoItem.objects.get(todo_item_guid=todo_item_guid)
                            todo.users.clear()
                            todo.roles.clear()
                            todo.delete()
                            return Response({"result":"success","message":""}, status=status.HTTP_200_OK )
                        except TodoItem.DoesNotExist:
                            error = "No todo item could be found"
                            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                        return Response({"result":"success","message":""}, status=status.HTTP_200_OK )
        except Expense.DoesNotExist:
            error = "No todo item could be found"
            return Response({"result":"error","message":""}, status=status.HTTP_400_BAD_REQUEST)