from __future__ import unicode_literals

from django.apps import AppConfig


class DashboardUserConfig(AppConfig):
    name = 'dashboard_user'
