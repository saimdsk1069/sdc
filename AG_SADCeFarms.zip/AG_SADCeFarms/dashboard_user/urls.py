from django.conf.urls import url
import views

urlpatterns = [
        url(r'^myaccount$', views.UserAccount.as_view(), name="myaccount"),
        url(r'^userinfo$', views.UserInfo.as_view(), name="userinfo"),
        url(r'^notification$', views.NotifyItem.as_view(), name="notification"),
        url(r'^notification/(?P<notify_guid>.*)$', views.NotifyItem.as_view(), name="notification"),

        url(r'^myapps$', views.UserApps.as_view(), name="myapps"),
        url(r'^mytodos$', views.UserTodos.as_view(), name="mytodos")
        ]
