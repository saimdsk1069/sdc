from rest_framework import serializers

from database.models import (Application,
                            AuthUserSadc,
                            AuthRoleSadc,
                            Notification,
                            Partner,
                            TodoItem)
from dashboard_application.appdash_serializers import UsersLimitedSerializer, RolesLimitedSerializer
from django.core.exceptions import ValidationError
from rest_framework.renderers import JSONRenderer
from rest_framework.parsers import JSONParser

import json
import cgi



# ######################################################################################################################
# # Partner Type for Roles
# ######################################################################################################################
class PartnerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Partner
        fields = (
            'partner_guid',
            'partner_name',
            'active_flg',
            'partner_type_desc',
            'county_code',
            'muni_code'
        )

# #*************************************************************************************
# # Roles
# #*************************************************************************************
class AuthRoleSadcSerializer(serializers.ModelSerializer):
    #auth_role_guid = serializers.IntegerField()
    auth_role_guid = serializers.CharField(max_length=36)
    partner_name = serializers.CharField(source='partner_guid.partner_name', read_only=True)
    partner_type = serializers.CharField(source='partner_guid.partner_type_desc.partner_type_desc', read_only=True)
    class Meta:
        model = AuthRoleSadc
        fields = (
            'auth_role_guid',
            'auth_role_name',
            'county_code',
            'muni_code',
            'tier_desc',
            'tier_group_desc',
            'tier_subgroup_desc',
            'partner_guid',
            'partner_name',
            'partner_type'
        )
        read_only_fields=('auth_role_guid',
            'auth_role_name',
            'county_code',
            'muni_code',
            'tier_desc',
            'tier_group_desc',
            'tier_subgroup_desc',
            'partner_guid',
            'partner_name',
            'partner_type')


# #*************************************************************************************
# # Users
# #*************************************************************************************
class AuthUserSadcSerializer(serializers.ModelSerializer):
    role = AuthRoleSadcSerializer(many=True)
    class Meta:
        model = AuthUserSadc
        fields = (
            'auth_user_guid',
            'salutation',
            'first_name',
            'last_name',
            'title',
            'organization',
            'address',
            'address_2',
            'city',
            'state',
            'zip',
            'zip4',
            'email_primary',
            'email_alternate',
            'phone_primary',
            'phone_primary_ext',
            'phone_alternate',
            'phone_alternate_ext',
            'auth_user_status_desc',
            'contact_type_desc',
            'person_type_desc',
            'role',
        )
        read_only_fields = ('auth_user_guid',
            'salutation',
            'first_name',
            'last_name',
            'title',
            'organization',
            'address',
            'address_2',
            'city',
            'state',
            'zip',
            'zip4',
            'email_primary',
            'email_alternate',
            'phone_primary',
            'phone_primary_ext',
            'phone_alternate',
            'phone_alternate_ext',
            'auth_user_status_desc',
            'contact_type_desc',
            'person_type_desc',
            'role')





# #*************************************************************************************
# # Notifications
# #*************************************************************************************
class NotificationSerializer(serializers.ModelSerializer):
    application_id = serializers.SerializerMethodField('get_appid')
    farm_id = serializers.SerializerMethodField('get_farmid')

    def get_appid(self,rec):
        if rec.application_key:
            return '-'.join(['A',str(rec.application_key.application_type_guid.application_type_id),'{:>06d}'.format(rec.application_key.application_key)]  )
        else:
            return ''
    def get_farmid(self,record):
        if record.farm_key:
          return '-'.join(['F','{:>06d}'.format(record.farm_key.farm_key)])
        else:
          return ''

    class Meta:
        model = Notification
        fields = ('notify_guid',
                    'notify_text',
                    'notify_user',
                    'application_id',
                    'farm_id',
                    'created_date',
                    'created_user_guid',
                    'deleted_flg',
                    'cleared_date'

        )
        read_only_fields = ('notify_guid',
                            'notify_text',
                            'notify_user',
                            'application_id',
                            'farm_id',
                            'created_date',
                            'created_user_guid',
                            'deleted_flg',
                            'cleared_date')


# #*************************************************************************************
# # User Applications
# #*************************************************************************************
class AppSerializer(serializers.ModelSerializer):
    application_id = serializers.SerializerMethodField('get_appid')
    application_type = serializers.CharField(source='application_type_guid.application_name', read_only=True)
    application_phase = serializers.CharField(source='application_phase_guid.application_phase_name', read_only=True)
    application_category = serializers.CharField(source='application_type_guid.program_category_desc.program_category_desc', read_only=True)
    partner_name = serializers.CharField(source='partner_guid.partner_name', read_only=True)
    program_type = serializers.CharField(source='program_type_guid.program_name', read_only=True)

    def get_appid(self,app):
        return '-'.join(  ['A',str(app.application_type_guid.application_type_id),'{:>06d}'.format(app.application_key)]  )


    class Meta:
            model = Application
            fields = (
                'application_id',
                'application_type',
                'application_category',
                'application_phase',
                'application_status',
                'application_date',
                'partner_name',
                'program_type',
                'last_edited_date'
            )
            read_only_fields = (
                'application_id',
                'application_type',
                'application_category',
                'application_phase',
                'application_status',
                'application_date',
                'partner_name',
                'program_type',
                'last_edited_date')


# #*************************************************************************************
# # User Todos
# #*************************************************************************************
class TodoSerializer(serializers.ModelSerializer):
    application_phase = serializers.CharField(source='application_phase_guid.application_phase_name', read_only=True)
    assigner = serializers.SerializerMethodField('get_name')
    completed_user = serializers.SerializerMethodField('get_compuser')
    application_id = serializers.SerializerMethodField('get_appid')
    farm_id = serializers.SerializerMethodField('get_farmid')
    users = UsersLimitedSerializer(many=True)
    roles = RolesLimitedSerializer(many=True)
    def get_appid(self,record):
        if record.application_key:
            return '-'.join(  ['A',str(record.application_key.application_type_guid.application_type_id),'{:>06d}'.format(record.application_key.application_key)]  )
        else:
            return ''
    def get_farmid(self,record):
        if record.farm_key:
            return '-'.join(  ['F','{:>06d}'.format(record.farm_key.farm_key)]  )
        else:
            return ''

    def get_name(self,item):
        if item.created_user_guid:
            lastnm = item.created_user_guid.last_name
            firstnm = item.created_user_guid.first_name
            return ', '.join([str(x) for x in [lastnm,firstnm] if x not in [None,' ','']])
        else:
            return ''
    def get_compuser(self,item):
        if item.completed_user_guid:
            lastnm = item.completed_user_guid.last_name
            firstnm = item.completed_user_guid.first_name
            return ', '.join([str(x) for x in [lastnm,firstnm] if x not in [None,' ','']])
        else:
            return ''

    class Meta:
        model = TodoItem
        fields = ('todo_item_guid',
                  'todo_item_title',
                  'todo_item_desc',
                  'todo_item_due_date',
                  'todo_item_conditional_flg',
                  'todo_item_completed_flg',
                  'farm_key',
                  'application_key',
                  'farm_id',
                  'application_id',
                  'application_phase_guid',
                  'application_phase',
                  'created_user_guid',
                  'created_date',
                  'completed_date',
                  'completed_user_guid',
                  'completed_user',
                  'assigner',
                  'users',
                  'roles')
        read_only_fields = ('todo_item_guid',
                  'todo_item_title',
                  'todo_item_desc',
                  'todo_item_due_date',
                  'todo_item_conditional_flg',
                  'todo_item_completed_flg',
                  'farm_key',
                  'application_key',
                  'farm_id',
                  'application_id',
                  'application_phase_guid',
                  'application_phase',
                  'created_user_guid',
                  'created_date',
                  'completed_date',
                  'completed_user_guid',
                  'completed_user',
                  'assigner',
                  'users',
                  'roles')


# #*************************************************************************************
# # User Info
# #*************************************************************************************
class UserInfoSerializer(serializers.ModelSerializer):
    class Meta:
        model = AuthUserSadc
        fields = (
            'auth_user_guid',
            'salutation',
            'first_name',
            'last_name',
            'title',
            'organization',
            'address',
            'address_2',
            'city',
            'state',
            'zip',
            'zip4',
            'email_primary',
            'email_alternate',
            'phone_primary',
            'phone_primary_ext',
            'phone_alternate',
            'phone_alternate_ext'
        )
        read_only_fields = ('auth_user_guid',)


    def update(self, instance, validated_data):
        """
        Update and return an existing `AuthUser` instance, given the validated data.
        """
        #instance.username = validated_data.get('username', instance.username)

        instance.salutation = validated_data.get('salutation', instance.salutation)
        instance.first_name = validated_data.get('first_name', instance.first_name)
        instance.last_name = validated_data.get('last_name', instance.last_name)
        instance.title = validated_data.get('title', instance.title)
        instance.organization = validated_data.get('organization', instance.organization)
        instance.address = validated_data.get('address', instance.address)
        instance.address_2 = validated_data.get('address_2', instance.address_2)
        instance.city = validated_data.get('city', instance.city)
        instance.state = validated_data.get('state', instance.state)
        instance.zip = validated_data.get('zip', instance.zip)
        instance.zip4 = validated_data.get('zip4', instance.zip4)
        instance.email_primary = validated_data.get('email_primary', instance.email_primary)
        instance.email_alternate = validated_data.get('email_alternate', instance.email_alternate)
        instance.phone_primary = validated_data.get('phone_primary', instance.phone_primary)
        instance.phone_primary_ext = validated_data.get('phone_primary_ext', instance.phone_primary_ext)
        instance.phone_alternate = validated_data.get('phone_alternate', instance.phone_alternate)
        instance.phone_alternate_ext = validated_data.get('phone_alternate_ext', instance.phone_alternate_ext)

        instance.save()
        return instance