from AG_SADCeFarms import settings
from database.models import (Application,
                             ApplicationContact,
                             AuthUserSadc,
                             Notification,
                             Partner,
                             TodoItem)
from .userdash_serializers import *
from security import Authenticate

from django.http import Http404, HttpResponse, JsonResponse
from django.core.exceptions import PermissionDenied, ObjectDoesNotExist
from django.middleware.csrf import get_token
from django.db import IntegrityError
from django.db.models import Q
from django.utils import timezone

from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

#
import logging
import traceback
import sys
import json

import hashlib
from datetime import datetime
from django.db.models import Q

logger = logging.getLogger(__name__)

class UserAccount(APIView):
    """
        Get Account Info & Stats for the User
    """
    def get(self, request, auth_user_guid=None,format=None):
        try:
            cred = Authenticate.get_session_credentials(request)
            if not cred:
                #TODO User not authenticated- DONE
                return Response({"result": "error", "message": "User not authenticated"}, status=status.HTTP_403_FORBIDDEN)
            if cred:
                userguid = cred['user_guid']
                seluser = AuthUserSadc.objects.get(auth_user_guid=userguid)
                serializer = AuthUserSadcSerializer(seluser)

                return JsonResponse({"stats":[],"userinfo":serializer.data}, safe=False)
        except AuthUserSadc.DoesNotExist:
            error = "Cannot get account info"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            #print e.message
            logger.debug("Cannot get account info %s" % e.message)
            error = "Cannot get account info"
            logger.debug("Cannot get account info %s" % e.message)
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

class UserApps(APIView):
    """
        Get Applications for the User
    """
    def get(self, request, format=None):
        try:
            cred = Authenticate.get_session_credentials(request)
            if not cred:
                #TODO User not authenticated- DONE
                return Response({"result": "error", "message": "User not authenticated"}, status=status.HTTP_403_FORBIDDEN)

            userSADC = False
            userSADC = Authenticate.get_user_sadc(request)
            #print 'SADC Staff?',userSADC
            logger.debug("SADC Staff? %s" % userSADC)
            if userSADC:
                activeapps = Application.objects.filter(application_status='In Progress')
                inactiveapps = Application.objects.exclude(application_status='In Progress')
                actserializer = AppSerializer(activeapps, many=True)
                inactserializer = AppSerializer(inactiveapps, many=True)
                return JsonResponse({"active_applications":actserializer.data,
                                     "inactive_applications":inactserializer.data}, safe=False)
            if not userSADC:
                userguid = cred['user_guid']
                partners = AuthRoleSadc.objects.filter(wxuserrole__auth_user_guid=userguid).exclude(partner_guid=None).values_list('partner_guid', flat=True)
                apps = ApplicationContact.objects.filter(auth_user_guid=userguid).values_list('application_key', flat=True)

                activeapps = Application.objects.filter(Q(partner_guid__in=partners,application_status='In Progress') | Q(pk__in=apps,application_status='In Progress') )
                inactiveapps = Application.objects.filter(Q(partner_guid__in=partners) |Q(pk__in=apps)).exclude(application_status='In Progress')
                actserializer = AppSerializer(activeapps, many=True)
                inactserializer = AppSerializer(inactiveapps, many=True)
                return JsonResponse({"active_applications":actserializer.data,
                                     "inactive_applications":inactserializer.data}, safe=False)#({"active_applications":actserializer.data,"inactive_applications":[]}, safe=False)
        except Exception as e:
            error = e.message
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

class NotifyItem(APIView):
    """
        Get Notifications for the User
    """
    def get(self, request, format=None):
        try:
            cred = Authenticate.get_session_credentials(request)
            if not cred:
                #TODO User not authenticated- DONE
                return Response({"result": "error", "message": "User not authenticated"}, status=status.HTTP_403_FORBIDDEN)
            if cred:
                userguid = cred['user_guid']
                current_user = AuthUserSadc.objects.get(auth_user_guid=userguid)
                selnotify = Notification.objects.filter(notify_user=current_user,deleted_flg=False).order_by('created_date')
                serializer = NotificationSerializer(selnotify, many=True)
                return JsonResponse(serializer.data, safe=False) #Response(serializer.data)
        except AuthUserSadc.DoesNotExist:
            error = "Request user can't be found"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)


    def delete(self, request, notify_guid=None, format=None):
        try:
            if not notify_guid:
                error = "No notify_guid given"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

            else:

                cred = Authenticate.get_session_credentials(request)
                if not cred:
                    #TODO User not authenticated- DONE
                    return Response({"result": "error", "message": "User not authenticated"}, status=status.HTTP_403_FORBIDDEN)
                if cred:
                    userguid = cred['user_guid']
                    current_user = AuthUserSadc.objects.get(auth_user_guid=userguid)
                    selnotify = Notification.objects.get(notify_guid=notify_guid,deleted_flg=False)

                    if selnotify.notify_user.auth_user_guid == current_user.auth_user_guid:
                        selnotify.deleted_flg = True
                        selnotify.cleared_date = timezone.now()
                        selnotify.save()
                        return Response({"result":"success","message":""}, status=status.HTTP_200_OK)
                    else:
                        return Response({"result":"error","message":""}, status=status.HTTP_403_FORBIDDEN)

        except Notification.DoesNotExist:
            error = "Notification item can't be found"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        except:
            error = "Cannot delete item"
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)



class UserTodos(APIView):
    """
        Get Todo Items for a User
    """
    def get(self, request,format=None):
        app_id = self.request.query_params.get('application_id', None)
        farm_id = self.request.query_params.get('farm_id', None)
        try:
            cred = Authenticate.get_session_credentials(request)
            #print 'todoscred',cred
            logger.debug(" todoscred %s" % cred)

            if not cred:
                #TODO User not authenticated
                return Response({"result": "error", "message": "User not authenticated"}, status=status.HTTP_403_FORBIDDEN)
            if cred:
                userguid = cred['user_guid']
                userRoles = AuthRoleSadc.objects.filter(wxuserrole__auth_user_guid=userguid)
                if app_id:
                    appkey = int(str(app_id).split('-')[2])
                    todorecs = TodoItem.objects.filter(Q(application_key=appkey,users__auth_user_guid=userguid) | Q(application_key=appkey,roles__auth_role_guid__in=userRoles))
                    serializer = TodoSerializer(todorecs,many=True)
                    return JsonResponse(serializer.data, safe=False)
                if farm_id:
                    farmkey = int(str(farm_id).split('-')[1])
                    todorecs = TodoItem.objects.filter(Q(farm_key=farmkey,users__auth_user_guid=userguid) | Q(farm_key=farmkey,roles__auth_role_guid__in=userRoles))
                    serializer = TodoSerializer(todorecs,many=True)
                    return JsonResponse(serializer.data, safe=False)
                else:
                    todorecs = TodoItem.objects.filter(Q(users__auth_user_guid=userguid) | Q(roles__auth_role_guid__in=userRoles)).exclude(todo_item_completed_flg=True)
                    serializer = TodoSerializer(todorecs,many=True)
                    return JsonResponse(serializer.data, safe=False)
        except Exception as e:
            #print e.message
            logger.debug("ERROR %s" % e.message)
            return Response({"result":"error","message":e.message}, status=status.HTTP_400_BAD_REQUEST)



class UserInfo(APIView):
    """
        Update contact information for a user
    """
    def put(self, request):

        try:
            cred = Authenticate.get_session_credentials(request)
            if not cred:
                #TODO User not authenticated
                return Response({"result": "error", "message": "User not authenticated"}, status=status.HTTP_403_FORBIDDEN)
            if cred:
                userguid = cred['user_guid']
                the_user = AuthUserSadc.objects.get(auth_user_guid=userguid)

                logger.debug("REQUEST DATA IN: %s" % request.data)
                serializer = UserInfoSerializer(the_user, data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                logger.debug("SERIALIZER ERRORS: %s" % serializer.errors)
                return Response({"result": "error", "message": serializer.errors }, status=status.HTTP_400_BAD_REQUEST)
        except AuthUserSadc.DoesNotExist:
            error = "err-a002"
            #logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result": "error", "message": error}, status=status.HTTP_400_BAD_REQUEST)