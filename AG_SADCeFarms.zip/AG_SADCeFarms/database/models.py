# eFarms Django Models - DO NOT DELETE OR OVERWRITE
# THIS COPY IS ONLY TO BE MANUALLY UPDATED!!
#
########################################################################

from __future__ import unicode_literals

from django.db import models
from django.utils import timezone

from importlib import import_module
from django.conf import settings
from django.utils import timezone
from security.RequestUser import get_current_user

import jsonfield
import uuid
import logging
import json


logger = logging.getLogger(__name__)

class Ada(models.Model):
    ada_guid = models.CharField(primary_key=True, max_length=36)
    year = models.IntegerField(blank=True, null=True)
    name = models.CharField(max_length=100, blank=True, null=True)
    shape = models.TextField(blank=True, null=True)  # This field type is a guess.
    created_date = models.DateTimeField(blank=True, null=True)
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid', related_name='created_user_ada', blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.ForeignKey('AuthUserSadc', db_column='last_edited_user_guid', related_name='last_edited_user_ada', blank=True, null=True)
    oid = models.BigIntegerField(unique=True, blank=True, null=True)
    calc_acre = models.DecimalField(max_digits=38, decimal_places=3, blank=True, null=True)
    area_sq_foot = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'ada'


class Aoi(models.Model):
    aoi_guid = models.CharField(primary_key=True, max_length=36)
    farm_key = models.ForeignKey('Farm', db_column='farm_key', blank=True, null=True)
    note_group_guid = models.CharField(max_length=36)
    restriction_guid = models.ForeignKey('Restriction', db_column='restriction_guid', blank=True, null=True)
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid', related_name='created_user_aoi', blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.ForeignKey('AuthUserSadc', db_column='last_edited_user_guid', related_name='last_edited_user_aoi', blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    shape = models.TextField(blank=True, null=True)  # This field type is a guess.
    oid = models.BigIntegerField(unique=True, blank=True, null=True)
    idn_gis = models.BigIntegerField(blank=True, null=True)
    calc_acre = models.DecimalField(max_digits=38, decimal_places=3, blank=True, null=True)
    area_sq_foot = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    aoi_category_desc = models.ForeignKey('AoiCategory', db_column='aoi_category_desc', blank=True, null=True)
    aoi_type_desc = models.ForeignKey('AoiType', db_column='aoi_type_desc', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'aoi'


class AoiCategory(models.Model):
    aoi_category_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'aoi_category'


class AoiNaturalResource(models.Model):
    details = models.CharField(max_length=1000, blank=True, null=True)
    nr_impact_area_desc = models.ForeignKey('NrImpactArea', db_column='nr_impact_area_desc', blank=True, null=True)
    nr_issue_desc = models.ForeignKey('NrIssue', db_column='nr_issue_desc', blank=True, null=True)
    aoi_guid = models.ForeignKey('Aoi', db_column='aoi_guid')

    class Meta:
        managed = False
        db_table = 'aoi_natural_resource'


class AoiStructure(models.Model):
    acres = models.IntegerField(blank=True, null=True)
    construction_date = models.DateField(blank=True, null=True)
    existing_flg = models.NullBooleanField()
    number_occupants = models.BigIntegerField(blank=True, null=True)
    demolished_date = models.DateField(blank=True, null=True)
    aoi_guid = models.ForeignKey('Aoi', db_column='aoi_guid', primary_key=True)
    floor_type_desc = models.ForeignKey('FloorType', db_column='floor_type_desc', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'aoi_structure'


class AoiType(models.Model):
    aoi_type_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'aoi_type'


class ApplicationAda(models.Model):
    ada_guid = models.CharField(max_length=36)
    year = models.IntegerField(blank=True, null=True)
    name = models.CharField(max_length=100, blank=True, null=True)
    shape = models.TextField(blank=True, null=True)  # This field type is a guess.
    created_date = models.DateTimeField(blank=True, null=True)
    created_user_guid = models.CharField(max_length=36, blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.CharField(max_length=36, blank=True, null=True)
    oid = models.BigIntegerField()
    calc_acre = models.DecimalField(max_digits=38, decimal_places=3, blank=True, null=True)
    area_sq_foot = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    se_anno_cad_data = models.BinaryField(blank=True, null=True)
    #application_map_guid = models.ForeignKey('ApplicationMap', db_column='application_map_guid', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'application_ada'


class ApplicationAoi(models.Model):
    aoi_guid = models.CharField(max_length=36)
    note_group_guid = models.CharField(max_length=36)
    document_group_guid = models.CharField(max_length=36, blank=True, null=True)
    restriction_guid = models.CharField(max_length=36, blank=True, null=True)
    created_user_guid = models.CharField(max_length=36, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.CharField(max_length=36, blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    shape = models.TextField(blank=True, null=True)  # This field type is a guess.
    oid = models.BigIntegerField()
    idn_gis = models.BigIntegerField(blank=True, null=True)
    calc_acre = models.DecimalField(max_digits=38, decimal_places=3, blank=True, null=True)
    area_sq_foot = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    aoi_category_desc = models.CharField(max_length=100, blank=True, null=True)
    aoi_type_desc = models.CharField(max_length=100, blank=True, null=True)
    se_anno_cad_data = models.BinaryField(blank=True, null=True)
    legacy_flg = models.NullBooleanField()
    #application_map_guid = models.ForeignKey('ApplicationMap', db_column='application_map_guid', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'application_aoi'


class ApplicationContactType(models.Model):
    contact_type_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'application_contact_type'

class ApplicationFarmParcel(models.Model):
    parcel_guid = models.CharField(max_length=36)
    pcl_block = models.CharField(max_length=10, blank=True, null=True)
    pcl_lot = models.CharField(max_length=10, blank=True, null=True)
    pams_pin = models.CharField(max_length=100, blank=True, null=True)
    acres_gross = models.DecimalField(max_digits=38, decimal_places=4, blank=True, null=True)
    acres_net = models.DecimalField(max_digits=38, decimal_places=4, blank=True, null=True)
    acres_paid = models.DecimalField(max_digits=38, decimal_places=4, blank=True, null=True)
    parcel_publish_date = models.DateField(blank=True, null=True)
    oid = models.BigIntegerField()
    shape = models.TextField(blank=True, null=True)  # This field type is a guess.
    created_user_guid = models.CharField(max_length=36, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.CharField(max_length=36, blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    pclqcode = models.CharField(max_length=11, blank=True, null=True)
    idn_gis = models.BigIntegerField(blank=True, null=True)
    muni_code = models.CharField(max_length=4, blank=True, null=True)
    muni_code_original = models.CharField(max_length=4, blank=True, null=True)
    calc_acre = models.DecimalField(max_digits=38, decimal_places=3, blank=True, null=True)
    area_sq_foot = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    pcl_guid = models.CharField(max_length=36, blank=True, null=True)
    pcl_pbdate = models.DateField(blank=True, null=True)
    se_anno_cad_data = models.BinaryField(blank=True, null=True)
    farm_key = models.IntegerField(blank=True, null=True)
    legacy_flg = models.NullBooleanField()
    #application_map_guid = models.ForeignKey('ApplicationMap', db_column='application_map_guid', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'application_farm_parcel'


class ApplicationLayerFilter(models.Model):
    application_layer_filter_guid = models.CharField(primary_key=True, max_length=36)
    application_type_guid = models.ForeignKey('ApplicationType', db_column='application_type_guid', blank=True, null=True)
    layer_guid = models.ForeignKey('Layer', db_column='layer_guid', blank=True, null=True)
    spatial_filter_json = models.TextField(blank=True, null=True)
    attribute_filter_json = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'application_layer_filter'


class ApplicationMap(models.Model):
    application_map_guid = models.CharField(primary_key=True, max_length=36)
    application_key = models.ForeignKey('Application', db_column='application_key', blank=True, null=True)
    map_name = models.CharField(max_length=300, blank=True, null=True)
    default_map_flg = models.NullBooleanField()
    map_description = models.CharField(max_length=1000, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'application_map'


class ApplicationMapLayer(models.Model):
    application_layer_guid = models.CharField(primary_key=True, max_length=36)
    application_type_guid = models.CharField(max_length=36, blank=True, null=True)
    layer_guid = models.CharField(max_length=36, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'application_map_layer'


class ApplicationPaInventory(models.Model):
    pa_inventory_guid = models.CharField(max_length=36)
    year = models.IntegerField(blank=True, null=True)
    shape = models.TextField(blank=True, null=True)  # This field type is a guess.
    pams_pin = models.CharField(max_length=38, blank=True, null=True)
    pclblock = models.CharField(max_length=10, blank=True, null=True)
    pcllot = models.CharField(max_length=10, blank=True, null=True)
    calc_acre = models.DecimalField(max_digits=38, decimal_places=3, blank=True, null=True)
    area_sq_foot = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    pclqcode = models.CharField(max_length=11, blank=True, null=True)
    pin_nodup = models.CharField(max_length=38, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    created_user_guid = models.CharField(max_length=36, blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.CharField(max_length=36, blank=True, null=True)
    oid = models.BigIntegerField()
    muni_code_original = models.CharField(max_length=4, blank=True, null=True)
    muni_code = models.CharField(max_length=4, blank=True, null=True)
    pcl_guid = models.CharField(max_length=36, blank=True, null=True)
    descr = models.CharField(max_length=200, blank=True, null=True)
    inv_type = models.CharField(max_length=3, blank=True, null=True)
    pcl_pbdate = models.DateField(blank=True, null=True)
    se_anno_cad_data = models.BinaryField(blank=True, null=True)
    #application_map_guid = models.ForeignKey('ApplicationMap', db_column='application_map_guid', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'application_pa_inventory'



class ApplicationPhaseMapPerm(models.Model):
    phase_map_guid = models.CharField(primary_key=True, max_length=36)
    application_phase_guid = models.ForeignKey('ApplicationPhase', db_column='application_phase_guid', blank=True, null=True)
    map_edit = models.NullBooleanField()

    class Meta:
        managed = False
        db_table = 'application_phase_map_perm'


class ApplicationProjectArea(models.Model):
    pa_guid = models.CharField(max_length=36)
    name = models.CharField(max_length=100, blank=True, null=True)
    shape = models.TextField(blank=True, null=True)  # This field type is a guess.
    pa_parcel_count = models.IntegerField(blank=True, null=True)
    calc_acre = models.DecimalField(max_digits=38, decimal_places=3, blank=True, null=True)
    area_sq_foot = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    created_user_guid = models.CharField(max_length=36, blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.CharField(max_length=36, blank=True, null=True)
    pa_density = models.FloatField(blank=True, null=True)
    pa_soil_prod = models.FloatField(blank=True, null=True)
    oid = models.BigIntegerField()
    year = models.IntegerField(blank=True, null=True)
    se_anno_cad_data = models.BinaryField(blank=True, null=True)
    #application_map_guid = models.ForeignKey('ApplicationMap', db_column='application_map_guid', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'application_project_area'

class AppQuestionAnswer(models.Model):
    app_question_answer_guid = models.CharField(primary_key=True, max_length=36)
    application_key = models.ForeignKey('Application', db_column='application_key',related_name='app_questionanswer')
    question_guid = models.CharField(max_length=36, blank=True, null=True)
    answer_json = jsonfield.JSONField()
    active_flg = models.NullBooleanField()

    class Meta:
        managed = False
        db_table = 'app_question_answer'

    def save(self, *args, **kwargs):
        # If no guid on save, must be a new record.
        if not self.pk:
            self.app_question_answer_guid = str(uuid.uuid4())
            self.active_flg = 1
        super(AppQuestionAnswer, self).save(*args, **kwargs)



class AppQuestionDocument(models.Model):
    app_question_document_guid = models.CharField(primary_key=True, max_length=36)
    application_key = models.ForeignKey('Application', models.DO_NOTHING, db_column='application_key', blank=True, null=True)
    document_guid = models.ForeignKey('Document', db_column='document_guid', blank=True, null=True)
    active_flg = models.NullBooleanField()
    question_guid = models.CharField(max_length=36, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'app_question_document'



class Application(models.Model):
    application_key = models.AutoField(primary_key=True)
    application_type_guid = models.ForeignKey('ApplicationType', db_column='application_type_guid', related_name='apptype', blank=True, null=True)
    application_phase_guid = models.ForeignKey('ApplicationPhase', db_column='application_phase_guid', related_name='appphase', blank=True, null=True)
    application_status = models.ForeignKey('ApplicationStatus', db_column='application_status', related_name='appstatus', blank=True, null=True)
    application_date = models.DateField(blank=True, null=True)
    farm_key = models.ForeignKey('Farm', db_column='farm_key', related_name='farm_apps', blank=True, null=True)
    muni_code = models.ForeignKey('Municipality', db_column='muni_code', related_name='appmuni', blank=True, null=True)
    county_code = models.ForeignKey('County', db_column='county_code', related_name='appcounty', blank=True, null=True)
    partner_guid = models.ForeignKey('Partner', db_column='partner_guid', related_name='apppartner', blank=True, null=True)
    questionnaire_json = jsonfield.JSONField()
    name_auth = models.CharField(max_length=40, blank=True, null=True)
    wp_tracker_guid = models.CharField(max_length=36, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid', related_name='appcreateduser', blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.ForeignKey('AuthUserSadc', db_column='last_edited_user_guid', related_name='appediteduser', blank=True, null=True)
    active_flg = models.NullBooleanField()
    program_type_guid = models.ForeignKey('ProgramType', db_column='program_type_guid', related_name='appprogram', blank=True, null=True)
    #contacts = models.ManyToManyField( AuthUserSadc, through='ApplicationContact', related_name='contactsapp')
    class Meta:
        managed = False
        db_table = 'application'


class ApplicationContact(models.Model):
    application_contact_guid = models.CharField(primary_key=True, max_length=36)
    application_key = models.ForeignKey('Application', db_column='application_key', blank=True, null=True)
    auth_user_guid = models.ForeignKey('AuthUserSadc', db_column='auth_user_guid', blank=True, null=True)
    active_flg = models.NullBooleanField()
    contact_type_desc = models.ForeignKey('ApplicationContactType', db_column='contact_type_desc', blank=True, null=True)
    note = models.CharField(max_length=2000, blank=True, null=True)

    class Meta:
        unique_together = ('application_key','contact_type_desc')
        managed = False
        db_table = 'application_contact'

    def save(self, *args, **kwargs):
        # If no guid on save, must be a new record.
        if self.application_contact_guid == '':
            logger.debug("Empty application_contact_guid during save")
            self.application_contact_guid = str(uuid.uuid4())
            self.active_flg = 1
        super(ApplicationContact, self).save(*args, **kwargs)
        logger.debug("ApplicationContact %s saved" % self.application_contact_guid )



# class ApplicationMap(models.Model):
#     application_map_guid = models.CharField(primary_key=True, max_length=36)
#     application_key = models.ForeignKey('Application', db_column='application_key',related_name='application_maps', blank=True, null=True)
#     map_name = models.CharField(max_length=300, blank=True, null=True)
#     default_map_flg = models.BooleanField()
#     map_description = models.CharField(max_length=1000, blank=True, null=True)
#
#     class Meta:
#         managed = False
#         db_table = 'application_map'
#
#
# class ApplicationMapLayer(models.Model):
#     application_layer_guid = models.CharField(primary_key=True, max_length=36)
#     application_type_guid = models.ForeignKey('ApplicationType', db_column='application_type_guid', blank=True, null=True)
#     layer_guid = models.ForeignKey('Layer', db_column='layer_guid', blank=True,related_name='app_layers', null=True)
#
#     class Meta:
#         managed = False
#         db_table = 'application_map_layer'



class ApplicationPhase(models.Model):
    application_phase_guid = models.CharField(primary_key=True, max_length=36)
    application_type_guid = models.ForeignKey('ApplicationType', db_column='application_type_guid',related_name='apptype_appphase', blank=True, null=True)
    application_phase_name = models.CharField(max_length=100)
    info = models.CharField(max_length=500, blank=True, null=True)
    phase_seq = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'application_phase'


class ApplicationPhaseMap(models.Model):
    phase_map_guid = models.CharField(primary_key=True, max_length=36)
    application_phase_guid = models.ForeignKey('ApplicationPhase', db_column='application_phase_guid', blank=True, null=True)
    map_edit = models.BooleanField()

    class Meta:
        managed = False
        db_table = 'application_phase_map'

class ApplicationQuestionnaire(models.Model):
    application_questionnaire_guid = models.CharField(primary_key=True, max_length=36)
    application_type_guid = models.ForeignKey('ApplicationType', db_column='application_type_guid',related_name='apptype_questions', blank=True, null=True)
    year = models.IntegerField(blank=True, null=True)
    questionnaire_json = jsonfield.JSONField()
    active_flg = models.NullBooleanField()
    created_user_guid = models.CharField(max_length=36, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.CharField(max_length=36, blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'application_questionnaire'


class ApplicationReview(models.Model):
    app_review_guid = models.CharField(primary_key=True, max_length=36)
    application_key = models.ForeignKey('Application', db_column='application_key', related_name='app_review')
    #note_group_guid = models.ForeignKey('NoteGroup', models.DO_NOTHING, db_column='note_group_guid', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'application_review'


class ApplicationStatus(models.Model):
    application_status_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'application_status'


class ApplicationTfParcel(models.Model):
    tf_guid = models.CharField(max_length=36)
    year = models.IntegerField(blank=True, null=True)
    owner_name = models.CharField(max_length=200, blank=True, null=True)
    shape = models.TextField(blank=True, null=True)  # This field type is a guess.
    pams_pin = models.CharField(max_length=38, blank=True, null=True)
    pclblock = models.CharField(max_length=10, blank=True, null=True)
    pcllot = models.CharField(max_length=10, blank=True, null=True)
    st_address = models.CharField(max_length=255, blank=True, null=True)
    city_state = models.CharField(max_length=50, blank=True, null=True)
    zip_code = models.CharField(max_length=5, blank=True, null=True)
    calc_acre = models.DecimalField(max_digits=38, decimal_places=3, blank=True, null=True)
    area_sq_foot = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    pclqcode = models.CharField(max_length=11, blank=True, null=True)
    pin_nodup = models.CharField(max_length=38, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    created_user_guid = models.CharField(max_length=36, blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.CharField(max_length=36, blank=True, null=True)
    farm_name = models.CharField(max_length=100, blank=True, null=True)
    oid = models.BigIntegerField()
    muni_code_original = models.CharField(max_length=4, blank=True, null=True)
    muni_code = models.CharField(max_length=4, blank=True, null=True)
    pcl_guid = models.CharField(max_length=36, blank=True, null=True)
    pcl_pbdate = models.DateField(blank=True, null=True)
    se_anno_cad_data = models.BinaryField(blank=True, null=True)
    application_map_guid = models.ForeignKey('ApplicationMap', db_column='application_map_guid', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'application_tf_parcel'



class ApplicationType(models.Model):
    application_type_guid = models.CharField(primary_key=True, max_length=36)
    application_type_id = models.IntegerField(blank=True, null=True)
    program_category_code = models.ForeignKey('ProgramCategory', db_column='program_category_code', related_name='program_category_apptype',blank=True, null=True)
    application_name = models.CharField(max_length=100, blank=True, null=True)
    application_description = models.CharField(max_length=500, blank=True, null=True)
    fiscal_reports_id = models.CharField(max_length=20, blank=True, null=True)
    legacy = models.NullBooleanField()
    active_flg = models.NullBooleanField()

    class Meta:
        managed = False
        db_table = 'application_type'


class Appraisal(models.Model):
    appraisal_guid = models.CharField(primary_key=True, max_length=36)
    appraiser = models.CharField(max_length=36, blank=True, null=True)
    application_key = models.ForeignKey('Application', db_column='application_key',related_name='app_appraisal', blank=True, null=True)
    farm_key = models.ForeignKey('Farm', db_column='farm_key', related_name='farm_appraisal',blank=True, null=True)
    appraisal_type_desc = models.ForeignKey('AppraisalType', db_column='appraisal_type_desc', related_name='appraisal_type_apprais',blank=True, null=True)
    appraisal_info_clob = jsonfield.JSONField()
    appraisal_date = models.DateField(blank=True, null=True)
    appraisal_review_desc = models.ForeignKey('AppraisalReview', db_column='appraisal_review_desc',related_name='appraisal_review_type_apprais', blank=True, null=True)
    cmv_guid = models.ForeignKey('Cmv', db_column='cmv_guid', related_name='cmv_appraisal',blank=True, null=True)
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid', blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'appraisal'



class AppraisalReview(models.Model):
    appraisal_review_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'appraisal_review'


class AppraisalType(models.Model):
    appraisal_type_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'appraisal_type'


class Appropriation(models.Model):
    appropriation_guid = models.CharField(primary_key=True, max_length=36)
    appropriation_unit = models.CharField(max_length=50, blank=True, null=True)
    #appropriation_name = models.CharField(max_length=50, blank=True, null=True)
    year = models.IntegerField(blank=True, null=True)
    program_type_guid = models.ForeignKey('ProgramType', db_column='program_type_guid',related_name='program_type_approp', blank=True, null=True)
    fund_guid = models.ForeignKey('Fund', db_column='fund_guid',related_name='fund_approps', blank=True, null=True)
    pl_type = models.CharField(max_length=50, blank=True, null=True)
    grant_type_desc = models.ForeignKey('GrantType', db_column='grant_type_desc', blank=True, null=True)
    initial_amount = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    encumbered = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    spent = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    balance = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    pending = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    reappropriated_out = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    reappropriated_in = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    appropriation_date = models.DateField(blank=True, null=True)
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid',related_name='user_createdapprops', blank=True, null=True)
    created_date = models.DateTimeField(auto_now_add=True,blank=True, null=True)
    last_edited_user_guid = models.ForeignKey('AuthUserSadc', db_column='last_edited_user_guid',related_name='user_editapprops', blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'appropriation'

    def save(self, *args, **kwargs):
        user = None
        userid = get_current_user()
        if userid:
            user = AuthUserSadc.objects.get(pk=userid)
        # If no pk on save, must be a new record.
        if not self.pk:
            logger.debug("Empty appropriation_guid during save")

            self.appropriation_guid = str(uuid.uuid4())
            self.created_date = timezone.now()
            self.created_user_guid = user
            self.balance = self.initial_amount
            self.encumbered = 0.0
            self.spent = 0.0
            self.pending = 0.0
            self.reappropriated_out = 0.0
            self.reappropriated_in = 0.0
        self.last_edited_date = timezone.now()
        self.last_edited_user_guid = user
        super(Appropriation, self).save(*args, **kwargs)
        logger.debug("Appropriation %s saved" % self.appropriation_guid )


class AuthPermissionSadc(models.Model):
    farm_key = models.ForeignKey('Farm', db_column='farm_key')
    auth_user_guid = models.CharField(max_length=36)
    auth_role_guid = models.ForeignKey('AuthRoleSadc', db_column='auth_role_guid')
    active_flg = models.NullBooleanField()
    application_key = models.ForeignKey('Application', db_column='application_key', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'auth_permission_sadc'


class AuthRoleSadc(models.Model):
    auth_role_guid = models.CharField(primary_key=True, max_length=36)
    auth_role_name = models.CharField(max_length=300, blank=True, null=True)
    description = models.CharField(max_length=55, blank=True, null=True)
    admin_managed = models.BigIntegerField(blank=True, null=True)
    county_code = models.ForeignKey('County', db_column='county_code', blank=True, null=True)
    muni_code = models.ForeignKey('Municipality', db_column='muni_code', blank=True, null=True)
    tier_desc = models.CharField(max_length=100, blank=True, null=True)
    tier_group_desc = models.CharField(max_length=100, blank=True, null=True)
    tier_subgroup_desc = models.CharField(max_length=100, blank=True, null=True)
    partner_guid = models.ForeignKey('Partner', db_column='partner_guid', blank=True, null=True)
    active_flg = models.NullBooleanField()

    class Meta:
        managed = False
        db_table = 'auth_role_sadc'

    def save(self, *args, **kwargs):
        # If no guid on save, must be a new record.
        if self.auth_role_guid == '':
            self.auth_role_guid = str(uuid.uuid4())
        super(AuthRoleSadc, self).save(*args, **kwargs)

class AuthUiComponent(models.Model):
    auth_ui_component_guid = models.CharField(primary_key=True, max_length=36)
    auth_ui_component_name = models.CharField(max_length=30, blank=True, null=True)
    auth_ui_component_desc = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'auth_ui_component'

    def save(self, *args, **kwargs):
        # If no guid on save, must be a new record.
        if self.auth_ui_component_guid == '':
            self.auth_ui_component_guid = str(uuid.uuid4())
        super(AuthUiComponent, self).save(*args, **kwargs)


class AuthUiPermission(models.Model):
    auth_ui_permission_guid = models.CharField(primary_key=True, max_length=36)
    auth_ui_component_guid = models.ForeignKey(AuthUiComponent, db_column='auth_ui_component_guid', blank=True, null=True)
    auth_role_guid = models.ForeignKey(AuthRoleSadc, db_column='auth_role_guid', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'auth_ui_permission'

    def save(self, *args, **kwargs):
        # If no guid on save, must be a new record.
        if self.auth_ui_permission_guid == '':
            self.auth_ui_permission_guid = str(uuid.uuid4())
        super(AuthUiPermission, self).save(*args, **kwargs)

class AuthUrl(models.Model):
    auth_url_address = models.CharField(max_length=500)
    active_flg = models.NullBooleanField(default=True)
    auth_url_guid = models.CharField(primary_key=True, max_length=36)

    class Meta:
        managed = False
        db_table = 'auth_url'

    def save(self, *args, **kwargs):
        # If no guid on save, must be a new record.
        if self.auth_url_guid == '':
            logger.debug("Empty auth_user_guid during save")
            self.auth_url_guid = str(uuid.uuid4())

        super(AuthUrl, self).save(*args, **kwargs)
        logger.debug("URL %s saved" % self.auth_url_address )

class AuthUrlPermission(models.Model):
    auth_url_permission_guid = models.CharField(primary_key=True, max_length=36)
    auth_url_guid = models.ForeignKey(AuthUrl, db_column='auth_url_guid', blank=True, null=True, related_name='permissions')
    auth_role_guid = models.ForeignKey(AuthRoleSadc, db_column='auth_role_guid', blank=True, null=True)
    permission_type = models.CharField(max_length=6, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'auth_url_permission'
        unique_together = (('auth_url_guid', 'auth_role_guid', 'permission_type'),)


    def save(self, *args, **kwargs):
        #print "Doing save, auth_url_permission_guid:", self.auth_url_guid, self.auth_role_guid, self.permission_type
        # If no guid on save, must be a new record.
        if not self.pk:
            self.auth_url_permission_guid = str(uuid.uuid4())
        super(AuthUrlPermission, self).save(*args, **kwargs)


class AuthUserSadc(models.Model):
    auth_user_guid = models.CharField(primary_key=True, max_length=36)
    auth_user_name = models.CharField(max_length=100, blank=True, null=True)
    auth_user_password = models.CharField(max_length=100, blank=True, null=True)
    salutation = models.CharField(max_length=20, blank=True, null=True)
    first_name = models.CharField(max_length=100, blank=True, null=True)
    last_name = models.CharField(max_length=100, blank=True, null=True)
    title = models.CharField(max_length=100, blank=True, null=True)
    organization = models.CharField(max_length=100, blank=True, null=True)
    address = models.CharField(max_length=100, blank=True, null=True)
    city = models.CharField(max_length=50, blank=True, null=True)
    state = models.CharField(max_length=2, blank=True, null=True)
    zip = models.CharField(max_length=5, blank=True, null=True)
    auth_code = models.CharField(max_length=32, blank=True, null=True)
    auth_id = models.CharField(max_length=32, blank=True, null=True)
    last_login = models.DateField(blank=True, null=True)
    phone_primary = models.CharField(max_length=15, blank=True, null=True)
    phone_primary_ext = models.CharField(max_length=15, blank=True, null=True)
    phone_alternate = models.CharField(max_length=15, blank=True, null=True)
    phone_alternate_ext = models.CharField(max_length=15, blank=True, null=True)
    email_primary = models.CharField(max_length=100, blank=True, null=True)
    email_alternate = models.CharField(max_length=100, blank=True, null=True)
    zip4 = models.CharField(max_length=4, blank=True, null=True)
    remove_flg = models.NullBooleanField()
    auth_user_status_desc = models.ForeignKey('AuthUserStatusSadc', db_column='auth_user_status_desc',
        related_name='auth_user_status_user', blank=True, null=True)
    contact_type_desc = models.ForeignKey('ContactType', db_column='contact_type_desc', blank=True, null=True)
    person_type_desc = models.ForeignKey('PersonType', db_column='person_type_desc', blank=True, null=True)
    legacy_flg = models.NullBooleanField()
    previous_status_desc = models.ForeignKey('AuthUserStatusSadc', db_column='previous_status_desc',
        related_name='previous_status_user', blank=True, null=True)
    address_2 = models.CharField(max_length=100, blank=True, null=True)
    #managed_role = models.ManyToManyField( AuthRoleSadc, through='WxManagedRole', related_name='managed_roles')
    role = models.ManyToManyField( AuthRoleSadc, through='WxUserRole', related_name='roles_user')

    class Meta:
        managed = False
        db_table = 'auth_user_sadc'

    def save(self, *args, **kwargs):
        # If no guid on save, must be a new record.
        #print "INCOMING AUTH_USER_GUID:", self.auth_user_guid
        if not self.pk:
            logger.debug("Empty auth_user_guid during save")
            self.auth_user_guid = str(uuid.uuid4())
            # Use email as username since it should be unique for each user
            self.auth_user_name = self.email_primary.lower()
        super(AuthUserSadc, self).save(*args, **kwargs)
        logger.debug("User %s saved" % self.auth_user_name )




class AuthUserStatusSadc(models.Model):
    auth_user_status_sadc_desc = models.CharField(primary_key=True, max_length=50)

    class Meta:
        managed = False
        db_table = 'auth_user_status_sadc'


class CmsContent(models.Model):
    content_guid = models.CharField(primary_key=True, max_length=36)
    content_id = models.CharField(max_length=50, blank=True, null=True)
    content_page = models.CharField(max_length=20, blank=True, null=True)
    content_markdown = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'cms_content'

class Cmv(models.Model):
    cmv_guid = models.CharField(primary_key=True, max_length=36)
    farm_key = models.ForeignKey('Farm',db_column='farm_key',related_name='farm_cmv', blank=True, null=True)
    application_key = models.ForeignKey('Application', db_column='application_key',related_name='app_cmv', blank=True, null=True)
    cmv_type = models.CharField(max_length=50, blank=True, null=True)
    cmv_desc = models.CharField(max_length=100, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'cmv'


class CompetitivePool(models.Model):
    competitive_pool_guid = models.CharField(primary_key=True, max_length=36)
    year = models.IntegerField(blank=True, null=True)
    program_type_guid = models.ForeignKey('ProgramType', db_column='program_type_guid',related_name='program_type_pool', blank=True, null=True)
    initial_award = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    spent = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    encumbered = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    pending = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    competitive_limit = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    reappropriated_out = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    balance = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'competitive_pool'

    def save(self, *args, **kwargs):
        user = None
        userid = get_current_user()
        if userid:
            user = AuthUserSadc.objects.get(pk=userid)
        # If no pk on save, must be a new record.
        if not self.pk:
            logger.debug("Empty competitive_pool_guid during save")
            self.competitive_pool_guid = str(uuid.uuid4())
            self.balance = self.initial_award
            self.spent = 0.0
            self.encumbered = 0.0
            self.pending = 0.0
            self.reappropriated_out = 0.0
            self.created_date = timezone.now()
            self.created_user_guid = user
        super(CompetitivePool, self).save(*args, **kwargs)
        logger.debug("Comp Pool %s saved" % self.competitive_pool_guid )



class ContactType(models.Model):
    contact_type_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'contact_type'


class CostShareStatus(models.Model):
    cost_share_status_desc = models.CharField(primary_key=True, max_length=50)

    class Meta:
        managed = False
        db_table = 'cost_share_status'


class County(models.Model):
    county_code = models.CharField(primary_key=True, max_length=2)
    county_name = models.CharField(max_length=20, blank=True, null=True)
    county_label = models.CharField(max_length=30, blank=True, null=True)
    gnis_name = models.CharField(max_length=30, blank=True, null=True)
    gnis = models.CharField(max_length=8, blank=True, null=True)
    active_flg = models.NullBooleanField()

    class Meta:
        managed = False
        db_table = 'county'


class DjangoAdminLog(models.Model):
    id = models.IntegerField(primary_key=True)  # AutoField?
    action_time = models.DateTimeField()
    object_id = models.TextField(blank=True, null=True)
    object_repr = models.CharField(max_length=400, blank=True, null=True)
    action_flag = models.IntegerField()
    change_message = models.TextField(blank=True, null=True)
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING, blank=True, null=True)
    #user = models.ForeignKey(AuthUser, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'django_admin_log'


class DjangoContentType(models.Model):
    id = models.IntegerField(primary_key=True)  # AutoField?
    app_label = models.CharField(max_length=200, blank=True, null=True)
    model = models.CharField(max_length=200, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'django_content_type'
        unique_together = (('app_label', 'model'),)


class DjangoMigrations(models.Model):
    id = models.IntegerField(primary_key=True)  # AutoField?
    app = models.CharField(max_length=510, blank=True, null=True)
    name = models.CharField(max_length=510, blank=True, null=True)
    applied = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_migrations'


class DjangoSession(models.Model):
    session_key = models.CharField(primary_key=True, max_length=80)
    session_data = models.TextField(blank=True, null=True)
    expire_date = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_session'



class Document(models.Model):
    document_guid = models.CharField(primary_key=True, max_length=36)
    created_date = models.DateTimeField(blank=True, null=True)
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid', related_name='user_docs',blank=True, null=True)
    minimum_view_auth_role = models.CharField(max_length=100, blank=True, null=True)
    active_flg = models.NullBooleanField()
    document_blob = models.BinaryField()
    document_size = models.CharField(max_length=20, blank=True, null=True)
    document_name = models.CharField(max_length=200, blank=True, null=True)
    document_fileext = models.CharField(max_length=20, blank=True, null=True)
    document_content_type = models.CharField(max_length=200, blank=True, null=True)
    document_status_desc = models.ForeignKey('DocumentStatus', db_column='document_status_desc', blank=True, null=True)#models.CharField(max_length=100, blank=True, null=True)
    public_access_flg = models.NullBooleanField()
    document_type_desc = models.ForeignKey('DocumentType', db_column='document_type_desc', blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.ForeignKey('AuthUserSadc', db_column='last_edited_user_guid', related_name='user_editdocs',blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'document'

    def save(self, *args, **kwargs):
        # Set user to null initially
        user = None
        userid = get_current_user()
        if userid:
            # If userid found from middleware, query AuthUserSadc for user obj
            user = AuthUserSadc.objects.get(pk=userid)
        # If no pk on save, must be a new record.- use this
        if not self.pk:
            self.created_date = timezone.now()
            self.created_user_guid = user
            logger.debug("Empty document_guid during save")
            #Set primary key for new record to uuid4
            self.document_guid = str(uuid.uuid4())
        self.last_edited_date = timezone.now()
        self.last_edited_user_guid = user
        super(Document, self).save(*args, **kwargs)
        logger.debug("Document %s saved" % self.document_guid )


class DocumentStatus(models.Model):
    document_status_desc = models.CharField(primary_key=True, max_length=100)
    permanent_flg = models.NullBooleanField()

    class Meta:
        managed = False
        db_table = 'document_status'


class DocumentTag(models.Model):
    seq_id = models.AutoField(primary_key=True)
    doc_tag_desc = models.ForeignKey('DocumentTagType', db_column='doc_tag_desc')
    document_guid = models.ForeignKey('Document', db_column='document_guid',related_name='tags')

    class Meta:
        managed = False
        db_table = 'document_tag'
        unique_together = (('doc_tag_desc', 'document_guid'),)


class DocumentTagType(models.Model):
    doc_tag_desc = models.CharField(primary_key=True, max_length=100)
    tag_category = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'document_tag_type'



class DocumentType(models.Model):
    document_type_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'document_type'


class Expense(models.Model):
    expense_guid = models.CharField(primary_key=True, max_length=36)
    application_key = models.ForeignKey('Application', db_column='application_key',related_name='app_expense', blank=True, null=True)
    farm_key = models.ForeignKey('Farm', db_column='farm_key',related_name='farm_expense', blank=True, null=True)
    expense_type = models.ForeignKey('ExpenseType', db_column='expense_type',related_name='type_expense', blank=True, null=True)
    expense_description = models.CharField(max_length=255, blank=True, null=True)
    expense_amount = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    expense_status_desc = models.ForeignKey('ExpenseStatus', db_column='expense_status_desc',related_name='status_expense', blank=True, null=True)
    cost_share_json = jsonfield.JSONField()
    created_date = models.DateTimeField(blank=True, null=True)
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid',related_name="expense_user", blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.ForeignKey('AuthUserSadc', db_column='last_edited_user_guid',related_name="expense_edituser", blank=True, null=True)
    legacy_flg = models.NullBooleanField()

    class Meta:
        managed = False
        db_table = 'expense'

    def save(self, *args, **kwargs):
        user = None
        userid = get_current_user()
        if userid:
            user = AuthUserSadc.objects.get(pk=userid)
        # If no pk on save, must be a new record.
        if not self.pk:
            self.created_date = timezone.now()
            self.created_user_guid = user
            logger.debug("Empty expense_guid during save")
            self.expense_guid = str(uuid.uuid4())
            self.active_flg = 1
        self.last_edited_date = timezone.now()
        self.last_edited_user_guid = user
        super(Expense, self).save(*args, **kwargs)
        logger.debug("Expense %s saved" % self.expense_guid )



class ExpensePayment(models.Model):
    expense_payment_guid = models.CharField(primary_key=True, max_length=36)
    partner_guid = models.ForeignKey('Partner', db_column='partner_guid', related_name='partner_payments',blank=True, null=True)
    partner_grant_guid = models.ForeignKey('PartnerGrant', db_column='partner_grant_guid', related_name='grant_payments',blank=True, null=True)
    competitive_pool_guid = models.ForeignKey('CompetitivePool', db_column='competitive_pool_guid', related_name='pool_payments',blank=True, null=True)
    appropriation_guid = models.ForeignKey('Appropriation', db_column='appropriation_guid',related_name='payments', blank=True, null=True)
    payment_status_desc = models.ForeignKey('PaymentStatus', db_column='payment_status_desc', blank=True, null=True)
    payment_amount = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    payment_comment = models.CharField(max_length=500, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.ForeignKey('AuthUserSadc', db_column='last_edited_user_guid', related_name='useredit_payments', blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    activity_code = models.CharField(max_length=50, blank=True, null=True)
    object_code = models.CharField(max_length=50, blank=True, null=True)
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid', related_name='user_payments', blank=True, null=True)
    paid_date = models.DateTimeField(blank=True, null=True)
    expense_guid = models.ForeignKey('Expense',  db_column='expense_guid', related_name='expense_payments',blank=False, null=False)
    reappropriation_guid = models.ForeignKey('Reappropriation',  db_column='reappropriation_guid', related_name='payment_reapprop',blank=True, null=True)
    vendor_code = models.CharField(max_length=20, blank=True, null=True)
    vendor_name = models.CharField(max_length=150, blank=True, null=True)
    payment_source_type = models.ForeignKey('PaymentSource', db_column='payment_source_type', blank=True, null=True)
    payment_source_desc = models.CharField(max_length=1000, blank=True, null=True)
    partner_flg = models.BooleanField()

    class Meta:
        managed = False
        db_table = 'expense_payment'

    def save(self, *args, **kwargs):
        user = None
        userid = get_current_user()
        if userid:
            user = AuthUserSadc.objects.get(pk=userid)
        # If no pk on save, must be a new record.
        if not self.pk:
            self.created_date = timezone.now()
            self.created_user_guid = user
            logger.debug("Empty expense_payment_guid during save")
            self.expense_payment_guid = str(uuid.uuid4())
        self.last_edited_user_guid = user
        self.last_edited_date = timezone.now()
        super(ExpensePayment, self).save(*args, **kwargs)
        logger.debug("ExpensePayment %s saved" % self.expense_payment_guid )



class ExpenseStatus(models.Model):
    expense_status_desc = models.CharField(primary_key=True, max_length=50)

    class Meta:
        managed = False
        db_table = 'expense_status'


class ExpenseType(models.Model):
    expense_type_desc = models.CharField(primary_key=True, max_length=50)

    class Meta:
        managed = False
        db_table = 'expense_type'


class Farm(models.Model):
    farm_key = models.AutoField(primary_key=True)
    farm_name = models.CharField(max_length=100, blank=True, null=True)
    address = models.CharField(max_length=1000, blank=True, null=True)
    #parent_id = models.IntegerField(blank=True, null=True)
    active_program_guid = models.CharField(max_length=36, blank=True, null=True)
    partner_guid = models.ForeignKey('Partner', db_column='partner_guid', related_name='farm_partner', blank=True, null=True)
    easement_holder_guid = models.CharField(max_length=36, blank=True, null=True)
    preserved_program_guid = models.CharField(max_length=36, blank=True, null=True)
    preserved_date = models.DateField(blank=True, null=True)
    preserved_acres = models.IntegerField(blank=True, null=True)
    paid_acres = models.IntegerField(blank=True, null=True)
    federal_funding_involved = models.BigIntegerField(blank=True, null=True)
    non_contiguous_parcels = models.BigIntegerField(blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid', related_name='created_user_farm', blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.ForeignKey('AuthUserSadc', db_column='last_edited_user_guid', related_name='last_edited_user_farm', blank=True, null=True)
    muni_code = models.ForeignKey('Municipality', db_column='muni_code',related_name='muni_farm', blank=True, null=True)
    muni_code_original = models.CharField(max_length=4, blank=True, null=True)
    status_preserved_desc = models.ForeignKey('StatusPreserved', db_column='status_preserved_desc', blank=True, null=True)
    current_flg = models.BooleanField()

    class Meta:
        managed = False
        db_table = 'farm'


class FarmContact(models.Model):
    farm_contact_guid = models.CharField(primary_key=True, max_length=36)
    farm_key = models.ForeignKey('Farm', db_column='farm_key',related_name='farm_contacts', blank=True, null=True)
    auth_user_guid = models.ForeignKey('AuthUserSadc', db_column='auth_user_guid', blank=True, null=True)
    active_flg = models.NullBooleanField()
    contact_type_desc = models.ForeignKey('FarmContactType', db_column='contact_type_desc', blank=True, null=True)
    note = models.CharField(max_length=2000, blank=True, null=True)

    class Meta:
        unique_together = ('farm_key','contact_type_desc')
        managed = False
        db_table = 'farm_contact'

    def save(self, *args, **kwargs):
        # If no guid on save, must be a new record.
        if not self.pk:
            logger.debug("Empty farm_contact_guid during save")
            self.farm_contact_guid = str(uuid.uuid4())
            self.active_flg = 1
        super(FarmContact, self).save(*args, **kwargs)
        logger.debug("FarmContact %s saved" % self.farm_contact_guid )


class FarmContactType(models.Model):
    contact_type_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'farm_contact_type'


class FarmDivision(models.Model):
    division_guid = models.CharField(primary_key=True, max_length=36)
    division_info = jsonfield.JSONField()
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid', related_name='created_user_farmdiv', blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.ForeignKey('AuthUserSadc', db_column='last_edited_user_guid', related_name='last_edited_user_farmdiv',blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'farm_division'

    def save(self, *args, **kwargs):
        user = None
        userid = get_current_user()
        if userid:
            user = AuthUserSadc.objects.get(pk=userid)
        # If no pk on save, must be a new record.
        if not self.pk:
            logger.debug("Empty division_guid during save")
            self.division_guid = str(uuid.uuid4())
            self.created_date = timezone.now()
            self.created_user_guid = user
        self.last_edited_date = timezone.now()
        self.last_edited_user_guid = user
        super(FarmDivision, self).save(*args, **kwargs)
        logger.debug("FarmDivision %s saved" % self.division_guid )


class FarmLineage(models.Model):
    lineage_guid = models.CharField(primary_key=True, max_length=36)
    parent_farm = models.ForeignKey('Farm', db_column='parent_farm', related_name='farms_parent', blank=True, null=True)
    child_farm = models.ForeignKey('Farm', db_column='child_farm', related_name='farms_children', blank=True, null=True)
    division_guid = models.ForeignKey('FarmDivision', db_column='division_guid',related_name='div_lineage', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'farm_lineage'

    def save(self, *args, **kwargs):
        # If no guid on save, must be a new record.
        if not self.pk:
            logger.debug("Empty lineage_guid during save")
            self.lineage_guid = str(uuid.uuid4())
        super(FarmLineage, self).save(*args, **kwargs)
        logger.debug("FarmLineage %s saved" % self.lineage_guid )


class FarmLandUse(models.Model):
    farm_land_use_desc = models.CharField(primary_key=True, max_length=18)

    class Meta:
        managed = False
        db_table = 'farm_land_use'



class FarmParcel(models.Model):
    parcel_guid = models.CharField(primary_key=True, max_length=36)
    pcl_block = models.CharField(max_length=10, blank=True, null=True)
    pcl_lot = models.CharField(max_length=10, blank=True, null=True)
    pams_pin = models.CharField(max_length=100, blank=True, null=True)
    acres_gross = models.DecimalField(max_digits=38, decimal_places=4, blank=True, null=True)
    acres_net = models.DecimalField(max_digits=38, decimal_places=4, blank=True, null=True)
    acres_paid = models.DecimalField(max_digits=38, decimal_places=4, blank=True, null=True)
    parcel_publish_date = models.DateField(blank=True, null=True)
    farm_key = models.ForeignKey('Farm', db_column='farm_key',related_name='farm_parcels',blank=True, null=True)
    oid = models.BigIntegerField(unique=True, blank=True, null=True)
    shape = models.TextField(blank=True, null=True)  # This field type is a guess.
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid', related_name='created_user_farmparcel', blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.ForeignKey('AuthUserSadc', db_column='last_edited_user_guid', related_name='last_edited_user_farmparcel',blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    pclqcode = models.CharField(max_length=11, blank=True, null=True)
    idn_gis = models.BigIntegerField(blank=True, null=True)
    muni_code = models.ForeignKey('Municipality', db_column='muni_code', blank=True, null=True)
    muni_code_original = models.CharField(max_length=4, blank=True, null=True)
    calc_acre = models.DecimalField(max_digits=38, decimal_places=3, blank=True, null=True)
    area_sq_foot = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    pcl_guid = models.CharField(max_length=36, blank=True, null=True)
    pcl_pbdate = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'farm_parcel'


class FarmParcelLegacy(models.Model):
    parcel_guid = models.ForeignKey('FarmParcel', db_column='parcel_guid', blank=True, null=True)
    idn_gis = models.BigIntegerField(primary_key=True)
    idn_sadc = models.CharField(max_length=100, blank=True, null=True)
    idn_8year = models.CharField(max_length=100, blank=True, null=True)
    cde_sadc_program = models.BigIntegerField(blank=True, null=True)
    new_municipal = models.BigIntegerField(blank=True, null=True)
    cde_county = models.BigIntegerField(blank=True, null=True)
    cde_featuresourc = models.BigIntegerField(blank=True, null=True)
    num_gis_ac = models.DecimalField(max_digits=38, decimal_places=4, blank=True, null=True)
    num_file_acres = models.DecimalField(max_digits=38, decimal_places=4, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'farm_parcel_legacy'


class FarmTag(models.Model):
    seq_id = models.AutoField(primary_key=True)
    farm_tag_desc = models.ForeignKey('FarmTagType', db_column='farm_tag_desc')
    farm_key = models.ForeignKey('Farm', db_column='farm_key',related_name='farm_tags')

    class Meta:
        managed = False
        db_table = 'farm_tag'
        unique_together = (('farm_tag_desc', 'farm_key'),)


class FarmTagType(models.Model):
    farm_tag_desc = models.CharField(primary_key=True, max_length=100)
    tag_category = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'farm_tag_type'


class FloorType(models.Model):
    floor_type_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'floor_type'


class Fund(models.Model):
    fund_guid = models.CharField(primary_key=True, max_length=36)
    fund_id = models.CharField(max_length=20, blank=True, null=True)
    fund_name = models.CharField(max_length=50, blank=True, null=True)
    fund_description = models.CharField(max_length=500, blank=True, null=True)
    balance = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    active_flg = models.NullBooleanField()
    encumbered = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    spent = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    last_edited_user_guid = models.ForeignKey('AuthUserSadc', db_column='last_edited_user_guid', blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'fund'
        app_label = 'database'

    def save(self, *args, **kwargs):
        user = None
        userid = get_current_user()
        if userid:
            user = AuthUserSadc.objects.get(pk=userid)
        # If no pk on save, must be a new record.
        if not self.pk:
            logger.debug("Empty fund_guid during save")
            self.fund_guid = str(uuid.uuid4())
            self.encumbered = 0.0
            self.spent = 0.0
            self.active_flg = 1
        self.last_edited_user_guid = user
        self.last_edited_date = timezone.now()
        super(Fund, self).save(*args, **kwargs)
        logger.debug("Fund %s saved" % self.fund_id )


class FundTransaction(models.Model):
    fund_transaction_guid = models.CharField(primary_key=True, max_length=36)
    fund_guid = models.ForeignKey(Fund, db_column='fund_guid', related_name='fund_trans', blank=True, null=True)
    transaction_type_desc = models.CharField(max_length=30, blank=True, null=True)
    transaction_status = models.CharField(max_length=30, blank=True, null=True) #models.ForeignKey('TransactionStatus', db_column='transaction_status',related_name='fundtrans_status', blank=True, null=True)
    amount = models.DecimalField(max_digits=38, decimal_places=2)
    description = models.CharField(max_length=300, blank=True, null=True)
    notes = models.CharField(max_length=300, blank=True, null=True)
    cancelled_flg = models.BooleanField()
    expense_payment_guid = models.ForeignKey('ExpensePayment', db_column='expense_payment_guid', related_name='fundtrans_payment', blank=True, null=True)
    transaction_date = models.DateTimeField(blank=True, null=True)
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'fund_transaction'

    def save(self, *args, **kwargs):
        user = None
        userid = get_current_user()
        if userid:
            user = AuthUserSadc.objects.get(pk=userid)
        # If no pk on save, must be a new record.
        if not self.pk:
            logger.debug("Empty fund_transaction_guid during save")
            self.fund_transaction_guid = str(uuid.uuid4())
            self.transaction_date = timezone.now()
            self.created_user_guid = user
        else:
            self.transaction_date = timezone.now()
            self.created_user_guid = user

        super(FundTransaction, self).save(*args, **kwargs)
        logger.debug("FundTransaction %s saved" % self.fund_transaction_guid )


class GrantType(models.Model):
    grant_type_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'grant_type'




class InpectionFarm(models.Model):
    farm_key = models.IntegerField(primary_key=True)
    shape = models.CharField(max_length=18, blank=True, null=True)
    oid = models.BigIntegerField(blank=True, null=True)
    created_user_guid = models.CharField(max_length=36, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.CharField(max_length=36, blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    farm_name = models.CharField(max_length=18, blank=True, null=True)
    pcl_block = models.CharField(max_length=10, blank=True, null=True)
    pcl_lot = models.CharField(max_length=10, blank=True, null=True)
    county = models.CharField(max_length=200, blank=True, null=True)
    municipality = models.CharField(max_length=200, blank=True, null=True)
    farm_number = models.CharField(max_length=18, blank=True, null=True)
    frpp = models.BigIntegerField(blank=True, null=True)
    owner_change = models.BigIntegerField(blank=True, null=True)
    owner_contact = models.BigIntegerField(blank=True, null=True)
    owner_deed = models.BigIntegerField(blank=True, null=True)
    original_block_lot = models.BigIntegerField(blank=True, null=True)
    subdivided = models.BigIntegerField(blank=True, null=True)
    subdivision_date = models.DateField(blank=True, null=True)
    subdivision_approval = models.BigIntegerField(blank=True, null=True)
    rdso_allocated = models.IntegerField(blank=True, null=True)
    rdso_exercised = models.IntegerField(blank=True, null=True)
    rdso_remaining = models.IntegerField(blank=True, null=True)
    rdso_remaining_restrict = models.CharField(max_length=1000, blank=True, null=True)
    imp_cover_restrict = models.BigIntegerField(blank=True, null=True)
    imp_cover_percent = models.DecimalField(max_digits=3, decimal_places=1, blank=True, null=True)
    imp_cover_sqft_allow = models.DecimalField(max_digits=8, decimal_places=2, blank=True, null=True)
    imp_cover_sqft = models.DecimalField(max_digits=8, decimal_places=2, blank=True, null=True)
    frpp_build_envelope = models.BigIntegerField(blank=True, null=True)
    frpp_build_envelope_cont = models.BigIntegerField(blank=True, null=True)
    easement_wood_acre = models.DecimalField(max_digits=8, decimal_places=2, blank=True, null=True)
    easment_wetland_acre = models.DecimalField(max_digits=8, decimal_places=2, blank=True, null=True)
    easment_water_body = models.DecimalField(max_digits=8, decimal_places=2, blank=True, null=True)
    cons_plan = models.BigIntegerField(blank=True, null=True)
    cons_plan_implement = models.BigIntegerField(blank=True, null=True)
    cons_plan_obstacle = models.CharField(max_length=300, blank=True, null=True)
    usda_program = models.BigIntegerField(blank=True, null=True)
    usda_program_list = models.CharField(max_length=300, blank=True, null=True)
    forest_plan = models.BigIntegerField(blank=True, null=True)
    historic_buildings = models.BigIntegerField(blank=True, null=True)
    resource_concern = models.BigIntegerField(blank=True, null=True)
    resource_concern_list = models.CharField(max_length=300, blank=True, null=True)
    conservation_violation = models.BigIntegerField(blank=True, null=True)
    conservation_concern = models.BigIntegerField(blank=True, null=True)
    negative_conditions = models.CharField(max_length=300, blank=True, null=True)
    owner_change_plan = models.CharField(max_length=300, blank=True, null=True)
    landowner_questions = models.CharField(max_length=4000, blank=True, null=True)
    landowner_assitance = models.CharField(max_length=4000, blank=True, null=True)
    inspection_weather = models.CharField(max_length=300, blank=True, null=True)
    inspection_date = models.CharField(max_length=18, blank=True, null=True)
    inspector_comments = models.CharField(max_length=4000, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'inpection_farm'


class InspectionContact(models.Model):
    oid = models.BigIntegerField(primary_key=True)
    created_user_guid = models.CharField(max_length=36, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.CharField(max_length=36, blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    farm_key = models.ForeignKey('Farm', models.DO_NOTHING, db_column='farm_key', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'inspection_contact'


class InspectionCrop(models.Model):
    oid = models.BigIntegerField(primary_key=True)
    created_user_guid = models.CharField(max_length=36, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.CharField(max_length=36, blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    farm_key = models.ForeignKey('Farm', models.DO_NOTHING, db_column='farm_key', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'inspection_crop'


class InspectionImperviousCover(models.Model):
    oid = models.BigIntegerField(primary_key=True)
    created_user_guid = models.CharField(max_length=36, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.CharField(max_length=36, blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    farm_key = models.ForeignKey('Farm', models.DO_NOTHING, db_column='farm_key', blank=True, null=True)
    cover_type = models.CharField(max_length=100, blank=True, null=True)
    area_cover = models.DecimalField(max_digits=8, decimal_places=2, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'inspection_impervious_cover'


class InspectionNonAg(models.Model):
    oid = models.BigIntegerField(primary_key=True)
    created_user_guid = models.CharField(max_length=36, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.CharField(max_length=36, blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    farm_key = models.ForeignKey('Farm', models.DO_NOTHING, db_column='farm_key', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'inspection_non_ag'


class InspectionResidenceFacility(models.Model):
    oid = models.BigIntegerField(primary_key=True)
    created_user_guid = models.CharField(max_length=36, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.CharField(max_length=36, blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    aoi_id = models.BigIntegerField(blank=True, null=True)
    facility_name = models.CharField(max_length=18, blank=True, null=True)
    facility_area = models.CharField(max_length=18, blank=True, null=True)
    farm_key = models.ForeignKey('Farm', models.DO_NOTHING, db_column='farm_key', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'inspection_residence_facility'


class InspectionWasteArea(models.Model):
    oid = models.BigIntegerField(primary_key=True)
    created_user_guid = models.CharField(max_length=36, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.CharField(max_length=36, blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    farm_key = models.ForeignKey('Farm', models.DO_NOTHING, db_column='farm_key', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'inspection_waste_area'


class Layer(models.Model):
    layer_guid = models.CharField(primary_key=True, max_length=36)
    layer_title = models.CharField(max_length=100, blank=True, null=True)
    layer_id = models.CharField(max_length=50, blank=True, null=True)
    service_id = models.CharField(max_length=2, blank=True, null=True)
    service_url = models.CharField(max_length=500)
    service_type = models.CharField(max_length=50)
    layer_type = models.CharField(max_length=50, blank=True, null=True)
    layer_description = models.CharField(max_length=2000, blank=True, null=True)
    metadata_url = models.CharField(max_length=500, blank=True, null=True)
    layer_rank = models.BigIntegerField(blank=True, null=True)
    source_layer = models.CharField(max_length=500, blank=True, null=True)
    active_flg = models.NullBooleanField()
    layer_info_json = jsonfield.JSONField()

    class Meta:
        managed = False
        db_table = 'layer'





class MapNotePoint(models.Model):
    map_note_point_guid = models.CharField(primary_key=True, max_length=36)
    note_label = models.CharField(max_length=150, blank=True, null=True)
    note_description = models.CharField(max_length=500, blank=True, null=True)
    application_key = models.ForeignKey('Application', db_column='application_key',related_name='app_mapnotepoint', blank=True, null=True)
    farm_key = models.ForeignKey('Farm', db_column='farm_key', blank=True, null=True)
    application_map_guid = models.ForeignKey('ApplicationMap', db_column='application_map_guid', blank=True, null=True)
    created_user_guid = models.CharField(max_length=36, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    active_flg = models.NullBooleanField()
    oid = models.BigIntegerField(unique=True)
    shape = models.TextField(blank=True, null=True)  # This field type is a guess.
    se_anno_cad_data = models.BinaryField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'map_note_point'




class ModuleType(models.Model):
    module_type_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'module_type'


class Municipality(models.Model):
    muni_code = models.CharField(primary_key=True, max_length=4)
    name = models.CharField(max_length=50, blank=True, null=True)
    gnis_name = models.CharField(max_length=50, blank=True, null=True)
    gnis = models.CharField(max_length=8, blank=True, null=True)
    active_flg = models.NullBooleanField()
    county = models.CharField(max_length=20, blank=True, null=True)
    county_code = models.ForeignKey('County', db_column='county_code', related_name="munilist", blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'municipality'


class NjFarmsOrig(models.Model):
    oid = models.BigIntegerField(primary_key=True)
    area = models.DecimalField(max_digits=38, decimal_places=3, blank=True, null=True)
    perimeter = models.DecimalField(max_digits=38, decimal_places=3, blank=True, null=True)
    njfarms = models.BigIntegerField(blank=True, null=True)
    block = models.CharField(max_length=20, blank=True, null=True)
    lot = models.CharField(max_length=250, blank=True, null=True)
    owner = models.CharField(max_length=30, blank=True, null=True)
    njfarms_id = models.FloatField(blank=True, null=True)
    idn_sadc = models.CharField(max_length=16, blank=True, null=True)
    idn_8year = models.CharField(max_length=16, blank=True, null=True)
    cde_sadc_program = models.BigIntegerField(blank=True, null=True)
    cde_municipal = models.BigIntegerField(blank=True, null=True)
    new_municipal = models.CharField(max_length=5, blank=True, null=True)
    cde_county = models.BigIntegerField(blank=True, null=True)
    cde_featuresourc = models.BigIntegerField(blank=True, null=True)
    num_gis_acres = models.DecimalField(max_digits=38, decimal_places=3, blank=True, null=True)
    num_file_acres = models.DecimalField(max_digits=38, decimal_places=3, blank=True, null=True)
    idn_gis = models.BigIntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'nj_farms_orig'



class NoteGroup(models.Model):
    note_group_guid = models.CharField(primary_key=True, max_length=36)
    note_group_title = models.CharField(max_length=500, blank=True, null=True)
    sadc_flg = models.BooleanField()
    last_edited_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.ForeignKey('AuthUserSadc', db_column='last_edited_user_guid', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'note_group'

    def save(self, *args, **kwargs):
        if self.sadc_flg not in [True,False]:
            self.sadc_flg = True
        user = None
        userid = get_current_user()
        if userid:
            user = AuthUserSadc.objects.get(pk=userid)
        # If no pk on save, must be a new record.
        if not self.pk:
            #print("Empty guid during save")
            logger.debug("Empty guid during save")
            self.note_group_guid = str(uuid.uuid4())
        self.last_edited_date = timezone.now()
        self.last_edited_user_guid = user

        super(NoteGroup, self).save(*args, **kwargs)

class Note(models.Model):
    note_guid = models.CharField(primary_key=True, max_length=36)
    created_date = models.DateTimeField(blank=True, null=True)
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid',related_name='user_creatednote', blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.ForeignKey('AuthUserSadc', db_column='last_edited_user_guid', blank=True, null=True)
    note_group_guid = models.ForeignKey('NoteGroup',on_delete=models.CASCADE, db_column='note_group_guid', related_name='notes')
    active_flg = models.NullBooleanField()
    note_text= models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'note'

    def save(self, *args, **kwargs):
        dtstamp = timezone.now()
        user = None
        userid = get_current_user()
        if userid:
            user = AuthUserSadc.objects.get(pk=userid)
        # If no pk on save, must be a new record.
        if not self.pk:
            #print("Empty guid during save")
            logger.debug("Empty guid during save")
            self.note_guid = str(uuid.uuid4())
            self.created_date = dtstamp
            self.created_user_guid = user
        self.last_edited_date = dtstamp
        self.last_edited_user_guid = user
        super(Note, self).save(*args, **kwargs)


class NoteGroupTag(models.Model):
    seq_id = models.AutoField(primary_key=True)
    tag_desc = models.CharField(max_length=100, blank=True)
    note_group_guid = models.ForeignKey('NoteGroup', db_column='note_group_guid',related_name='tags')

    class Meta:
        managed = False
        db_table = 'note_group_tag'
        unique_together = (('tag_desc', 'note_group_guid'),)


class NoteGroupTagType(models.Model):
    tag_desc = models.CharField(primary_key=True, max_length=100)
    tag_category = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'note_group_tag_type'


class Notification(models.Model):
    notify_guid = models.CharField(primary_key=True, max_length=36)
    notify_text = models.CharField(max_length=300)
    notify_user = models.ForeignKey('AuthUserSadc', db_column='notify_user',related_name='user_notifications', blank=True, null=True)
    application_key = models.ForeignKey('Application', db_column='application_key',blank=True,null=True)
    farm_key = models.ForeignKey('Farm', db_column='farm_key',blank=True,null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid',related_name='user_notifycreated', blank=True, null=True)
    deleted_flg = models.BooleanField()
    cleared_date = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'notification'

    def save(self, *args, **kwargs):
        user = None
        userid = get_current_user()
        if userid:
            user = AuthUserSadc.objects.get(pk=userid)
        # If no pk on save, must be a new record.
        if not self.pk:
            #print("Empty guid during save")
            logger.debug("Empty guid during save")
            self.notify_guid = str(uuid.uuid4())
            self.created_date = timezone.now()
            self.created_user_guid = user
        super(Notification, self).save(*args, **kwargs)


class NrImpactArea(models.Model):
    nr_impact_area_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'nr_impact_area'


class NrIssue(models.Model):
    nr_issue_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'nr_issue'





class PaInventory(models.Model):
    pa_inventory_guid = models.CharField(primary_key=True, max_length=36)
    year = models.IntegerField(blank=True, null=True)
    shape = models.TextField(blank=True, null=True)  # This field type is a guess.
    pams_pin = models.CharField(max_length=38, blank=True, null=True)
    pclblock = models.CharField(max_length=10, blank=True, null=True)
    pcllot = models.CharField(max_length=10, blank=True, null=True)
    calc_acre = models.DecimalField(max_digits=38, decimal_places=3, blank=True, null=True)
    area_sq_foot = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    pclqcode = models.CharField(max_length=11, blank=True, null=True)
    pin_nodup = models.CharField(max_length=38, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid', related_name='created_user_painv', blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.ForeignKey('AuthUserSadc', db_column='last_edited_user_guid', related_name='last_edited_user_painv',blank=True, null=True)
    oid = models.BigIntegerField(unique=True)
    muni_code_original = models.CharField(max_length=4, blank=True, null=True)
    muni_code = models.ForeignKey('Municipality', db_column='muni_code', blank=True, null=True)
    pcl_guid = models.CharField(max_length=36, blank=True, null=True)
    descr = models.CharField(max_length=200, blank=True, null=True)
    inv_type = models.ForeignKey('PaInventoryType', db_column='inv_type', blank=True, null=True)
    pcl_pbdate = models.DateField(blank=True, null=True)
    se_anno_cad_data = models.BinaryField(blank=True, null=True)
    application_map_guid = models.ForeignKey('ApplicationMap', db_column='application_map_guid', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'pa_inventory'


class PaInventoryType(models.Model):
    inv_type = models.CharField(primary_key=True, max_length=3)
    typeval = models.CharField(max_length=200, blank=True, null=True)
    description = models.CharField(max_length=300, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'pa_inventory_type'


class Partner(models.Model):
    partner_guid = models.CharField(primary_key=True, max_length=36)
    partner_name = models.CharField(max_length=200, blank=True, null=True)
    active_flg = models.NullBooleanField()
    partner_type_desc = models.ForeignKey('PartnerType', db_column='partner_type_desc', blank=True, null=True)
    county_code = models.ForeignKey('County', db_column='county_code', blank=True, null=True)
    muni_code = models.ForeignKey('Municipality', db_column='muni_code', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'partner'


class PartnerGrant(models.Model):
    partner_grant_guid = models.CharField(primary_key=True, max_length=36)
    program_type_guid = models.ForeignKey('ProgramType', db_column='program_type_guid',related_name='program_type_grant', blank=True, null=True)
    year = models.IntegerField(blank=True, null=True)
    partner_guid = models.ForeignKey('Partner', db_column='partner_guid', related_name='partner_grant',blank=True, null=True)
    initial_award = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    base_balance = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    base_spent = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    base_encumbered = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    pending = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    competitive_balance = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    competitive_encumbered = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    competitive_spent = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    reappropriated_out = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'partner_grant'

    def save(self, *args, **kwargs):
        user = None
        userid = get_current_user()
        if userid:
            user = AuthUserSadc.objects.get(pk=userid)
        # If no pk on save, must be a new record.
        if not self.pk:
            logger.debug("Empty partner_grant_guid during save")
            self.partner_grant_guid = str(uuid.uuid4())
            self.base_balance = self.initial_award
            self.base_spent = 0.0
            self.base_encumbered = 0.0
            self.pending = 0.0
            self.competitive_encumbered = 0.0
            self.competitive_spent = 0.0
            self.reappropriated_out = 0.0
            self.created_date = timezone.now()
            self.created_user_guid = user
        super(PartnerGrant, self).save(*args, **kwargs)
        logger.debug("Partner Grant %s saved" % self.partner_grant_guid )


class PartnerType(models.Model):
    partner_type_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'partner_type'


class PaymentSource(models.Model):
    payment_source_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'payment_source'


class PaymentStatus(models.Model):
    payment_status_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'payment_status'


class PermissionType(models.Model):
    permission_type_desc = models.CharField(primary_key=True, max_length=100)
    score = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'permission_type'


class PersonType(models.Model):
    person_type_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'person_type'


class Persons(models.Model):
    persons_guid = models.CharField(primary_key=True, max_length=36)
    first_name = models.CharField(max_length=100, blank=True, null=True)
    last_name = models.CharField(max_length=100, blank=True, null=True)
    person_type_desc = models.ForeignKey('PersonType', db_column='person_type_desc', blank=True, null=True)
    salutation = models.CharField(max_length=20, blank=True, null=True)
    title = models.CharField(max_length=100, blank=True, null=True)
    address = models.CharField(max_length=100, blank=True, null=True)
    phone_primary = models.CharField(max_length=15, blank=True, null=True)
    phone_alternate = models.CharField(max_length=15, blank=True, null=True)
    email_primary = models.CharField(max_length=100, blank=True, null=True)
    email_alternate = models.CharField(max_length=100, blank=True, null=True)
    city = models.CharField(max_length=50, blank=True, null=True)
    state = models.CharField(max_length=2, blank=True, null=True)
    zip = models.CharField(max_length=5, blank=True, null=True)
    zip4 = models.CharField(max_length=4, blank=True, null=True)
    phone_primary_ext = models.CharField(max_length=15, blank=True, null=True)
    phone_alternate_ext = models.CharField(max_length=15, blank=True, null=True)
    organization = models.CharField(max_length=100, blank=True, null=True)
    legacy_flg = models.NullBooleanField()
    remove_flg = models.NullBooleanField()

    class Meta:
        managed = False
        db_table = 'persons'



class PlTfPurchaseCost(models.Model):
    price_acre = models.FloatField(blank=True, null=True)
    cost_share_mun = models.FloatField(blank=True, null=True)
    cost_share_cnt = models.FloatField(blank=True, null=True)
    cost_share_state = models.FloatField(blank=True, null=True)
    cost_share_other = models.FloatField(blank=True, null=True)
    price_total = models.FloatField(blank=True, null=True)
    total_acre = models.FloatField(blank=True, null=True)
    mun_name = models.CharField(max_length=50, blank=True, null=True)
    pa_guid = models.ForeignKey('ProjectArea', db_column='pa_guid')

    class Meta:
        managed = False
        db_table = 'pl_tf_purchase_cost'


class PlTfPurchaseCostPlan(models.Model):
    cost_total_mun = models.FloatField(blank=True, null=True)
    cost_total_cnt = models.FloatField(blank=True, null=True)
    cost_total_state = models.FloatField(blank=True, null=True)
    cost_total_other = models.FloatField(blank=True, null=True)
    cost_total = models.FloatField(blank=True, null=True)
    pl_pa_year_id = models.CharField(max_length=18, blank=True, null=True)
    total_acre = models.FloatField(blank=True, null=True)
    cost_estimate = models.FloatField(blank=True, null=True)
    purchase_cost_plan_guid = models.CharField(primary_key=True, max_length=36)
    pa_guid = models.ForeignKey('ProjectArea', db_column='pa_guid')

    class Meta:
        managed = False
        db_table = 'pl_tf_purchase_cost_plan'


class ProgramCategory(models.Model):
    program_category_code = models.CharField(primary_key=True,max_length=10)
    program_category_desc = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'program_category'


class ProgramType(models.Model):
    program_type_guid = models.CharField(primary_key=True, max_length=36)
    program_name = models.CharField(max_length=100, blank=True, null=True)
    program_code = models.CharField(max_length=20, blank=True, null=True)
    program_category_desc = models.CharField(max_length=50, blank=True, null=True) # Add Foreign Key Relationship
    legacy = models.NullBooleanField()

    class Meta:
        managed = False
        db_table = 'program_type'


class ProjectArea(models.Model):
    pa_guid = models.CharField(primary_key=True, max_length=36)
    name = models.CharField(max_length=100, blank=True, null=True)
    shape = models.TextField(blank=True, null=True)  # This field type is a guess.
    pa_parcel_count = models.IntegerField(blank=True, null=True)
    calc_acre = models.DecimalField(max_digits=38, decimal_places=3, blank=True, null=True)
    area_sq_foot = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid', related_name='created_user_pa', blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.ForeignKey('AuthUserSadc', db_column='last_edited_user_guid', related_name='last_edited_user_pa', blank=True, null=True)
    pa_density = models.FloatField(blank=True, null=True)
    pa_soil_prod = models.FloatField(blank=True, null=True)
    oid = models.BigIntegerField(unique=True)
    year = models.IntegerField(blank=True, null=True)
    se_anno_cad_data = models.BinaryField(blank=True, null=True)
    application_map_guid = models.ForeignKey('ApplicationMap', db_column='application_map_guid', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'project_area'


class ProjectAreaInventoryParcel(models.Model):
    pai_summary_guid = models.ForeignKey('ProjectAreaInventorySummary', db_column='pai_summary_guid')
    pams_pin = models.CharField(max_length=38, blank=True, null=True)
    pin_nodup = models.CharField(max_length=38, blank=True, null=True)
    pai_parcel_guid = models.CharField(primary_key=True, max_length=36)
    comments = models.CharField(max_length=255, blank=True, null=True)
    calc_acre = models.DecimalField(max_digits=38, decimal_places=4, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'project_area_inventory_parcel'


class ProjectAreaInventorySummary(models.Model):
    pai_acre = models.FloatField(blank=True, null=True)
    summary_date = models.DateField(blank=True, null=True)
    pai_parcel_count = models.BigIntegerField(blank=True, null=True)
    pai_id = models.CharField(max_length=1, blank=True, null=True)
    pai_summary_guid = models.CharField(primary_key=True, max_length=36)
    pa_guid = models.ForeignKey('ProjectArea', db_column='pa_guid')

    class Meta:
        managed = False
        db_table = 'project_area_inventory_summary'



class Reappropriation(models.Model):
    reappropriation_guid = models.CharField(primary_key=True, max_length=36)
    appropriation_source_guid = models.ForeignKey('Appropriation', db_column='appropriation_source_guid', related_name='app_source_reapprop', blank=True, null=True)
    appropriation_target_guid = models.ForeignKey('Appropriation', db_column='appropriation_target_guid', related_name='reappropriations', blank=True, null=True)
    transfer_amount = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    balance = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    note = models.CharField(max_length=500, blank=True, null=True)
    status_transfer_desc = models.ForeignKey('StatusTransfer', db_column='status_transfer_desc', blank=True, null=True)
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid',related_name='user_reapprops', blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.ForeignKey('AuthUserSadc', db_column='last_edited_user_guid',related_name='user_editreapprops', blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    reappropriation_date = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'reappropriation'

    def save(self, *args, **kwargs):
        user = None
        userid = get_current_user()
        if userid:
            user = AuthUserSadc.objects.get(pk=userid)
        # If no pk on save, must be a new record.
        if not self.pk:
            self.created_date = timezone.now()
            self.created_user_guid = user
            logger.debug("Empty reappropriation_guid during save")
            self.reappropriation_guid = str(uuid.uuid4())
            self.balance = self.transfer_amount
        self.last_edited_date = timezone.now()
        self.last_edited_user_guid = user
        super(Reappropriation, self).save(*args, **kwargs)
        logger.debug("Reappropriation %s saved" % self.reappropriation_guid )


class ReappropriationDetail(models.Model):
    reapprop_detail_guid = models.CharField(primary_key=True, max_length=36)
    reappropriation_guid = models.ForeignKey('Reappropriation', db_column='reappropriation_guid', related_name='detail', blank=True, null=True)
    partner_grant_guid = models.ForeignKey('PartnerGrant', db_column='partner_grant_guid', related_name='partner_grant_reapprop', blank=True, null=True)
    competitive_pool_guid = models.ForeignKey('CompetitivePool', db_column='competitive_pool_guid', related_name='pool_reapprop', blank=True, null=True)
    amount = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    notes = models.CharField(max_length=300, blank=True, null=True)
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid', blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)


    class Meta:
        managed = False
        db_table = 'reappropriation_detail'

    def save(self, *args, **kwargs):
        user = None
        userid = get_current_user()
        if userid:
            user = AuthUserSadc.objects.get(pk=userid)
        # If no pk on save, must be a new record.
        if not self.pk:
            self.created_date = timezone.now()
            self.created_user_guid = user
            logger.debug("Empty reapprop_detail_guid during save")
            self.reapprop_detail_guid = str(uuid.uuid4())
        super(ReappropriationDetail, self).save(*args, **kwargs)
        logger.debug("Reappropriation Detail %s saved" % self.reapprop_detail_guid )


class ReoccurrenceType(models.Model):
    reoccurrence_type_name = models.CharField(primary_key=True, max_length=50)

    class Meta:
        managed = False
        db_table = 'reoccurrence_type'


class ReportViews(models.Model):
    report_guid = models.CharField(primary_key=True, max_length=36)
    report_label = models.CharField(max_length=150, blank=True, null=True)
    view_name = models.CharField(max_length=150, blank=True, null=True)
    module_type = models.CharField(max_length=100, blank=True, null=True)
    active_flg = models.BooleanField()
    last_update_date = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'report_views'


class Restriction(models.Model):
    restriction_guid = models.CharField(primary_key=True, max_length=36)
    farm_key = models.ForeignKey('Farm', models.DO_NOTHING, db_column='farm_key', blank=True, null=True)
    restriction_date = models.DateTimeField(blank=True, null=True)
    restriction_type_desc = models.ForeignKey('RestrictionType',  db_column='restriction_type_desc', blank=True, null=True)
    details = models.CharField(max_length=4000, blank=True, null=True)
    active_flg = models.NullBooleanField()
    restriction_category_desc = models.ForeignKey('RestrictionCategory', db_column='restriction_category_desc', blank=True, null=True)
    used_flg = models.NullBooleanField()

    class Meta:
        managed = False
        db_table = 'restriction'


class RestrictionCategory(models.Model):
    restriction_category_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'restriction_category'


class RestrictionType(models.Model):
    restriction_type_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'restriction_type'



class RuleDefinition(models.Model):
    rule_definition_guid = models.CharField(primary_key=True, max_length=36)
    rule_name = models.CharField(max_length=500, blank=True, null=True)
    rule_type = models.CharField(max_length=50, blank=True, null=True)
    rule_definition_json = jsonfield.JSONField()#models.TextField(blank=True, null=True)
    active_flg = models.NullBooleanField()
    description = models.CharField(max_length=500, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'rule_definition'


class RuleResult(models.Model):
    rule_result_guid = models.CharField(primary_key=True, max_length=36)
    rule_definition_guid = models.ForeignKey('RuleDefinition', db_column='rule_definition_guid', blank=True, null=True)
    application_key = models.ForeignKey('Application', db_column='application_key',related_name='app_ruleresult', blank=True, null=True)
    rule_result_source = models.CharField(max_length=50, blank=True, null=True)
    rule_result_json = jsonfield.JSONField()#models.TextField(blank=True, null=True)
    active_flg = models.NullBooleanField()
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid', blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'rule_result'


class Score(models.Model):
    score_guid = models.CharField(primary_key=True, max_length=36)
    application_key = models.ForeignKey('Application', db_column='application_key', related_name="app_scores", blank=True, null=True)
    score_type_guid = models.ForeignKey('ScoreType', db_column='score_type_guid', blank=True, null=True)
    name = models.CharField(max_length=100, blank=True, null=True)
    description = models.CharField(max_length=500, blank=True, null=True)
    score_status = models.ForeignKey('ScoreStatus', db_column='score_status', blank=True, null=True)
    score_json = jsonfield.JSONField()
    created_date = models.DateTimeField(blank=True, null=True)
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid', related_name='user_scores',blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.ForeignKey('AuthUserSadc', db_column='last_edited_user_guid', related_name='user_editscores',blank=True, null=True)
    active_flg = models.NullBooleanField()
    current_flg = models.NullBooleanField()

    class Meta:
        managed = False
        db_table = 'score'

    def save(self, *args, **kwargs):
        user = None
        userid = get_current_user()
        if userid:
            user = AuthUserSadc.objects.get(pk=userid)
        # If no pk on save, must be a new record.
        if not self.pk:
            self.created_user_guid = user
            self.created_date = timezone.now()
            logger.debug("Empty score_guid during save")
            self.score_guid = str(uuid.uuid4())
        self.last_edited_user_guid = user
        self.last_edited_date = timezone.now()
        super(Score, self).save(*args, **kwargs)
        logger.debug("Score %s saved" % self.score_guid )


class ScoreType(models.Model):
    score_type_guid = models.CharField(primary_key=True, max_length=36)
    score_type_desc = models.CharField(max_length=100, blank=True, null=True)
    score_type_json = jsonfield.JSONField()
    created_date = models.DateTimeField(blank=True, null=True)
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid', related_name='user_scoretypes',blank=True, null=True)
    active_flg = models.NullBooleanField()

    class Meta:
        managed = False
        db_table = 'score_type'


class ScoreStatus(models.Model):
    score_status_desc = models.CharField(primary_key=True, max_length=20)

    class Meta:
        managed = False
        db_table = 'score_status'


class Status(models.Model):
    status_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'status'


class StatusPreserved(models.Model):
    status_preserved_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'status_preserved'


class StatusTracking(models.Model):
    status_tracking_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'status_tracking'

class StatusTransfer(models.Model):
    status_transfer_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'status_transfer'


class StatusUserfeed(models.Model):
    status_userfeed_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'status_userfeed'



class Tasks(models.Model):
    task_id = models.IntegerField(primary_key=True)
    task_title = models.CharField(max_length=50, blank=True, null=True)
    time_init = models.DateTimeField(blank=True, null=True)
    reoccurrence_type_name = models.ForeignKey('ReoccurrenceType', db_column='reoccurrence_type_name', blank=True, null=True)
    rule_definition_guid = models.ForeignKey('RuleDefinition', db_column='rule_definition_guid', blank=True, null=True)
    next_run_time = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tasks'


class TfParcel(models.Model):
    tf_guid = models.CharField(primary_key=True, max_length=36)
    year = models.IntegerField(blank=True, null=True)
    owner_name = models.CharField(max_length=200, blank=True, null=True)
    shape = models.TextField(blank=True, null=True)  # This field type is a guess.
    pams_pin = models.CharField(max_length=38, blank=True, null=True)
    pclblock = models.CharField(max_length=10, blank=True, null=True)
    pcllot = models.CharField(max_length=10, blank=True, null=True)
    st_address = models.CharField(max_length=255, blank=True, null=True)
    city_state = models.CharField(max_length=50, blank=True, null=True)
    zip_code = models.CharField(max_length=5, blank=True, null=True)
    calc_acre = models.DecimalField(max_digits=38, decimal_places=3, blank=True, null=True)
    area_sq_foot = models.DecimalField(max_digits=38, decimal_places=2, blank=True, null=True)
    pclqcode = models.CharField(max_length=11, blank=True, null=True)
    pin_nodup = models.CharField(max_length=38, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid', related_name='created_user_tfp', blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.ForeignKey('AuthUserSadc', db_column='last_edited_user_guid', related_name='last_edited_user_tfp', blank=True, null=True)
    farm_name = models.CharField(max_length=100, blank=True, null=True)
    application_map_guid = models.ForeignKey('ApplicationMap', db_column='application_map_guid', blank=True, null=True)
    oid = models.BigIntegerField(unique=True)
    muni_code_original = models.CharField(max_length=4, blank=True, null=True)
    muni_code = models.ForeignKey('Municipality', db_column='muni_code', blank=True, null=True)
    pcl_guid = models.CharField(max_length=36, blank=True, null=True)
    pcl_pbdate = models.DateField(blank=True, null=True)
    se_anno_cad_data = models.BinaryField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tf_parcel'


class Tier(models.Model):
    tier_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'tier'


class TierGroup(models.Model):
    tier_group_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'tier_group'


class TierSubgroup(models.Model):
    tier_subgroup_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'tier_subgroup'


class TodoItem(models.Model):
    todo_item_guid = models.CharField(primary_key=True, max_length=36)
    farm_key = models.ForeignKey('Farm', db_column='farm_key', related_name="farm_todos", blank=True, null=True)
    application_key = models.ForeignKey('Application', db_column='application_key',related_name='app_todos', blank=True, null=True)
    todo_item_desc = models.CharField(max_length=200, blank=True, null=True)
    todo_item_due_date = models.DateField(blank=True, null=True)
    todo_item_conditional_flg = models.BooleanField(default=False)
    application_phase_guid = models.ForeignKey('ApplicationPhase', db_column='application_phase_guid', blank=True, null=True)
    todo_item_completed_flg = models.BooleanField(default=False)
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid', related_name='todo_assigner', blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    last_edited_user_guid = models.ForeignKey('AuthUserSadc', db_column='last_edited_user_guid', related_name='todo_lasteditor', blank=True, null=True)
    last_edited_date = models.DateTimeField(blank=True, null=True)
    completed_date = models.DateTimeField(blank=True, null=True)
    completed_user_guid = models.ForeignKey('AuthUserSadc', db_column='completed_user_guid', related_name='todo_user', blank=True, null=True)
    todo_item_title = models.CharField(max_length=200, blank=True, null=True)
    users = models.ManyToManyField( AuthUserSadc, through='WxUserTodo', related_name='users_todo')
    roles = models.ManyToManyField( AuthRoleSadc, through='WxRoleTodo', related_name='roles_todo')

    class Meta:
        managed = False
        db_table = 'todo_item'

    def save(self, *args, **kwargs):
        user = None
        userid = get_current_user()
        if userid:
            user = AuthUserSadc.objects.get(pk=userid)
        # If no pk on save, must be a new record.
        if not self.pk:
            logger.debug("Empty todo_item_guid during save")
            self.todo_item_guid = str(uuid.uuid4())
            self.created_date = timezone.now()
            self.created_user_guid = user
            self.todo_item_conditional_flg = False
            self.todo_item_completed_flg = False
        self.last_edited_user_guid = user
        self.last_edited_date = timezone.now()
        super(TodoItem, self).save(*args, **kwargs)
        logger.debug("TodoItem %s saved" % self.todo_item_guid )


class WxUserTodo(models.Model):
    auth_user_guid = models.ForeignKey(AuthUserSadc, db_column='auth_user_guid')
    todo_item_guid = models.ForeignKey(TodoItem, db_column='todo_item_guid')
    wx_user_todo_guid = models.CharField(primary_key=True, max_length=36)

    class Meta:
        managed = False
        db_table = 'wx_user_todo'

    def save(self, *args, **kwargs):
        if not self.pk:
            #print("Empty guid during save")
            logger.debug("Empty guid during save")
            self.wx_user_todo_guid = str(uuid.uuid4())
        super(WxUserTodo, self).save(*args, **kwargs)


class WxRoleTodo(models.Model):
    todo_item_guid = models.ForeignKey(TodoItem, db_column='todo_item_guid')
    auth_role_guid = models.ForeignKey(AuthRoleSadc, db_column='auth_role_guid')
    wx_role_todo_guid = models.CharField(primary_key=True, max_length=36)

    class Meta:
        managed = False
        db_table = 'wx_role_todo'

    def save(self, *args, **kwargs):
        if not self.pk:
            #print("Empty guid during save")
            logger.debug("Empty guid during save")
            self.wx_role_todo_guid = str(uuid.uuid4())
        super(WxRoleTodo, self).save(*args, **kwargs)


class TodoList(models.Model):
    todo_list_guid = models.CharField(primary_key=True, max_length=36)
    todo_list_title = models.CharField(max_length=200, blank=True, null=True)
    todo_list_desc = models.CharField(max_length=500, blank=True, null=True)
    application_type_guid = models.ForeignKey('ApplicationType', db_column='application_type_guid', blank=True, null=True)
    todo_list_json = jsonfield.JSONField()
    created_date = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    created_user_guid = models.ForeignKey('AuthUserSadc', db_column='created_user_guid', related_name='created_user_todolist', blank=True, null=True)
    active_flg = models.NullBooleanField()

    class Meta:
        managed = False
        db_table = 'todo_list'

    def save(self, *args, **kwargs):
        # Check if todo_list_json is string, if not, convert to text
        #if not isinstance(self.todo_list_json, basestring):
        #    print '>>>>>', type(self.todo_list_json)
        #    self.todo_list_json = json.dumps(self.todo_list_json)

        user = None
        userid = get_current_user()
        if userid:
            user = AuthUserSadc.objects.get(pk=userid)
        # If no pk on save, must be a new record.
        if not self.pk:
            logger.debug("Empty todo_list_guid during save")
            self.todo_list_guid = str(uuid.uuid4())
            self.created_date = timezone.now()
            self.created_user_guid = user
            self.active_flg = 1
        super(TodoList, self).save(*args, **kwargs)
        logger.debug("Todo List %s saved" % self.todo_list_title )


class TransactionStatus(models.Model):
    trans_status_desc = models.CharField(primary_key=True, max_length=30)
    class Meta:
        managed = False
        db_table = 'transaction_status'


class TransactionType(models.Model):
    transaction_type_desc = models.CharField(primary_key=True, max_length=30)
    class Meta:
        managed = False
        db_table = 'transaction_type'

class Workflow(models.Model):
    workflow_guid = models.CharField(primary_key=True, max_length=36)
    workflow_name = models.CharField(max_length=50, blank=True, null=True)
    workflow_lock = models.NullBooleanField()
    workflow_blob = models.BinaryField(blank=True, null=True)
    created_user_guid = models.CharField(max_length=36, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'workflow'


    def save(self, *args, **kwargs):
        if self.workflow_guid == '':
            #print("Empty guid during save")
            logger.debug("Empty guid during save")
            self.workflow_guid = str(uuid.uuid4())
        super(Workflow, self).save(*args, **kwargs)


class WorkflowDocument(models.Model):
    workflow_document_guid = models.CharField(primary_key=True, max_length=36)
    workflow_type_desc = models.ForeignKey('WorkflowType', db_column='workflow_type_desc', blank=True, null=True)
    workflow_desc = models.CharField(max_length=40, blank=True, null=True)
    workflow_document_blob = models.BinaryField(blank=True, null=True)
    created_user_guid = models.CharField(max_length=36, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    active_flg = models.NullBooleanField()

    class Meta:
        managed = False
        db_table = 'workflow_document'

    def save(self, *args, **kwargs):
        if self.workflow_doc_guid == '':
            #print("Empty guid during save")
            logger.debug("Empty guid during save")
            self.workflow_doc_guid = str(uuid.uuid4())
        super(WorkflowDocument, self).save(*args, **kwargs)

class WorkflowProcess(models.Model):
    wp_guid = models.CharField(primary_key=True, max_length=36)
    wp_trigger_desc = models.ForeignKey('WpTrigger', db_column='wp_trigger_desc', blank=True, null=True)
    wp_seq = models.IntegerField(blank=True, null=True)
    rule_definition_guid = models.ForeignKey('RuleDefinition', db_column='rule_definition_guid', blank=True, null=True)
    application_phase_guid = models.ForeignKey('ApplicationPhase', db_column='application_phase_guid', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'workflow_process'

class WorkflowType(models.Model):
    workflow_type_desc = models.CharField(primary_key=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'workflow_type'

class WpStatus(models.Model):
    wp_status_desc = models.CharField(primary_key=True, max_length=50)

    class Meta:
        managed = False
        db_table = 'wp_status'


class WpTracker(models.Model):
    wp_tracker_guid = models.CharField(primary_key=True, max_length=36)
    wp_guid = models.CharField(max_length=36)
    wp_status_desc = models.ForeignKey('WpStatus', db_column='wp_status_desc')
    application_key = models.ForeignKey('Application', db_column='application_key',related_name='app_wptracker', blank=True, null=True)
    wpt_log_who = models.CharField(max_length=36, blank=True, null=True)
    wpt_log_when = models.DateTimeField(blank=True, null=True)
    wpt_log_what = models.CharField(max_length=500, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'wp_tracker'

class WpTrigger(models.Model):
    wp_trigger_desc = models.CharField(primary_key=True, max_length=50)

    class Meta:
        managed = False
        db_table = 'wp_trigger'



class WxApplicationNote(models.Model):
    wx_app_note_guid = models.CharField(primary_key=True, max_length=36)
    application_key = models.ForeignKey(Application, db_column='application_key')
    note_group_guid = models.ForeignKey(NoteGroup, db_column='note_group_guid')

    class Meta:
        managed = False
        db_table = 'wx_application_note'

    def save(self, *args, **kwargs):
        if not self.pk:
            #print("Empty guid during save")
            logger.debug("Empty guid during save")
            self.wx_app_note_guid = str(uuid.uuid4())
        super(WxApplicationNote, self).save(*args, **kwargs)


class WxApplicationDocument(models.Model):
    app_document_guid = models.CharField(primary_key=True, max_length=36)
    application_key = models.ForeignKey('Application',  db_column='application_key')
    document_guid = models.ForeignKey('Document',  db_column='document_guid')

    class Meta:
        managed = False
        db_table = 'wx_application_document'

    def save(self, *args, **kwargs):
        # If no guid on save, must be a new record.
        if not self.pk:
            logger.debug("Empty app_document_guid during save")
            self.app_document_guid = str(uuid.uuid4())
        super(WxApplicationDocument, self).save(*args, **kwargs)
        logger.debug("WxApplicationDocument %s saved" % self.app_document_guid )


class WxFarmDocument(models.Model):
    farm_document_guid = models.CharField(primary_key=True, max_length=36)
    farm_key = models.ForeignKey('Farm', db_column='farm_key')
    document_guid = models.ForeignKey('Document', db_column='document_guid')

    class Meta:
        managed = False
        db_table = 'wx_farm_document'

    def save(self, *args, **kwargs):
        # If no guid on save, must be a new record.
        if not self.pk:
            logger.debug("Empty farm_document_guid during save")
            self.farm_document_guid = str(uuid.uuid4())
        super(WxFarmDocument, self).save(*args, **kwargs)
        logger.debug("WxFarmDocument %s saved" % self.farm_document_guid )



class WxFarmNote(models.Model):
    wx_farm_note_guid = models.CharField(primary_key=True, max_length=36)
    farm_key = models.ForeignKey(Farm, db_column='farm_key')
    note_group_guid = models.ForeignKey(NoteGroup, db_column='note_group_guid')

    class Meta:
        managed = False
        db_table = 'wx_farm_note'

    def save(self, *args, **kwargs):
        if not self.pk:
            #print("Empty guid during save")
            logger.debug("Empty guid during save")
            self.wx_farm_note_guid = str(uuid.uuid4())
        super(WxFarmNote, self).save(*args, **kwargs)



class WxFarmLandUse(models.Model):
    farm_land_use_date = models.DateField(blank=True, null=True)
    farm_land_use_desc = models.ForeignKey(FarmLandUse, db_column='farm_land_use_desc')
    parcel_guid = models.ForeignKey(FarmParcel, db_column='parcel_guid')

    class Meta:
        managed = False
        db_table = 'wx_farm_land_use'


class WxManagedRole(models.Model):
    auth_role_guid = models.ForeignKey(AuthRoleSadc, db_column='auth_role_guid')
    auth_user_guid = models.ForeignKey(AuthUserSadc, db_column='auth_user_guid')
    wx_managed_role_guid = models.CharField(primary_key=True, max_length=36)

    class Meta:
        managed = False
        db_table = 'wx_managed_role'


class WxUserRole(models.Model):
    auth_user_guid = models.ForeignKey(AuthUserSadc, db_column='auth_user_guid')
    auth_role_guid = models.ForeignKey(AuthRoleSadc, db_column='auth_role_guid')
    wx_user_role_guid = models.CharField(primary_key=True, max_length=36)

    class Meta:
        managed = False
        db_table = 'wx_user_role'

    def save(self, *args, **kwargs):
        if not self.pk:
            self.wx_user_role_guid = str(uuid.uuid4())
        super(WxUserRole, self).save(*args, **kwargs)

