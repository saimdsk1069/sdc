from __future__ import with_statement
from fabric.api import local, settings, abort, run, cd, env, put
from fabric.contrib.console import confirm

import time
import datetime
import os
import logging

logger = logging.getLogger(__name__)

env.user = 'apache'
env.hosts = ['apache@wading02.oit.state.nj.us']

username = os.getenv("USERNAME")
appname = 'AG_SADCeFarms'
app_dir = '/opt/django_apps/' + appname
log_dir = '/opt/django_apps/archive/'
logfile = log_dir + 'djangodeploy.log'

def deploy():
    with settings(warn_only=True):
        if run("test ! -e %s.lck" % app_dir ).succeeded: # Lock file doesn't exist, so do deployment
            timestamp = '{:%Y-%m-%d %H:%M:%S}'.format(datetime.datetime.now())
            #with cd(app_dir):
            run("echo \"%s %s\" > %s.lck" % ( timestamp, username, app_dir ) )# Create a lock file until deployment is complete
            run("echo '%s: Deployment of %s by %s has started.' >> %s" % ( timestamp, appname, username, logfile ))
            #local("python ../manage.py collectstatic --noinput")
            run("/usr/local/bin/django_archive %s" % appname)
            #print("Archiving application is complete")
            logger.debug("Archiving application is complete")
            #print("Removing old application")
            logger.debug("Removing old application")
            run("rm -r %s" % app_dir)
            logger.debug("Copying the application to the server.")
            #print("Copying the application to the server.")
            put('../../%s' % appname, '/opt/django_apps')
            #print("Setting permissions for the application")
            logger.debug("Setting permissions for the application")
            # run("chown -R apache:apache %s" % app_dir )
            run("chmod -R 750 %s" % app_dir )
            #print("Cleaning up files")
            logger.debug("Cleaning up files")
            run("find %s -name 'CVS' -exec rm -r {} \;" % app_dir ) # Get rid of any CVS files
            run("find %s -name '.idea' -exec rm -r {} \;" % app_dir ) # Get rid of any .idea files
            run("find %s -name '.DS_Store' -exec rm {} \;" % app_dir ) # Get rid of any .DS_Store
            run('find %s -name "*.pyc" -exec rm {} \;' % app_dir ) # Get rid of any .pyc files Why ' instead of "? Wildcard requires it.
            run("find %s -type d -name 'deployment' -exec rm -r {} \;" % app_dir ) # Get rid of deployment directory
            run("find %s -type d -name 'configuration_info' -exec rm -r {} \;" % app_dir ) # Get rid of the configuration information directory
            run("rm -r %s/admin_authAdmin/data_loading" % app_dir ) # Get rid of the configuration information directory
            #print("Restarting Apache")
            logger.debug("Don't forget to restart Apache!")
            # run("/usr/apache2/2.4/bin/apachectl stop")
            # #print("Sleeping to wait for stop to finish")
            # logger.debug("Sleeping to wait for stop to finish")
            # time.sleep(10)
            # run("/usr/apache2/2.4/bin/apachectl start")
            # #print("Apache Restart Complete")
            # logger.debug("Apache Restart Complete")
            run("rm %s.lck" % app_dir ) # Remove the lock file
            timestamp = '{:%Y-%m-%d %H:%M:%S}'.format(datetime.datetime.now())
            run("echo '%s: Deployment of %s by %s has completed.' >> %s" % ( timestamp, appname, username, logfile ))
        else:
            #print("ANOTHER DEPLOYMENT IS IN PROGRESS, PLEASE TRY AGAIN LATER")
            logger.debug("ANOTHER DEPLOYMENT IS IN PROGRESS, PLEASE TRY AGAIN LATER")
            #print("CURRENT DEPLOYMENT IN PROGRESS:")
            logger.debug("CURRENT DEPLOYMENT IN PROGRESS:")
            run("cat %s.lck" % app_dir ) # Show the current lock file



