from . import utils

def intersectUserCredAndPgmPerm(ucList, ppList):
    # ucList --> User cred list (list of eFarms roles)
    # ppList --> Role-Permission list for a program or instance of a program (an application, by its status & milestone types)

    intACL = {}
    intUCL = []
    intPPL = []

    # todo: clean-up
    # print "ppList: " + str(ppList)
    # print "ucList: " + str(ucList)

    if ppList and ucList:
        for uc in ucList:
            for pp in ppList:
                # todo: define public access; absence of tier type cannot be access to all. doesn't sound right
                # if None == pp.tier_type_guid and None == pp.tier_group_type_guid and None == pp.tier_subgroup_type_guid and None == pp.partner_type_guid:
                #     # Public access? Should never happen for app.
                #     # Will happen for doc but this may not be the right place for that anyway?
                #     intPPL.append(pp)
                #     intUCL.append(uc)
                #     # break
                # else:

                # print "Tier check: " + pp.tier_type_guid + " = = " + uc["tier_type_guid"]
                if pp.tier_type_guid and pp.tier_type_guid == uc["tier_type_guid"]:
                    # Tier - match!
                    if pp.tier_group_type_guid:
                        # tier group present
                        # print "Tier group check: " + pp.tier_group_type_guid + " = = " + uc["tier_group_guid"]
                        if pp.tier_group_type_guid == uc["tier_group_guid"]:
                            #   Tier & tier group match
                            if pp.tier_subgroup_type_guid or pp.partner_type_guid:
                                #  tier sub group and/or partner type presnt
                                #  role is based on tier, tier group, tier sub group and/or partner type
                                addToList = True
                                # print "Tier sub-group check: " + pp.tier_subgroup_type_guid + " = = " + uc["tier_subgroup_guid"]
                                if pp.tier_subgroup_type_guid:
                                    # sub group present
                                    if pp.tier_subgroup_type_guid == uc["tier_subgroup_guid"]:
                                        addToList = True
                                    else:
                                        addToList = False

                                # print "Partner_name check: " + pp.partner_type + " = = " + uc["partner_name"]
                                if addToList and pp.partner_type_guid:
                                    # partner type present and tier_subgroup_guid is either null or match
                                    if pp.partner_type_guid == uc["partner_type_guid"]:
                                         addToList = True
                                    else:
                                        addToList = False

                                if addToList:
                                    intPPL.append(pp)
                                    intUCL.append(uc)
                                    # break
                            else:
                                # Neither tier sub group nor partner type, role is based on tier & tier group
                                intPPL.append(pp)
                                intUCL.append(uc)
                                # break
                    else:
                        # No tier group; role is based on tier
                        intPPL.append(pp)
                        intUCL.append(uc)
                        # break

    # print "intppList: " + str(intPPL)
    # print "intucList: " + str(intUCL)
    intACL["intUC"] = intUCL    # User cred
    intACL["intPP"] = intPPL    # Program permission

    return intACL

def sortByTierPriority_notused():
    tierRank = {"ADMIN": 5, "SADC STAFF": 4, "PARTNER": 3, "SADC MANAGEMENT": 2, "FARM/PROGRAM CONTACT": 2, "VENDOR": 2, "PUBLIC": 1}
    # Admin & Public tier should ideally never show up here! Keeping for completeness.
    ret = []
    return ret

def usrappmode(uobj, appInfo):
    # todo: tailored for planning applications; got to make it generic post AA
    #  4/22/2016

    # def usrappmode(usrroles, appstatus, approvaltype):
    # todo - after integrating w/ authadmin;
    #       cleanup
    #       externalize logic to DB where possible
    #       Make code sharable with other parts of app
    # Based on  Application status + User roles
    # determine user privilege on the app and view mode
    #       View mode - Public for approved doc; Partner during SADC review phase
    #       Edit mode - Partner edits before submission; Staff review post submission; ...
    #       + Comments/Attachments --> Staff comment priv for partner (for every comment), ...

    # User viewmode (UI) Options: deny, view, append, sign, submit, edit

    ret = 'deny'    # default; unless proven otherwise
    usrapppriv = distilluser(uobj, appInfo)  # User role on the app + comment/attachment tier score
    # print "usrapppriv "+ str(usrapppriv)
    utype = usrapppriv['app_role']
    #
    # print "utype" + str(utype)

    # todo - make everything case insensitive check
    if 'Public' in utype:
        if 'Approved' == appInfo.status and 'Final' == appInfo.approvaltype:
            ret = 'public'  # SADC public doc - Committee resolution
        else:
            ret = 'deny'

    else:
        # may procced if user is either SADC staff or applicant partner or somebody with privilege to app
        # todo: LO rules

        # By now user tied to the highest role
        #     SADC-SO --> PL + Approve for Committee + Sign committee approved
        #     PL --> GISS + Submit for approval + Submit to committee (for planning applications)
        #           + Ability to edit application prior to submission, to assist partners with the app process (?)
        #     GISS --> SADC Staff + Append (comments & uploads)
        #     SADC-VIEW/SADC Staff -->  View
        #     LocalSO --> LocalSS + Sign before submit to SADC
        #     LocalRep --> LocalSS + Submit to LocalSO, Submit to SADC
        #     LocalSS --> Edit
        #     LocalPS --> Edit
        # Who does what & when to be determined by workflow manager; beyond scope for django view - By design;
        # Diff levels of separation helps wth loose coupling (BTW what is this supposed to mean? :) )

        ret = 'view'    # lowest allowed at this stage
        if ('Approved' == appInfo.status) and ('Preliminary' == appInfo.approvaltype):
            # No data edit (of existing) but could append through comments & uploads
            if 'SADC Staff' not in utype:   # todo - got to revisit
                ret = 'append'
        elif 'Incoming' == appInfo.status:
            if 'LocalSO' in utype:
                ret = 'sign'
            elif 'LocalRep' in utype:
                ret = 'submit'
            elif 'LocalPS' in utype or 'LocalSS' in utype:
                # or 'PL' == utype:  --> Should get custom privilege instead??
                # PL to assist partner through app process
                ret = 'edit'
            # elif 'GISS' in utype:
            #     ret = 'append'
        elif 'Review' == appInfo.status:
            if 'SADC-SO' in utype:
                ret = 'sign'
            elif 'PL' in utype:
                ret = 'submit'
            elif 'GISS' in utype:
                ret = 'append'
        # already covered ??
        # elif 'Denied' == appstatus:
        #      ret = 'view'  # SADC *; Local *

    usrapppriv['viewmode'] = ret
    return usrapppriv

def distilluser(uobj, ai):
    # todo - finalize code after authAdmin
    # Extract user role & tier over application and comment/attachments
    # Based on the user role(s); extract user
    #   Privilege on application
    #   Tier score for comment/attachments (within the application)
    uroles = utils.getobjbykey(uobj, "roles")
    apppriv = {'app_role': [], 'ca_tier': getcatierscore('Public')}
    # utype = 'Public'
    # if 'SADC-VIEW' in uroles:
    #     utype = 'SADC Staff'  # SADC staff
    # elif 'LocalSO' in uroles:
    #     utype = 'LocalSO'
    # elif 'LocalRep' in uroles:
    #     utype = 'LocalRep'
    # elif 'LocalSS' in uroles:
    #     utype = 'LocalSS'
    # elif 'LocalPS' in uroles:
    #     utype = 'LocalPS'

    utype = []
    for ur in uroles:
        if "SADC" == ur["tier_type"]:
            utype.append('SADC Staff')

        if "PROGRAM PARTNER" == ur["tier_group"]:
            #  Is pgm  partner; next confirm whether pgm partner for app in question
            if ai.partnername == ur["partner_name"] or ai.partnerid == ur["partner_guid"]:
                # Is application partner. identify partner official type

                if ur["tier_subgroup"] == "SIGNATORY OFFICIAL":
                    utype.append('LocalSO')

                if ur["tier_subgroup"] == "COORDINATOR":
                    utype.append('LocalRep')

                if ur["tier_subgroup"] == "SUPPORT STAFF":
                    utype.append('LocalPS')

                apppriv['ca_tier'] = getcatierscore('Partner')

    # if no role provide public access
    if len(utype) == 0:
        utype.append('Public')

    # # Check custom permission for the user on this application
    # # Could apply for
    # #   SADC staff helping out a partner
    # #   County coordinator helping out muni ...
    # #   3rd party consultants helping out on this application
    # # privileges = getCustomPrivByEntity(uobj, ai.programtype, ai.partnername)
    # # privileges could be 0 length array
    #
    #         privileges = []  # todo: fix this mess
    #         # todo - custom priv will be roles; so this concept is going away
    #         for p in privileges:
    #             # Check comment/attachment access tier score based on privileges. Provide highest score
    #             # Assign 'Support staff' or LO score, if was assigned lower (public) score previously
    #             score = 0
    #             if 'LO' == p:
    #                 score = getcatierscore('LO')
    #             else:
    #                 score = getcatierscore('Support')
    #
    #             if apppriv['ca_tier'] < score:
    #                 apppriv['ca_tier'] = score
    #
    #         if len(privileges) > 0:
    #             if 'Public' != utype:
    #                 privileges.extend([utype])
    #         else:
    #             privileges.insert(0, utype)
    #
    #         apppriv['app_role'] = privileges

    apppriv['app_role'] = utype
    return apppriv

def getCustomPrivByEntity(uobj, programType, programRef):
    # Not application partner
    # check custom privilege
    # Entity; ID; Role    todo: This structure is still evolving; finalize it post AA
    #     "entity": "planning",
    #     "id": "Moorestown Township",
    #     "role": "LocalSS"
    ret = []
    upriv = utils.getobjbykey(uobj, "user.permissions")
    # print upriv
    for p in upriv:
        if p["entity"] == programType and p["id"] == programRef:
            ret.append(p["role"])

    return ret

def getcatierscore(tier):
    """
    :param tier: User tier based on their role.
    :return: Tier score
    """
    # Get comment/attachment access tier score
    # Access (view) to comment/attachment are based on tier level.
    # For an user to see; their tier should have a score equal or better than the comm & att 's score

    # todo - externalize & improve after authAdmin
    # made it float to leave room to grow; sub-tiers e.g. Partner rep vs Partner support non-profit
    privtiers = {'SADCStaff': 9.9, 'Partner': 7.0, 'Support': 5.0, 'LO': 3.0, 'SADCMgt': 3.0, 'Public': 1.0}

    ret = 99
    if tier in privtiers:
        ret = privtiers[tier]
    else:
        ret = privtiers['Public']
    return ret

# def getuserdetails(uid):
#     # get user details
#     usr = None
#     # print "uid: "+ uid
#     if None != uid:
#         # todo - Call AA (auth admin) to get user details
#         # usr = gettestuserbyid(uid)  # todo - replace w/ actual; after AA integration; not sure what all is brought in by AA
#         pl_user = '{"sessionexpiration":1460531034,"user":{"id":"sadcpl","name":"SADC Planning","email":"jay.rajamohan@oit.nj.gov","type":["SADC Staff"],"org":"SADC","orgtype":"SADC","agstoken":"RVwb_MkM4jBTuvD3JJ7VMWro7AaWpd4RWom5xC9ozmx0BA4GsVqWWfRXKOY99CuHUZ2j752Qdk3GzVPs2iJZeRPU1C2KoqOEZfNwpfyHSfnGjpI8-Y8mhjye_xrF1gxe","roles":["SADC-VIEW","PL"],"permissions":[]}}'
#         local_rep_user = '{"sessionexpiration":1470231034,"user":{"id":"lrep","name":"Pgm Partner & EH","email":"jay.rajamohan@oit.nj.gov","type":["program partner","Easement Holder"],"org":"Burlington County","orgtype":"County","agstoken":"RVwb_MkM4jBTuvD3JJ7VMWro7AaWpd4RWom5xC9ozmx0BA4GsVqWWfRXKOY99CuHUZ2j752Qdk3GzVPs2iJZeRPU1C2KoqOEZfNwpfyHSfnGjpI8-Y8mhjye_xrF1gxe","roles":["LocalSO","LocalRep"],"permissions":[{"entity":"farm","id":"<farm id 123>","role":"LO"},{"entity":"farm","id":"<farm id 345>","role":"FO (Farm operator)"}, {"entity": "planning","id": "Moorestown Township","role": "LocalSS"}]}}'
#
#         # print "local_rep_user: " + local_rep_user
#         usr = json.loads(local_rep_user)
#
#     if None == usr:
#          usr = json.loads('{"sessionexpiration":0,"user":{"id":"*","name":"","email":"","type":"Public","org":"Public","orgtype":"Public","agstoken":"","roles":["Public"],"permissions":[]}}', strict=False)
#
#     return usr

def clearuserdetails(uid):
    # todo - Call AA to clear user session; after AA integration
    return

def terminateSession():
    # todo - terminate session and force to logout page
    return '../home/logout.html'

def getGridItemsForUsr(usr):
    # Role based
    # get landing page items for user based on their role.
    # Make an array of JSON strings (feed from DB)
    # convert to PY and send to calling func
    ret = []
    # Search/Query panel
    ret.append({"name":"searchfarms","label":"Search NJFPP Farms","url":"/home/search","metadata":"Not sure - place holder; Mini Help?"})

    # Search committee resolutions
    ret.append({"name":"searchfinal","label":"Search Committee Resolutions","url":"/home/searchresolutions","metadata":"Search SADC committee resolutions"})

    ret.append({"name":"searchtest1","label":"Test 1","url":"/home/searchresolutions","metadata":"Search SADC committee resolutions"})
    ret.append({"name":"searchtest2","label":"Test 2","url":"/home/searchresolutions","metadata":"Search SADC committee resolutions"})
    ret.append({"name":"searchtest3","label":"Test 3","url":"/home/searchresolutions","metadata":"Search SADC committee resolutions"})
    # ret.append({"name":"searchfr","label":"Test 4","url":"/home/searchresolutions","metadata":"Search SADC committee resolutions"})

    return ret

def getMenuDropDownsForUsr(usr):
    # Menu drop downs should be role based? Or role & permission based?
    # Maybe this has to happen at page load, instead of lazy load. The Menu items got to stay,
    # irrespective of whether the user navigate to some other portion of the app

    # todo: hardcoded till DB is in place
    ret = [{"name": "home", "label": "Home", "parent": "", "url": "", "pgTarget": "_top", "metadata": "Place holder; Mini Help?"}]
    usrR = utils.getobjbykey(usr, "roles")
    # print "usrRoles: " + str(usrR)

    if usrR:
        # Authenticated user
        if utils.genfilter(usrR, "tier_type", "SADC STAFF"):
            # SADC folks - get all
            ret.extend(getMenuItemsByKey("acq", ["COUNTY", "MUNI", "NP", "DE"]))
            ret.extend(getMenuItemsByKey("plan", None))
            ret.extend(getMenuItemsByKey("stw", None))
            ret.extend(getMenuItemsByKey("rtf", None))
            ret.extend(getMenuItemsByKey("rpt", None))

        elif utils.genfilter(usrR, "tier_type", "PARTNER"):
            # SADC partners - Program and/or Easement
            subKey = []
            ppList = utils.genfilter(usrR, "tier_group", "PROGRAM PARTNER")
            if ppList:
                for r in ppList:
                    if r["county"]:
                        # get county PIG info ACQ & PL
                        subKey.append("COUNTY")
                        break
                for r in ppList:
                    if r["municipality"]:
                        # get municipality PIG info ACQ & PL
                        subKey.append("MUNI")
                        break

                if subKey:
                    ret.extend(getMenuItemsByKey("acq", subKey))
                    ret.extend(getMenuItemsByKey("plan", None))

            if utils.genfilter(usrR, "tier_group", "EASEMENT PARTNER"):
                ret.extend(getMenuItemsByKey("stw", None))

            ret.extend(getMenuItemsByKey("rpt", None))

        if utils.genfilter(usrR, "tier_type", "ADMIN"):
            # SADC ADMIN
            subKey = []
            if utils.genfilter(usrR, "tier_subgroup", "APPLICATION MANAGER"):
                subKey.append("APPLICATION MANAGER")

            if utils.genfilter(usrR, "tier_subgroup", "USER MANAGER"):
                subKey.append("USER MANAGER")

            if subKey:
                ret.extend(getMenuItemsByKey("manage", subKey))


    # Details tab for all
    ret.append({"name": "details", "label": "Details", "parent": "", "url": "", "pgTarget": "", "metadata": "Place holder; Mini Help?"})
     # print "ret : " + ret
    ret = prepareMenuItemsForDisplay(ret)

    return ret

def getMenuItemsByKey(k1, k2):
    ret = []
    # todo: externalize these!!!!!

    if "acq" == k1:
        ret.append({"name": "acq", "label": "Acquisition", "parent": "", "url": "", "pgTarget": "", "metadata": "Place holder; Mini Help?"})
        if "COUNTY" in k2:
            ret.append({"name": "aq_CPIG", "label": "County PIG Application(s)", "parent": "acq", "url": "../acq/application/list/?cpig", "pgTarget": "", "metadata": "Place holder; Mini Help?"})
        if "MUNI" in k2:
            ret.append({"name": "aq_MPIG", "label": "Municipal PIG Application(s)", "parent": "acq", "url": "../acq/application/list/?mpig", "pgTarget": "", "metadata": "Place holder; Mini Help?"})
        if "NP" in k2:
            ret.append({"name": "aq_NP", "label": "Non-Profit Application(s)", "parent": "acq", "url": "../acq/application/list/?np", "pgTarget": "", "metadata": "Place holder; Mini Help?"})
        if "DE" in k2:
            ret.append({"name": "aq_DE", "label": "Direct Easement Application(s)", "parent": "acq", "url": "../acq/application/list/?de", "pgTarget": "", "metadata": "Place holder; Mini Help?"})

        ret.append({"name": "aq_FAQ", "label": "Frequently Asked Questions", "parent": "acq", "url": "http://www.nj.gov/agriculture/sadc/farmpreserve/programs/pigcountyfaqs.pdf", "pgTarget": "", "metadata": "Place holder; Mini Help?"})
        ret.append({"name": "aq_GR", "label": "Guidelines & Resources", "parent": "acq", "url": "http://www.nj.gov/agriculture/sadc/farmpreserve/programs/countyPIG.html", "pgTarget": "", "metadata": "Place holder; Mini Help?"})

    elif "plan" == k1:
        ret.append({"name": "plan", "label": "Planning", "parent": "", "url": "", "pgTarget": "", "metadata": "Place holder; Mini Help?"})
        ret.append({"name": "pl_IG", "label": "Annual Application(s)", "parent": "plan", "url": "../planning/application/list/", "pgTarget": "", "metadata": "Place holder; Mini Help?"})
        ret.append({"name": "pl_FAQ", "label": "Frequently Asked Questions", "parent": "plan", "url": "http://www.nj.gov/agriculture/sadc/farmpreserve/programs/pigcountyfaqs.pdf", "pgTarget": "", "metadata": "Place holder; Mini Help?"})
        ret.append({"name": "pl_GR", "label": "Guidelines & Resources", "parent": "plan", "url": "http://www.nj.gov/agriculture/sadc/farmpreserve/programs/countyPIG.html", "pgTarget": "", "metadata": "Place holder; Mini Help?"})

    elif "stw" == k1:
        ret.append({"name": "stw", "label": "Stewardship", "parent": "", "url": "", "pgTarget": "", "metadata": "Place holder; Mini Help?"})

    elif "rtf" == k1:
        ret.append({"name": "rtf", "label": "Right to farm", "parent": "", "url": "", "pgTarget": "", "metadata": "Place holder; Mini Help?"})

    elif "rpt" == k1:
        ret.append({"name": "rpt", "label": "Reports", "parent": "", "url": "../reports/", "pgTarget": "", "metadata": "Place holder; Mini Help?"})

    elif "manage" == k1:
        ret.append({"name": "manage", "label": "Admin", "parent": "", "url": "", "pgTarget": "", "metadata": "Place holder; Mini Help?"})
        if "APPLICATION MANAGER" in k2:
            ret.append({"name": "mg_QS", "label": "App Questionnaire Mgmt", "parent": "manage", "url": "../efmanage/list/", "pgTarget": "_blank", "metadata": "Place holder; Mini Help?"})
        if "USER MANAGER" in k2:
            ret.append({"name": "mg_US", "label": "User Mgmt", "parent": "manage", "url": "../manageusers/", "pgTarget": "_blank", "metadata": "Place holder; Mini Help?"})

    return ret

def prepareMenuItemsForDisplay(mitems):
    # This to prepare menu items for display; Django template is not quite flexible.
    # If you write in JS, at browser; the menu items will start loading only after the page
    # is loaded and that could look ugly

    # Add a new field to flag whether the menu item will have sub-items or not
    for m in mitems:
        m["haschild"] = False

    # Group menu items by their parents
    ret = groupItemsByParents(mitems, '')

    # todo: now that we are converting object to HTML here; combine groupItemsByParents & htmlNavBar
    # now it looks like unnecessary hoops

    # prepare as HTML and send to client; save a lot of pain - django template coding
    ret = htmlNavBar(ret, '')

    return ret

def groupItemsByParents(items, parentval=''):
    # Group the elements by their parents
    ret = []
    farr = utils.genfilter(items, 'parent', parentval)
    for m in farr:
        carr = groupItemsByParents(items, m['name'])
        if len(carr) > 0:
            m["haschild"] = True
        ret.append(m)
        ret.extend(carr)

    return ret

def htmlNavBar(milist, parentval=''):
    # Custom voodoo to overcome django template limitations
    #todo: use HTML DOM to create these from server side JSON feed
    ret = ""
    mitems = utils.genfilter(milist, "parent", parentval)
    for m in mitems:
        if m["haschild"]:
            ret += '<li class="dropdown'
            if m["parent"] != "":
                ret += ' dropdown-submenu'
            ret += '"><a class="dropdown-toggle" ' \
                   'data-toggle="dropdown" href="javascript:void();">'+ m["label"]
            if m["parent"] == "":
                ret += '<span class="caret"></span>'
            ret += '</a> <ul class="dropdown-menu">'
            ret += htmlNavBar(milist, m["name"])
            ret += '</ul></li>'
        else:
            ret += '<li><a href="' + m["url"] + '" data-target="' + m["pgTarget"] + '">' + m["label"] + '</a></li>'

        # inverse scheme for drop down items & sub-menu items
        # navbar-inverse   <span class="ef_menu_inverse_txt">   </span>
        # .ef_menu_inverse_txt>label
        # {
        #     color: #ffffff; background-color: transparent;
        # }
    return ret


def filterUserCred(ucList, param, val):
    # If the param in UC have a value specified, it should match.
    # Include param even if it doesn't have a value in UC, as the role could be authorized on tier/'ANY' mode ???
    ret = []
    for uc in ucList:
        # print "uc : " + str(uc)
        if param in uc:
            if uc[param] != "":
                # Param in UC have value
                if uc[param] == val:
                    ret.append(uc)
            else:
                # Param in UC is empty
                ret.append(uc)
    return ret