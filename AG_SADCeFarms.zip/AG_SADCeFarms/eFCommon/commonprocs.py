from eFCommon.models import QuestionnaireForDisplay, AppInfo
import utils
# import sys

# def getQuestionnaireByProgram(pgmname, pgmtype):
#     from .models import Questionnaire
#     # List the questions by program - Name & type.
#
#     qs = Questionnaire()
#     # Not the right usage? but this way everything custom will be self contained
#
#     # prepSQL
#     #   sectionactive --> None for all, 1 for active & 0 for inactive
#     #   questionactive --> None for all, 1 for active & 0 for inactive
#     #   withsectionidfilter --> True to Add section ID filter, False to ignore
#     #   withquestionidfilter  --> True to Add question ID filter, False to ignore
#     sqlstr = qs.prepSQL(None, None, False, False)
#     # print sqlstr
#
#     try:
#         # force queryset evaluation, before sending to page.
#         # May not be necessary, isn't sure whether each for loop will re-evaluate the queryset
#         return (list(Questionnaire.objects.raw(sqlstr, [pgmname, pgmtype])))
#
#     except:
#         # todo: Log error here; Client notification handled by caller
#         return list()
#
#
# def getQuestionnaireActiveByProgram(pgmname, pgmtype):
#     from .models import Questionnaire
#     # List the questions by program - Name & type ids.
#     # get only the active ones.
#     # To be used by application questionnaire as well as to manage the questions
#
#     qs = Questionnaire()
#     # Not the right usage; but this way everything custom will be self contained
#
#     # prepSQL
#     #   sectionactive --> None for all, 1 for active & 0 for inactive
#     #   questionactive --> None for all, 1 for active & 0 for inactive
#     #   withsectionidfilter --> True to Add section ID filter, False to ignore
#     #   withquestionidfilter  --> True to Add question ID filter, False to ignore
#     sqlstr = qs.prepSQL(1, 1, False, False)
#     # print sqlstr
#
#     try:
#         # force queryset evaluation, before sending to page.
#         # May not be necessary, isn't sure whether each for loop will re-evaluate the queryset
#         return (list(Questionnaire.objects.raw(sqlstr, [pgmname, pgmtype])))
#
#     except:
#         # todo: Log error here; Client notification handled by caller
#         return list()


def getSectionsByProgramMSID(pgmmsid):
    # return QuestionSection.objects.filter(program_type_id=pgmid)
    qfd = QuestionnaireForDisplay()
    # For the program milestone, get all active section(s)
    return list(QuestionnaireForDisplay.objects.raw(qfd.fetchByProgramMSId_SQL(False), {"msguid": pgmmsid}))

def prepareSectionForTreeView(allS, filteredS):
    # Sample
    #   (Missing in sample is href param; used here to handle section's id)
    # [{"text":"Overview","nodes":[{"text":"Individual or compiled","nodes":[{"text":"Data attributes"},{"text":"Programmatic API"}]},
    # {"text":"No conflict"}]},{"text":"Transitions"},{"text":"Modal"},{"text":"Dropdown"}]

    ret = []
    if None == filteredS:
        #first time; Get all sections that are at root
        filteredS = utils.objListFilter(allS, "parentid", "")

    # filteredS = sorted(filteredS, key=lambda QuestionSection: QuestionSection.section_sequence)   # already sorted at sql query using meta tag
    for s in filteredS:
        sObl = {"text": s.text}
        sObl["href"] = s.id     # will have to add custom JS func instead?
        tlist =  utils.objListFilter(allS, "parentid", s.id)
        if len(tlist) > 0:
             sObl["nodes"] = prepareSectionForTreeView(allS, tlist)

        ret.append(sObl)

    return ret

def getQuestionsBySectionID(sid):
    qfd = QuestionnaireForDisplay()
    # Get both sections & questions for the section id
    return list(QuestionnaireForDisplay.objects.raw(qfd.fetchBySectionId_SQL(True), {"sectionid": sid}))

def prepareSQForClientView(ql):
    #  Sections (sub sections) & Questions
    ret = []
    for q in ql:
        qDict = {"id": q.id}
        qDict["itemtype"] = q.cattype
        qDict["parentid"] = q.parentid
        qDict["displayseq"] = q.displayseq
        qDict["text"] = q.text
        qDict["hint"] = q.hint
        qDict["pgm_milestoneid"] =  q.pgm_milestoneid
        qDict["questionsectionid"] = q.qsectionid
        qDict["path"] = q.question_path
        qDict["ansrequired"] = q.question_required
        qDict["anstype"] = q.answer_data_type
        qDict["trigger"] = q.trigger_value
        ret.append(qDict)

    return ret

def prepareAIForClientView(aL):
    # App info for client
    ret = []
    for a in aL:
        aiDict = {"id": a.id}
        aiDict["appdate"] = a.appdate.strftime('%Y-%m-%d')
        aiDict["programtype"] = a.programtype
        aiDict["programname"] = a.programname
        aiDict["programsubtypename"] = a.programsubtypename
        aiDict["partnername"] = a.partnername
        aiDict["status"] = a.status
        aiDict["milestonetype"] = a.milestonetype
        # todo: Post AA integration get user name, instead of ID; Change @ DB not here
        aiDict["lastupdatedby"] = a.lastediteduser
        aiDict["lastupdated"] = a.lastediteddate.strftime('%Y-%m-%d %I:%M %p')

        ret.append(aiDict)
    return ret

def prepareAnswerForClientView(aL):
    # Answers for client view
    # Answer id & program app id have no significance here; Its available at the calling end.
    # Answers were queried based on those to begin with

    ret = []
    for a in aL:
        anDict = {"answer": a.answer}
        if a.question_id:
            anDict["refid"] = a.question_id
        elif a.section_id:
            anDict["refid"] = a.section_id
        else:
            anDict["refid"] = None

        anDict["notegrp_id"] = a.notegrp_id
        anDict["docgrp_id"] = a.docgrp_id
        # todo: Post AA integration get user name, instead of ID; Change @ DB pull not here
        anDict["lastupdatedby"] = a.last_edited_user
        anDict["lastupdated"] = a.last_edited_date.strftime('%Y-%m-%d %I:%M %p')

        ret.append(anDict)

    return ret

def prepareNoteForClientView(nL):
    # Comments
    ret = []
    for n in nL:
        # nDict = {"id": n.note_group_id + "_" + n.id}
        # Add independent note id, only if it is really required at client
        nDict = {"grpid": n.note_group_id}
        nDict["note"] = n.note
        nDict["createddate"] = n.created_date.strftime('%Y-%m-%d %I:%M %p')
        nDict["createdby"] = n.created_user
        nDict["active"] = n.active
        ret.append(nDict)

    return ret

def prepareDocForClientView(dL):
    # Attached files
    ret = []
    for d in dL:
        # docInfo = {"name": aDoc.doc_name, "id": str(aDoc.id), "groupid": str(aDoc.doc_group_id)}
        ret.append({"name": d.doc_name, "id": d.id, "groupid": d.doc_group_id})
    return ret

def roleBasedCleansing(reviewlist, keyelement, userpriv):
    # reviewlist --> List of objects requiring review
    # keyelement --> Key in reviewlist that hold the priv info
    # userpriv --> user's max privilege level over the list's content.

    # for each object in list,  check the priv listed in key element.
    # Allow if user priv is at or above the object's
    # else drop the object from ret list
    # print "keyelement: "+ keyelement

    approvedList = []
    # try:
    for rl in reviewlist:
        if getattr(rl, keyelement) >= userpriv:
            approvedList.append(rl)

    # except:
    #     print "Error @ roleBasedCleansing   ", sys.exc_info()

    return approvedList


def getApplicationInfoByID(appid):
    # Application metadata
    # Return [AppInfo] as list; If none, empty list
    # Forcing to list here --> to force execute query & better error handling with list???
    aMeta = AppInfo()
    sqlStr = aMeta.selectSQLByID()
    return list(AppInfo.objects.raw(sqlStr, [appid]))


def getAppAppInfoByPgmTypeAndPrtnr(pgmType, pgmName, prtnrId, appDate):
    aMeta = AppInfo()
    paramDict = {"programtype": pgmType}
    if prtnrId:
        paramDict["partnerid"] = prtnrId
    if appDate:
        paramDict["appdate"] = str(appDate)   # without str() wrapper, its failing at val substitution!
    if pgmName:
        paramDict["programname"] = pgmName

    # paramDict["programsubtypename"] = "test"

    sqlStr = aMeta.selectSQLByParams(paramDict)
    return list(AppInfo.objects.raw(sqlStr, paramDict))


def getLatestApproved(prtnrID, pgmID):
    # Partner Id
    # Program ID
    # Milestone type = 'Approved'  # 'Approved - Preliminary' Never ???
    # Status type =  'Final'
    # Active = 1

    paramDict = {"partnerid": prtnrID, "programid": pgmID, "appmilestonename": "Approved", "status": "Final", "activeflag": "1"}
    aMeta = AppInfo()
    sqlStr = aMeta.selectSQLByParams(paramDict)
    return list(AppInfo.objects.raw(sqlStr, paramDict))