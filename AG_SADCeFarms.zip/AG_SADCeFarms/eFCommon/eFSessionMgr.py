# from django.contrib.sessions.backends.cached_db import SessionStore
# from django.http import HttpResponseRedirect
# from django.conf import settings
# from django.core import signing
# from time import time


import sys
# from . import aaa, utils
from admin_authAdmin import Authenticate

class RequestSniffer(object):

    def process_request(self, request):
        print(">>>> REQUEST BEING SENT:", request)
        # if request.user.is_authenticated():
        #     print "request.user is authenticated"
        # else:
        #     print "Nope"

        if request.session:
            print "session present - " + str(request.session)
        else:
            print "No session obj!"

        if request.user:    # Coming in as AnonymousUser
            print "User present - " + str(request.user)

            if request.user.is_active:
                print "User is actvie"
            else:
                print "What am i missing?"

        else:
            print "No user obj!"

        uCreds = None
        try:
            uCreds = Authenticate.get_credentials(request)
            # print "uCreds: " + str(uCreds)
            if uCreds:

                if "SUCCESS" == uCreds['status']:
                    # print "uCreds['username']: " + uCreds['username']
                    uCreds['userid'] = uCreds['username']   # todo: take it out after AA tweaked to provide id

                else:
                    # Not an authenticated user
                    print "Authentication check returned negative"
                    uCreds = None
            else:
                #     System failure???
                print "Authentication check failed - potential system err!"
                print sys.exc_info()
                uCreds = None

        except:
            print "Authentication check failed - potential system err!  ???"
            print sys.exc_info()

        finally:
            if None == uCreds:
                # Send a json string w/ empty elements
                uCreds = {'': ''}   # Will this work?

        request.efUsr = uCreds
        return None

    def process_response(self, request, response):
        # Wipe the user object (efUsr) set as request attribute on its way in
        if hasattr(request, "efUsr"):
            # efUsr is not set for authadmin requests; hence always check

            # Initiate process to save session at server side

            # create client token cookie

            # Wipe the full user object off HTTP Req/Res objects
            del request.efUsr

        return response

    # def process_request(self, request):
    #
    #     if request.path.startswith('/AuthAdmin'):
    #         # No check on traffic to authadmin
    #         return None
    #
    #     else:
    #         # All other calls
    #         # Get user id (or some key?), from client cookie.
    #         #   if none --> give public id
    #         #   if expired session --> redirect to login
    #         #   if tampered cookie --> clear cookie and forward to login page
    #
    #         # sStore = self.import_module(settings.SESSION_ENGINE).SessionStore
    #         # sStore[s.session_key] = 1376587691
    #         # sStore.expire_date
    #
    #         uobj = None
    #
    #         try:
    #
    #             # if 'myNJAGSADCeFarms' in request.session:
    #             #     sStore = SessionStore[request.session['myNJAGSADCeFarms']]
    #             #
    #             #
    #             # else:
    #             #     pass
    #
    #             # uid = request.get_signed_cookie(settings.COOKIE_NAME, salt=settings.COOKIE_SALT_KEY)
    #             # , max_age=settings.COOKIE_MAX_AGE_IN_SEC - do not set; authadmin be single source for status?
    #
    #             uid = "lrep"    # local rep for pgm partner as well as easement holder
    #             # uid = "sadcpl"  # SADC Planning staff
    #             # uid = "sadcpl123"   # non existent ID; but should assume as though session at AA got lost; thus expecting redirect to login
    #             # uid = "*"     # public user
    #
    #             # get user details; from server side session - mem/db
    #             # Session store
    #             uobj = aaa.getuserdetails(uid)
    #
    #             uobj_uid = utils.getobjbykey(uobj, "user.id")
    #             # print uobj_uid
    #
    #             if uid != uobj_uid:
    #                 # uid != uobj_uid --> was active but now expired and memory sweep cleared info at AA;
    #                 # Hence AA identified user as public user. Redirect to login instead of proceeding as public user
    #                 uobj = None
    #
    #             if "*" != uobj_uid:
    #                 # named user
    #                 exp = utils.getobjbykey(uobj, "sessionexpiration")
    #                 # temporary till all code come to use time in same units - Sec, milliSec, microSec
    #                 exp = utils.roundtimetosec(exp)
    #                 # print str(exp) + " %%% " + str(time())
    #                 if exp < time():
    #                     # Session expired - redirect to login
    #                     aaa.clearuserdetails(uid)
    #                     uobj = None
    #
    #         except KeyError:
    #             # 'non-existing-cookie'
    #             # Public user; Or direct access
    #             print "Key Error - No cookie found"
    #             uobj = aaa.getuserdetails(None)
    #
    #         except signing.SignatureExpired:
    #             # max_age check not set; so will never reach here?
    #             # Session expired - redirect to portal to login again
    #             print "Signature Expired Error"
    #             uobj = None
    #
    #         except signing.BadSignature:
    #             # Signature tampered! clear out existing cookie and force to login page
    #             # don't want to know who or what; for system safety ignore and move on
    #             print "Bad Signature Error"
    #             uobj = None
    #
    #         except:
    #             print sys.exc_info()
    #
    #         finally:
    #             if None == uobj:
    #                 # Due to the way cookies work, path and domain should be the same values used in set_cookie()
    #                 # otherwise the cookie may not be deleted.
    #                 # res = HttpResponsePermanentRedirect(settings.SESSION_EXPIRED_URL)
    #                 res = HttpResponseRedirect(settings.SESSION_EXPIRED_URL)
    #                 res.delete_cookie(settings.SESSION_COOKIE_NAME, settings.SESSION_COOKIE_PATH, None)
    #                 return res
    #             else:
    #                 # Pass uobj to rest of the app
    #                 # and wipe it on the way out
    #                 request.efUsr = uobj
    #                 return None

