from security import Authenticate

def credsForMapByApp(username, appMeta, appPerm, activeAppId):

    ret = {"status": "FAILED"}

    if username and appMeta:
        mapAppCred = {}
        agsToken = Authenticate.get_token(username, 60)
        # print "agsToken: " + str(agsToken)

        # todo : get duration from config_settings. Check w/ Jim whether to get it directly or via settings.py
        # todo : purpose of the duration under environment vs General, .. ;how to access
        # Success:
        #   {"token": "kZoLs9QTnrSLA6Aku-IPmo8D4M-kOl5wFoxgcVeKjqkhxOg89q8dl0e66WHjLfsz", "expires": 1462471274502 }
        # Failure if username is not in the database:
        #   {"error": {"message": "User could not be found in database"}}

        if "token" in agsToken:
            agsToken["program_type"] = appMeta.programtype
            agsToken["program_name"] = appMeta.programname
            # agsToken["applicationrole"] # is  now called privilege
            agsToken["privilege"] = appPerm  # options - view, edit & none
            agsToken["applicationid"] = appMeta.id
            agsToken["applicationyr"] = appMeta.appdate.strftime('%Y')  # map app need only the year of application
            if activeAppId:
                # Available only in EDIT mode. Not generated in View mode
                agsToken["applicationid_active"] = activeAppId
            else:
                agsToken["applicationid_active"] = ""

            if appMeta.partner_cnty_cde:
                area = {"type": "county", "municipality": "", "county": appMeta.partnername, "county_code": appMeta.partner_cnty_cde, "municipality_code": ""}
            elif appMeta.partner_muni_cde:
                area = {"type": "muni", "municipality": appMeta.partnername, "county": "", "county_code": "", "municipality_code": appMeta.partner_cnty_cde}
            else:
                area = {"type": "", "municipality": "", "county": "", "county_code": "", "municipality_code": ""}

            agsToken["area"] = area
            ret = agsToken

            ret["status"] = "SUCCESS"
    return ret


