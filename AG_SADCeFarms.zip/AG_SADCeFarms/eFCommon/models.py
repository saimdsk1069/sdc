from django.db import models, connection, utils
import cx_Oracle, sys

# while using Manager.raw: you should properly escape any parameters that the user can control by
# using params in order to protect against SQL injection attacks.
# e.g. Person.objects.raw('SELECT * FROM myapp_person WHERE last_name = %s', [lname])
#
#   Warning: Do not use string formatting on raw queries!
#       It's tempting to write the above query as:
#       >>> query = 'SELECT * FROM myapp_person WHERE last_name = %s' % lname
#       >>> Person.objects.raw(query)
#       Don't!
#
# Using the params argument completely protects you from SQL injection attacks, a common exploit where attackers
# inject arbitrary SQL into your database. If you use string interpolation, sooner or later you'll fall victim to
# SQL injection. As long as you remember to always use the params argument you'll be protected.

class eFarmDBReader (models.Manager):
    """
        For view/read ONLY
        Filter archived, by default?

        Got to work on this
            1. Filter out archived, unless asked for
    """
    def get_queryset(self):
        # may be return null
        return super(eFarmDBReader, self).get_queryset()

    def save(self, *args, **kwargs):
        return

    def delete(self, *args, **kwargs):
        return

    def create(self):
        return

class PgmACL (models.Model):
    # todo - eventually may want to use either name or ID for most of the params. may never need both. any benefit?
    id = models.CharField(max_length=36, primary_key=True)
    tier_type = models.CharField(max_length=100)
    tier_type_guid = models.CharField(max_length=36)
    tier_group_type = models.CharField(max_length=100)
    tier_group_type_guid = models.CharField(max_length=36)
    tier_subgroup_type = models.CharField(max_length=100)
    tier_subgroup_type_guid = models.CharField(max_length=36)
    partner_type = models.CharField(max_length=100)
    partner_type_guid = models.CharField(max_length=36)
    perm_type = models.CharField(max_length=100)
    perm_score = models.IntegerField()
    perm_type_guid = models.CharField(max_length=36)
    pgm_milestone_guid = models.CharField(max_length=36)
    pgm_milestone_seq = models.IntegerField()
    program_type = models.CharField(max_length=100)
    program_name = models.CharField(max_length=100)
    program_type_guid = models.CharField(max_length=36)

    programsubtypeid = models.CharField(max_length=36)
    programsubtypename = models.CharField(max_length=50)
    programsubtypeseq = models.IntegerField()

    milestone_type = models.CharField(max_length=100)
    milestone_type_guid = models.CharField(max_length=36)
    status_type_guid = models.CharField(max_length=36)
    status_type = models.CharField(max_length=100)
    objects = eFarmDBReader()

    class Meta:
        managed = False

    # No Ins/Upd/Del via app. In phase eFarms v25, may add more mgmt tools. till then ...
    def selectSQLByParams(self, addOns, mode):
        # mode = flexible or strict (default strict)
        # Use flexible, when you want to get  priv on a program
        # Otherwise (for application) go with strict
        # e.g. SADC Committee member do have access to any application in any program; but ONLY when the app is in
        #   specific milestone_type & status_type combo(s).
        #   Use mode = flexible when attempting to fetch list of programs or all partners within a program
        #   accessible to SADC Committee member
        #
        #   Use mode = strict, while accessing a specific application for SADC Committee member. Member should be
        #   able to see details ONLY if the application is in certain milestone type and/or status type.

        # In general --> ACLs for program level: mode = flexible
        #            --> ACLs for an application: mode = strict

        # todo: not all sample here reflect PROGRAM_PHASE filter.
        # mode = flexible --> All ACLs for programs of Type = Planning with View permission
        #                 --> Sub-program have no significance in this
        # SELECT x.PGM_MILESTONE_PERM_GUID as id, y.TYPEVAL  as TIER_TYPE, y.tier_type_guid,  tg.TYPEVAL as TIER_GROUP_TYPE, tg.TIER_GROUP_TYPE_GUID,
        # tsg.TYPEVAL as TIER_SUBGROUP_TYPE,  tsg.TIER_SUBGROUP_TYPE_GUID, rt.TYPEVAL as PARTNER_TYPE, rt.PARTNER_TYPE_GUID,  m.TYPEVAL as PERM_TYPE, m.score as PERM_SCORE,
        # m.PERMISSION_TYPE_GUID as PERM_TYPE_GUID,  w.PGM_MILESTONE_GUID, w.PROGRAM_TYPE, w.PROGRAM_NAME, w.PROGRAM_TYPE_GUID, w.SEQ as PGM_MILESTONE_SEQ,  w.MILESTONE_TYPE,
        # w.MILESTONE_TYPE_GUID, w.STATUS_TYPE, w.STATUS_TYPE_GUID
        # FROM PGM_MILESTONE_PERM x
        # LEFT JOIN PARTNER_TYPE rt ON rt.PARTNER_TYPE_GUID = x.PARTNER_TYPE_GUID
        # LEFT JOIN TIER_TYPE y ON y.TIER_TYPE_GUID = x.TIER_TYPE_GUID
        # LEFT JOIN TIER_GROUP_TYPE tg ON tg.TIER_GROUP_TYPE_GUID = x.TIER_GROUP_TYPE_GUID
        # LEFT JOIN TIER_SUBGROUP_TYPE tsg ON tsg.TIER_SUBGROUP_TYPE_GUID = x.TIER_SUBGROUP_TYPE_GUID
        # JOIN PERMISSION_TYPE m ON m.PERMISSION_TYPE_GUID = x.PERMISSION_TYPE_GUID
        # JOIN (
        #     SELECT c.PGM_MILESTONE_GUID, pt.PROGRAM_TYPE, pt.PROGRAM_NAME, pt.PROGRAM_TYPE_GUID, c.SEQ, c.INFO,      ms.TYPEVAL as MILESTONE_TYPE, ms.MILESTONE_TYPE_GUID,
        #     s.TYPEVAL as STATUS_TYPE, s.STATUS_TYPE_GUID
        #     from
        #       ( select fl.* from PGM_MILESTONE fl where (
        #           ( fl.PROGRAM_TYPE_GUID IN (select gr.PROGRAM_TYPE_GUID from PROGRAM_TYPE gr  where gr.PROGRAM_TYPE IN ('ANY', 'Planning') )
        #             OR
        #             fl.MILESTONE_TYPE_GUID IN ( select mo.MILESTONE_TYPE_GUID from MILESTONE_TYPE mo where              mo.TYPEVAL  IN ('ANY'    )) OR
        #             fl.STATUS_TYPE_GUID IN ( select st.STATUS_TYPE_GUID from STATUS_TYPE  st where          st.TYPEVAL IN ('ANY' ))
        #             )
        #             )  and fl.ACTIVE = 1
        #       ) c
        #       LEFT JOIN PROGRAM_TYPE pt ON pt.PROGRAM_TYPE_GUID = c.PROGRAM_TYPE_GUID
        #       LEFT JOIN MILESTONE_TYPE ms ON ms.MILESTONE_TYPE_GUID  = c.MILESTONE_TYPE_GUID
        #       LEFT JOIN STATUS_TYPE s ON s.STATUS_TYPE_GUID = c.STATUS_TYPE_GUID
        # ) w ON w.PGM_MILESTONE_GUID = x.PGM_MILESTONE_GUID
        # WHERE 1=1   and m.TYPEVAL  = 'View'
        # ORDER by PERM_SCORE desc, SEQ, PROGRAM_TYPE, PROGRAM_NAME, MILESTONE_TYPE, STATUS_TYPE;

        # mode = flexible --> All ACLs for a specific program (or sub-program)
        #                       - program (ACQ - CPIG)
        #                       - sub-program (ACQ - CPIG - Closing)
        # SELECT x.PGM_MILESTONE_PERM_GUID as id, y.TYPEVAL  as TIER_TYPE, y.tier_type_guid,  tg.TYPEVAL as TIER_GROUP_TYPE, tg.TIER_GROUP_TYPE_GUID, tsg.TYPEVAL as
        # TIER_SUBGROUP_TYPE,  tsg.TIER_SUBGROUP_TYPE_GUID, rt.TYPEVAL as PARTNER_TYPE, rt.PARTNER_TYPE_GUID,  m.TYPEVAL as PERM_TYPE, m.score as PERM_SCORE,
        # m.PERMISSION_TYPE_GUID as PERM_TYPE_GUID,  w.PGM_MILESTONE_GUID, w.PROGRAM_TYPE, w.PROGRAM_NAME, w.PROGRAM_TYPE_GUID, w.SEQ as PGM_MILESTONE_SEQ,  w.MILESTONE_TYPE,
        # w.MILESTONE_TYPE_GUID, w.STATUS_TYPE, w.STATUS_TYPE_GUID,  w.programsubtypeid, w.programsubtypename, w.programsubtypeseq
        # FROM PGM_MILESTONE_PERM x
        # LEFT JOIN PARTNER_TYPE rt ON rt.PARTNER_TYPE_GUID = x.PARTNER_TYPE_GUID
        # LEFT JOIN TIER_TYPE y ON y.TIER_TYPE_GUID = x.TIER_TYPE_GUID
        # LEFT JOIN TIER_GROUP_TYPE tg ON tg.TIER_GROUP_TYPE_GUID = x.TIER_GROUP_TYPE_GUID
        # LEFT JOIN TIER_SUBGROUP_TYPE tsg ON tsg.TIER_SUBGROUP_TYPE_GUID = x.TIER_SUBGROUP_TYPE_GUID
        # JOIN PERMISSION_TYPE m ON m.PERMISSION_TYPE_GUID = x.PERMISSION_TYPE_GUID
        # JOIN (
        #   SELECT c.PGM_MILESTONE_GUID, pt.PROGRAM_TYPE, pt.PROGRAM_NAME, pt.PROGRAM_TYPE_GUID, c.SEQ, c.INFO,      ms.TYPEVAL as MILESTONE_TYPE, ms.MILESTONE_TYPE_GUID,
        #   s.TYPEVAL as STATUS_TYPE, s.STATUS_TYPE_GUID,
        #   pst.PROGRAM_PHASE_GUID as programsubtypeid, pst.SUB_PGM_NAME as programsubtypename, NVL(pst.SUB_PGM_SEQ, 1) as programsubtypeseq
        #   from
        #     ( select fl.* from PGM_MILESTONE fl where (
        #       ( fl.PROGRAM_TYPE_GUID IN
        #         (
        #           select gr.PROGRAM_TYPE_GUID from PROGRAM_TYPE gr
        #             LEFT JOIN PROGRAM_PHASE sty ON gr.PROGRAM_TYPE_GUID = sty.PROGRAM_TYPE_GUID
        #           where gr.PROGRAM_TYPE = 'ANY' OR (gr.PROGRAM_TYPE_GUID = '429534c1-9c63-40f7-abd2-299ad0281ee9' AND sty.sub_pgm_name = 'Closing')
        #         )
        #         OR fl.MILESTONE_TYPE_GUID IN ( select mo.MILESTONE_TYPE_GUID from MILESTONE_TYPE mo where              mo.TYPEVAL  IN ('ANY'    ))
        #         OR fl.STATUS_TYPE_GUID IN ( select st.STATUS_TYPE_GUID from STATUS_TYPE  st where          st.TYPEVAL IN ('ANY' ))
        #       )
        #       )  and fl.ACTIVE = 1
        #     ) c
        #     LEFT JOIN PROGRAM_TYPE pt ON pt.PROGRAM_TYPE_GUID = c.PROGRAM_TYPE_GUID
        #     LEFT JOIN PROGRAM_PHASE pst ON pst.PROGRAM_PHASE_GUID = c.PROGRAM_PHASE_GUID
        #     LEFT JOIN MILESTONE_TYPE ms ON ms.MILESTONE_TYPE_GUID  = c.MILESTONE_TYPE_GUID
        #     LEFT JOIN STATUS_TYPE s ON s.STATUS_TYPE_GUID = c.STATUS_TYPE_GUID
        # ) w ON w.PGM_MILESTONE_GUID = x.PGM_MILESTONE_GUID
        # WHERE 1=1
        # ORDER by PERM_SCORE desc, SEQ, PROGRAM_TYPE, PROGRAM_NAME, MILESTONE_TYPE, STATUS_TYPE


        # mode = strict --> All ACLs for a specific application, as identified by its Pgm_MileStone (Program, milestone type & status type)
        # SELECT x.PGM_MILESTONE_PERM_GUID as id, y.TYPEVAL  as TIER_TYPE, y.tier_type_guid,  tg.TYPEVAL as TIER_GROUP_TYPE, tg.TIER_GROUP_TYPE_GUID, tsg.TYPEVAL as
        # TIER_SUBGROUP_TYPE,  tsg.TIER_SUBGROUP_TYPE_GUID, rt.TYPEVAL as PARTNER_TYPE, rt.PARTNER_TYPE_GUID,  m.TYPEVAL as PERM_TYPE, m.score as PERM_SCORE,
        # m.PERMISSION_TYPE_GUID as PERM_TYPE_GUID,  w.PGM_MILESTONE_GUID, w.PROGRAM_TYPE, w.PROGRAM_NAME, w.PROGRAM_TYPE_GUID, w.SEQ as PGM_MILESTONE_SEQ,  w.MILESTONE_TYPE,
        # w.MILESTONE_TYPE_GUID, w.STATUS_TYPE, w.STATUS_TYPE_GUID
        # FROM PGM_MILESTONE_PERM x
        # LEFT JOIN PARTNER_TYPE rt ON rt.PARTNER_TYPE_GUID = x.PARTNER_TYPE_GUID
        # LEFT JOIN TIER_TYPE y ON y.TIER_TYPE_GUID = x.TIER_TYPE_GUID
        # LEFT JOIN TIER_GROUP_TYPE tg ON tg.TIER_GROUP_TYPE_GUID = x.TIER_GROUP_TYPE_GUID
        # LEFT JOIN TIER_SUBGROUP_TYPE tsg ON tsg.TIER_SUBGROUP_TYPE_GUID = x.TIER_SUBGROUP_TYPE_GUID
        # JOIN PERMISSION_TYPE m ON m.PERMISSION_TYPE_GUID = x.PERMISSION_TYPE_GUID
        # JOIN
        # (   SELECT c.PGM_MILESTONE_GUID, pt.PROGRAM_TYPE, pt.PROGRAM_NAME, pt.PROGRAM_TYPE_GUID, c.SEQ, c.INFO,      ms.TYPEVAL as MILESTONE_TYPE, ms.MILESTONE_TYPE_GUID,
        #     s.TYPEVAL as STATUS_TYPE, s.STATUS_TYPE_GUID
        #     from ( select fl.* from PGM_MILESTONE fl
        #           where (  fl.PGM_MILESTONE_GUID = '8efe063d-f9ed-45b8-97f9-1ca58b462566'
        #           OR
        #             ( fl.PROGRAM_TYPE_GUID IN (select gr.PROGRAM_TYPE_GUID from PROGRAM_TYPE gr  where gr.PROGRAM_TYPE = 'ANY' )
        #               AND       fl.MILESTONE_TYPE_GUID IN ( select mo.MILESTONE_TYPE_GUID from MILESTONE_TYPE mo where              mo.TYPEVAL  IN ('ANY'    ))
        #               AND    fl.STATUS_TYPE_GUID IN ( select st.STATUS_TYPE_GUID from STATUS_TYPE  st where          st.TYPEVAL IN ('ANY' ))
        #             )
        #           ) and fl.ACTIVE = 1
        #         ) c
        #         LEFT JOIN PROGRAM_TYPE pt ON pt.PROGRAM_TYPE_GUID = c.PROGRAM_TYPE_GUID
        #         LEFT JOIN MILESTONE_TYPE ms ON ms.MILESTONE_TYPE_GUID  = c.MILESTONE_TYPE_GUID
        #         LEFT JOIN STATUS_TYPE s ON s.STATUS_TYPE_GUID = c.STATUS_TYPE_GUID
        # ) w ON w.PGM_MILESTONE_GUID = x.PGM_MILESTONE_GUID
        # WHERE 1=1
        # ORDER by PERM_SCORE desc, SEQ, PROGRAM_TYPE, PROGRAM_NAME, MILESTONE_TYPE, STATUS_TYPE


        ret = " SELECT x.PGM_MILESTONE_PERM_GUID as id, y.TYPEVAL  as TIER_TYPE, y.tier_type_guid, " \
              " tg.TYPEVAL as TIER_GROUP_TYPE, tg.TIER_GROUP_TYPE_GUID, tsg.TYPEVAL as TIER_SUBGROUP_TYPE, " \
              " tsg.TIER_SUBGROUP_TYPE_GUID, rt.TYPEVAL as PARTNER_TYPE, rt.PARTNER_TYPE_GUID, " \
              " m.TYPEVAL as PERM_TYPE, m.score as PERM_SCORE, m.PERMISSION_TYPE_GUID as PERM_TYPE_GUID, " \
              " w.PGM_MILESTONE_GUID, w.PROGRAM_TYPE, w.PROGRAM_NAME, w.PROGRAM_TYPE_GUID, w.SEQ as PGM_MILESTONE_SEQ, " \
              " w.MILESTONE_TYPE, w.MILESTONE_TYPE_GUID, w.STATUS_TYPE, w.STATUS_TYPE_GUID, w.programsubtypeid, " \
              " w.programsubtypename, w.programsubtypeseq " \
              " FROM PGM_MILESTONE_PERM x " \
              " LEFT JOIN PARTNER_TYPE rt ON rt.PARTNER_TYPE_GUID = x.PARTNER_TYPE_GUID " \
              " LEFT JOIN TIER_TYPE y ON y.TIER_TYPE_GUID = x.TIER_TYPE_GUID " \
              " LEFT JOIN TIER_GROUP_TYPE tg ON tg.TIER_GROUP_TYPE_GUID = x.TIER_GROUP_TYPE_GUID " \
              " LEFT JOIN TIER_SUBGROUP_TYPE tsg ON tsg.TIER_SUBGROUP_TYPE_GUID = x.TIER_SUBGROUP_TYPE_GUID " \
              " JOIN PERMISSION_TYPE m ON m.PERMISSION_TYPE_GUID = x.PERMISSION_TYPE_GUID " \
              " JOIN ( " \
              "     SELECT c.PGM_MILESTONE_GUID, pt.PROGRAM_TYPE, pt.PROGRAM_NAME, pt.PROGRAM_TYPE_GUID, c.SEQ, c.INFO, " \
              "     ms.TYPEVAL as MILESTONE_TYPE, ms.MILESTONE_TYPE_GUID, s.TYPEVAL as STATUS_TYPE, s.STATUS_TYPE_GUID, "\
              "     pst.PROGRAM_PHASE_GUID as programsubtypeid, pst.SUB_PGM_NAME as programsubtypename, NVL(pst.SUB_PGM_SEQ, 1) as programsubtypeseq " \
              "     from ( select fl.* from PGM_MILESTONE fl where ( "
        if "programmilestoneid" in addOns:
            ret += " fl.PGM_MILESTONE_GUID = %s OR "

        if "programmilestoneseq" in addOns:
            ret += " fl.seq = %s OR "

        ret += "    ( fl.PROGRAM_TYPE_GUID IN (select gr.PROGRAM_TYPE_GUID from PROGRAM_TYPE gr " \
               "        LEFT JOIN PROGRAM_PHASE sty ON gr.PROGRAM_TYPE_GUID = sty.PROGRAM_TYPE_GUID "

        # not sure whether all options of PROGRAM_PHASE is explored. fix/add as req
        if "programid" in addOns:
            ret += " where gr.PROGRAM_TYPE = 'ANY' OR (gr.PROGRAM_TYPE_GUID = %s "
            if "programsubtypeid" in addOns:
                ret += " AND sty.PROGRAM_PHASE_GUID = %s "
            ret += " )) "
        elif "programtype" in addOns:
            ret += " where gr.PROGRAM_TYPE IN ('ANY', %s) "
            if "programname" in addOns:
                ret += " and gr.PROGRAM_NAME IN ('ANY', %s) "
                if "programsubtypename" in addOns:
                    ret += " and sty.SUB_PGM_NAME  ('ANY', %s) "
            ret += ") "
        else:
            ret += " where gr.PROGRAM_TYPE = 'ANY' ) "

        if mode and "flexible" == mode:
            ret += " OR "
        else:   # default to stricter filter
            ret += " AND "

        ret += "      fl.MILESTONE_TYPE_GUID IN ( select mo.MILESTONE_TYPE_GUID from MILESTONE_TYPE mo where " \
               "             mo.TYPEVAL  IN ('ANY'"
        if "milestonetype" in addOns:
            ret += ", %s "
        ret += "    ))"

        if mode and "flexible" == mode:
            ret += " OR "
        else:   # default to stricter filter
            ret += " AND "

        ret += "   fl.STATUS_TYPE_GUID IN ( select st.STATUS_TYPE_GUID from STATUS_TYPE  st where " \
               "         st.TYPEVAL IN ('ANY'"
        if "statustype" in addOns:
            ret += ", %s "
        ret += " )) " \
               " )) "

        if "showall" in addOns:
            pass
        else:
            ret += " and fl.ACTIVE = 1 "

        ret += "     ) c " \
               "     LEFT JOIN PROGRAM_TYPE pt ON pt.PROGRAM_TYPE_GUID = c.PROGRAM_TYPE_GUID" \
               "     LEFT JOIN PROGRAM_PHASE pst ON pst.PROGRAM_PHASE_GUID = c.PROGRAM_PHASE_GUID" \
               "     LEFT JOIN MILESTONE_TYPE ms ON ms.MILESTONE_TYPE_GUID  = c.MILESTONE_TYPE_GUID" \
               "     LEFT JOIN STATUS_TYPE s ON s.STATUS_TYPE_GUID = c.STATUS_TYPE_GUID" \
               " ) w ON w.PGM_MILESTONE_GUID = x.PGM_MILESTONE_GUID WHERE 1=1  "

        if "permissiontype" in addOns:
              ret += " and m.TYPEVAL  = %s "

        if "tiertype" in addOns:
            ret += " and y.TYPEVAL = %s "
            if "tiergroup" in addOns:
                ret += " and (tg.TYPEVAL = %s or tg.TYPEVAL IS NULL) "
                if "tiersubgroup" in addOns:
                    ret += " and (tsg.TYPEVAL = %s or tsg.TYPEVAL IS NULL) "

        ret += " ORDER by PERM_SCORE desc, SEQ, PROGRAM_TYPE, PROGRAM_NAME, MILESTONE_TYPE, STATUS_TYPE "

        return ret

    def __str__(self):
        return self.perm_type + " - " + self.milestone_type + " - " + self.status_type

class PgmMilestone (models.Model):
    # todo - eventually may want to use either name or ID for most of the params. may never need both. any benefit?
    id = models.CharField(max_length=36, primary_key=True)
    pgm_milestone_seq = models.IntegerField()
    milestone_type = models.CharField(max_length=100)
    milestone_type_guid = models.CharField(max_length=36)
    status_type_guid = models.CharField(max_length=36)
    status_type = models.CharField(max_length=100)

    program_type = models.CharField(max_length=100)
    program_name = models.CharField(max_length=100)
    program_type_guid = models.CharField(max_length=36)
    program_phase_guid = models.CharField(max_length=36)
    program_phase_name = models.CharField(max_length=50)
    program_phase_seq = models.IntegerField()

    objects = eFarmDBReader()

    class Meta:
        managed = False

    # No Ins/Upd/Del via app. In phase eFarms v25, may add more mgmt tools. till then ...
    def selectSQLByParams(self, addOns):
        # SELECT PGM_MILESTONE_GUID, pt.PROGRAM_TYPE, pt.PROGRAM_NAME, sty.PROGRAM_PHASE_GUID as program_phase_guid,
        # sty.SUB_PGM_NAME as program_phase_name, NVL(sty.SUB_PGM_SEQ, 1) as program_phase_seq,
        #   ms.TYPEVAL as MILESTONE_TYPE, s.TYPEVAL as STATUS_TYPE, SEQ, c.INFO
        #   FROM (select fl.* from PGM_MILESTONE fl where fl.ACTIVE = 1  and fl.SEQ != -1  ) c
        #   JOIN ( select gr.PROGRAM_TYPE_GUID, gr.PROGRAM_TYPE, gr.PROGRAM_NAME from PROGRAM_TYPE gr
        #           where
        #           --gr.PROGRAM_TYPE_GUID = '429534c1-9c63-40f7-abd2-299ad0281ee9'
        #           gr.PROGRAM_TYPE = 'Planning' and PROGRAM_NAME = 'County PIG Program - Annual Application'
        #
        #        ) pt ON pt.PROGRAM_TYPE_GUID = c.PROGRAM_TYPE_GUID
        #   LEFT JOIN PROGRAM_PHASE sty ON sty.PROGRAM_PHASE_GUID = c.PROGRAM_PHASE_GUID
        #   JOIN MILESTONE_TYPE ms ON ms.MILESTONE_TYPE_GUID  = c.MILESTONE_TYPE_GUID
        #   JOIN  STATUS_TYPE s ON s.STATUS_TYPE_GUID = c.STATUS_TYPE_GUID
        # WHERE 1=1
        # --AND  sty.PROGRAM_PHASE_GUID = ''
        # -- Already limited to a specific program, so additional filter by program guid is not required to get unique sub-program name
        # --AND sty.SUB_PGM_NAME is null
        # order by program_phase_seq, SEQ, STATUS_TYPE;

        ret = " SELECT PGM_MILESTONE_GUID as id, pt.PROGRAM_TYPE, pt.PROGRAM_NAME, sty.PROGRAM_PHASE_GUID as " \
              " program_phase_guid, sty.SUB_PGM_NAME as program_phase_name, NVL(sty.SUB_PGM_SEQ, 1) as program_phase_seq, " \
              " ms.TYPEVAL as MILESTONE_TYPE, s.TYPEVAL as STATUS_TYPE, SEQ, c.INFO " \
              " FROM (select fl.* from PGM_MILESTONE fl where fl.ACTIVE = 1  and fl.SEQ != -1  ) c " \
              " JOIN ( select gr.PROGRAM_TYPE_GUID, gr.PROGRAM_TYPE, gr.PROGRAM_NAME from PROGRAM_TYPE gr " \

        if "programid" in addOns:
            ret += " where gr.PROGRAM_TYPE_GUID = %(programid)s "
        elif "programtype" in addOns and "programname" in addOns:
            ret += " where gr.PROGRAM_TYPE = %(programtype)s and gr.PROGRAM_NAME = %(programname)s "

        ret += " ) pt ON pt.PROGRAM_TYPE_GUID = c.PROGRAM_TYPE_GUID " \
               " LEFT JOIN PROGRAM_PHASE sty ON sty.PROGRAM_PHASE_GUID = c.PROGRAM_PHASE_GUID " \
               " JOIN MILESTONE_TYPE ms ON ms.MILESTONE_TYPE_GUID  = c.MILESTONE_TYPE_GUID " \
               " JOIN  STATUS_TYPE s ON s.STATUS_TYPE_GUID = c.STATUS_TYPE_GUID " \
               " WHERE 1=1 "

        if "programphaseid" in addOns:
            ret += " AND sty.PROGRAM_PHASE_GUID = %(programphaseid)s "
        elif "programphasename" in addOns:
            ret += " AND sty.SUB_PGM_NAME = %(programphasename)s "

        ret += " order by program_phase_seq, SEQ, STATUS_TYPE "

        return ret

    def __str__(self):
        return self.program_name + " - " + self.program_phase_name + " - " + self.milestone_type + " - " + self.status_type

class PgmPartner(models.Model):

    id = models.CharField(max_length=36, primary_key=True)  # PARTNER_TYPE_GUID
    name = models.CharField(max_length=200)
    county_code = models.CharField(max_length=2)
    muni_code = models.CharField(max_length=4)
    partner_type = models.CharField(max_length=100)
    partner_type_guid = models.CharField(max_length=36)
    active = models.IntegerField()
    objects = eFarmDBReader()

    class Meta:
        managed = False

    def selectSQLByParams(self, addOns):
        ret = " SELECT pr.PARTNER_GUID as id, pr.PARTNER_NAME as name,  pr.COUNTY_CODE, pr.MUNI_CODE,  pr.active, " \
              " py.PARTNER_TYPE_GUID, py.TYPEVAL as PARTNER_TYPE  FROM PARTNER pr " \
              " JOIN ( select * from PARTNER_TYPE pyi  "

        if "partnertypeid-Multi" in addOns:
            ret += " where pyi.PARTNER_TYPE_GUID IN {} "

        if "partnertypeid-Single" in addOns:
            ret += " where pyi.PARTNER_TYPE_GUID = %s "

        # todo : Review following
        #     if "programid" in addOns or "programtype" in addOns:
        #         ret += " pyi.PARTNER_TYPE_GUID IN ( " \
        #                "     select distinct x.PARTNER_TYPE_GUID from PGM_MILESTONE_PERM x " \
        #                "     JOIN (  SELECT PGM_MILESTONE_GUID FROM " \
        #                "         (select fl.* from PGM_MILESTONE fl where fl.ACTIVE = 1 ) c " \
        #                "          JOIN ( select gr.PROGRAM_TYPE_GUID, gr.PROGRAM_TYPE, gr.PROGRAM_NAME from PROGRAM_TYPE gr where "
        #         # PGM Milestone filters (prgm type/name)
        #         if "programid" in addOns:
        #             ret += " gr.PROGRAM_TYPE_GUID = %s "
        #         elif "programtype" in addOns:
        #             # For 'ANY': typically partner type will be null? Wonder whether IN clause is req at all!!!
        #             ret += " gr.PROGRAM_TYPE IN ('ANY', %s ) "
        #             if "programname" in addOns:
        #                 ret += " and gr.PROGRAM_NAME IN ('ANY', %s) "
        #
        #         ret += "        ) pt ON pt.PROGRAM_TYPE_GUID = c.PROGRAM_TYPE_GUID ) w " \
        #                "     ON w.PGM_MILESTONE_GUID = x.PGM_MILESTONE_GUID "
        #
        #         # AppPartner obj could be requested for SADC Staff, Partner or others (SADC committee etc)
        #         #   for SADC Staff --> no tier filter
        #         #   for PARTNER --> tier & tier grp filter
        #         #   for other types --> tier, tier grp & tier sub-grp
        #         if "partnerrole" in addOns or "otherroles" in addOns:
        #             ret += "     JOIN (select * from TIER_TYPE yi where yi.TIER_TYPE_GUID = %s ) y " \
        #                    "     ON y.TIER_TYPE_GUID = x.TIER_TYPE_GUID " \
        #                    "     JOIN (select * from TIER_GROUP_TYPE tgi where tgi.TIER_GROUP_TYPE_GUID = %s )tg " \
        #                    "     ON tg.TIER_GROUP_TYPE_GUID = x.TIER_GROUP_TYPE_GUID "
        #
        #         if "otherrole" in addOns:
        #             ret += "     JOIN (select * from TIER_SUBGROUP_TYPE tsgi where tsgi.TIER_SUBGROUP_TYPE_GUID = %s )tsg " \
        #                    "     ON tsg.TIER_SUBGROUP_TYPE_GUID = x.TIER_SUBGROUP_TYPE_GUID "
        #
        #         ret += "     where x.PARTNER_TYPE_GUID IS NOT NULL ) "
        # todo: review the above code/logic

        ret += " ) py ON py.PARTNER_TYPE_GUID = pr.PARTNER_TYPE_GUID " \
               " WHERE 1 =1 "

        #   if "partnerrole" in addOns:  # todo: part of the above todo list
        #       ret += ' and pr.PARTNER_TYPE_GUID = %s '

        if 'partnerid-Single' in addOns:
            ret += ' and pr.PARTNER_GUID = %s '  # Should be able to get inactive to see historic rec

        if 'partnerid-Multi' in addOns:
            ret += ' and pr.PARTNER_GUID IN {} '

        if 'active' in addOns:
            ret += ' and pr.ACTIVE = 1 '  # Should be able to get inactive to see historic rec

        ret += ' order by pr.PARTNER_NAME '

        return ret

    def __str__(self):
        return self.name

class AppInfo (models.Model):
    id = models.CharField(max_length=36, primary_key=True)
    appdate = models.DateField()  # for planning put submission target year; not the actual
                                  # application year? instead should add a new field for that?
                                  # Dec 15th is the cut off for upcoming yr
    nameauth = models.CharField(max_length=40)
    notegrpid = models.CharField(max_length=36)
    docgrpid = models.CharField(max_length=36)
    pgm_milestoneid = models.CharField(max_length=36)
    pgm_milestoneseq = models.IntegerField()
    programtype = models.CharField(max_length=50)
    programname = models.CharField(max_length=50)
    programid = models.CharField(max_length=36)

    programsubtypeid = models.CharField(max_length=36)
    programsubtypename = models.CharField(max_length=50)
    programsubtypeseq = models.IntegerField()

    partnername = models.CharField(max_length=50)
    partner_cnty_cde = models.CharField(max_length=2)
    partner_muni_cde = models.CharField(max_length=4)
    partnerid = models.CharField(max_length=36)
    milestonetype = models.CharField(max_length=100)
    milestonetypeid = models.CharField(max_length=36)
    statustypeid = models.CharField(max_length=36)
    status = models.CharField(max_length=100)
    # approvaltype = models.CharField(max_length=100)
    createddate = models.DateTimeField()
    lastediteddate = models.DateTimeField()
    # todo: Change to user guid instead of user name
    createduser = models.CharField(max_length=36)
    lastediteduser = models.CharField(max_length=36)

    #todo - Add
    # mun_code  -- why code in app table? why not get from partner id? for situations where there is no partner?
    # county_code -- ????

    objects = eFarmDBReader()

    class Meta:
        managed = False
        # ordering in Meta have no significance while in rawsql mode

    # def insertSQLByPrtnrName(self, appdate):
    #     if None == appdate or "" == appdate:
    #         appdate = "sysdate"
    #
    #     ret = " insert into program_application (PROGRAM_APPLICATION_GUID, APPLICATION_DATE, PROGRAM_TYPE_GUID, PARTNER_NAME, STATUS_TYPE_GUID, ACTIVE, " \
    #           " CREATED_DATE, LAST_EDITED_DATE, CREATED_USER, LAST_EDITED_USER) " \
    #           " select %s, " + appdate + ", pt.PROGRAM_TYPE_GUID, og.PARTNER_GUID, st.STATUS_TYPE_GUID, 1, systimestamp, systimestamp, %s, %s from T_WX_PROGRAM_PARTNER x, " \
    #           " (select PROGRAM_TYPE_GUID from PROGRAM_TYPE p where p.PROGRAM_TYPE = %s ) pt, " \
    #           " (select o.PARTNER_GUID , o.PARTNER_TYPE_GUID from PARTNER o where o.PARTNER_NAME = %s ) og," \
    #           " (select s.STATUS_TYPE_GUID from status_type s where s.TYPEVAL = %s ) st" \
    #           " where x.PARTNER_TYPE_GUID = og.PARTNER_TYPE_GUID and x.PROGRAM_TYPE_GUID = pt.PROGRAM_TYPE_GUID"
    #     return ret

    def insertSQL(self, appdate):
        if None == appdate or "" == appdate:
            appdate = "sysdate"

        # entered by app, as part of answers/comments/docs
        # NOTE_GROUP_GUID
        # DOCUMENT_GROUP_GUID

        # todo :  COUNTY_CODE, MUNI_CODE & NAME_AUTH
        # purpose of NAME_AUTH??  Same as created_user
        # mun_code & county_code -- why code in app table? why not get from partner id? for apps with no partner?

        ret = " insert into program_application (PROGRAM_APPLICATION_GUID, APPLICATION_DATE, PARTNER_GUID, ACTIVE, " \
              " CREATED_DATE, LAST_EDITED_DATE, CREATED_USER_GUID, LAST_EDITED_USER, PGM_MILESTONE_GUID, CUSTOM_INFO) " \
              " VALUES ( %s, " + appdate + ", %s, 1, systimestamp, systimestamp, %s, %s, %s, %s ) "

        return ret

    def updateSQL(self, addOns):
        # todo : fix it!
        ret = " UPDATE program_application set "
        if "app date" in addOns:
            ret += " APPLICATION_DATE = %s, "
        if "approval type" in addOns:
            ret += " APPROVAL_TYPE_GUID = (select APPROVAL_TYPE_GUID from APPROVAL_TYPE where TYPEVAL = %s), "
        if "status" in addOns:
            ret += " STATUS_TYPE_GUID = (select STATUS_TYPE_GUID from STATUS_TYPE where TYPEVAL = %s), "
        if "doc group id" in addOns:
            ret += " DOCUMENT_GROUP_GUID = %s, "
        if "note group id" in addOns:
            ret += " NOTE_GROUP_GUID = %s, "
        if "active" in addOns:
            ret += " ACTIVE = %s, "
        ret += " LAST_EDITED_DATE = systimestamp, LAST_EDITED_USER = %s where PROGRAM_APPLICATION_GUID = %s "

        return ret

    def selectSQLByID(self):
        # Program app by id
        # select
        #            papm.id, papm.appdate, papm.nameauth,  papm.notegrpid, papm.docgrpid,  papm.createddate, papm.createduser, cu.FIRST_NAME || ' ' || cu.LAST_NAME as CUSER,
        #            papm.lastediteddate, papm.lastediteduser,  uu.FIRST_NAME || ' ' || uu.LAST_NAME as UUSER, papm.pgm_milestoneseq,
        #            pr.partner_name as partnername, pr.PARTNER_GUID as partnerid,
        #            pt.PROGRAM_TYPE_GUID as programid, pt.PROGRAM_TYPE as programtype, pt.PROGRAM_NAME as programname,
        #            ms.MILESTONE_TYPE_GUID as milestonetypeid, ms.TYPEVAL as milestonetype,
        #            s.STATUS_TYPE_GUID as statusid, s.TYPEVAL as status,
        #            sty.PROGRAM_PHASE_GUID as programsubtypeid, sty.SUB_PGM_NAME programsubtypename, NVL(sty.SUB_PGM_SEQ, 1) as programsubtypeseq
        #          from (
        #            select
        #            pa.PROGRAM_APPLICATION_GUID as id, pa.APPLICATION_DATE as appdate, pa.NAME_AUTH as nameauth,  pa.NOTE_GROUP_GUID as notegrpid,
        #            pa.DOCUMENT_GROUP_GUID as docgrpid,  pa.CREATED_DATE as createddate, pa.CREATED_USER_GUID as createduser,
        #            pa.LAST_EDITED_DATE as lastediteddate, pa.LAST_EDITED_USER as lastediteduser, pa.PARTNER_GUID,
        #            pmi.PGM_MILESTONE_GUID, pmi.SEQ as pgm_milestoneseq, pmi.PROGRAM_TYPE_GUID,  pmi.MILESTONE_TYPE_GUID, pmi.STATUS_TYPE_GUID,
        #            pmi.PROGRAM_PHASE_GUID
        #            from
        #              (select pai.* from program_application pai where pai.PROGRAM_APPLICATION_GUID = '0fc2e1bc-78d0-404a-a0c0-0b8338390f03') pa
        #              JOIN PGM_MILESTONE pmi ON pmi.PGM_MILESTONE_GUID = pa.PGM_MILESTONE_GUID
        #          ) papm
        #          JOIN PARTNER pr ON pr.PARTNER_GUID = papm.PARTNER_GUID
        #          JOIN PROGRAM_TYPE pt ON pt.PROGRAM_TYPE_GUID = papm.PROGRAM_TYPE_GUID
        #          LEFT JOIN PROGRAM_PHASE sty ON sty.PROGRAM_PHASE_GUID = papm.PROGRAM_PHASE_GUID
        #          JOIN MILESTONE_TYPE ms ON ms.MILESTONE_TYPE_GUID  = papm.MILESTONE_TYPE_GUID
        #          JOIN STATUS_TYPE s ON s.STATUS_TYPE_GUID = papm.STATUS_TYPE_GUID
        #          LEFT JOIN AUTH_USER_SADC cu ON cu.AUTH_USER_GUID = papm.createduser
        #          LEFT JOIN AUTH_USER_SADC uu ON uu.AUTH_USER_GUID = papm.lastediteduser;

        # todo check whether is it OK to alias at multiple places? or do it once to save on computing?
        ret = " select papm.id, papm.appdate, papm.nameauth,  papm.notegrpid, papm.docgrpid,  papm.createddate, " \
              " cu.FIRST_NAME || ' ' || cu.LAST_NAME as  createduser, papm.lastediteddate, " \
              " uu.FIRST_NAME || ' ' || uu.LAST_NAME as lastediteduser, papm.pgm_milestoneid, papm.pgm_milestoneseq, " \
              " pr.county_code as partner_cnty_cde, pr.muni_code as partner_muni_cde, " \
              " pr.partner_name as partnername, pr.PARTNER_GUID as partnerid, pt.PROGRAM_TYPE_GUID as programid, " \
              " pt.PROGRAM_TYPE as programtype, pt.PROGRAM_NAME as programname, ms.MILESTONE_TYPE_GUID as milestonetypeid, " \
              " ms.TYPEVAL as milestonetype, s.STATUS_TYPE_GUID as statusid, s.TYPEVAL as status, " \
              " sty.PROGRAM_PHASE_GUID as programsubtypeid, sty.SUB_PGM_NAME as programsubtypename, NVL(sty.SUB_PGM_SEQ, 1) as programsubtypeseq" \
              " from ( select pa.PROGRAM_APPLICATION_GUID as id, pa.APPLICATION_DATE as appdate, pa.NAME_AUTH as nameauth,  " \
              "     pa.NOTE_GROUP_GUID as notegrpid, pa.DOCUMENT_GROUP_GUID as docgrpid,  pa.CREATED_DATE as createddate, " \
              "     pa.CREATED_USER_GUID as createduser, pa.LAST_EDITED_DATE as lastediteddate, pa.LAST_EDITED_USER as lastediteduser, " \
              "     pa.PARTNER_GUID, pmi.PGM_MILESTONE_GUID as pgm_milestoneid, pmi.SEQ as pgm_milestoneseq, pmi.PROGRAM_TYPE_GUID,  " \
              "     pmi.MILESTONE_TYPE_GUID, pmi.STATUS_TYPE_GUID, pmi.PROGRAM_PHASE_GUID from " \
              "     (select pai.* from program_application pai where pai.PROGRAM_APPLICATION_GUID = %s ) pa " \
              "     JOIN PGM_MILESTONE pmi ON pmi.PGM_MILESTONE_GUID = pa.PGM_MILESTONE_GUID ) papm " \
              " JOIN PARTNER pr ON pr.PARTNER_GUID = papm.PARTNER_GUID " \
              " JOIN PROGRAM_TYPE pt ON pt.PROGRAM_TYPE_GUID = papm.PROGRAM_TYPE_GUID " \
              " LEFT JOIN PROGRAM_PHASE sty ON sty.PROGRAM_PHASE_GUID = papm.PROGRAM_PHASE_GUID " \
              " JOIN MILESTONE_TYPE ms ON ms.MILESTONE_TYPE_GUID  = papm.MILESTONE_TYPE_GUID " \
              " JOIN STATUS_TYPE s ON s.STATUS_TYPE_GUID = papm.STATUS_TYPE_GUID " \
              " LEFT JOIN AUTH_USER_SADC cu ON cu.AUTH_USER_GUID = papm.createduser " \
              " LEFT JOIN AUTH_USER_SADC uu ON uu.AUTH_USER_GUID = papm.lastediteduser "

        return ret

    def selectSQLByParams(self, addOnDict):
        # Program app obj by
        #   1. Pg milestone (pgm type/name, ms type, st type)
        #   2. Partner info
        #
        #
        # -- Without program sub type as a param
        # select pa.PROGRAM_APPLICATION_GUID as id, pa.APPLICATION_DATE as appdate, pa.NAME_AUTH as nameauth,  pa.NOTE_GROUP_GUID as notegrpid, pa.DOCUMENT_GROUP_GUID as docgrpid,
        # pa.partnername,  pa.partnerid,  pa.partner_cnty_cde, pa.partner_muni_cde,  pm.PROGRAM_TYPE_GUID as programid, pm.PROGRAM_TYPE as programtype,  pm.PROGRAM_NAME
        # as programname,  pm.PGM_MILESTONE_GUID as pgm_milestoneid, pm.SEQ as pgm_milestoneseq, pm.milestonetypeid, pm.milestonetype,  pm.statusid,  pm.status, pm.programsubtypeid,
        # pm.programsubtypename, pm.programsubtypeseq,  pa.CREATED_DATE as createddate, pa.createduser,   pa.LAST_EDITED_DATE as lastediteddate, pa.lastediteduser
        # from
        #     -- 1st set
        #     (select pai.*, pr.*, cu.FIRST_NAME || ' ' || cu.LAST_NAME as createduser, uu.FIRST_NAME || ' ' ||  uu.LAST_NAME as lastediteduser
        #         from (select * from program_application WHERE 1=1 ) pai
        #         JOIN (select pri.PARTNER_GUID as partnerid, pri.partner_name as partnername,
        #                 pri.county_code as partner_cnty_cde, pri.muni_code as partner_muni_cde
        #                 from PARTNER pri  where pri.PARTNER_GUID = 'd73c82cf-e964-4159-b562-cb3b43d03186'
        #              ) pr ON pai.PARTNER_GUID = pr.partnerid
        #         LEFT JOIN AUTH_USER_SADC cu ON cu.AUTH_USER_GUID = pai.created_user_GUID
        #         LEFT JOIN AUTH_USER_SADC uu ON uu.AUTH_USER_GUID = pai.last_edited_user
        #      ) pa,
        #      -- 2nd set
        #      (SELECT pmi.PGM_MILESTONE_GUID, pmi.SEQ, pt.PROGRAM_TYPE_GUID, pt.PROGRAM_TYPE, pt.PROGRAM_NAME,
        #           ms.milestonetypeid, ms.MILESTONETYPE, s.statusid, s.STATUS, pt.programsubtypeid,
        #           pt.programsubtypename, pt.programsubtypeseq
        #       FROM (select * from PGM_MILESTONE where SEQ > 0) pmi
        #       JOIN ( select gr.PROGRAM_TYPE_GUID, gr.PROGRAM_TYPE, gr.PROGRAM_NAME,  null as programsubtypeid, null as programsubtypename,  1 as programsubtypeseq
        #               from PROGRAM_TYPE gr  where gr.PROGRAM_TYPE = 'Planning' ) pt ON pt.PROGRAM_TYPE_GUID = pmi.PROGRAM_TYPE_GUID
        #       JOIN ( select mo.MILESTONE_TYPE_GUID as milestonetypeid, mo.TYPEVAL as MILESTONETYPE from MILESTONE_TYPE mo ) ms ON ms.milestonetypeid  = pmi.MILESTONE_TYPE_GUID
        #       JOIN ( select st.STATUS_TYPE_GUID  as statusid, st.TYPEVAL as STATUS from STATUS_TYPE  st ) s ON s.statusid = pmi.STATUS_TYPE_GUID
        #       ) pm
        # WHERE pa.PGM_MILESTONE_GUID = pm.PGM_MILESTONE_GUID
        #
        # -- With program sub type as a param
        # select pa.PROGRAM_APPLICATION_GUID as id, pa.APPLICATION_DATE as appdate, pa.NAME_AUTH as nameauth,  pa.NOTE_GROUP_GUID as notegrpid, pa.DOCUMENT_GROUP_GUID as docgrpid,
        # pa.partnername,  pa.partnerid,  pa.partner_cnty_cde, pa.partner_muni_cde,  pm.PROGRAM_TYPE_GUID as programid, pm.PROGRAM_TYPE as programtype,  pm.PROGRAM_NAME as
        # programname,  pm.PGM_MILESTONE_GUID as pgm_milestoneid, pm.SEQ as pgm_milestoneseq, pm.milestonetypeid, pm.milestonetype,  pm.statusid,  pm.status, pm.programsubtypeid,
        # pm.programsubtypename, pm.programsubtypeseq,  pa.CREATED_DATE as createddate, pa.createduser,   pa.LAST_EDITED_DATE as lastediteddate, pa.lastediteduser
        # from
        #   -- 1st set
        #   (select pai.*, pr.*, cu.FIRST_NAME || ' ' || cu.LAST_NAME as createduser, uu.FIRST_NAME || ' ' ||  uu.LAST_NAME as lastediteduser
        #       from (select * from program_application WHERE 1=1 ) pai
        #       JOIN (select pri.PARTNER_GUID as partnerid, pri.partner_name as partnername, pri.county_code as partner_cnty_cde, pri.muni_code as partner_muni_cde
        #               from PARTNER pri  where pri.PARTNER_GUID = 'd73c82cf-e964-4159-b562-cb3b43d03186'
        #             ) pr ON pai.PARTNER_GUID = pr.partnerid
        #       LEFT JOIN AUTH_USER_SADC cu ON cu.AUTH_USER_GUID = pai.created_user_GUID
        #       LEFT JOIN AUTH_USER_SADC uu ON uu.AUTH_USER_GUID = pai.last_edited_user
        #   ) pa,
        #   -- 2nd set
        #   (SELECT pmi.PGM_MILESTONE_GUID, pmi.SEQ, pt.PROGRAM_TYPE_GUID, pt.PROGRAM_TYPE, pt.PROGRAM_NAME,ms.milestonetypeid, ms.MILESTONETYPE, s.statusid, s.STATUS,
        #       pt.programsubtypeid,      pt.programsubtypename, pt.programsubtypeseq
        #       FROM (select * from PGM_MILESTONE where SEQ > 0) pmi
        #       JOIN ( select gr.PROGRAM_TYPE_GUID, gr.PROGRAM_TYPE, gr.PROGRAM_NAME,  sty.PROGRAM_PHASE_GUID as programsubtypeid,
        #                 sty.SUB_PGM_NAME as programsubtypename, NVL(sty.SUB_PGM_SEQ, 1) as programsubtypeseq
        #                 from PROGRAM_TYPE gr
        #                 LEFT JOIN PROGRAM_PHASE sty ON sty.PROGRAM_TYPE_GUID = gr.PROGRAM_TYPE_GUID  and sty.SUB_PGM_NAME = 'test'
        #             where gr.PROGRAM_TYPE = 'Planning'
        #             ) pt ON pt.PROGRAM_TYPE_GUID = pmi.PROGRAM_TYPE_GUID
        #       JOIN ( select mo.MILESTONE_TYPE_GUID as milestonetypeid, mo.TYPEVAL as MILESTONETYPE from MILESTONE_TYPE mo ) ms ON ms.milestonetypeid  = pmi.MILESTONE_TYPE_GUID
        #       JOIN ( select st.STATUS_TYPE_GUID  as statusid, st.TYPEVAL as STATUS from STATUS_TYPE  st      ) s ON s.statusid = pmi.STATUS_TYPE_GUID
        #   ) pm
        # WHERE pa.PGM_MILESTONE_GUID = pm.PGM_MILESTONE_GUID

        ret = " select pa.PROGRAM_APPLICATION_GUID as id, pa.APPLICATION_DATE as appdate, pa.NAME_AUTH as nameauth, " \
              " pa.NOTE_GROUP_GUID as notegrpid, pa.DOCUMENT_GROUP_GUID as docgrpid,  pa.partnername,  pa.partnerid, " \
              " pa.partner_cnty_cde, pa.partner_muni_cde, " \
              " pm.PROGRAM_TYPE_GUID as programid, pm.PROGRAM_TYPE as programtype,  pm.PROGRAM_NAME as programname, " \
              " pm.PGM_MILESTONE_GUID as pgm_milestoneid, pm.SEQ as pgm_milestoneseq, pm.milestonetypeid, pm.milestonetype, " \
              " pm.statusid,  pm.status, pm.programsubtypeid, pm.programsubtypename, pm.programsubtypeseq, " \
              " pa.CREATED_DATE as createddate, pa.createduser,  " \
              " pa.LAST_EDITED_DATE as lastediteddate, pa.lastediteduser " \
              " from (select pai.*, pr.*, cu.FIRST_NAME || ' ' || cu.LAST_NAME as createduser, " \
              "     uu.FIRST_NAME || ' ' ||  uu.LAST_NAME as lastediteduser from (select * from program_application WHERE 1=1 "
        # Application specific filter
        # Application date
        if "appdate" in addOnDict:
            # App date do have time in it; so use 'between' for all
            #   1. by date (typical application)
            #   2. by year (used for annual applications - e.g. Planning)
            # Strictly by a day --> and trunc(pa.APPLICATION_DATE) = to_date('01-01-2016','MM-DD-YYYY')
            # Generic for any date range --> and pa.APPLICATION_DATE BETWEEN to_date('01-01-2016 00:00:00','MM-DD-YYYY HH24:MI:SS') and to_date('12-31-2016 23:59:59','MM-DD-YYYY HH24:MI:SS')
            ret += " and APPLICATION_DATE BETWEEN to_date( %(appdate)s ,'MM-DD-YYYY HH24:MI:SS') and to_date( %(appdate)s ,'MM-DD-YYYY HH24:MI:SS') "

        if "activeflag" in addOnDict:
            ret += " and ACTIVE = %(activeflag)s "

        ret += ") pai" \
               "        JOIN (select pri.PARTNER_GUID as partnerid, pri.partner_name as partnername,  " \
               "            pri.county_code as partner_cnty_cde, pri.muni_code as partner_muni_cde  from PARTNER pri "
        # Partner filter - either by id or name( there is literally nothing enforcing unique name for a partner, i guess its beyond scope for this for now)
        if "partnerid" in addOnDict:
            ret += " where pri.PARTNER_GUID = %(partnerid)s  "
        elif "partnername" in addOnDict:
            ret += " where pri.PARTNER_NAME = %(partnername)s  "

        ret += "         ) pr ON pai.PARTNER_GUID = pr.partnerid" \
               "        LEFT JOIN AUTH_USER_SADC cu ON cu.AUTH_USER_GUID = pai.created_user_GUID " \
               "        LEFT JOIN AUTH_USER_SADC uu ON uu.AUTH_USER_GUID = pai.last_edited_user " \
               "        ) pa, " \
               " (SELECT pmi.PGM_MILESTONE_GUID, pmi.SEQ, pt.PROGRAM_TYPE_GUID, pt.PROGRAM_TYPE, pt.PROGRAM_NAME, " \
               "     ms.milestonetypeid, ms.MILESTONETYPE, s.statusid, s.STATUS, pt.programsubtypeid, " \
               "     pt.programsubtypename, pt.programsubtypeseq " \
               "     FROM (select * from PGM_MILESTONE where SEQ > 0) pmi" \
               "     JOIN ( select gr.PROGRAM_TYPE_GUID, gr.PROGRAM_TYPE, gr.PROGRAM_NAME, "

        # Program type filter - either by ID or Type (& Name)

        # todo: pgm_sub_type (program_phase) new to this; got to test it
        # If program_phase name or ID included, left join sub_type table to program type
        if "programsubtypeid" in addOnDict or "programsubtypename" in addOnDict:
            ret += " sty.PROGRAM_PHASE_GUID as programsubtypeid, sty.SUB_PGM_NAME as programsubtypename, NVL(sty.SUB_PGM_SEQ, 1) as programsubtypeseq " \
                   " from PROGRAM_TYPE gr " \
                   " LEFT JOIN PROGRAM_PHASE sty ON sty.PROGRAM_TYPE_GUID = gr.PROGRAM_TYPE_GUID "
            if "programsubtypeid" in addOnDict:
                ret += " and sty.PROGRAM_PHASE_GUID = %(programsubtypeid)s "
            else:
                ret += " and sty.SUB_PGM_NAME = %(programsubtypename)s "
        else:
            ret += " null as programsubtypeid, null as programsubtypename,  1 as programsubtypeseq " \
                   " from PROGRAM_TYPE gr " \

        if "programid" in addOnDict:
            ret += " where gr.PROGRAM_TYPE_GUID = %(programid)s "
        elif "programtype" in addOnDict:
            ret += " where gr.PROGRAM_TYPE = %(programtype)s "
            if "programname" in addOnDict:
                ret += " and gr.PROGRAM_NAME = %(programname)s "

        ret += "     ) pt ON pt.PROGRAM_TYPE_GUID = pmi.PROGRAM_TYPE_GUID" \
               "     JOIN ( select mo.MILESTONE_TYPE_GUID as milestonetypeid, mo.TYPEVAL as MILESTONETYPE from MILESTONE_TYPE mo "

        # Milestone type filter - either by id or type
        if "appmilestonetypeid" in addOnDict:
            ret += " where mo.MILESTONE_TYPE_GUID = %(appmilestonetypeid)s "
        elif "appmilestonename" in addOnDict:
            ret += " where mo.TYPEVAL  = %(appmilestonename)s "

        ret += "     ) ms ON ms.milestonetypeid  = pmi.MILESTONE_TYPE_GUID " \
               "     JOIN ( select st.STATUS_TYPE_GUID  as statusid, st.TYPEVAL as STATUS from STATUS_TYPE  st "

        # Status type filter - either by ID or Type
        if "statusid" in addOnDict:
            ret += " where st.STATUS_TYPE_GUID = %(statusid)s "
        elif "status" in addOnDict:
            ret += " where st.TYPEVAL = %(status)s "

        ret += "     ) s ON s.statusid = pmi.STATUS_TYPE_GUID " \
               "  ) pm " \
               " WHERE pa.PGM_MILESTONE_GUID = pm.PGM_MILESTONE_GUID "

        # ret +=  " LEFT JOIN AUTH_USER_SADC uu ON uu.AUTH_USER_GUID = pa.last_edited_user "

        return ret

    def __str__(self):
        return self.id

class AppAnswer (models.Model):
    id = models.CharField(max_length=36, primary_key=True)
    docgrp_id = models.CharField(max_length=36)  # FK to Doc Group ID   #, db_column='DOCUMENT_GROUP_GUID'
    notegrp_id = models.CharField(max_length=36)  # FK to Note Group ID
    pgmapp_id = models.CharField(max_length=36)  # FK to Program Application ID
    question_id = models.CharField(max_length=36)  # FK to Question ID
    section_id = models.CharField(max_length=36)  # FK to Section ID
    answer = models.TextField()
    created_date = models.DateTimeField()
    created_user = models.CharField(max_length=36)  # FK to user id
    last_edited_date = models.DateTimeField()
    last_edited_user = models.CharField(max_length=36)  # FK to user id
    # ACTIVE = models.BooleanField
    objects = eFarmDBReader()

    class Meta:
        managed = False
        db_table = 'APPLICATION_ANSWER'

    def selectSQLByParams(self, strFormat, addOns):
        # strFormat --> django or python; default to django
        #   django -- %s paramater replacement
        #   python  -- {} string formatting
        # Introduced to accommodate for raw query's inability to handle string values within IN filter
        # or lack of my understanding of this crap. Spent over a day working with DBA to get a clue.

        # ACTIVE = models.BooleanField
        ret = "select ANSWER_GUID as id, DOCUMENT_GROUP_GUID as DOCGRP_ID, NOTE_GROUP_GUID as NOTEGRP_ID, PROGRAM_APPLICATION_GUID as PGMAPP_ID, " \
              " QUESTION_GUID as QUESTION_ID, SECTION_ID as SECTION_ID, ANSWER, CREATED_DATE, " \
              " CREATED_USER_GUID as created_user, LAST_EDITED_DATE, LAST_EDITED_USER from APPLICATION_ANSWER aa" \
              " where 1=1 "

        for ao in addOns:
            if "program_app" == ao:
                if strFormat and "python" == strFormat:
                    ret += " and aa.PROGRAM_APPLICATION_GUID = '{}'  "
                else:
                    ret += " and aa.PROGRAM_APPLICATION_GUID = %s  "

            elif "questions" == ao:
                if strFormat and "python" == strFormat:
                    ret += " and aa.QUESTION_GUID  in  {} "
                else:
                    ret += " and aa.QUESTION_GUID  in  %s "

            elif "sections" == ao:
                if strFormat and "python" == strFormat:
                    ret += " and aa.SECTION_ID  in  {} "
                else:
                    ret += " and aa.SECTION_ID  in  %s "

            elif "sec_ques" == ao:
                if strFormat and "python" == strFormat:
                    ret += " and ( aa.SECTION_ID  in {} OR aa.QUESTION_GUID  in {} )"
                else:
                    ret += " and ( aa.SECTION_ID  in %s OR aa.QUESTION_GUID  in %s )"

            elif "note_grp" == ao:
                if strFormat and "python" == strFormat:
                    ret += " and aa.NOTE_GROUP_GUID = {} "
                else:
                    ret += " and aa.NOTE_GROUP_GUID = %s "

            elif "doc_grp" == ao:
                if strFormat and "python" == strFormat:
                    ret += " and aa.DOCUMENT_GROUP_GUID = {} "
                else:
                    ret += " and aa.DOCUMENT_GROUP_GUID = %s "

        # ret += 'order by LAST_EDITED_DATE desc'   # any purpose? avoid additional overhead, if not required
        return ret

    def insertAnsSQl(self, singleInsert):
        ret = " INTO APPLICATION_ANSWER (ANSWER_GUID, QUESTION_GUID, SECTION_ID, PROGRAM_APPLICATION_GUID, ANSWER, NOTE_GROUP_GUID, " \
              " DOCUMENT_GROUP_GUID, CREATED_USER_GUID, CREATED_DATE, LAST_EDITED_USER, LAST_EDITED_DATE ) " \
              " VALUES (%s, %s, %s, %s, %s, %s, %s, %s, systimestamp, %s, systimestamp) "
        if singleInsert:
            ret = "INSERT " + ret
        return ret

    def updateAnsSQL(self, addAns, addNoteGrp, addDocGrp, is_Q_S):
        ret = ""
        if addAns or addNoteGrp or addDocGrp:
            ret = "UPDATE APPLICATION_ANSWER SET "
            if addAns:
                ret += " ANSWER = %s,  LAST_EDITED_USER = %s, LAST_EDITED_DATE =  systimestamp,"
            if addNoteGrp:
                ret += " NOTE_GROUP_GUID = %s,"
            if addDocGrp:
                ret += " DOCUMENT_GROUP_GUID = %s,"

            # remove last comma
            ret = ret[:-1]
            # LAST_EDITED_USER, LAST_EDITED_DATE --> ONLY if the answer change and not if just the comm or doc change
            # otherwise comments on answers after submission will modify the answer date & user

            if "section" == is_Q_S:
                ret += " WHERE QUESTION_GUID is null AND SECTION_ID = %s AND PROGRAM_APPLICATION_GUID = %s "

            else:
                ret += " WHERE QUESTION_GUID = %s AND SECTION_ID is null AND PROGRAM_APPLICATION_GUID = %s "

        return ret

    def __str__(self):
        return self.answer

class AppNote (models.Model):
    # Notes (comments)
    id = models.CharField(max_length=36, primary_key=True)
    note_group_id = models.CharField(max_length=36)
    note = models.TextField()
    created_date = models.DateTimeField()
    created_user = models.CharField(max_length=36)
    min_view_role = models.FloatField()
    active = models.BooleanField()

    class Meta:
            # db_table = 'note'
            managed = False

    def selectSQL(self, addActive):
        dSQL = "select n.note_guid as id, n.note_group_guid as note_group_id, n.note, n.created_date, n.CREATED_USER_GUID as created_user, " \
               " n.MINIMUM_VIEW_AUTH_ROLE as min_view_role, n.active " \
               " from note n where n.note_group_guid in {}"
        if addActive:
            dSQL += " and n.active = {} "

        return dSQL

    def insertNoteGrpSQl(self, singleInsert):
        # Note group table -- NOTE_GROUP
        ret = " INTO NOTE_GROUP (NOTE_GROUP_GUID, RELATED_TABLE, RELATED_TABLE_ID) " \
              " VALUES (%s, %s, %s) "
        if singleInsert:
            ret = "INSERT " + ret
        return ret

    def insertNoteSQl(self, singleInsert):
        ret = " INTO NOTE (NOTE_GROUP_GUID, NOTE_GUID, NOTE, MINIMUM_VIEW_AUTH_ROLE, CREATED_USER_GUID, CREATED_DATE,  ACTIVE) " \
              " VALUES (%s, %s, %s, %s, %s, systimestamp, 1) "
        if singleInsert:
            ret = "INSERT " + ret
        return ret

    def updateNoteByGrpIdSQL(self):
        # Typically used when an application is being prepared. There will be only one comment/note per
        # section/question till an application is submitted. Overwrite on every save
        ret = "UPDATE NOTE SET NOTE = %s, MINIMUM_VIEW_AUTH_ROLE = %s, " \
              " CREATED_USER_GUID = %s, CREATED_DATE = systimestamp,  ACTIVE = 1 " \
              " where NOTE_GROUP_GUID = %s"
        # if byGrpId:
        #     # Typically used when an application is being prepared. There will be only one comment/note per
        #     # section/question till an application is submitted. Overwrite on every save
        #     ret += " where NOTE_GROUP_GUID = %s"
        # else:
        #    # Ideally should never happend. For a submiited app, it should always be an append (insert)
        #     ret += " where NOTE_GUID = %s"

        return ret

class BlobField(models.Field):
    description = "Blob - Place holder"

    def db_type(self, connection):
        return 'blob'

class AppDoc (models.Model):
    # Docs (attachments)
    # Access to a doc:
    #   is_public = 0/false --> Restricted. Follow associated application's ACL and then apply 'min_view_role'
    #               for further filtering within that application
    #   is_public = 1/true --> Public - Let it fly.
    # Typically for a doc to be public; it must either be of status Resolution or Final. Not all final are public.
    # All status=Resolution  --> should be public. status='Resolution - Closed Session' --> Not public

    id = models.CharField(primary_key=True, max_length=36)
    doc_group_id = models.CharField(max_length=36)
    doc_type = models.TextField(max_length=100)
    doc_type_id = models.CharField(max_length=36)
    doc = BlobField()
    doc_name = models.TextField(max_length=100)
    doc_size = models.TextField(max_length=20)
    doc_content_type = models.TextField(max_length=100)
    doc_status = models.TextField(max_length=100)
    created_date = models.DateTimeField()
    created_user = models.CharField(max_length=36)
    min_view_role = models.FloatField()
    active = models.BooleanField()
    is_public = models.BooleanField()
    doc_group_ref = models.TextField(max_length=100)
    doc_group_ref_id = models.CharField(max_length=36)

    class Meta:
        managed = False

    def selectMetaSQL(self, byGroup, addActive):
        # Get doc(s) info by their group id
        dSQL = " select d.DOCUMENT_GUID as id, d.DOCUMENT_GROUP_GUID as doc_group_id, d.MINIMUM_VIEW_AUTH_ROLE as min_view_role, " \
               " d.CREATED_DATE, d.CREATED_USER_GUID as created_user, dt.TYPEVAL as doc_type, dt.DOCUMENT_TYPE_GUID as doc_type_id," \
               " null as doc, d.DOCUMENT_NAME as doc_name, " \
               " d.document_size as doc_size, d.document_content_type as doc_content_type, d.active, s.typeval as doc_status, " \
               " d.PUBLIC_ACCESS as is_public, dg.RELATED_TABLE as doc_group_ref, dg.RELATED_TABLE_ID as doc_group_ref_id " \
               " from document d, DOCUMENT_GROUP dg,document_status_type s, DOCUMENT_TYPE dt where d.DOCUMENT_GROUP_GUID = dg.DOCUMENT_GROUP_GUID and " \
               " d.DOCUMENT_TYPE_GUID = dt.DOCUMENT_TYPE_GUID and d.document_status_type_guid = s.document_status_type_guid " \
               " and "

        if byGroup:
            dSQL += " d.DOCUMENT_GROUP_GUID  in {} "
            #   python  -- {} string formatting

        else:
            dSQL += " d.DOCUMENT_GUID = %s "
            #   django -- %s paramater replacement

        if addActive:
            dSQL += " and d.active = %s "

        return dSQL

    def selectGrpID(self):
        ret = " SELECT null as id, DOCUMENT_GROUP_GUID as doc_group_id, null as min_view_role, " \
              " null as CREATED_DATE, null as CREATED_USER, null as doc_type, null as doc, null as doc_name, " \
              " null as doc_size, null as doc_content_type, null as active, null as doc_status, null as is_public," \
              " RELATED_TABLE as doc_group_ref, RELATED_TABLE_ID as doc_group_ref_id " \
              " from DOCUMENT_GROUP where RELATED_TABLE = %s and RELATED_TABLE_ID = %s"
        return ret

    def insertDocGrpSQL(self):
        # DOCUMENT group table -- DOCUMENT_GROUP
        # Other attributes will me populated by consumer app components.
        # This is strictly to support doc upload. Its integration with rest of the app is consumer's job
        ret = "INSERT INTO DOCUMENT_GROUP (DOCUMENT_GROUP_GUID, RELATED_TABLE, RELATED_TABLE_ID) " \
              " VALUES (%s, %s, %s) "
        return ret

    def insertDocSQL(self):
        # ret = " INTO DOCUMENT (DOCUMENT_GROUP_GUID, DOCUMENT_GUID, DOCUMENT_BLOB, MINIMUM_VIEW_AUTH_ROLE, DOCUMENT_NAME, " \
        #       " DOCUMENT_SIZE, DOCUMENT_CONTENT_TYPE, CREATED_USER_GUID, CREATED_DATE, DOCUMENT_TYPE_GUID, ACTIVE, DOCUMENT_STATUS_TYPE_GUID ) " \
        #       " SELECT %s, %s, %s, %s, %s, %s, %s, %s, systimestamp, dt.DOCUMENT_TYPE_GUID, 1,  ds.document_status_type_guid from" \
        #       " (SELECT t.DOCUMENT_TYPE_GUID from DOCUMENT_TYPE t where t.TYPEVAL = %s ) dt,  " \
        #       " (SELECT s.document_status_type_guid from document_status_type s where s.typeval = %s ) ds "
        ret = " INTO DOCUMENT (DOCUMENT_GROUP_GUID, DOCUMENT_GUID, DOCUMENT_BLOB, MINIMUM_VIEW_AUTH_ROLE, DOCUMENT_NAME, " \
              " DOCUMENT_SIZE, DOCUMENT_CONTENT_TYPE, CREATED_USER_GUID, CREATED_DATE, DOCUMENT_TYPE_GUID, ACTIVE, DOCUMENT_STATUS_TYPE_GUID ) " \
              " SELECT %s, %s, %s, %s, %s, %s, %s, %s, systimestamp, %s, 1,  ds.document_status_type_guid from" \
              " (SELECT s.document_status_type_guid from document_status_type s where s.typeval = %s ) ds "
        return ret

    def updateDocSQL(self):
        # Only a few attributes can change for a doc
        # Custom view role, Active/Inactive, Public access, doc type & doc status type
        ret = " update document set MINIMUM_VIEW_AUTH_ROLE = %s, ACTIVE = %s, PUBLIC_ACCESS = %s," \
              " DOCUMENT_TYPE_GUID = (select document_type_guid from document_type where typeval = %s), " \
              " DOCUMENT_STATUS_TYPE_GUID = (select DOCUMENT_STATUS_TYPE_GUID from DOCUMENT_STATUS_TYPE where typeval = %s ) " \
              " where DOCUMENT_GUID = %s "
        return ret

    def deleteDocSQL(self):
        # return " delete from document where DOCUMENT_GUID = %s and document_status_type_guid not in " \
        #        " ( select s.document_status_type_guid from document_status_type s where s.typeval in" \
        #        " ('Final', 'Resolution', 'Resolution - Closed Session'))"
        return " delete from document where DOCUMENT_GUID = %s and document_status_type_guid not in " \
               " (select s.document_status_type_guid from document_status_type s where s.permanent = 1) "

    def save(self, grpParams):
        ret = False
        insSQL = self.insertDocSQL()
        cursor = connection.cursor()
        try:
            cxblob = cursor.var(cx_Oracle.BLOB)
            cxblob.setvalue(0, self.doc)
            if grpParams:
                # Not used ???
                insSQL = "INSERT ALL " + self.insertDocGrpSQl() + " " + insSQL + " SELECT 1 FROM DUAL"
                cursor.execute(insSQL, [self.doc_group_id, grpParams[0], grpParams[1],
                                        self.doc_group_id, self.id, cxblob, self.min_view_role, self.doc_name,
                                        self.doc_size, self.doc_content_type, self.created_user, self.doc_type_id, self.doc_status])
            else:
                insSQL = "INSERT " + insSQL
                cursor.execute(insSQL, [self.doc_group_id, self.id, cxblob, self.min_view_role, self.doc_name,
                                        self.doc_size, self.doc_content_type, self.created_user, self.doc_type_id, self.doc_status])

            connection.commit()
            ret = True
        except utils.DatabaseError, exc:
            error, = exc.args
            ret = False
            print >> sys.stderr, "Oracle-Error-Code:", error.code
            print >> sys.stderr, "Oracle-Error-Message:", error.message
        finally:
            cursor.close()
            connection.close()

        return ret

    def getDoc(self):
        # Get doc's binary content by id
        ret = False
        cursor = connection.cursor()
        try:
            dSQL = " select d.DOCUMENT_BLOB, d.DOCUMENT_NAME, d.document_size, d.document_content_type, " \
                   " d.MINIMUM_VIEW_AUTH_ROLE, d.CREATED_DATE, d.CREATED_USER_GUID, d.active, d.public_access, " \
                   " t.typeval, s.typeval  from document d, document_status_type s, document_type t " \
                   " where d.DOCUMENT_TYPE_GUID = t.DOCUMENT_TYPE_GUID " \
                   " and d.document_status_type_guid = s.document_status_type_guid and  d.DOCUMENT_GUID = %s "

            cursor.execute(dSQL, [self.id])
            rs = cursor.fetchone()
            if None != rs:
                self.doc = rs[0].read()
                self.doc_name = rs[1]
                self.doc_size = rs[2]
                if None != rs[3]:
                    self.doc_content_type = rs[3]
                else:
                    self.doc_content_type = "application/octet-stream"
                self.min_view_role = rs[4]
                self.created_date = rs[5]
                self.created_user = rs[6]
                self.active = rs[7]
                self.is_public = rs[8]
                self.doc_type = rs[9]
                self.doc_status = rs[10]

                ret = True
        except:
            return False
        finally:
            cursor.close()
            connection.close()

        if ret:
            return self
        else:
            return None

    def __str__(self):
        return self.doc_name

class QuestionnaireForDisplay(models.Model):
    id = models.CharField(max_length=36, primary_key=True)
    parentid = models.CharField(max_length=36)
    displayseq = models.IntegerField()
    text = models.TextField()
    hint = models.TextField()
    pgm_milestoneid = models.CharField(max_length=36)
    cattype = models.CharField(max_length=30)
    qsectionid = models.CharField(max_length=36)
    question_path = models.TextField()
    question_required = models.IntegerField()
    answer_data_type = models.CharField(max_length=30)
    trigger_value = models.CharField(max_length=50)
    objects = eFarmDBReader()

    class Meta:
        managed = False
        db_table = ''

    def fetchByProgramMSId_SQL(self, includeQuestions):
        # Conceptually - Model methods are for row level functionality.
        # This method should ideally be associated with Manager. Since manager is also not used in true Django sense
        # keeping it all in here for convenience.
        sectopsql = " select " \
                    "   aqs.section_id as id, aqs.parent_section as parentid, aqs.section_sequence as displayseq,  aqs.section as text, aqs.hint hint," \
                    "   aqs.pgm_milestone_guid as pgm_milestoneid, 'section' as cattype, " \
                    "   '' as qsectionid,  '' as question_path, 0 as question_required, '' as answer_data_type, '' as trigger_value "

        secbttmsql = " from application_question_section aqs " \
                     " where  aqs.pgm_milestone_guid = %(msguid)s " \
                     " and aqs.active = 1 " \
                     " and (aqs.parent_section is null or aqs.parent_section in (select paqs.section_id from " \
                     " application_question_section paqs where paqs.active= 1 and paqs.pgm_milestone_guid = %(msguid)s))"
                     # " and (aqs.parent_section is null or aqs.parent_section not in (select paqs.section_id from " \
                     # " application_question_section paqs where paqs.active= 0 and  paqs.active is not null and paqs.program_type_id = %s))"
        #               Without the parent_section filter/sub-query - child section who's parent are inactive get selected!

        quessql = " select " \
                  "     question_guid as id, parent_question_guid as parentid, question_sequence as displayseq, question as text, hint as hint, " \
                  "     '' as pgm_milestoneid, 'question' as cattype, "\
                  "     section_id as qsectionid, question_path, question_required, answer_data_type, trigger_value " \
                  " from application_question q where q.active=1 " \
                  " and (q.parent_question_guid is null or q.parent_question_guid not in (select question_guid from " \
                  " application_question pq where pq.active = 0 and pq.active is not null)) "
        #           Without the parent_question_guid filter/sub-query - child question who's parent are inactive get selected!
        #   assumption - filter at DBless costlier than a filter at client? True?
        #   todo: Once in production, evaluate performance

        quessectionfilter = " and q.section_id in ( select section_id " + secbttmsql + " )"

        ret = sectopsql + secbttmsql

        # if "includeQuestions" in addOnDict and addOnDict["includeQuestions"]:
        if includeQuestions:
            ret += " union "
            ret += quessql + quessectionfilter

        ret += " order by  cattype desc, displayseq, parentid desc "
        return ret

    def fetchBySectionId_SQL(self, includeQuestions):
        # SQL to get:
        #   Active section and their immediate (active) child section(s)
        #   On-demand: Active questions for the section and their active child question(s)

        # Conceptually - Model methods are for row level functionality.
        # This method should ideally be associated with Manager. Since manager is also not used in true Django sense
        # keeping it all in here for convenience.
        ret = " select " \
                    "   aqs.section_id as id, aqs.parent_section as parentid, aqs.section_sequence as displayseq,  aqs.section as text, aqs.hint hint," \
                    "   aqs.pgm_milestone_guid as pgm_milestoneid, 'section' as cattype, " \
                    "   '' as qsectionid,  '' as question_path, 0 as question_required, '' as answer_data_type, '' as trigger_value " \
                    " from application_question_section aqs " \
                    " where  aqs.active = 1 " \
                    " and (aqs.section_id = %(sectionid)s or aqs.parent_section = %(sectionid)s)"

        if includeQuestions:
            quessql = " select " \
                  "     question_guid as id, parent_question_guid as parentid, question_sequence as displayseq, question as text, hint as hint, " \
                  "     '' as pgm_milestoneid, 'question' as cattype, "\
                  "     section_id as qsectionid, question_path, question_required, answer_data_type, trigger_value " \
                  " from application_question q where q.active=1 " \
                  " and q.section_id = %(sectionid)s " \
                  " and (q.parent_question_guid is null or q.parent_question_guid in (select question_guid from " \
                  " application_question pq where pq.active = 1 and pq.section_id = %(sectionid)s)) "

            ret += " union " + quessql

        ret += " order by cattype desc, displayseq, parentid desc"

        # print 'c3c9918d-c7d3-4dd9-98ed-2be612262caa'
        # print ret
        return ret

    def __str__(self):
        return self.text

class ProgramType(models.Model):
    program_type_guid = models.CharField(max_length=36, primary_key=True)
    program_type = models.CharField(max_length=100)
    program_name = models.CharField(max_length=100)
    # active = models.BooleanField()
    # created_user = models.CharField(max_length=50)
    # created_date = models.DateTimeField()
    # last_edited_user = models.CharField(max_length=50)
    # last_edited_date = models.DateTimeField()
    objects = eFarmDBReader()

    class Meta:
        # db_table = 'program_type'
        managed = False

    # def inactivatesql(self):
    #     ret = "update program_type set " \
    #           " active = 0, last_edited_date = sysdate, last_edited_user = %s " \
    #           " where program_type_id = %s"
    #     return ret

    def insertsql(self):
        ret = "insert into program_type " \
              " (program_type_guid, program_type, program_name)" \
              " values (%s, %s, %s)"
        return ret

    def selectsql(self):
        # 'ANY' is strictly for program milestone management. Have no purpose for client/users to see
        ret = "select program_type_guid, program_type, program_name from program_type " \
              " WHERE program_type != 'ANY' AND program_name!= 'ANY' "
        return ret

    def __str__(self):
        return self.type

class RuleDef (models.Model):
    # Rule definition
    rule_definition_guid = models.CharField(max_length=36, primary_key=True)
    rule_name = models.TextField()
    rule_type = models.TextField()
    rule_definition_json = models.TextField()
    active = models.BooleanField()
    objects = eFarmDBReader()

    class Meta:
            managed = False

    def selectByNameSQL(self, serachAll):
        dSQL = "select rule_definition_guid, rule_name, rule_type, rule_definition_json, active " \
               " from rule_definition n where rule_name = %(rname)s"

        if serachAll:
            # available & == True
            pass
        else:
            dSQL += " and active = 1 "

        return dSQL

class CustomSQL():
    def push(self, sqlstr, paramlist):
        # Use this for Insert, Update & Delete
        ret = False
        cursor = connection.cursor()
        try:
            cursor.execute(sqlstr, paramlist)
            # print "cursor.rowcount"
            # print cursor.rowcount
            if cursor.rowcount > 0:
                connection.commit()
                ret = True
        # except utils.DatabaseError, exc:
        #     error, = exc.args
        #     print >> sys.stderr, "Oracle-Error-Code:", error.code
        #     print >> sys.stderr, "Oracle-Error-Message:", error.message
        # Let this throw exception and have the consumer handle it
        finally:
            cursor.close()
            connection.close()

        return ret

    def pull(self,sqlstr):
        cursor = connection.cursor()
        try:
            cursor.execute(sqlstr)
            # ret = cursor.fetchall()
            ret = self.dictfetchall(cursor)
            # print "Fetch: " + str(len(ret))
        except utils.DatabaseError, exc:
            error, = exc.args
            print >> sys.stderr, "Oracle-Error-Code:", error.code
            print >> sys.stderr, "Oracle-Error-Message:", error.message
        # Let this throw exception and have the consumer handle it
        finally:
            cursor.close()
            connection.close()

        # print "Done here @ pull"
        return ret
        # pass

    def dictfetchall(self, cursor):
        "Return all rows from a cursor as a dict"
        columns = [col[0] for col in cursor.description]
        return [
            dict(zip(columns, row))
            for row in cursor.fetchall()
        ]
