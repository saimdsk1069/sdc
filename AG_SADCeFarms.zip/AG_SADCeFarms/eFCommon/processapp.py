__author__ = 'OAXRAJA'
from eFCommon import utils as aaau
from eFCommon.models import CustomSQL, AppAnswer, AppNote, AppDoc
from datetime import date, datetime
import commonprocs as cp
# import sys
#     , json
# import utils as cu

def questionnarie(ai, reqSection, comm_doc_priv):
    # Autorization check to happen at calling app:
    # Worker bee here got to just collect data and send it to caller
    # It becomes the responsibility of the calling app to decide on data cleansing & massaging.

    # todo: This is still evolving
    # todo: lot of logic form calling app should get here eventually

    jsonfeed = {}
    if None == reqSection:
        slist = cp.getSectionsByProgramMSID(ai.pgm_milestoneid)
        reqSection = slist[0].id
        jsonfeed = {"treeview": cp.prepareSectionForTreeView(slist, None)}
        # print "jsonfeed: "+ str(jsonfeed)

    basefeed = {"appinfo":  cp.prepareAIForClientView([ai]), "section": reqSection}

    qlist = cp.getQuestionsBySectionID(reqSection)

    idList = []
    if len(qlist):
        basefeed["qspayload"] = cp.prepareSQForClientView(qlist)
        qIdList = [q.id.encode('ascii') for q in aaau.objListFilter(qlist, "cattype", "question")]

        # Get saved answers for program application, by application ID
        # Optional filters --> section, question IDs
        ansList = getAppAnswersByIds(ai.id.encode('ascii'), [reqSection.encode('ascii')], qIdList)

        if len(ansList):
            basefeed["answers"] = cp.prepareAnswerForClientView(ansList)
            nGrpIds = []
            dGrpIds = []
            for a in ansList:
                if a.notegrp_id:
                    nGrpIds.append(a.notegrp_id.encode('ascii'))
                if a.docgrp_id:
                    dGrpIds.append(a.docgrp_id.encode('ascii'))
            # if answers have associated comments or docs; get them. Meta ONLY for docs
            if len(nGrpIds):
                comList = getNotesByGrpIds(nGrpIds)
                comList = cp.roleBasedCleansing(comList, "min_view_role", comm_doc_priv)
                basefeed["comments"] = cp.prepareNoteForClientView(comList)
            else:
                basefeed["comments"] = []

            if len(dGrpIds):
                docList = getDocsByGrpIds(dGrpIds)
                # todo - bring back access control
                # docList = cp.roleBasedCleansing(docList, "min_view_role", comm_doc_priv)
                basefeed["docs"] = cp.prepareDocForClientView(docList)
            else:
                basefeed["docs"] = []

    # print "basefeed: " + str(basefeed)
    jsonfeed["bodyview"] = basefeed

    return jsonfeed

def startnewApplication(appmeta, uid):
    # WIll not know the actual program info. Based on program type & partner org,
    # find out the actual program (Name & Type combo)
    # e.g. if   appmeta.partnername  == Burlington County
    #           appmeta.programtype  ==  Planning
    #   program --> will be 'County Planning Incentive Grant'

    # User authorization: Already checked at calling app
    #   Between roles & privileges; Identify permission(s) over this application
    #   1. List all roles
    #   2. Get privileges
    #       a. For program type
    #       b. Further filter by program partner
    #   3. Based on the combined list of roles/priv; check user have 'edit'
    #      permission over the application for the program partner

    # 7/25/2016
    # user authorized to start app?

    appmeta.id = aaau.getNewGUID()
    yrtxt = 'sysdate'
    if "Planning" == appmeta.programtype:
        yrtxt = "to_date(\'" + getNewPlanningAppYr() + "\', 'MM-DD-YYYY')"
    # insSQL = appmeta.insertSQLByPrtnrName(yrtxt)
    insSQL = appmeta.insertSQL(yrtxt)
    cs = CustomSQL()
    cs.push(insSQL, [appmeta.id, appmeta.partnerid, uid, uid, appmeta.pgm_milestoneid, ''])

    return appmeta.id

def getNewPlanningAppYr():
    # When planning, application is for next year; save that for application date
    # Dec 15th is planning application's cutoff for next year.
    today = date.today()
    yrtxt = "01-01-"
    if today.month == 12 and today.day > 15:
        yrtxt += str(today.year + 2)
    else:
        yrtxt += str(today.year + 1)

    return yrtxt

def getApplictaion():
    # Must have confirmed:
    #   User authorization - to app
    #

    # Required params:
    #   - Program
    #       Name
    #       Type
    #       Year
    #   - Partner
    #   - Status set to "Incoming(default)", if new

    pass

# --------------------------------------------------------
#
# --------------------------------------------------------
# --------------------------------------------------------
def appDataPush (request, appmeta, uid, usrapppriv):
    # Step 1: user authorization - calling app's responsibility
    #     User viewmode (UI) Options: deny, view, append, sign, submit, edit
    #     ----------------------------------------------------------------------------
    #     User UI Mode                     Privilege
    #                       Edit answers        Add comments        Add documents
    #       Edit                Y                   Y                   Y
    #       Append              N                   Y                   Y
    #       Submit              N                   Y                   Y
    #       Sign                N                   Y                   Y
    #     -----------------------------------------------------------------------------
    #     Note: New comments and/or docs could force updates to answers table for FK values

    # print "usrapppriv['viewmode']: " + str(usrapppriv['viewmode'])

    if usrapppriv['viewmode'] in ['Edit', 'Append', 'Submit', 'Sign']:
        # calling app have already checked. serves no benefit here!

        retfeed = "Error"

        # django bulk_create(objs, batch_size=None)
        # This method inserts the provided list of objects into the database in an efficient manner
        # (generally only 1 query, no matter how many objects there are):
        # This has a number of caveats though:
        #     The model's save() method will not be called, and the pre_save and post_save signals
        #           will not be sent.
        #     It does not work with child models in a multi-table inheritance scenario.
        #     If the model's primary key is an AutoField it does not retrieve and set the
        #           primary key attribute, as save() does.
        #     It does not work with many-to-many relationships.

        # print "len(existinga) : " + str(len(existinga))

        # Raw SQL string for insert comments, attachments (& answers, if edit)
        cs = CustomSQL()
        aa = AppAnswer()
        inssql = ''
        paramArr = []

        # Comments and attachments may be:
        #   Add-on to previously entered comment/att (have a group id for c/a & thus an answer entry too)
        #   First time comment/att to an existing answer (no group id for c/a & just an answer entry)
        #   New Comment or Att for previously not answered question or for a section

        try:
            # print "usrapppriv['viewmode'] " + str(usrapppriv['viewmode'])
            comments = parsepayload(request, 'com')
            attachments = parsepayload(request, 'att')
            answers = parsepayload(request, 'ans')
            updSqlParamArr = []

            anote = AppNote()
            adoc = AppDoc()

            # From DB get existing answers
            # todo: Now that questionnaire is listed by section
            # todo: further filter existing answers to refine to the question/section IDs in the payload ??
            existinga = getapplicationanswers(appmeta.id)  # just the answer table this time

            # Process updates & appends
            for e in existinga:
                # loop through existing answers
                # Note: Section GUID are used when comments/Docs are tied to section instead of question

                guidKey = "abcd"    # Starting w/ random; either question or section GUID should replace
                if e.question_id:
                    guidKey = e.question_id
                elif e.section_id:
                    guidKey = e.section_id

                # Comments/Notes - Start
                noteGrpId = None
                if guidKey in comments:
                    # Comment payload for this answer
                    # During 'incoming' phase, only one comment is allowed. Beyond that phase
                    # question/section could have multiple comments. But only one will be in 'edit' mode.
                    # Other(s) will be in display mode. So safe to expect only one comment per q/s in a payload.

                    if e.notegrp_id:
                        # Note group id exist for this answer rec
                        if "Incoming" == appmeta.status:
                            # Overwrite notes/comments; Must honor empty notes in overwrite mode
                            cs.push(anote.updateNoteByGrpIdSQL(), [comments[guidKey], usrapppriv['ca_tier'], uid,  e.notegrp_id])

                        elif comments[guidKey]:
                            # Additional notes/comments; Ignore if empty
                            inssql += anote.insertNoteSQl(False)        # SQL for bulk insert
                            paramArr.extend([e.notegrp_id, aaau.getNewGUID(), comments[guidKey], usrapppriv['ca_tier'], uid])

                    else:
                        # Note is new to this answer rec; Ignore if empty
                        if comments[guidKey]:
                            # Group entry
                            noteGrpId = aaau.getNewGUID()
                            inssql += anote.insertNoteGrpSQl(False)     # SQL for bulk insert
                            paramArr.extend([noteGrpId, 'Answer@' + appmeta.id, guidKey])

                            # Note entry
                            inssql += anote.insertNoteSQl(False)        # SQL for bulk insert
                            paramArr.extend([noteGrpId, aaau.getNewGUID(), comments[guidKey], usrapppriv['ca_tier'], uid])

                    # remove processed
                    del comments[guidKey]
                # Comments/Notes - End

                # Attached files - Start
                # Associate a saved doc to a question/section/...
                # todo: fix after attach file code implementation
                docGrpId = None
                if guidKey in attachments:

                    # Actual doc push happens outside of questionnaire save process.
                    # Attempt here is to link saved doc to a question/section; through doc_group_id
                    docGrpId = attachments[guidKey]
                    if guidKey not in answers:
                        # to handle attached files to section
                        answers[guidKey] = ''

                    # if e.docgrp_id:
                    #     # Group ID for docs is already there
                    #     pass
                    # else:
                    #     docGrpId = aaau.getNewGUID()
                    #     inssql += adoc.insertDocGrpSQl(False)     # SQL for bulk insert
                    #     paramArr.extend([docGrpId, 'Answer@' + appmeta.id, guidKey])
                    # todo - go associate docgroupid to the actual doc record

                    # remove processed
                    del attachments[guidKey]
                # Attached files - End

                # Answers - Start
                if guidKey in answers:
                    updateAns = False
                    if "Incoming" == appmeta.status:
                        updateAns = True

                    if updateAns or docGrpId or noteGrpId:
                        # If any of the above is true; go update
                        if e.section_id and not e.question_id:
                            # Update is for note/doc entry in section
                            updsql = aa.updateAnsSQL(updateAns, noteGrpId, docGrpId, "section")
                        else:
                            updsql = aa.updateAnsSQL(updateAns, noteGrpId, docGrpId, "question")

                        updParamArr = []    # append seq is critical
                        if updateAns:
                            updParamArr.append(answers[guidKey])
                            updParamArr.append(uid)

                        if noteGrpId:
                            updParamArr.append(noteGrpId)

                        if docGrpId:
                            updParamArr.append(docGrpId)

                        if e.section_id and not e.question_id:
                            # Cont'd from above selection between question vs section
                            updParamArr.append(e.section_id)
                        else:
                            updParamArr.append(e.question_id)

                        updParamArr.append(appmeta.id)

                        updSqlParamArr.append({'sql': updsql, 'params': updParamArr})
                        # cs.push(,) # Cannot happen now; got to wait for inserts to complete

                    # remove processed
                    del answers[guidKey]
                # Answers - End
            existinga = None

            # todo - All comment & doc insert must happen before answer insert/update for FK

            # New answers - first time the questionnaire section is saved
            for k, v in answers.iteritems():
                if "Incoming" == appmeta.status:
                    # Incoming mode - save all

                    # Comments/Notes - Start
                    noteGrpId = None
                    if k in comments:
                        # Comment payload for this answer
                        # During 'incoming' phase only one comment is allowed.

                        # Note is new to system; Ignore if empty
                        if comments[k]:
                            # Group entry
                            noteGrpId = aaau.getNewGUID()
                            inssql += anote.insertNoteGrpSQl(False)     # SQL for bulk insert
                            paramArr.extend([noteGrpId, 'Answer@' + appmeta.id, k])

                            # Note entry
                            inssql += anote.insertNoteSQl(False)        # SQL for bulk insert
                            paramArr.extend([noteGrpId, aaau.getNewGUID(), comments[k], usrapppriv['ca_tier'], uid])

                        # remove processed
                        del comments[k]
                    # Comments/Notes - End

                    # Attached files - Start
                    # Associate a saved doc to a question/section/...
                    # todo: fix after attach file code implementation
                    docGrpId = None
                    if k in attachments:
                        # Actual doc push happens outside of questionnaire save process.
                        # Attempt here is to link saved doc to a question/section; through doc_group_id
                        docGrpId = attachments[k]

                        # docGrpId = aaau.getNewGUID()
                        # inssql += adoc.insertDocGrpSQl(False)     # SQL for bulk insert
                        # paramArr.extend([docGrpId, 'Answer@' + appmeta.id, k])

                        # todo - go associate docgroupid to the actual doc record

                        # remove processed
                        del attachments[k]
                    # Attached files - End

                    inssql += aa.insertAnsSQl(False)     # SQL for bulk insert
                    paramArr.extend([aaau.getNewGUID(), k, None, appmeta.id, v, noteGrpId, docGrpId, uid, uid])
                    # Answer collection will always be tied to questions and never to section
                    # Set section guid to None here

                else:
                    # Should ideally never reach here
                    # New Answers/comments/att - post incoming mode!
                    # cleaning up comments or att tied to question. Any left behind now would be those for Sections
                    del comments[k]
                    del attachments[k]

            # process left out comments/att
            # Add them as an answer record even though tied to section and not question.
            #   Empty answer but with respective group id of comm/att
            # They are comm/att tied to sections and coming in for the first time (otherwise would have caught at
            #   iteration of existing answers, in the very beginning)

            # Comments - Start
            for k, v in comments.iteritems():
                # Comment payload for a section
                # They could come in anytime till committee approval

                # Ignore if empty
                noteGrpId = None
                if v:
                    # Group entry
                    noteGrpId = aaau.getNewGUID()
                    inssql += anote.insertNoteGrpSQl(False)     # SQL for bulk insert
                    paramArr.extend([noteGrpId, 'Answer@' + appmeta.id, k])

                    # Note entry
                    inssql += anote.insertNoteSQl(False)        # SQL for bulk insert
                    paramArr.extend([noteGrpId, aaau.getNewGUID(), v, usrapppriv['ca_tier'], uid])

                # Attached files - Start
                # Associate a saved doc to a question/section/...
                # todo: fix after attach file code implementation
                docGrpId = None
                if k in attachments:
                    # Actual doc push happens outside of questionnaire save process.
                    # Attempt here is to link saved doc to a question/section; through doc_group_id
                    docGrpId = attachments[k]

                    # docGrpId = aaau.getNewGUID()
                    # inssql += adoc.insertDocGrpSQl(False)     # SQL for bulk insert
                    # paramArr.extend([docGrpId, 'Answer@' + appmeta.id, k])

                    # todo - go associate docgroupid to the actual doc record

                    # remove processed
                    del attachments[k]
                # Attached files - End

                if noteGrpId or docGrpId:
                    inssql += aa.insertAnsSQl(False)     # SQL for bulk insert
                    paramArr.extend([aaau.getNewGUID(), None, k, appmeta.id, None, noteGrpId, docGrpId, uid, uid])
                    # Comments/Docs tied to section. Set question guid to None here

            # Comments - End

            # Attached files - Start
            # Section w/ no comment but just file(s) ONLY
            # Associate a saved doc to a question/section/...
            # todo: fix after attach file code implementation
            docGrpId = None
            for k, v in attachments.iteritems():
                # Actual doc push happens outside of questionnaire save process.
                # Attempt here is to link saved doc to a question/section; through doc_group_id

                docGrpId = v
                # inssql += adoc.insertDocGrpSQl(False)     # SQL for bulk insert
                # paramArr.extend([docGrpId, 'Answer@' + appmeta.id, k])

                # todo - go associate docgroupid to the actual doc record

                inssql += aa.insertAnsSQl(False)     # SQL for bulk insert
                paramArr.extend([aaau.getNewGUID(), None, k, appmeta.id, None, None, docGrpId, uid, uid])
                # Doc(s) tied to section. Set question guid to None here

            # Attached files - End

            # Final DB actions
            # Insert
            if inssql:
                inssql = "INSERT ALL " + inssql + " SELECT 1 FROM DUAL;"
                # print "inssql " + inssql
                # print "paramArr " + str(paramArr)
                cs.push(inssql, paramArr)

            # Update
            for u in updSqlParamArr:
                # print "Update SQL: " + u['sql']
                # print "Update Params: " + str(u['params'])
                cs.push(u['sql'], u['params'])

            # update last edit user & time in app's meta
            if (cs.push(appmeta.updateSQL([""]), [uid, appmeta.id])):
                appmeta.lastediteddate = datetime.now()
                appmeta.lastediteduser = uid

            retfeed = "Success"
            # print "all done?"

        except:
            # print "Error @ appDataPush - edit access   ", sys.exc_info()
            retfeed = "Error"

        # todo:  need to clean up and make this readable & usable

        # todo redirect based on app mode
        #   - Edit/Append: Save & continue
        #   - Edit/Append: Save & get out?
        #   - Sign/Submit: Save & be done with it (to be determined by WFM?)

    else:
        # todo - terminate session and force to logout page?
        # return HttpResponsePermanentRedirect('efarms/forcedlogout')
        retfeed = "Unauthorized"

    return retfeed

def getapplicationanswers(appid):
    # todo: Application details: Answers, except the attachments & comments not authorized for the user (tier)

    aa = AppAnswer()
    sqlStr = aa.selectSQLByParams("django", ["program_app"])
    # abc = AppAnswer.objects.raw(sqlStr, [appid])
    # print sqlStr
    # print abc
    return list(AppAnswer.objects.raw(sqlStr, [appid]))

def getAppAnswersByIds(appid, sIdList, qIdList):
    # App ID, Question IDs & Section IDs
    # todo: Section & Question IDs could be on-demand? If none, bring all out? If present filter accordingly.
    # todo: Include Answers, Comments and Docs. (Docs - Meta only)
    aa = AppAnswer()
    filterReqList = ["program_app"]
    filterParamList = [appid]

    # First time using 'IN' filter in Django. That turned out to be quite an exercise. Lesson learnt:
    # Django raw query --> parameters are passed as an array. parameter array cannot take list/array as an element, but
    # can take tuple as an element. Hence to pass multiple values (for IN), as one element of the parameter array,
    # got to convert value list/arr to tuple. Unfortunately django/cx_oracle world handle tuples with numbers better
    # than tuple with string values; With string tuple, something end up messing the query and oracle never return
    # a value; eventhough query from log work perfectly through sql developer!
    # To overcome this issue, python string formatter is used to prepare SQL stmt. Keeping the usual one in place just
    # in case somebody figure this out, someday. Since all the filter values are derived form DB in the steps before,
    # there is no possibility of custom user key in value and thus no possibility of SQL injection.

    # Note: String values in tuple must be ascii encoded else will end up with unicode notation before every value
    # and filter will fail.
    # IN filter value list when when not empty must have at least 2 values. Single value tuple could yield errors.
    # With single element tuple e.g.(123, ) though there is no 2nd element, a comma has be present.
    # comma do get into sql string and end up upsetting oracle! Solution --> add a fake 2nd element.

    if len(sIdList) == 1:
        sIdList.append('20160405abc123')
    if len(qIdList) == 1:
        qIdList.append('20160405abc123')

    if sIdList and qIdList:
        # both section & question ids are pesent
        filterReqList.append("sec_ques")
        # # filterParamList.append("'" + '\',\''.join(sIdList) + "'")
        # # filterParamList.append("'" + '\',\''.join(qIdList) + "'")
        filterParamList.append(tuple(sIdList))
        filterParamList.append(tuple(qIdList))

    elif sIdList:
        # By section id(s) only
        filterReqList.append("sections")
        filterParamList.append(tuple(sIdList))

    elif qIdList:
        # By question id(s) only
        filterReqList.append("questions")
        filterParamList.append(tuple(qIdList))

    sqlStr = aa.selectSQLByParams("python", filterReqList)
    sqlStr = sqlStr.format(*filterParamList)
    # print str(sqlStr)
    return list(AppAnswer.objects.raw(sqlStr))
    # return list(AppAnswer.objects.raw(sqlStr, [appid, tuple(sIdList), tuple(qIdList)]))

def getNotesByGrpIds(grdIdList):
    # read notes at getAppAnswersByIds() for more info on the voodoos
    if len(grdIdList) == 1:
        grdIdList.append('20160405abc123')
    an = AppNote()
    sqlStr = an.selectSQL(None)
    sqlStr = sqlStr.format(tuple(grdIdList))
    # print sqlStr
    return list(AppNote.objects.raw(sqlStr))

def getDocsByGrpIds(grdIdList):
    if len(grdIdList) == 1:
        grdIdList.append('20160405abc123')
    ad = AppDoc()
    sqlStr = ad.selectMetaSQL(True, False)
    sqlStr = sqlStr.format(tuple(grdIdList))
    # print sqlStr
    return list(AppNote.objects.raw(sqlStr))


def parsepayload(request, parseitem):
    # parseitem:    'ans' for answers
    #               'com' for comments
    #               '' for attachments
    # e.g.  For answers, loop through keys that starts with ans_
    #       From key extract the question id. Key --> 'ans_<questionid>'
    # Return dictionary key(s) will always be guid
    #   Answers: guid will be for questions
    #   Comments & Attachments: guid could be of either question or section (or parent)
    retdictionary = {}
    for k, v in request.POST.iteritems():
        kparts = k.split('_', 1)
        if parseitem == kparts[0]:
            retdictionary[kparts[1]] = v

    # print parseitem + " @@@@ " + str(retdictionary)
    return retdictionary


# --------------------------------------------------------
# For Program - Section/Question Mgmt  (App questionnaire Mgmt)
# --------------------------------------------------------
# --------------------------------------------------------

def perparedisplayhtml(fulllist, filteredlist, cntr):

    # not used?
    # When required - replace genfilter with objListFilter

    ret = ""
    if None == filteredlist:
        #first time; Get all sections that are at root
        #   Step 1. Get all sections
        #   Step 2. Further filter to get objects without parent
        filteredlist = aaau.genfilter(fulllist, "cattype", "section")
        filteredlist = aaau.genfilter(filteredlist, "parentid", "")
        cntr = 0

    filteredlist = sorted(filteredlist, key=lambda QuestionnaireForDisplay: QuestionnaireForDisplay.displayseq)
    for qobj in filteredlist:
        if "question" == qobj.cattype:
            # is question
            if '' == qobj.parentid:
                ret += headerforquestion()

            cntr += 1
            ret += bodyforquestion(qobj, str(cntr))
            tlist = aaau.genfilter(fulllist, "parentid", qobj.id)
            if len(tlist) > 0:
                # sddcontainer --> fake class exclusively for sortable/drag-drop sub-questions
                ret += '<div class="list-group-item sddcontainer">'
                ret += perparedisplayhtml(fulllist, tlist, cntr)
                ret += "</div>"

            if '' == qobj.parentid:
                ret += footerforquestion()
        elif "section" == qobj.cattype:
            # is section
            cntr +=1
            ret += headerforsection(qobj, str(cntr))

            tlist = aaau.genfilter(fulllist, "qsectionid", qobj.id)  #questions within
            tlist = aaau.genfilter(tlist, "parentid", "")  # questions within; but no parent (Ignore sub-questions within the section)
            tlist.extend(aaau.genfilter(fulllist, "parentid", qobj.id))    # sub-section

            if len(tlist) > 0:
                ret += perparedisplayhtml(fulllist, tlist, cntr)

            ret += footerforsection()

    return ret

def headerforsection(q, c):
    # sddclass --> Fake class for    Sort + drag & drop
    ret = '<div class="panel panel-default sddclass" id="' + q.cattype + '_' + str(q.displayseq) + '_' + q.id + '" name="' + q.id + '">' \
          ' <div class="panel-heading">' \
          '     <span id="txt_' + q.id + '">  <b>' + q.text + '</b> </span>' \
          '     <a href="#hint_' + q.id + '" data-toggle="collapse"><span class="glyphicon glyphicon-info-sign"></span></a>' \
          '     <div id="hint_' + q.id + '" class="collapse small"><em>' + q.hint + '</em></div>' \
          '     <div class="small text-right">' \
          '         <ul class="list-inline">' \
          '             <li><button type="button" class="btn btn-info btn-xs" data-task="EditSection" data-uid="' + q.id + '">Edit</button></li>' \
          '             <li><button type="button" class="btn btn-info btn-xs" data-task="RemoveSection" data-uid="' + q.id + '">Remove</button></li>' \
          '             <li><button type="button" class="btn btn-info btn-xs" data-task="SubSection" data-uid="' + q.id + '">Add new sub-section</button></li>' \
          '             <li><button type="button" class="btn btn-info btn-xs" data-task="AddQuestion" data-uid="' + q.id + '">Add new question</button></li>' \
          '         </ul>' \
          '     </div>' \
          ' </div>' \
          ' <div class="panel-body sddcontainer">'
    return ret

def footerforsection():
    ret = ' </div>' \
          '</div>'
    return ret

def headerforquestion():
    ret = '<div class="list-group" >'
    return ret

def footerforquestion():
    ret = ' </div>'
    return ret

def bodyforquestion(q, c):
    # question_path = models.TextField()
    # question_required = models.IntegerField()
    # answer_data_type = models.CharField(max_length=30)
    # trigger_value = models.CharField(max_length=50)
    # sddclass --> Fake class for    Sort + drag & drop


    ret = '<div class="list-group-item list-group-item-info sddclass" id="' + q.cattype + '_' + str(q.displayseq) + '_' + q.id + '" name="' + q.id + '">' \
          '     <div>' \
          '         <span id="txt_' + q.id + '">' + q.text + '</span>' \
          '         <a href="#hint_' + q.id + '" data-toggle="collapse"><span class="glyphicon glyphicon-info-sign"></span></a>' \
          '         <div id="hint_' + q.id + '" class="collapse small"><em>' + q.hint + '</em></div> ' \
          '         <div class="form-group form-group-sm"> '\
          '             <label class="sr-only" for="{{ps.question_guid}}_ans">{{ps.question}}</label> '\
          '             {% if "boolean" == ps.answer_data_type %} '\
          '                  <input type="checkbox" id="{{ps.question_guid}}_ans" > '\
          '             {% elif "number" == ps.answer_data_type  or "url" == ps.answer_data_type %} '\
          '                 <input type="text" class="form-control" id="{{ps.question_guid}}_ans" value="{{ a.answer }}" > '\
          '             {% else %} '\
          '                 <textarea id="{{ps.question_guid}}_ans" spellcheck="true" class="form-control" >{{ a.answer }}</textarea> '\
          '             {% endif %} '\
          '         </div> '\
          '         <div id="' + q.id + '_com_main" class="collapse"> Note/Comment:' \
          '             <div id="' + q.id + '_com_div" class="form-group form-group-sm">'\
          '                 <label class="sr-only" for="' + q.id + '_com">Add a comment</label>'\
          '                 <textarea id="' + q.id + '_com" spellcheck="true" class="form-control" ></textarea>'\
          '             </div> '\
          '         </div> '\
          '         <div id="' + q.id + '_att_div" class="collapse">Attachments: <br></div> '\
          '         <div class="small text-right"> '\
          '             <ul class="list-inline"> '\
          '               <li><button type="button" class="btn btn-info btn-xs" data-task="comment" data-uid="' + q.id + '">Add note/comment?</button></li> '\
          '               <li><button type="button" class="btn btn-info btn-xs" data-task="attach" data-uid="' + q.id + '">Attach file?</button></li> '\
          '             </ul> '\
          '         </div> ' \
          '     </div> '\
          '</div> '

    # '             <li><button type="button" class="btn btn-info btn-xs" data-task="EditQuestion" data-uid="' + q.id + '">Edit</button></li> '\
    # '             <li><button type="button" class="btn btn-info btn-xs" data-task="RemoveQuestion" data-uid="' + q.id + '">Remove</button></li> '\
    # '             <li><button type="button" class="btn btn-info btn-xs" data-task="SubQuestion" data-uid="' + q.id + '">Add new sub-question</button></li> '\

    return ret
