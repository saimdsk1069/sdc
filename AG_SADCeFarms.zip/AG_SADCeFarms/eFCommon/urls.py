__author__ = 'OAXRAJA'

from django.conf.urls import patterns, url

urlpatterns = patterns('eFCommon.views',
                       # url(r'^/$', 'attach'),  # new or save request - should nuke this?
                       url(r'^attach/$', 'attachfile'),  # new or save request
                       url(r'^fetch/$', 'fetchfile'),   # get the requested
                       url(r'^delete/$', 'deletefile'),   # delete the requested
                       url(r'^byName/$', 'processRuleByName'),   # Process a rule, identified by its name
                       )
