import uuid

# Value extractor for Py-Json obj
def getobjbykey(pj, jkey):
    # json(py) value extractor 1 of 2: Parse keys
    ret = None

    jkeys = jkey.split(".")
    # print jkeys
    for k in jkeys:
        # print k
        ret = None  # reset the final result
        pj = getjsonobj(pj, k)
        # ret = []
        # ret.append(pj)
        ret = pj

    return ret

def getjsonobj(pyjs, ename):
    # json(py) value extractor 2 of 2: get json(py) object for the key
    ret = None

    if isinstance(pyjs, list):
        # print "is list and " + ename
        ret = []
        for item in pyjs:
            jsobj = getjsonobj(item, ename)
            if None != jsobj:
                if isinstance(jsobj, list):
                    # instead of keep as multiple sub array; put them all at the main array
                    for o in jsobj:
                        ret.append(o)
                else:
                    ret.append(jsobj)

    elif isinstance(pyjs, dict):
        # print "is dict and " + ename
        if ename in pyjs:
            # ret.append(pyjs[ename])
            ret = pyjs[ename]

    return ret

def roundtimetosec(intime):
    # not sure whether time is set in sec, millsec or microsec.
    # till that's figured out, go with this!
    return float(str(intime)[:10])

def getNewGUID():
    """Create a GUID"""
    # return '{' + str(uuid.uuid4()).upper() + '}'
    # no curly braces; no hyphens; - neither contribute to making this unique
    # not having hyphen, make it RFC4122 non-compliant?
    # return uuid.uuid4().hex.upper()
    # 1/19/2016 switched to py's default UUID4 (in lowercase & with hyphens)
    return uuid.uuid4()

def genfilter(alist, filterattr, filterval):
    # General filter for list or dictionary
    # Handle both list as well as dictionary
    ret = []
    for o in alist:
        if isinstance(o, dict):
            if o[filterattr] == filterval:
                ret.append(o)
        elif isinstance(alist, list):
            if o.filterattr == filterval:
                ret.append(o)

    return ret

def objListFilter (alist, filterattr, filterval):
    # filter list of objects by object's attribute & value

    if None == alist or len(alist) == 0:
        return []
    else:
        return [o for o in alist if getattr(o, filterattr) == filterval]
