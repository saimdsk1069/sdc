from django.shortcuts import render_to_response
from django.template import RequestContext
from django.http import HttpResponse, JsonResponse
from .models import AppDoc, CustomSQL, RuleDef
import utils as aaau
import json

def attachfile(request):
    retmsg = ""
    refID = None
    appID = None
    usr = request.efUsr

    if request.method == 'GET':
        # Open UI to attach file
        if "refID" in request.GET:
            refID = request.GET["refID"]
        if "appID" in request.GET:
            appID = request.GET["appID"]

        return render_to_response('common/attachfile.html', {"msg": retmsg, "refID": refID, "appID": appID}, context_instance= RequestContext(request))

    elif request.method == 'POST':
        aDoc = prepDocFromRequest(request, 'docfile')
        if aDoc:
            # todo - fix logic when integrating with farm directly
            # right now tailored exclusively for upload from questionnaire

            # Group id.
            # GroupID params when document uploaded as part of application questionnaire
            # DOCUMENT_ID_GUID --> GUID new or existing(multi docs to same question)
            # RELATED_TABLE --> Answer@<application id>
            # RELATED_TABLE_ID --> <question/section ID>
            if "refID" in request.POST:
                refID = request.POST["refID"]
            if "appID" in request.POST:
                appID = request.POST["appID"]

            # todo - User authorization check against the program app id

            if appID and refID:
                appID = 'Answer@' + appID
                pDocGrpIDList = list(AppDoc.objects.raw(aDoc.selectGrpID(), [appID, refID]))

                if pDocGrpIDList:
                    # If any, should be only one. if more than one, we got to have other issues
                    aDoc.doc_group_id = pDocGrpIDList[0].doc_group_id

                else:
                    aDoc.doc_group_id = aaau.getNewGUID()
                    dGrpInsSQL = aDoc.insertDocGrpSQL()
                    cs = CustomSQL()
                    cs.push(dGrpInsSQL, [aDoc.doc_group_id, appID, refID])

                aDoc.id = aaau.getNewGUID()
                aDoc.created_user = aaau.getobjbykey(usr, "user_guid")
                saveResp = False
                if aDoc.doc_group_id:
                    saveResp = aDoc.save(None)
                # else:  # New logic will avoid this for good
                #     aDoc.doc_group_id = aaau.getNewGUID()
                #     saveResp = aDoc.save([appID, refID])

                if saveResp:
                    docInfo = {"name": aDoc.doc_name, "id": str(aDoc.id), "groupid": str(aDoc.doc_group_id)}
                    retmsg = {"status": "Success", "info": docInfo}

        if "" == retmsg:
            docInfo = ""
            if aDoc:
                docInfo = {"name": aDoc.doc_name}
            retmsg = {"status": "Failed to save", "info": docInfo}

        return JsonResponse(retmsg)
        # return render_to_response('home/load.html', {"msg": retmsg, "refID": refID, "appID": appID}, context_instance= RequestContext(request))

def fetchfile(request):

    # get doc by its ID.
    # Get ACL on the doc. If public stream out
    # if restricted; go with user AA against the program app

    if request.method == 'GET':
        if "docID" in request.GET:
            fs = fetchDocById(request.GET["docID"])
            if None != fs:
                # todo - User authorization check
                # IS public - let it pass
                # otherwise - Is user SADC? --> let it pass; SADC staff allowed to read all
                #             If not --> application security should kick in
                if fs.is_public:
                    response = HttpResponse(fs.doc, content_type=fs.doc_content_type)
                    response['Content-Disposition'] = 'attachment; filename="%s"' % fs.doc_name

                    if None != fs.doc_size:
                        response['Content-Length'] = fs.doc_size
                        # print "filesize :" + fs.doc_size
                    return response

                else:
                    # based on the doc group id, get the question/application info
                    # application info --> apply ACL against pgm_milestone

                    # Doc security is still worked upon.
                    pass

    return JsonResponse({"msg": "Sorry! Error getting the requested file."})

def deletefile(request):
    # todo : got to create a soft delete option

    retMsg = {"status": "Sorry! Error deleting file."}
    if request.method == 'POST':
         if "docID" in request.POST:
            docid = request.POST["docID"]

            aDoc = AppDoc()
            # Get doc meta
            dList = list(AppDoc.objects.raw(aDoc.selectMetaSQL(False, False), [docid]))
            if dList:
                aDoc = dList[0]

                # todo:
                #   User authorization
                #       From doc group id, get app id.
                #       Get user's priv over the app and thus the doc
                #       If authorized go on to next step

                # if status = Incoming Ok to delete
                # if status = Review - archive as draft ???
                # if status = <others> - archive

                # delete
                cs = CustomSQL()
                if cs.push(aDoc.deleteDocSQL(), [aDoc.id]):
                    retMsg = {"status": "Success", "docID": docid}

    return JsonResponse(retMsg)

def prepDocFromRequest(request, paramName):
    ret = None
    # Build core doc object
    if paramName in request.FILES:
        docfile = request.FILES[paramName]
        ret = AppDoc()
        ret.doc_name = docfile.name
        ret.doc_size = str(docfile.size)
        ret.doc_content_type = docfile.content_type
        ret.doc = b''.join([chunk for chunk in docfile.chunks()])
        # 'b' or 'B'; they produce an instance of the bytes (byte array); but ignored in py 2x (required in 3x)

    # Add attributes
    # Never set ID or groupID here? # id,  doc_group_id
    if ret:
        ret.active = True
        ret.is_public = False

        if "doctypeID" in request.POST:
            ret.doc_type_id = request.POST["doctypeID"]
        # else:
        #     ret.doc_type = 'Unknown'

        if "docStatus" in request.POST:
            ret.doc_status = request.POST["docStatus"]
        else:
            ret.doc_status = 'Incoming'

    return ret

def fetchDocById(id):
    ret = None
    if id:
        ad = AppDoc()
        ad.id = id
        ret = ad.getDoc()
    return ret

def processRuleByName(request):
    # fetch the rule
    # if access == public --> Process
    # else --> authorize check

    retmsg = ""
    # ruleType
    #   == DROP_DOWN_VALUES: Do not save result. Package and return it in http response

    if "ruleName" in request.GET:
        rd = RuleDef()
        rdList = list(RuleDef.objects.raw(rd.selectByNameSQL(False), {"rname": request.GET["ruleName"]}))
        if len(rdList) == 1:
            rJsonObj = json.loads(rdList[0].rule_definition_json)

            # Post rule def: Step1:  Privilege check
            okToExecute = False
            if "access" in rJsonObj and "public" == rJsonObj["access"].lower():
                # Ok to proceed
                okToExecute = True
            else:
                # got to authorize
                pass

            if okToExecute:
                rresult = ""
                # Step2: Execute rule
                rresult = ruleProcessor(rJsonObj)

                # Step3: Process result
                # Parse into id:val dictionary?

                retmsg = {"status": "Success", "rule_result": rresult}
        else:
            # Houston we got a problem!!!!
            pass

    if "" == retmsg:
        retmsg = {"status": "Failed to process request"}

    return JsonResponse(retmsg)


def ruleProcessor(rjson):
    # Execute the rule. Already authorized, so proceed ..
    ret = None
    if "database query" == rjson["action"].lower():
        sqlStr = "select " + ', '.join(rjson["source_fields"]) + " from " + rjson["source_table"]
        ret = processDBRequest(sqlStr)
        if None == ret:
            ret = {"msg": "Sorry! Error getting the requested data."}

    elif 1 == 2:
        pass

    return ret

def processDBRequest(sqlStr):
    ret = "Error"
    if sqlStr:
        cs = CustomSQL()
        ret = cs.pull(sqlStr)
    return ret
