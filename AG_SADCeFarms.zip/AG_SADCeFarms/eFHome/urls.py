from django.conf.urls import patterns, url

print "In url home"
urlpatterns = patterns('eFHome.views',
                       url(r'^$', 'home'),  # eFarms' home page
                       url(r'^logout/$', 'logout_user'),
                       )
