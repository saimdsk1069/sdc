from django.shortcuts import render_to_response
from django.http import HttpResponse, HttpResponseRedirect
import AG_SADCeFarms.settings as s
from eFCommon import aaa, utils

def home(request):
    # Step 1: Get the list of UI objects available for the user
    # Menu items as well as Grid (channel) items;
    # Lazy load grid item's contents

    mItems = defaultPageItems(request.efUsr, "menu")
    gItems = defaultPageItems(request.efUsr, "grid")  # lazy load contents

    uname = ""
    fn = utils.getobjbykey(request.efUsr, "first_name")
    ln = utils.getobjbykey(request.efUsr, "last_name")
    if fn and ln:
        uname = fn + " " + ln

    return render_to_response('home/default.html',  {'uname': uname, 'menu': mItems, 'grid': gItems,'static_prefix': s.STATIC_URL})


def defaultPageItems(user, type):
    ret = None
    if "menu" == type:
        # ret = aaav.getMenuItemsForUsr(user)
        ret = aaa.getMenuDropDownsForUsr(user)

    elif "grid" == type:
        ret = aaa.getGridItemsForUsr(user)

    return ret

def logout_user(request):
     res = HttpResponseRedirect('/AG_SADCeFarms/home/')  # todo: generalize the path? Or will work all the time?
     res.delete_cookie('iPlanetDirectoryPro', '/', '.state.nj.us')
     return res