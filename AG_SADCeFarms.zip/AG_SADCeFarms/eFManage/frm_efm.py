
from django.forms import ModelForm
from .models import QuestionSection

class QSectionForm (ModelForm):
    class Meta:
        model = QuestionSection
        # fields = '__all__'
        fields =['section', 'hint', 'programname', 'programtype', 'parent_section']