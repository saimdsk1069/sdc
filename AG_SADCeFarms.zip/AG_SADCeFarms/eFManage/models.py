from django.db import models
from eFCommon.models import eFarmDBReader

# while using Manager.raw: you should properly escape any parameters that the user can control by
# using params in order to protect against SQL injection attacks.
# e.g. Person.objects.raw('SELECT * FROM myapp_person WHERE last_name = %s', [lname])
#
#   Warning: Do not use string formatting on raw queries!
#       It's tempting to write the above query as:
#       >>> query = 'SELECT * FROM myapp_person WHERE last_name = %s' % lname
#       >>> Person.objects.raw(query)
#       Don't!
#
# Using the params argument completely protects you from SQL injection attacks, a common exploit where attackers
# inject arbitrary SQL into your database. If you use string interpolation, sooner or later you'll fall victim to
# SQL injection. As long as you remember to always use the params argument you'll be protected.

# class ProgramName(models.Model):
#     program_name_id = models.AutoField(primary_key=True)
#     program_name = models.CharField(max_length=100)
#
#     class Meta:
#         db_table = 'program_name'
#         managed = False
#
#     def __str__(self):
#         return self.program_name


class QuestionSection(models.Model):
    section_id = models.CharField(max_length=36, primary_key=True)
    section = models.CharField(max_length=255)
    parent_section = models.CharField(max_length=36)
    section_sequence = models.IntegerField()
    auth_tier = models.CharField(max_length=3)
    hint = models.TextField(blank=True)
    pgm_milestone_guid = models.CharField(max_length=36)
    # program_type_id = models.IntegerField()
    # program_name_id = models.IntegerField()
    active = models.BooleanField()
    created_user = models.CharField(max_length=36, db_column="created_user_guid")
    created_date = models.DateTimeField()
    last_edited_user = models.CharField(max_length=36)
    last_edited_date = models.DateTimeField()
    objects = eFarmDBReader()

    class Meta:
        db_table = 'application_question_section'
        ordering = ['section_sequence']
        managed = False

    def inactivatesql(self):
        ret = "update application_question_section set " \
              " active = 0, last_edited_date = sysdate, last_edited_user = %s " \
              " where section_id = %s"
        return ret

    def insertsql(self):
        ret = ""
        if self.section_id:
            # SQL to get current record's sequence
            sseq = " select section_sequence as aa from application_question_section where section_id = %s "

        else:
            # Add request - Insert
            # Append to the existing group. Get the max seq, within the parent and assign the next number.
            sseq = "select (NVL (max(section_sequence), 0) + 1) as aa from application_question_section where parent_section = %s "
            if not self.parent_section:
                # got to handle both null or empty
                sseq += " or parent_section is NULL "

        # Insert the payload as a new record. Only diff between an edit & add request is the section sequence number.
        # If edit - reuse inactivated record's seq; If add - add to the end of the list, for the parent
        ret = "insert into application_question_section " \
                 " (section_id, section, parent_section, hint, pgm_milestone_guid, active, created_user_GUID, created_date," \
                 " last_edited_user, last_edited_date, section_sequence) values " \
                 " (%s, %s, %s, %s, %s, 1, %s, systimestamp, %s, systimestamp, " \
                 " (" + sseq + ") )"

        return ret

    def updateseq(self, reordercount):
        # attempting to update in single shot instead of multiple calls
        # UPDATE application_question_section
        #    SET section_sequence  = CASE section_id
        #                       WHEN '11523738-87ac-4053-86f0-4549df0f2cd1' THEN 1
        #                       WHEN '2228c29f-e597-415e-a00b-c4228570ac16' THEN 2
        #                       WHEN '5ec50f2d-aa17-4a20-a852-c9d2b26b565a' THEN 3
        #                       ELSE 1
        #                       END
        #  WHERE section_id IN('11523738-87ac-4053-86f0-4549df0f2cd1', '2228c29f-e597-415e-a00b-c4228570ac16', '5ec50f2d-aa17-4a20-a852-c9d2b26b565a');
        ret = "update application_question_section SET " \
              " last_edited_user = %s,  last_edited_date = systimestamp, " \
              " section_sequence = CASE section_id "

        inparams = " where section_id in ("

        # without to_char(%s) its failing at Oracle!
        for x in xrange(reordercount):
            ret += " WHEN to_char(%s) THEN %s "
            inparams += " %s,"

        inparams = inparams.rsplit(",", 1)[0] + ")"
        ret += " ELSE 1 END " + inparams

        return ret

    def __str__(self):
        return self.section

class Question (models.Model):
    question_guid = models.CharField(max_length=36, primary_key=True)
    question = models.TextField()
    section_id = models.CharField(max_length=36)
    parent_question_guid = models.CharField(max_length=36)
    answer_data_type = models.CharField(max_length=30)
    question_sequence = models.IntegerField()
    trigger_value = models.CharField(max_length=50)
    question_path = models.TextField()
    question_required = models.BooleanField()
    hint = models.TextField()
    created_user = models.CharField(max_length=36, db_column="created_user_guid")
    created_date = models.DateTimeField()
    last_edited_user = models.CharField(max_length=36)
    last_edited_date = models.DateTimeField()
    active = models.BooleanField()
    objects = eFarmDBReader()

    class Meta:
        db_table = 'application_question'
        managed = False
        ordering = ['question_sequence']

    def inactivatesql(self):
        ret = "update application_question set " \
              " active = 0, last_edited_date = sysdate, last_edited_user = %s " \
              " where question_guid = %s"
        return ret

    def insertsql(self):
        ret = ""
        if self.question_guid:
            # Edit request - Insert
            # Get current record's sequence
            sseq = " select question_sequence as aa from application_question where question_guid = %s "

            # Insert the payload as new record
            # Apply inactivated(current) record's sequence
            ret = "insert into application_question " \
                  " (question_guid, question, section_id, parent_question_guid, hint, question_required, answer_data_type, question_path," \
                  " trigger_value, created_user_GUID, created_date, last_edited_user, last_edited_date, active, question_sequence) values " \
                  " (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, systimestamp, %s, systimestamp, 1, " \
                  " (" + sseq + ") )"
        else:
            # Add request - Insert
            # Sequence - Append to a group (Section or Parent question). Get max seq, within the group and assign next number.
            sseq = "select (NVL (max(question_sequence), 0) + 1) as aa from application_question where "

            # Insert the payload as new record.
            # Only diff between an edit & add request should be the question sequence number.
            if self.parent_question_guid:
                # sub-question
                sseq += " parent_question_guid = %s "

                # Get section id from parent
                sidSql = " select section_id from application_question where question_guid = %s "

                ret = "insert into application_question " \
                      " (question_guid, question, section_id, parent_question_guid, hint, question_required, answer_data_type, question_path," \
                      " trigger_value, created_user_GUID, created_date, last_edited_user, last_edited_date, active, question_sequence) values " \
                      " (%s, %s, (" + sidSql + "), %s, %s, %s, %s, %s, %s, %s, systimestamp, %s, systimestamp, 1, " \
                      " (" + sseq + ") )"

            else:
                # question under a section
                sseq += " section_id = %s "
                ret = "insert into application_question " \
                      " (question_guid, question, section_id, parent_question_guid, hint, question_required, answer_data_type, question_path," \
                      " trigger_value, created_user_GUID, created_date, last_edited_user, last_edited_date, active, question_sequence) values " \
                      " (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, systimestamp, %s, systimestamp, 1, " \
                      " (" + sseq + ") )"

        return ret

    def updateseq(self, reordercount):
        # attempting to update in single shot instead of multiple calls
        ret = "update application_question SET " \
              " last_edited_user = %s,  last_edited_date = systimestamp, " \
              " question_sequence = CASE question_guid "

        inparams = " where question_guid in ("

        # without to_char(%s) its failing at Oracle!
        for x in xrange(reordercount):
            ret += " WHEN to_char(%s) THEN %s "
            inparams += " %s,"

        inparams = inparams.rsplit(",", 1)[0] + ")"
        ret += " ELSE 1 END " + inparams

        return ret

    def __str__(self):
        return self.question
