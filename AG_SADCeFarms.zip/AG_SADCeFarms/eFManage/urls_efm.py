from django.conf.urls import patterns, url

urlpatterns = patterns('eFManage.views',
                       # url(r'^overview/$', 'overview'),  # eFManage overview
                       url(r'^list/$', 'viewcontent'),
                       url(r'^edit/$', 'editcontent'),
                       url(r'reorder/$', 'reorderquestionnaire'),
                       url(r'^help/$', 'helpcontent'),
                       )
