import sys
import json

from django.http import JsonResponse
from django.views.decorators.http import require_safe, require_http_methods
from django.shortcuts import render_to_response
from django.template import RequestContext

from eFCommon.models import QuestionnaireForDisplay, CustomSQL, ProgramType, PgmMilestone
from eFCommon import utils as aaau
from .models import QuestionSection, Question

# @require_safe()

def helpcontent(request):
    return render_to_response('manage/questionHelp.html',
                              {}, context_instance=RequestContext(request)
                              )

def viewcontent(request):
    if request.method == 'GET':
        pn = None
        pt = None
        pid = None
        msid = None
        msphase = None
        mstype = None
        msstatus = None

        if 'pgmname' in request.GET:
            pn = request.GET['pgmname']

        if 'pgmtype' in request.GET:
            pt = request.GET['pgmtype']

        if 'programid' in request.GET:
            pid = request.GET['programid']

        if 'pgmmsid' in request.GET:
            msid = request.GET['pgmmsid']

        if 'pgmmsphase' in request.GET:
            msphase = request.GET['pgmmsphase']

        if 'pgmmstype' in request.GET:
            mstype = request.GET['pgmmstype']

        if 'pgmmsstatus' in request.GET:
            msstatus = request.GET['pgmmsstatus']

        qlistashtml = ""
        tlist = []
        mslist = []
        if None == pid:
            # get the list of program types & names
            pt = ProgramType()
            sqlStr = pt.selectsql()
            tlist = list(ProgramType.objects.raw(sqlStr))

            # tlist = list(ProgramType.objects.all())
            # return render_to_response('eFManage/prep_questions.html',
            #                           {'namelist': nlist, 'typelist': tlist,
            #                            'questionlist': qlist}, context_instance=RequestContext(request)
            #                           )

        else:
            pObj = ProgramType()
            pObj.program_type_guid = pid
            pObj.program_type = pt
            pObj.program_name = pn
            tlist.append(pObj)

            print "msid is=" + msid + "abc"

            if None == msid or "" == msid:
                # get the phases & milestones for a program
                pgmMSObj = PgmMilestone()
                paramDict = {"programid": pid}
                mslist = list(PgmMilestone.objects.raw(pgmMSObj.selectSQLByParams(paramDict), paramDict))
                # # nlist = {"program_name": pn}
                # # tlist = {"type": pt}
                # # resdata = {'namelist': [pn], 'typelist': [pt], 'questionlist': qlist}
                # # return JsonResponse(resdata)

            else:
                pgmMSObj = PgmMilestone()
                pgmMSObj.id = msid
                pgmMSObj.program_phase_name = msphase
                pgmMSObj.milestone_type = mstype
                pgmMSObj.status_type = msstatus
                mslist.append(pgmMSObj)

                # Get the sections & questions tied to the milestone
                qfd = QuestionnaireForDisplay()
                qlist = (list(QuestionnaireForDisplay.objects.raw(qfd.fetchByProgramMSId_SQL(True), {"msguid": msid})))
                if qlist:
                    qlistashtml = perparedisplayhtml(qlist, None, 0)
                else:
                    qlistashtml = "<div>No entry found for the program. Please start by adding a new section.</div>"

        return render_to_response('manage/prep_questions.html',
                                  {'programlist': tlist, 'pgmmilestonelist': mslist,
                                   'questionlist': qlistashtml}, context_instance=RequestContext(request)
                                  )

@require_http_methods(["GET", "POST"])
def editcontent(request):
    if request.method == 'GET':
        # Form for edit/add/..
        # loadURL = "../edit/?pgmname=" + $("#pgmname").val() + "&pgmtype=" + $("#pgmtype").val()";
        # case "AddSection":
        # case "SubSection":
        #     loadURL += "&mode=add&category=section&sectionid=" + $(this).data("uid")
        # case "EditSection":
        #     loadURL += "&mode=edit&category=section&sectionid=" + $(this).data("uid")
        # case "RemoveSection":
        #     loadURL += "&mode=remove&category=section&sectionid=" + $(this).data("uid")
        # case "AddQuestion":
        #     loadURL += "&mode=add&category=question&sectionid=" + $(this).data("uid")
        # case "SubQuestion":
        #     loadURL += "&mode=add&category=question&questionid=" + $(this).data("uid")
        # case "EditQuestion":
        #     loadURL += "&mode=edit&category=question&questionid=" + $(this).data("uid")
        # case "RemoveQuestion":
        #     loadURL += "&mode=remove&category=question&questionid=" + $(this).data("uid")
        # case "AddProgram":
        #     loadURL = "mode=add&category=program;
        # + "&pgmmsid=" + $("#pgmmsid").val();

        actiontype = None
        actioncategory = None
        if 'mode' in request.GET:
            actiontype = request.GET['mode'].lower()

        if 'category' in request.GET:
            actioncategory = request.GET['category'].lower()

        # todo - streamline; its a mess now. Fix it!
        if "section" == actioncategory:
            # mode == add
            #   section id - Yes: Request is to add a sub-section
            #   section id - No: Request is to add a section to root
            # mode == edit or remove --> must have section id; ideally thats the only thing required

            sid = ""
            if 'sectionid' in request.GET:
                sid = request.GET['sectionid']

            if "edit" == actiontype or "remove" == actiontype:
                qsObj = QuestionSection.objects.get(section_id=sid)
                return render_to_response('manage/question_section.html',
                                          {'qsObj': qsObj, 'category': actioncategory, 'mode': actiontype}, context_instance=RequestContext(request)
                                          )
            elif "add" == actiontype:
                # New Section - w/ or w/o  parent
                # pn = ""
                # pt = ""
                # if 'pgmname' in request.GET:
                #     pn = request.GET['pgmname']
                # if 'pgmtype' in request.GET:
                #     pt = request.GET['pgmtype']

                pmsid = ""
                if 'pgmmsid' in request.GET:
                    pmsid = request.GET['pgmmsid']

                if pmsid:  # Note: None or empty string evaluates to False
                    qsObj = QuestionSection()
                    qsObj.pgm_milestone_guid = pmsid
                    if sid:
                        qsObj.parent_section = sid

                    return render_to_response('manage/question_section.html',
                                              {'qsObj': qsObj, 'category': actioncategory, 'mode': actiontype}, context_instance=RequestContext(request)
                                              )
                else:
                    return render_to_response('home/error.html',
                                              {'errormsg': "Require program info"}, context_instance=RequestContext(request)
                                              )

        elif "question" == actioncategory.lower():
            # mode == add
            #   question id - Yes: Request is to add a sub-question
            #   question id - No: Request is to add a question to the section
            #                     Must have a section id
            # mode == edit or remove --> must have question id; ideally thats the only thing required

            qid = sid = ""
            if 'questionid' in request.GET:
                qid = request.GET['questionid']

            if "edit" == actiontype or "remove" == actiontype:
                qObj = Question.objects.get(question_guid=qid)
                return render_to_response('manage/question.html',
                                          {'qObj': qObj, 'category': actioncategory, 'mode': actiontype}, context_instance=RequestContext(request)
                                          )
            elif "add" == actiontype:
                if 'sectionid' in request.GET:
                    sid = request.GET['sectionid']

                qObj = Question()

                if qid:
                    qObj.parent_question_guid = qid
                if sid:
                    qObj.section_id = sid

                # For testing:
                # qObj.trigger_value = "abc"
                # qObj.question_required = 1
                # qObj.answer_data_type = "url"

                return render_to_response('manage/question.html',
                                          {'qObj': qObj, 'category': actioncategory, 'mode': actiontype}, context_instance=RequestContext(request)
                                          )
        # Disable adding new program - it is more involved: Pgm sub type & then milestone, permission on MS, ...
        # May be in a future phase
        # elif "program" == actioncategory.lower():
        #         return render_to_response('manage/program.html',
        #                                   {'category': actioncategory, 'mode': actiontype}, context_instance=RequestContext(request)
        #                                   )

    elif request.method == 'POST':
        # Save
        resdata = {'status': "Success/Failure msg"}
        if 'category' in request.POST:
            usr = request.efUsr
            uid = aaau.getobjbykey(usr, "user.id")

            # Disable adding new program - it is more involved: Pgm sub type & then milestone, permission on MS, ...
            # May be in a future phase
            # if 'program' == request.POST['category']:
            #     # Payload
            #     #   programid is empty --> Add new program
            #     #   programid NOT empty
            #     #       --> pgmname & pgmtype empty --> Archive/inactivate
            #     try:
            #         pObj = ProgramType()
            #         pObj.program_name = request.POST['pgmname']
            #         pObj.program_type = request.POST['pgmtype']
            #         pObj.program_type_guid = request.POST['programid']
            #
            #         # print "pObj.program_name  = "+ pObj.program_name
            #         # print "pObj.program_type  = "+ pObj.program_type
            #
            #         resdata = {'status': "Failed! Invalid request."}
            #         cs = CustomSQL()
            #         if pObj.program_type_guid:
            #             if "" == pObj.program_name and "" == pObj.program_type:
            #                 # make it inactive
            #                 # updsql = pObj.inactivatesql()
            #                 # cs.push(updsql, [uid, pObj.program_type_id])
            #                 # resdata = {'status': "Success"}
            #                 pass
            #
            #         elif pObj.program_name and pObj.program_type:
            #             inssql = pObj.insertsql()
            #             cs.push(inssql, [aaau.getNewGUID(), pObj.program_type, pObj.program_name])
            #             resdata = {'status': "Success"}
            #
            #     except:
            #         print "eFManage.V.Editcontent.POST error:", sys.exc_info()[0]
            #         resdata = {'status': "Failed to save program info!"}
            #
            # el
            if 'section' == request.POST['category']:
                # Payload
                #   section_id is empty
                #       parentid is empty --> Add new section to root
                #       parentid NOT empty --> New Sub-section
                #   section_id NOT empty
                #       section is empty --> Remove section (inactivate)
                #       section NOT empty --> Update section (inactivate current and create new with the payload)
                # Never delete, once in production. Record may have FK ref to application/answers. The text should be
                # maintained as-is, forever

                try:
                    # Mandatory form elements; if any missing, something fishy; throw error
                    # pn = request.POST['pgmname']
                    # pt = request.POST['pgmtype']
                    # pid = request.POST['parentid']
                    # sec = request.POST['section'].strip()
                    # hint = request.POST['hint']
                    qsObj = QuestionSection()
                    # print qsObj.section_id
                    qsObj.section = request.POST['section'].strip()
                    qsObj.hint = request.POST['hint']
                    qsObj.parent_section = request.POST['parentid']
                    # qsObj.program_name_id = request.POST['pgmname']
                    qsObj.pgm_milestone_guid = request.POST['pgmmsid']

                    cs = CustomSQL()
                    if "sectionid" in request.POST:
                        qsObj.section_id = request.POST['sectionid']

                        if qsObj.section_id:
                            # Remove or Edit
                            updsql = qsObj.inactivatesql()
                            cs.push(updsql, [uid, qsObj.section_id])

                            if qsObj.section:
                                # Edit cont'd: proceed to insert with current section's sequence
                                inssql = qsObj.insertsql()
                                cs.push(inssql, [aaau.getNewGUID(), qsObj.section, qsObj.parent_section, qsObj.hint, qsObj.pgm_milestone_guid, uid, uid, qsObj.section_id])
                        else:
                            # Add new
                            inssql = qsObj.insertsql()
                            cs.push(inssql, [aaau.getNewGUID(), qsObj.section, qsObj.parent_section, qsObj.hint, qsObj.pgm_milestone_guid, uid, uid, qsObj.parent_section])

                        resdata = {'status': "Success"}

                    else:
                        resdata = {'status': "Failed! Invalid request."}

                except:
                    print "eFManage.V.Editcontent.POST error:", sys.exc_info()[0]
                    resdata = {'status': "Failed to save section info!"}

            elif 'question' == request.POST['category']:
                # Payload
                #   question_id is empty
                #       section_id present --> Add new question to section
                #       parentid present --> Add new sub-question (parentid trumps over sectionid)
                #   question_id NOT empty
                #       question is empty --> Remove question (inactivate)
                #       question NOT empty --> Update question (inactivate current and create new with the payload)
                # Never delete, once in production. Record may have FK ref to application/answers. The text should be
                # maintained as-is, forever
                resdata = {'status': "Failed! Invalid request."}

                try:
                    # Mandatory form elements; if any missing, something fishy; throw error
                    # Checkbox will come through only if selected.
                    qObj = Question()
                    qObj.question = request.POST['question'].strip()
                    qObj.hint = request.POST['hint']
                    qObj.parent_question_guid = request.POST['parentid']
                    qObj.section_id = request.POST['sectionid']
                    qObj.question_guid = request.POST['questionid']

                    if "answerrequired" in request.POST:
                        qObj.question_required = 1
                    else:
                        qObj.question_required = 0

                    qObj.trigger_value = ""
                    if "tvcheck" in request.POST:
                        qObj.trigger_value = request.POST['triggerval']

                    qObj.question_path = ""
                    if "anstype" in request.POST:
                        qObj.answer_data_type = request.POST['anstype']
                        if "url" == qObj.answer_data_type:
                            qObj.question_path = request.POST['qpath']
                    else:
                        qObj.answer_data_type = "text"

                    cs = CustomSQL()
                    if qObj.question_guid:
                        # Remove or Edit
                        #  -->  Archive the record
                        updsql = qObj.inactivatesql()
                        cs.push(updsql, [uid, qObj.question_guid])

                        if qObj.question:
                            # Edit cont'd: proceed to insert with current question's sequence
                            inssql = qObj.insertsql()
                            cs.push(inssql, [aaau.getNewGUID(), qObj.question, qObj.section_id, qObj.parent_question_guid, qObj.hint, qObj.question_required, qObj.answer_data_type,
                                             qObj.question_path, qObj.trigger_value, uid, uid, qObj.question_guid])

                        resdata = {'status': "Success"}

                    else:
                        # Add new
                        inssql = qObj.insertsql()
                        if qObj.parent_question_guid:
                            # Sub-question
                            # Section id --> glean from parent question
                            # Sequence id --> add to the bottom of the group (parent question)
                            cs.push(inssql, [aaau.getNewGUID(), qObj.question, qObj.parent_question_guid, qObj.parent_question_guid, qObj.hint, qObj.question_required, qObj.answer_data_type, qObj.question_path,
                                             qObj.trigger_value, uid, uid, qObj.parent_question_guid])
                            resdata = {'status': "Success"}

                        elif qObj.section_id:
                            # Direct under a section
                            # Section id --> from payload
                            # Sequence id --> add to the bottom of the group (section)
                            cs.push(inssql, [aaau.getNewGUID(), qObj.question, qObj.section_id, qObj.parent_question_guid, qObj.hint, qObj.question_required, qObj.answer_data_type, qObj.question_path,
                                             qObj.trigger_value, uid, uid, qObj.section_id])
                            resdata = {'status': "Success"}

                except:
                    print "eFManage.V.Editcontent.POST error:", sys.exc_info()[0]
                    resdata = {'status': "Failed to save section info!"}

        # let the calling app decide what to do next
        return JsonResponse(resdata)

def reorderquestionnaire(request):
    resdata = {'status': "Success/Failure msg"}
    if request.method == 'POST':
        try:
            usr = request.efUsr
            uid = aaau.getobjbykey(usr, "user.id")

            jsonpayload = json.loads(request.body)
            secList = []
            qusList = []

            for o in jsonpayload:
                if "section" == o['type']:
                    secList.append(o)
                elif "question" == o['type']:
                    qusList.append(o)

            if secList:
                print len(secList)
                updateseq(secList, "section", uid)

            if qusList:
                print len(qusList)
                updateseq(qusList, "question", uid)

            resdata = {'status': "Success"}

        except:
            print "eFManage.V.ReorderQuestionnaire.POST error:", sys.exc_info()
            resdata = {'status': "Failed to save section info!"}
    else:
        print "OOPs! Not a post"

    return JsonResponse(resdata)

def updateseq(itemList, qtype, uid):
    sqlstr = ""
    if "section" == qtype:
        qs = QuestionSection()
        sqlstr = qs.updateseq(len(itemList))

    elif "question" == qtype:
        q = Question()
        sqlstr = q.updateseq(len(itemList))

    paramlist1 = [uid]
    paramlist2 = []
    # item ["id"] = idArr[2];
    # item ["seq"] = i;
    # item ["type"] = idArr[0];
    for item in itemList:
        paramlist1.append(item["id"])
        paramlist1.append(item["seq"])
        paramlist2.append(item["id"])

    paramlist1.extend(paramlist2)

    cs = CustomSQL()
    cs.push(sqlstr, paramlist1)

    return

# todo: move the following to common
# todo: move after converting to JS based page; instead of py/template based
def perparedisplayhtml(fulllist, filteredlist, cntr):
    # todo move off here; take it to JS & CSS world in HTML page
    ret = ""
    if None == filteredlist:
        #first time; Get all sections that are at root
        #   Step 1. Get all sections
        #   Step 2. Further filter to get objects without parent
        filteredlist = aaau.objListFilter(fulllist, "cattype", "section")
        filteredlist = aaau.objListFilter(filteredlist, "parentid", "")
        cntr = 0

    filteredlist = sorted(filteredlist, key=lambda QuestionnaireForDisplay: QuestionnaireForDisplay.displayseq)
    for qobj in filteredlist:
        if "question" == qobj.cattype:
            # is question
            if '' == qobj.parentid:
                ret += headerforquestion()

            cntr += 1
            ret += bodyforquestion(qobj, str(cntr))
            tlist = aaau.objListFilter(fulllist, "parentid", qobj.id)
            if len(tlist) > 0:
                # sddcontainer --> fake class exclusively for sortable/drag-drop sub-questions
                ret += '<div class="list-group-item sddcontainer">'
                ret += perparedisplayhtml(fulllist, tlist, cntr)
                ret += "</div>"

            if '' == qobj.parentid:
                ret += footerforquestion()
        elif "section" == qobj.cattype:
            # is section
            cntr +=1
            ret += headerforsection(qobj, str(cntr))

            tlist = aaau.objListFilter(fulllist, "qsectionid", qobj.id)  #questions within
            tlist = aaau.objListFilter(tlist, "parentid", "")  # questions within; but no parent (Ignore sub-questions within the section)
            tlist.extend(aaau.objListFilter(fulllist, "parentid", qobj.id))    # sub-section

            if len(tlist) > 0:
                ret += perparedisplayhtml(fulllist, tlist, cntr)

            ret += footerforsection()

    return ret

def headerforsection(q, c):
    # sddclass --> Fake class for    Sort + drag & drop
    ret = '<div class="panel panel-default sddclass" id="' + q.cattype + '_' + str(q.displayseq) + '_' + q.id + '" name="' + q.id + '">' \
          ' <div class="panel-heading">' \
          '     <span id="txt_' + q.id + '">  <b>' + q.text + '</b> </span>' \
          '     <a href="#hint_' + q.id + '" data-toggle="collapse"><span class="glyphicon glyphicon-info-sign"></span></a>' \
          '     <div id="hint_' + q.id + '" class="collapse small"><em>' + q.hint + '</em></div>' \
          '     <div class="small text-right">' \
          '         <ul class="list-inline">' \
          '             <li><button type="button" class="btn btn-info btn-xs" data-task="EditSection" data-uid="' + q.id + '">Edit</button></li>' \
          '             <li><button type="button" class="btn btn-info btn-xs" data-task="RemoveSection" data-uid="' + q.id + '">Remove</button></li>' \
          '             <li><button type="button" class="btn btn-info btn-xs" data-task="SubSection" data-uid="' + q.id + '">Add new sub-section</button></li>' \
          '             <li><button type="button" class="btn btn-info btn-xs" data-task="AddQuestion" data-uid="' + q.id + '">Add new question</button></li>' \
          '         </ul>' \
          '     </div>' \
          ' </div>' \
          ' <div class="panel-body sddcontainer">'
    return ret

def footerforsection():
    ret = ' </div>' \
          '</div>'
    return ret

def headerforquestion():
    ret = '<div class="list-group" >'
    return ret

def footerforquestion():
    ret = ' </div>'
    return ret

def bodyforquestion(q, c):
    # question_path = models.TextField()
    # question_required = models.IntegerField()
    # answer_data_type = models.CharField(max_length=30)
    # trigger_value = models.CharField(max_length=50)
    # sddclass --> Fake class for    Sort + drag & drop
    ret = '<div class="list-group-item list-group-item-info sddclass" id="' + q.cattype + '_' + str(q.displayseq) + '_' + q.id + '" name="' + q.id + '">' \
          '     <div>' \
          '         <span id="txt_' + q.id + '">' + q.text + '</span>' \
          '         <a href="#hint_' + q.id + '" data-toggle="collapse"><span class="glyphicon glyphicon-info-sign"></span></a>' \
          '         <div id="hint_' + q.id + '" class="collapse small"><em>' + q.hint + '</em></div> '\
          '         <div class="small text-right"> '\
          '             <ul class="list-inline"> '\
          '             <li><button type="button" class="btn btn-info btn-xs" data-task="EditQuestion" data-uid="' + q.id + '">Edit</button></li> '\
          '             <li><button type="button" class="btn btn-info btn-xs" data-task="RemoveQuestion" data-uid="' + q.id + '">Remove</button></li> '\
          '             <li><button type="button" class="btn btn-info btn-xs" data-task="SubQuestion" data-uid="' + q.id + '">Add new sub-question</button></li> '\
          '             </ul> '\
          '         </div> ' \
          '     </div> '\
          '</div> '
    return ret
