from django.conf.urls import patterns, url
urlpatterns = patterns('eFPlanning.views',
                       url(r'^home/$', 'home'),  # redirect to eFarms' home page
                       # url(r'^overview/$', 'overview'),  # Planning overview/landing pg
                       # url(r'^details/$', 'details'),   # Planning document - view or should go with the following?
                       # url(r'^application/edit/$', 'sniffnroute'),   # Planning application/document - Edit & Save
                       # url(r'^application/review/$', 'reviewapplication'),   # Planning application/document - Review
                       # url(r'^application/$', 'sniffnroute', {"task": None}),   # Planning application - New (Default)
                       # url(r'^application/list/$', 'sniffnroute', {"task": "list"}),   # Planning application - New (Default)
                       url(r'^application/getapp/$', 'editApplication'),   # Planning application - New (Default)
                       url(r'^application/review/$', 'editApplication'),   # Planning application - review phase
                       url(r'^application/initMap/$', 'launchMapApp'),   # Planning application - review phase
                       url(r'^application/list/$', 'planningHome'),
                       )
