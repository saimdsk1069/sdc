import json
import sys

from django.shortcuts import render_to_response
from django.http import HttpResponseRedirect, HttpResponse, JsonResponse
from django.template import RequestContext

from eFCommon.aaa import filterUserCred
from eFCommon.commonprocs import getApplicationInfoByID, getAppAppInfoByPgmTypeAndPrtnr, getLatestApproved
from eFCommon.models import AppInfo, PgmPartner, PgmACL
from eFCommon import aaa, utils, mapIntegration
import eFCommon.processapp as pa
import bs_map.views as mv


def home(request):
    return HttpResponseRedirect('../home/')

def planningHome(request):
        # Get list of (existing) applications;
        #   Filter
        #       by program types (in this case planning)
        #       and user Tier type/group  (if multiple, first ask user to identify partner)
        #   Note: even for planning for same partner for same yr could have multiple application with different status
        #       e.g. Yr 2015 BUR could have a withdrawn and an active planning app
        # To edit or start new - check whether user is authorized based user role & WKFL_program_Control

        usr = request.efUsr
        prtnrDictArr = []
        yrD = []

        if request.method == 'GET':
            if 'partnerid' in request.GET:
                prtnr_guid = request.GET['partnerid']
                prtnr_name = request.GET['partnername']
                prtnrDictArr.append({'partnerid': prtnr_guid, 'partnername': prtnr_name})
                yrD = getPartnerAppYrList(usr, 'Planning', None,  prtnr_guid)
                return HttpResponse(JsonResponse({'datafeed': {'pInfo': prtnrDictArr, 'pYrs': yrD}}), content_type='application/json')

            else:
                # Get all available planning programs and thus partners user have access to

                # Step 1: Get all roles that have view perm over Planning programs
                pgmACL = PgmACL()
                sqlStr = pgmACL.selectSQLByParams(["programtype", "permissiontype"], "flexible")
                pgmACLlist = list(PgmACL.objects.raw(sqlStr, ["Planning", "View"]))

                # Step 2: Filter out the list based on user cred
                #      2a:  & get all partner types
                prtnrTypeList = {}
                if pgmACLlist:
                    uroles = utils.getobjbykey(usr, "roles")
                    aclIntDict = aaa.intersectUserCredAndPgmPerm(uroles, pgmACLlist)
                    aclIntList = aclIntDict["intPP"]  # program partner intersect
                    ucIntList = aclIntDict["intUC"]  # user cred intersect

                    # Get all unique partner types
                    # If intersect result have ANY for either program type or name; get all
                    # else stay with what is in the list
                    for p in aclIntList:
                        if p.program_type == "ANY" or p.program_name == "ANY":
                            prtnrTypeList["ANY"] = "ANY"
                            break
                        elif p.partner_type_guid:
                            prtnrTypeList[p.partner_type_guid] = p.partner_type

                    if "ANY" in prtnrTypeList:
                        # blow ANY out
                        # get all partner types from the original list
                        for p in pgmACLlist:
                            if p.partner_type_guid:
                                prtnrTypeList[p.partner_type_guid] = p.partner_type

                        del prtnrTypeList["ANY"]
                        ucIntList = []  # emptying out to allow any potential restriction in next step
                                        # e.g. SADC Staff w/ additional Bur Cnty priv, should get all partners

                # Step 3: Based on partner types in list, get all active partners
                if prtnrTypeList:
                    # todo: Could avoid next DB call under certain condition(s). For ease, go for it for now

                    # both section & question ids are pesent
                    filterReqList = []
                    filterParamList = []

                    pp = PgmPartner()
                    if len(prtnrTypeList) == 1:
                        filterParamList.append(tuple([prtnrTypeList.keys()[0], '20160405abc123']))
                        # single elem array to tuple conversion will introduce a comma that could throw
                        # sql engine/oracle off balance. Hence the random string as a 2nd elem
                    else:
                        filterParamList.append(tuple(prtnrTypeList.keys()))

                    filterReqList.append("partnertypeid-Multi")

                    prtnrIdList = []
                    if ucIntList:
                        # print "ucIntList is present"
                        for u in ucIntList:
                            if u["partner_guid"]:
                                prtnrIdList.append(u["partner_guid"])

                        if prtnrIdList:
                            if len(prtnrIdList) == 1:
                                prtnrIdList.append('20160405abc123')    # random string to prepare the array for tuple conversion
                                # single elem array to tuple will introduce a comma that could throw sql engine/oracle off balance

                            filterParamList.append(tuple(prtnrIdList))
                            filterReqList.append("partnerid-Multi")

                    ptnrSQL = pp.selectSQLByParams(filterReqList)

                    # ############################################################################################
                    # String format replace is done ONLY because the parameter values are from DB (UCRoles are from DB as well as ACL).
                    # Never user this method when parameter values are from HTTP feed
                    # ############################################################################################
                    ptnrSQL = ptnrSQL.format(*filterParamList)
                    ptnrList = list(PgmPartner.objects.raw(ptnrSQL))
                    if ptnrList:
                        for pr in ptnrList:
                            prtnrDictArr.append({"partnerid": pr.id, "partnername": pr.name})

                if len(prtnrDictArr) == 1:
                    # get all app yrs for the prtnr
                    #   Note: For a partner for same yr, they could have multiple applications but with different status
                    #       e.g. Yr 2015 BUR could have a withdrawn and an active planning app

                    yrD = getPartnerAppYrList(usr, 'Planning', None,  prtnrDictArr[0]['partnerid'])

            return render_to_response('planning/overview.html',
                                      {'datafeed': json.dumps({'pInfo': prtnrDictArr, 'pYrs': yrD})}, context_instance=RequestContext(request)
                                      )

def getPartnerAppYrList(usr, pgmType, pgmName, ptrID):
    yrDictArr = []

    usroles = utils.getobjbykey(usr, "roles")
    usroles = filterUserCred(usroles, "partner_guid", ptrID)

    if usroles:
        authObj = None

        # Get all applications from the partner on the program tyep
        appInfoList = getAppAppInfoByPgmTypeAndPrtnr(pgmType, None, ptrID, None)

        if appInfoList:
            pgmIdSet = set([p.programid for p in appInfoList])
            # Get the program id from the list; It is expected to be unique. If for any reason there diff pgm type ids, loop
            #  through & merge to get all pgmACLs. Ideally should never happen

            # Get Permission(s) for user by program id
            authDict = getProgramPermForUsr(usroles, False, 'flexible', ["programid"], [pgmIdSet.pop()]) # flexible --> inclusive search
            authObj = authDict["pgmACL"]
        else:
            # Partner may have no prev app; could be new to system
            authDict = getProgramPermForUsr(usroles, False, 'flexible', ["programtype"], [pgmType]) # flexible --> inclusive search
            authObj = authDict["pgmACL"]

        if authObj:
            # Presence of authObj prove user is authorized to view the app at least during one milestone, through its lifecycle
            yrDictArr = getPtrnrYrList(appInfoList)

            # Get all VIEW ACL Objs; If VIEW is ONLY for specific milestone - filter apps out accordingly
            viewOnlyACLs = utils.objListFilter(authObj, "perm_type", "View")
            # print "viewOnlyACLs : " + str(viewOnlyACLs)

            # Get all Edit ACL objs. If edit is for SEQ = 1, insert "Start/edit new app" to json response
            editList = utils.objListFilter(authObj, "perm_type", "Edit")
            # print "editList : " + str(editList)
            editList = utils.objListFilter(editList, "pgm_milestone_seq", 1)
            # print "editList post milestone seq filter : " + str(editList)

            if editList:
                if yrDictArr:
                    yrDictArr.insert(0, {'appid': -1, 'yr_st': "Start/edit new app"})
                else:
                    yrDictArr = [{'appid': -1, 'yr_st': "Start/edit new app"}]

    return yrDictArr

def getProgramPermForUsr(uroles, getHighestRanked, searchType, paramArr, valArr):
    # Get all User roles/permission for a program (/pgm milestone) by
    #   - Program type (& milestone)
    #   - User credentials
    #   Return obj to include all roles from user cred, that matched with the program/milestone
    # todo - generalize this proc ans sync with aaa.getUserAppPermForMap
    ret = {"pgmACL": None, "pgmUC": None}

    # Step 1: Get all roles that have any perm over specified program, based on the parameters specified
    pgmACL = PgmACL()
    sqlStr = pgmACL.selectSQLByParams(paramArr, searchType)   # mode defaults to strict
    pgmACLlist = list(PgmACL.objects.raw(sqlStr, valArr))
    # print "pgmACLlist count : " + str(len(pgmACLlist))
    # print "pgmACLlist : " + str(pgmACLlist)

    # Step 2: Filter out the list based on user cred
    if pgmACLlist:
        aclIntDict = aaa.intersectUserCredAndPgmPerm(uroles, pgmACLlist)
        aclIntList = aclIntDict["intPP"]  # program partner intersect
        # ucIntList = aclIntDict["intUC"]  # user cred intersect
        ret["pgmUC"] = aclIntDict["intUC"]  # user cred intersect

        # If at least one intersect ACL - user have some kind of access to the pgm type
        # If edit permission in pgm seq 1 (Initiate request - MS type &  Incoming - Status type)
        #   user authorized to start a new application of this pgm type

        if aclIntList:
            # print "aclIntList count : " + str(len(aclIntList))
            if len(aclIntList) > 1:
                # Sort by permission score/rank
                aclIntList = sorted(aclIntList, key=lambda PgmACL:PgmACL.perm_score, reverse=True)

            if getHighestRanked:  # If != None && == True
                # ret.append(aclIntList[0])
                ret["pgmACL"] = [aclIntList[0]]
            else:
                # ret = aclIntList
                ret["pgmACL"] = aclIntList

        # print "aclIntList : " + str(aclIntList)
    return ret

def getPtrnrYrList(aiList):
    retArr = []
    if aiList:
        for ai in aiList:
            # strftime('%Y-%m-%d')
            aiMeta = ai.appdate.strftime('%Y') + ' - ' + ai.status
            retArr.append({'appid': ai.id, 'yr_st': aiMeta})
    return retArr


def getresolutionbyappid(appid):
    # todo - everything!!
    return 'abc'

def terminateSession():
    ret = aaa.terminateSession()
    return render_to_response(ret, {})

def editApplication(request):
    # Start New, Edit, Append, ...
    # todo: make it generic & move to common func

    appmeta = None
    reqSection = None
    usr = request.efUsr

    if request.method == 'POST':
        # Save payload, if available and get next/first section
        # If new - create a new app and get first section
        prtnrID = None
        appID = None
        if "partnerid" in request.POST:
            prtnrID = request.POST['partnerid']
        if "appid" in request.POST:
            appID = request.POST['appid']

        if appID and "-1" != appID:
            appmeta = getApplicationInfoByID(request.POST['appid'])[0]  # todo not a safe call; what if it ret none. got to handle err gracefully
            # if prtnrID and prtnrID != appmeta.partnerid:
            #     # if the request accompanied partnerid, then it should match. In all normal cases, it will.
            #     # just to intercept rare cases
            #     # todo  throw error
            #     return

        else:
            # Make sure this is not a duplicate request. Planning, can have only one active application per yr.
            # If an active active application in incoming mode, open it instead of creating a new

            if prtnrID:
                pgmType = 'Planning'    # todo: make pgmType = 'Planning' global to this view
                # appmetaList = getAppAppInfoByPgmTypePrtnrAndDt(pgmType, prtnrID, pa.getNewPlanningAppYr())
                appmetaList = getAppAppInfoByPgmTypeAndPrtnr(pgmType, None, prtnrID, pa.getNewPlanningAppYr())

                if len(appmetaList) == 1:
                    appmeta = appmetaList[0]

                elif len(appmetaList) == 0:
                        appmeta = AppInfo()
                        appmeta.pgm_milestoneseq = 1
                        appmeta.partnerid = prtnrID
                        appmeta.programtype = pgmType
                else:
                    # todo : err handling & re-route
                    return

            else:   #  len(appmetaList) > 1: # should never happen
                # # todo : err handling & re-route
                return

        # todo : verify & externalize
        usroles = utils.getobjbykey(usr, "roles")
        usroles = filterUserCred(usroles, "partner_guid", appmeta.partnerid)
        # print "usroles: " + str(usroles)
        if usroles:

            if appmeta.id:
                # by app's current status as identified by pgm_milestone id
                pgmPermDict = getProgramPermForUsr(usroles, False, 'strict', ["programmilestoneid"], [appmeta.pgm_milestoneid])

            else:
                # By partner, program & pgm milestone seq (to start an app - step 1)
                # require programname? At least for planning need only type. For ACQ may need more????
                pgmPermDict = getProgramPermForUsr(usroles, False, 'strict', ["programmilestoneseq", "programtype"], [appmeta.pgm_milestoneseq, appmeta.programtype])
                # authList = pgmPermDict["pgmACL"]

            authList = pgmPermDict["pgmACL"]
            # print "pgmUC: " + str(pgmPermDict["pgmUC"])

            # todo - auth obj - make it pgmACL obj. that way the partner info is also available. to save & query app
            # todo : Doc/Comm privilege --> usrapppriv['ca_tier']
            # Append, Approve, Delete, Edit, Sign, Submit, View
            if authList:
                retfeed = {}
                status = "Error"

                #  todo - app specific filter:
                # applictaion is an instance of a program specific to partner/farm owner
                # pgmUCredList = pgmPermDict["pgmUC"]     # if authList, respective userCred obj(s) will be present.
                # from pgm level, drill down to app level
                # Purpose: Burlington county coordinator (bcc) & Camden county coordinator (ccc) both will have access to
                # any milestone within a planning application. This filter is to make sure bcc will get access only to burlington
                # app and ccc will get only for camden app.
                # e.g. Direct request to a ccc app (by id, without providing partner id) by bcc should result in error/session termination

                appUCredList = pgmPermDict["pgmUC"]  #  filter happened already while getting usroles. No need to repeat - filterUserCred(pgmPermDict["pgmUC"], "partner_guid", appmeta.partnerid)
                # print "appUCredList: " + str(appUCredList)
                if appUCredList:

                    # authList is sorted by perm_score. Highest score will be be on top
                    authPerm = [p.perm_type for p in authList]
                    usrapppriv = {'viewmode': authPerm[0]}
                    usrapppriv['ca_tier'] = 1   # todo address this: Doc/Comm privilege --> usrapppriv['ca_tier']

                    # print "authPerm: " + str(authPerm)
                    # Create new or Save payload, as applicable, if authorized
                    if '' == appmeta.id and 1 == appmeta.pgm_milestoneseq:
                        if 'Edit' in authPerm:
                            # start new app
                            authObj = [ao for ao in authList if ao.perm_type == 'Edit'][0]
                            appmeta.pgm_milestoneid = authObj.pgm_milestone_guid
                            appmeta.programid = authObj.program_type_guid
                            #     partner_type
                            #     partner_type_guid
                            newID = pa.startnewApplication(appmeta, utils.getobjbykey(usr, "user_guid"))

                            # consuming components expect complete appmeta info, so get from DB
                            appmeta = getApplicationInfoByID(newID)[0]
                            status = "Success"
                        else:
                            # throw 'not authorized' error
                            status = "Unauthorized"   # or warning msg?
                    elif appmeta.id:
                        # existing app
                        if set(authPerm).difference(['View']):
                            # got permission beyond view - May edit/append/sign/...
                            # Hence save payload, if any.
                            if ('initPgLoad' in request.POST) and ("false" == request.POST['initPgLoad']):
                                # Ignore save when payload is empty (at initial request of questionnaire page)
                                status = pa.appDataPush(request, appmeta, utils.getobjbykey(usr, "user_guid"), usrapppriv)
                            else:
                                status = "Success"
                        else:
                            # View only permission - Do not save while navigating through app
                            status = "Success"
                    else:
                        # Should never reach here
                        status = "Unauthorized"
                else:
                    status = "Unauthorized"

                # print "status: " + status
                # If all OK, read the questionnaire, along with answers (& others)
                if "Unauthorized" == status:
                    terminateSession()
                    return  # will the call reach here?

                elif "Success" == status:
                    reqSection = None
                    if "nextsection" in request.POST:
                        # Move on to requested section
                        reqSection = request.POST["nextsection"]

                    try:
                        retfeed = pa.questionnarie(appmeta, reqSection, usrapppriv['ca_tier'])
                    except:
                        print "Error @ editApplication - POST edit access ", sys.exc_info()
                        status = "Error"
                else:
                    status = "Error"

                retfeed["status"] = status
                if ('initPgLoad' in request.POST) and ("false" == request.POST['initPgLoad']):
                    return HttpResponse(JsonResponse(retfeed), content_type='application/json')

                else:
                    return render_to_response('common/questionnaire.html',
                                              {'datafeed': json.dumps(retfeed)},
                                              context_instance=RequestContext(request)
                                              )
            else:
                terminateSession()
                return  # will the call reach here?
        else:
            terminateSession()
            return  # will the call reach here?

    else:
       return render_to_response('error.html', {'errormsg': 'Sorry! Error processing information.'})

def launchMapApp(mapreq):
    # todo: eventually make it generic & move to common func

    appmetaList = getApplicationInfoByID(mapreq.GET['appID'])
    if len(appmetaList) == 1:
        appPriv = 'none'
        uName = utils.getobjbykey(mapreq.efUsr, "username")
        appmeta = appmetaList[0]

        # Step 1: Filter down user role(s) to those tied to the application in question
        usroles = utils.getobjbykey(mapreq.efUsr, "roles")
        usroles = filterUserCred(usroles, "partner_guid", appmeta.partnerid)
        prevAppId = None
        if usroles:
            # Step 2: Get user permission(s) based on app's program-milestone
            # todo: Give GISS Edit perm over any app under status types --> Incoming & Review ? Or at least during Review
            pgmPermDict = getProgramPermForUsr(usroles, False, 'strict', ["programmilestoneid"], [appmeta.pgm_milestoneid])
            authList = pgmPermDict["pgmACL"]
            appUCredList = pgmPermDict["pgmUC"]

            if authList and appUCredList:
                editList = utils.objListFilter(authList, "perm_type", "Edit")
                # print "editList: " + str(editList)
                if editList:
                    appPriv = 'edit'
                    gLAList = getLatestApproved(appmeta.partnerid, appmeta.programid)
                    # print "gLAList: " + str(gLAList)

                    if gLAList:
                        gLAList = sorted(gLAList, key=lambda AppInfo:AppInfo.appdate, reverse=True)
                        prevAppId = gLAList[0].id

                else:
                    appPriv = 'view'

        mapreq.cred = mapIntegration.credsForMapByApp(uName, appmeta, appPriv, prevAppId)

        #TODO: mapreq.layers =

        # print "mapreq.cred: " + str(mapreq.cred)

        return mv.bs_map_planning(mapreq)

    else:
        # if it didn't find any or found more than one - either way that is a problem
        return render_to_response('error.html', {'errormsg': 'Sorry! Error processing information.'})

def intersectPgmACLwithAppMS (app, pgmacl):
    # pgmacl will include all ACLs for for a specific PgmMilestone, as well as all global ACLs
    # e.g. SADC Committee member have access to an application in any program; but ONLY when the app is in
    # specific milestone_type & status_type combo(s).

    # Now achieved through DB flexible/strict query for PgmACL
    #   Pgm level queries --> flexible
    #   App level queries --> strict

    return

