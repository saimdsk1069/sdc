from rest_framework import serializers

from database.models import Layer

from django.core.exceptions import ValidationError
from rest_framework.renderers import JSONRenderer
from rest_framework.parsers import JSONParser

import json
import cgi


class LayerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Layer
        fields = (
            'layer_guid',
            'layer_title',
            'layer_id',
            'service_url',
            'service_type',
            'layer_description',
            'layer_info_json'
        )


