from django.conf.urls import url
import views

urlpatterns = [
    url(r'^applayers/(?P<appid>[A]{1}-[0-9]{3}-[0-9]{6})$', views.ApplicationLayers.as_view(), name="applayers"),
    url(r'^farmlayers/(?P<farmid>[F]{1}-[0-9]{6})$', views.FarmLayers.as_view(), name="farmlayers"),

    url(r'^map/application/(?P<appid>[A]{1}-[0-9]{3}-[0-9]{6})/(?P<servicepath>.*)$', views.appmapproxy),
    url(r'^map/farm/(?P<farmid>[F]{1}-[0-9]{6})/(?P<servicepath>.*)$', views.farmmapproxy)
    #url(r'^mapnote/application/(?P<appid>[A]{1}-[0-9]{3}-[0-9]{6})/(?P<servicepath>.*)$', views.appnoteproxy),
    #url(r'^mapnote/farm/(?P<farmid>[F]{1}-[0-9]{6})/(?P<servicepath>.*)$', views.farmnoteproxy)
]
