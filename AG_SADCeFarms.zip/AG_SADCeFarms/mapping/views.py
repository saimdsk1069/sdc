from AG_SADCeFarms import settings
from database.models import (Application,
                            ApplicationMap,
                            ApplicationPhaseMap,
                            ApplicationMapLayer,
                             Farm,
                             Layer,)
from .map_serializers import LayerSerializer


from common import Notifications
from django.http import Http404, HttpResponse, JsonResponse, HttpResponseForbidden
from django.core.exceptions import PermissionDenied, ObjectDoesNotExist, ValidationError
from django.middleware.csrf import get_token
from django.db import IntegrityError, connection, transaction
from django.db.models import Q
from django.contrib.contenttypes.models import ContentType
from django.apps import apps
from django.core import serializers
from django.http import QueryDict


from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView
from rest_framework.parsers import FormParser,JSONParser, FileUploadParser,MultiPartParser
from security import Authenticate


#
import logging
import traceback
import sys
import json
import requests
#import magic

import hashlib
from datetime import datetime
from collections import OrderedDict

logger = logging.getLogger(__name__)




'''
class Basemaps(APIView):
    """
        Get Basemaps for the Map
    """
    def get(self, request):
        #print request.data
        print 'BASEMAPS request'
        try:
            basemaps = Layer.objects.filter(layer_type="Basemap")
            print 'BASEMAPS:',basemaps
            serializer = LayerSerializer(basemaps, many=True)
        except Layer.DoesNotExist:
            print 'exception layers'
            raise Http404

        return Response(serializer.data)


class ReferenceLayers(APIView):
    """
        Get all Reference Layers for the Map
    """
    def get(self, request):
        #print request.data
        print 'Reference Layers request'
        try:
            reflayers = Layer.objects.filter(layer_type="Reference")
            print 'REFERENCE LYERS:',reflayers
            serializer = LayerSerializer(reflayers, many=True)
        except Layer.DoesNotExist:
            print 'exception layers'
            raise Http404

        return Response(serializer.data)
'''

class ApplicationLayers(APIView):
    """
        Get OperationalLayers for the Specific Application
    """
    def get(self, request, appid=None, format=None):
        applayers = {"mapedit":False,
                     "maps":[{"application_map_guid":"f63e22c1-d5ad-4063-ac38-8f7195dfe5a3","map_name":"Default","default_map_flg":True},
                             {"application_map_guid":"333333-d5ad-4063-ac38-8f7195dfe5a3","map_name":"Test 1","default_map_flg":False}],
                     "operationallayers":[],
                     "basemaplayers":[],
                     "imagerylayers":[],
                     "referencelayers":[],
                     "wms_server":settings.get_prop('WMS_SERVER'),
                     "geocodeservice":settings.get_prop('GEOCODE_SERVICE'),
                     "jsonservice": settings.get_prop('TOJSON_SERVICE')}
        try:
            if appid:
                appkey = int(str(appid).split('-')[2])
                app = Application.objects.get(application_key=appkey)

                # If user is not SADC, user can only delete their own notes
                cred = Authenticate.get_session_credentials(request)
                if not cred:
                    return Response({"result": "error", "message": "User not authenticated"}, status=status.HTTP_403_FORBIDDEN)
                if cred:
                    userguid = cred['user_guid']

                    sadcflg = Authenticate.get_user_sadc(request)

                    #TODO: Query for map edit permission
                    mapedit = True

                    #TODO: Query for operational layers
                    #oplayers = Layer.objects.filter(layer)

                    return JsonResponse(applayers, safe=False)
                    '''
                    print 'AppLayerRequest: ', program_application_guid
                    #TODO- Need to check for Application Guid and get current Program_Phase for current app
                    #TODO- Security convert user session Auth_User_Guid to active roles
                    #TODO- Query ProgramPhaseLayers objects using current phase guid and multiple active roles
                    #TODO- Check if user can edit/view map notes
                    mapnotesPriv = 'Edit'

                    oplayers = AppPhaseLayerRolePerm.objects.filter(application_phase_guid="15ab05b7-1492-45ba-96aa-00bcc235d85c")
                    opserializer = PhaseLayerSerializer(oplayers, many=True)

                    if mapnotesPriv:
                        notelayers = Layer.objects.filter(layer_type="Notes")
                        noteserializer = LayerSerializer(notelayers, many=True)
                        return Response({"oplayers": opserializer.data,
                                        "mapnotes":noteserializer.data, "mapnotes_priv": mapnotesPriv})
                    else:
                        return Response({"oplayers": opserializer.data,
                                        "mapnotes_priv": None})
                    '''

        except Layer.DoesNotExist:
            #print 'notes layers'
            logger.debug("notes layers")
            raise Http404




class FarmLayers(APIView):
    """
        Get OperationalLayers for the Farm
    """
    def get(self, request, farmid, format=None):
        farmlayers = {"mapedit":False,
                     "maps":[],
                     "operationallayers":[],
                     "basemaplayers":[],
                     "imagerylayers":[],
                     "referencelayers":[],
                     "wms_server":settings.get_prop('WMS_SERVER'),
                     "geocodeservice":settings.get_prop('GEOCODE_SERVICE'),
                     "jsonservice": settings.get_prop('TOJSON_SERVICE')}
        try:
            #print 'FARMID',farmid
            logger.debug("FARMID %s" % farmid)
            return JsonResponse(farmlayers, safe=False)

        except Layer.DoesNotExist:
            #print 'exception layers'
            logger.debug("exception layers")
            raise Http404

        #return Response(serializer.data)



##################################################################################################
#
#  Feature / Map Services Proxy
#
##################################################################################################

def proxy_view(request, url, requests_args=None):
    """
    Forward as close to an exact copy of the request as possible along to the
    given url.  Respond with as close to an exact copy of the resulting
    response as possible.
    If there are any additional arguments you wish to send to requests, put
    them in the requests_args dictionary.
    """
    requests_args = (requests_args or {}).copy()
    headers = get_headers(request.META)
    params = request.GET.copy()

    if 'headers' not in requests_args:
        requests_args['headers'] = {}
    if 'data' not in requests_args:
        requests_args['data'] = request.body
    if 'params' not in requests_args:
        requests_args['params'] = QueryDict('', mutable=True)

    # Overwrite any headers and params from the incoming request with explicitly
    # specified values for the requests library.
    headers.update(requests_args['headers'])
    params.update(requests_args['params'])

    # If there's a content-length header from Django, it's probably in all-caps
    # and requests might not notice it, so just remove it.
    for key in list(headers.keys()):
        if key.lower() == 'content-length':
            del headers[key]

    requests_args['headers'] = headers
    requests_args['params'] = params

    response = requests.request(request.method, url, **requests_args)

    proxy_response = HttpResponse(
        response.content,
        status=response.status_code)

    excluded_headers = set([
        # Hop-by-hop headers
        # ------------------
        # Certain response headers should NOT be just tunneled through.  These
        # are they.  For more info, see:
        # http://www.w3.org/Protocols/rfc2616/rfc2616-sec13.html#sec13.5.1
        'connection', 'keep-alive', 'proxy-authenticate',
        'proxy-authorization', 'te', 'trailers', 'transfer-encoding',
        'upgrade',

        # Although content-encoding is not listed among the hop-by-hop headers,
        # it can cause trouble as well.  Just let the server set the value as
        # it should be.
        'content-encoding',

        # Since the remote server may or may not have sent the content in the
        # same encoding as Django will, let Django worry about what the length
        # should be.
        'content-length',
    ])
    for key, value in response.headers.items():
        if key.lower() in excluded_headers:
            continue
        proxy_response[key] = value

    return proxy_response


def get_headers(environ):
    """
    Retrieve the HTTP headers from a WSGI environment dictionary.  See
    https://docs.djangoproject.com/en/dev/ref/request-response/#django.http.HttpRequest.META
    """
    headers = {}
    for key, value in environ.items():
        # Sometimes, things don't like when you send the requesting host through.
        if key.startswith('HTTP_') and key != 'HTTP_HOST':
            headers[key[5:].replace('_', '-')] = value
        elif key in ('CONTENT_TYPE', 'CONTENT_LENGTH'):
            headers[key.replace('_', '-')] = value

    return headers

def appmapproxy(request, appid,servicepath):
    logger.debug("APPID %s" % appid)
    #print 'APPID', appid
    #print 'PATH',servicepath
    logger.debug("PATH %s" % servicepath)

    extra_requests_args = {}
    remoteurl = settings.get_prop('AGS_TOKEN_SERVER') + '/' +  servicepath
    return proxy_view(request, remoteurl, extra_requests_args)


def farmmapproxy(request, farmid,servicepath):
    #print 'FARMID',farmid
    logger.debug ("FARMID %s " % farmid)
    #print 'PATH',servicepath
    logger.debug("PATH %s" % servicepath)
    extra_requests_args = {}
    remoteurl = settings.get_prop('AGS_TOKEN_SERVER') + '/' +  servicepath
    return proxy_view(request, remoteurl, extra_requests_args)
