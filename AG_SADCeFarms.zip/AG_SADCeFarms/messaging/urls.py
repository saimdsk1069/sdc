from django.conf.urls import url

from . import views

urlpatterns = [
    url(r'^messaging/slackbot_handler/', views.slackbot_handler, name='slackbot_handler'),
]