import logging
import json
from django.shortcuts import get_object_or_404, render
from django.http import HttpResponse
from django.views.decorators.http import require_http_methods
from AG_SADCeFarms import settings
from slackclient import SlackClient

@require_http_methods(["POST"])
def slackbot_handler(request):

    params = dict.fromkeys(['method', 'username', 'text', 'channel', 'parse', 'icon_emoji', 'mrkdwn', 'attachments'])

    for param in params:
        if request.POST.get(param):
            params[param] =  request.POST.get(param)

    sc = SlackClient(settings.slackbot_token)


    #sc.api_call("chat.postMessage", channel="#random", text="Hello from Python messaging app! :tada:", username='farmbot', icon_emoji=':robot_face:')
    sc.api_call(params['method'], channel = params['channel'], text = params['text'], username = params['username'], icon_emoji = params['icon_emoji'], mrkdwn = params['mrkdwn'])

    return HttpResponse('true')