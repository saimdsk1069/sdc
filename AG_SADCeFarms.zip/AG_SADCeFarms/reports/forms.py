from django import forms
#from bootstrap3_datetime.widgets import DateTimePicker
# https://github.com/nkunihiko/django-bootstrap3-datetimepicker

# class SearchForm(forms.Form):
#     address = forms.CharField(label='Address', max_length=100)

# choice_cnt = (('',''),
#               ('BURLINGTON', 'Burlington'),
#               ('MERCER', 'Mercer'),)
#
# choice_mun = (('',''),
#               ('TRENTON', 'Trenton'),
#               ('HAMILTON TOWNSHIP', 'Hamilton Township'),)
#
# choice_zip = (('',''),
#               ('12345', '12345'),
#               ('23456', '23456'),)

class SearchForm(forms.Form):
    SADC_GUID = forms.CharField(
        label = 'SADC_GUID (The unique ID of the farm)',
        required = False,
        widget=forms.TextInput(attrs={"class": "form-control"}))

    ADDRESS = forms.CharField(
        required = False,
        widget=forms.TextInput(attrs={"class": "form-control"}))
    '''
        PRESERVED_DATE_after = forms.DateField(
            required=False,
            label='Preserved On or After',
            widget=DateTimePicker(options={"format": "YYYY-MM-DD HH:mm",
                                           "pickTime": True,
                                           "pickSeconds": False}))

    PRESERVED_DATE_before = forms.DateTimeField(
        required=False,
        label='Preserved On or Before',
        widget=DateTimePicker(options={"format": "YYYY-MM-DD HH:mm",
                                       "pickTime": True,
                                       "pickSeconds": False}))
    '''
    # county = forms.ChoiceField(
    #     required = False,
    #     choices=choice_cnt)

    # municipality = forms.ChoiceField(
    #     required = False,
    #     choices=choice_mun)

    # zip = forms.ChoiceField(
    #     label = 'Zip Code',
    #     required = False,
    #     choices=choice_zip)

    def __init__(self, *args, **kwargs):
        if len(kwargs)>0:
            extra = kwargs.pop('extra')
            super(SearchForm, self).__init__(*args, **kwargs)
            for i, question in enumerate(extra):
                for k, v in question.iteritems():
                    self.fields[k] = v