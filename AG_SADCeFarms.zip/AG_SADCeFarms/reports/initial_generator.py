import json
import random
from common import util
import logging

logger = logging.getLogger(__name__)



print util.calcGUID()


farm_number = 10
parcel_per_farm = 3

FARM = []
FARM_PARCEL = []

CNT_OPT = ['MERCER', 'BURLINGTON', 'CAMDEN']
MUN_OPT = ['TRENTON', 'HAMILTON TOWNSHIP', 'LAWRENCEVILLE']

ij = 0
for i in range(farm_number):
    guid = util.calcGUID()
    # create a farm
    FARM.append(
        { 'model': 'reports.Farm',
          'pk': i,
          'fields':{
            'SADC_GUID': guid,
            'ADDRESS': str(random.randint(1,1000)) + ' Main Street',
            #'CITY': 'East Bumble',
            #'ZIP': '09987',
            'PARENT_GUID': None,
            'ACTIVE_PROGRAM_GUID': None,
            'PARTNER_GUID': None,
            'EASEMENT_HOLDER_GUID': None,
            'PRESERVED_PROGRAM_GUID': None,
            'PRESERVED_DATE': '{0}-01-21'.format(random.randint(1970,2016)),
            'PRESERVED_ACRES': random.randint(1, 100),
            'PAID_ACRES': random.randint(1, 100),
            'FEDERAL_FUNDING': 0,
            #'PRIMARY_COUNTY': CNT_OPT[random.randint(0,len(CNT_OPT)-1)],
            #'PRIMARY_MUNI': MUN_OPT[random.randint(0,len(MUN_OPT)-1)],
						'MUNI_CODE': '0101',
						'MUNI_CODE_ORIGINAL': '0101',
            'NON_CONTIGUOUS_PARCELS': random.randint(0,1),
            'RESTRICTION_GUID': None}
        })
    for ii in range(parcel_per_farm):
        # create parcels
        FARM_PARCEL.append({
            'model': 'reports.FARM_PARCELX',
            'pk': ij,
            'fields':{
            'PARCEL_GUID': util.calcGUID(),
            'SADC_GUIDX': guid,
            'COUNTY': CNT_OPT[random.randint(0,len(CNT_OPT)-1)],
            'MUNICIPALITY': MUN_OPT[random.randint(0,len(MUN_OPT)-1)],
            'BLOCK': random.randint(1,100),
            'LOT': random.randint(1,100),
            'PAMS_PIN': random.randint(1,100),
            'ACRES_GROSS': random.randint(1,100),
            'ACRES_NET': random.randint(1,100),
            'ACRES_PAID': random.randint(1,100),
            'PARCEL_PUBLISH_DATE': '2016-01-21',
            'CREATED_USER': 'createduser',
            'CREATED_DATE': '2016-01-21',
            'LAST_EDITED_USER': 'lastediteduser',
            'LAST_EDITED_DATE': '2016-01-21'
            }
        })
        ij += 1



#print FARM + FARM_PARCEL
logger.debug("Farm %s and farm parcel %s" % FARM, FARM_PARCEL)
dictout = FARM + FARM_PARCEL

with open(r'C:\Users\oaxfarr\Documents\web\eFarms\reports\fixtures\initial_data.json', 'w') as f:
    json.dump(dictout, f)