from __future__ import unicode_literals
from django.db import models


class Farm(models.Model):
    sadc_guid = models.CharField(primary_key=True, max_length=36)
    address = models.CharField(max_length=1000, blank=True, null=True)
    parent_guid = models.CharField(max_length=36, blank=True, null=True)
    active_program_guid = models.CharField(max_length=36, blank=True, null=True)
    partner_guid = models.CharField(max_length=36, blank=True, null=True)
    easement_holder_guid = models.CharField(max_length=36, blank=True, null=True)
    preserved_program_guid = models.CharField(max_length=36, blank=True, null=True)
    preserved_date = models.DateField(blank=True, null=True)
    preserved_acres = models.IntegerField(blank=True, null=True)
    paid_acres = models.IntegerField(blank=True, null=True)
    federal_funding_involved = models.BigIntegerField(blank=True, null=True)
    non_contiguous_parcels = models.BigIntegerField(blank=True, null=True)
    #restriction_guid = models.ForeignKey('Restriction', db_column='restriction_guid', blank=True, null=True)
    created_date = models.DateField(blank=True, null=True)
    created_user = models.CharField(max_length=36, blank=True, null=True)
    last_edited_date = models.DateField(blank=True, null=True)
    last_edited_user = models.CharField(max_length=36, blank=True, null=True)
    muni_code = models.ForeignKey('Municipality', db_column='muni_code', blank=True, null=True)
    muni_code_original = models.CharField(max_length=4, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'farm'

class FarmParcel(models.Model):
    parcel_guid = models.CharField(primary_key=True, max_length=36)
    pcl_block = models.CharField(max_length=10, blank=True, null=True)
    pcl_lot = models.CharField(max_length=10, blank=True, null=True)
    pams_pin = models.CharField(max_length=100, blank=True, null=True)
    acres_gross = models.DecimalField(max_digits=38, decimal_places=4, blank=True, null=True)
    acres_net = models.DecimalField(max_digits=38, decimal_places=4, blank=True, null=True)
    acres_paid = models.DecimalField(max_digits=38, decimal_places=4, blank=True, null=True)
    parcel_publish_date = models.DateField(blank=True, null=True)
    sadc_guid = models.ForeignKey(Farm, db_column='sadc_guid')
    oid = models.BigIntegerField(unique=True, blank=True, null=True)
    shape = models.TextField(blank=True, null=True)  # This field type is a guess.
    created_user = models.CharField(max_length=40, blank=True, null=True)
    created_date = models.DateField(blank=True, null=True)
    last_edited_user = models.CharField(max_length=50, blank=True, null=True)
    last_edited_date = models.DateField(blank=True, null=True)
    pclqcode = models.CharField(max_length=11, blank=True, null=True)
    idn_gis = models.BigIntegerField(blank=True, null=True)
    muni_code = models.ForeignKey('Municipality', db_column='muni_code', blank=True, null=True)
    muni_code_original = models.CharField(max_length=4, blank=True, null=True)
    calc_acre = models.DecimalField(max_digits=38, decimal_places=4, blank=True, null=True)
    pcl_guid = models.CharField(max_length=38, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'farm_parcel'

class Municipality(models.Model):
    muni_code = models.CharField(primary_key=True, max_length=4)
    name = models.CharField(max_length=50, blank=True, null=True)
    gnis_name = models.CharField(max_length=50, blank=True, null=True)
    gnis = models.CharField(max_length=8, blank=True, null=True)
    active = models.BigIntegerField(blank=True, null=True)
    county = models.CharField(max_length=20, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'municipality'

# class FARMX(models.Model):
#     SADC_GUIDX = models.CharField(max_length=36, primary_key=True)
#     ADDRESS = models.CharField(max_length=1000, null=True, blank=True)
#     CITY = models.CharField(max_length=1000, null=True, blank=True)
#     ZIP = models.CharField(max_length=5, null=True, blank=True)
#     PARENT_GUID = models.CharField(max_length=36, null=True, blank=True)
#     ACTIVE_PROGRAM_GUID = models.CharField(max_length=36, null=True, blank=True)
#     PARTNER_GUID = models.CharField(max_length=36, null=True, blank=True)
#     EASEMENT_HOLDER_GUID = models.CharField(max_length=36, null=True, blank=True)
#     PRESERVED_PROGRAM_GUID = models.CharField(max_length=36, null=True, blank=True)
#     PRESERVED_DATE = models.DateTimeField('date preserved', null=True, blank=True)
#     PRESERVED_ACRES = models.DecimalField(max_digits=10, decimal_places=4, null=True, blank=True)
#     PAID_ACRES = models.DecimalField(max_digits=10, decimal_places=4, null=True, blank=True)
#     FEDERAL_FUNDING = models.NullBooleanField(null=True, blank=True)
#     PRIMARY_COUNTY = models.CharField(max_length=200, null=True, blank=True)
#     PRIMARY_MUNI = models.CharField(max_length=200, null=True, blank=True)
#     NON_CONTIGUOUS_PARCELS = models.NullBooleanField(null=True, blank=True)
#     RESTRICTION_GUID = models.CharField(max_length=36, null=True, blank=True)
#
# class FARM_PARCELX(models.Model):
#     PARCEL_GUID = models.CharField(max_length=36, primary_key=True)
#     SADC_GUIDX = models.ForeignKey(FARMX, on_delete=models.CASCADE)
#     COUNTY = models.CharField(max_length=200, null=True, blank=True)
#     MUNICIPALITY = models.CharField(max_length=200, null=True, blank=True)
#     BLOCK = models.CharField(max_length=10, null=True, blank=True)
#     LOT = models.CharField(max_length=10, null=True, blank=True)
#     PAMS_PIN = models.CharField(max_length=100, null=True, blank=True)
#     ACRES_GROSS = models.DecimalField(max_digits=10, decimal_places=4, null=True, blank=True)
#     ACRES_NET = models.DecimalField(max_digits=10, decimal_places=4, null=True, blank=True)
#     ACRES_PAID = models.DecimalField(max_digits=10, decimal_places=4, null=True, blank=True)
#     PARCEL_PUBLISH_DATE = models.DateTimeField('parcel publish date', null=True, blank=True)
#     CREATED_USER = models.CharField(max_length=100, null=True, blank=True)
#     CREATED_DATE = models.DateTimeField('created date', null=True, blank=True)
#     LAST_EDITED_USER = models.CharField(max_length=100, null=True, blank=True)
#     LAST_EDITED_DATE = models.DateTimeField('last edited date', null=True, blank=True)


