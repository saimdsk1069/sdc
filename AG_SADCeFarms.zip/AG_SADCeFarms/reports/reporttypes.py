


reportlist = {"fiscal1":{"id":"fiscal1", "type":"Fiscal", "name":"FY Summary by Program-Fund","title":"Fiscal Year Summary By Program and Fund"},
               "fiscal2":{"id":"fiscal2", "type":"Fiscal", "name":"Preserved Summary","title":"Summary of Preserved Farms"},
               "fiscal3":{"id":"fiscal3", "type":"Fiscal", "name":"Preserved List","title":"Listing of Preserved Farms"},
               "fiscal4":{"id":"fiscal4", "type":"Fiscal", "name":"Pending Summary","title":"Summary of Farms Pending Preservation"},
               "fiscal5":{"id":"fiscal5", "type":"Fiscal", "name":"Pending List", "title":"Listing of Farms Pending Preservation"},
               "fiscal6":{"id":"fiscal6", "type":"Fiscal", "name":"County PIG Funding Status", "title":"County PIG Funding Status"},
               "fiscal7":{"id":"fiscal7", "type":"Fiscal", "name":"County PIG Program Status", "title":"County PIG Program Status"},
               "fiscal8":{"id":"fiscal8", "type":"Fiscal", "name":"Highlands Preservation Funds", "title":"Highlands Preservation Funds"},
               "acq1":{"id":"acq1", "type":"Acquisition", "name":"State Acquisition Tracking and Funding", "title":"State Acquisition Tracking and Funding"},
               "acq2":{"id":"acq2", "type":"Acquisition", "name":"Project Manager Work Tracking", "title":"Project Manager Work Tracking"},
               "acq3":{"id":"acq3", "type":"Acquisition", "name":"Active/Inactive Project Stats", "title":"Active and Inactive Project Stats"},
               "acq4":{"id":"acq4", "type":"Acquisition", "name":"Fiscal Year Final Approval & Closing","title":"Fiscal Year Final Approval & Closing"},
               "acq5":{"id":"acq5", "type":"Acquisition", "name":"8 Year Program","title":"8 Year Program Stats"},
               "stew1":{"id":"stew1", "type":"Stewardship", "name":"Monitoring Visits","title":"Stewardship- Listing of Monitoring Visits"},
               "stew2":{"id":"stew2", "type":"Stewardship", "name":"Monitoring Visits Summary", "title":"Stewardship- Summary of Monitoring Visits"},
                "plan1":{"id":"plan1", "type":"Planning", "name":"Planning Report Type", "title":"Planning Reports"}
              }



