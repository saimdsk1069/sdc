from django.core.context_processors import csrf
import operator
import csv
from django.shortcuts import get_object_or_404, render
from django import forms
from django.db.models import Q
import logging
logger = logging.getLogger(__name__)
from django.core.urlresolvers import reverse
from django.http import HttpResponse
from django.shortcuts import render_to_response

from AG_SADCeFarms import settings
from .models import Farm
from .forms import SearchForm
from OGIS_Python.OGIS_Common.emailHandler.mail import Email
from reports import reporttypes


def emailer(request):

    eM = Email('appmail.state.nj.us')
    recipients = ['edward.farrell@oit.nj.gov']
    eM.send( recipients, 'Django Test', 'Message')
    return HttpResponse('Email Success')

def form_builder(*datadict):

    farmheader = Farm._meta.get_fields(include_parents=False)

    choice_cnt = [('','')]
    choice_mun = [('','')]
    choice_zip = [('','')]
    choice_farmfields = [('','')]


    cnt_qs = Farm.objects.values_list('muni_code').distinct().order_by('muni_code')
    mun_qs = Farm.objects.values_list('muni_code').distinct().order_by('muni_code')
    zip_qs = Farm.objects.values_list('muni_code').distinct().order_by('muni_code')

    for v in cnt_qs:
        choice_cnt.append((v[0], v[0].capitalize()))
    for v in mun_qs:
        choice_mun.append((v[0], v[0].capitalize()))
    for v in zip_qs:
        choice_zip.append((v[0], v[0].capitalize()))
    for v in farmheader:
        choice_farmfields.append((v, v))

    PRIMARY_COUNTY = forms.ChoiceField(
        label='County',
        required = False,
        choices=choice_cnt)
    PRIMARY_MUNI = forms.ChoiceField(
        label = 'Municipality',
        required = False,
        choices=choice_mun)
    ZIP = forms.ChoiceField(
        label = 'Zip Code',
        required = False,
        choices=choice_zip)
    FarmFields = forms.MultipleChoiceField(
        label='Fields to Summarize',
        required=False,
        widget=forms.CheckboxSelectMultiple,
        choices=choice_farmfields)

    if datadict:
        form = SearchForm(initial=datadict, extra=[{'PRIMARY_COUNTY': PRIMARY_COUNTY},
                            {'PRIMARY_MUNI': PRIMARY_MUNI},
                            {'ZIP': ZIP}])
    else:
        form = SearchForm(extra=[{'PRIMARY_COUNTY': PRIMARY_COUNTY},
                            {'PRIMARY_MUNI': PRIMARY_MUNI},
                            {'ZIP': ZIP},
                            {'FarmFields': FarmFields}])

    return form

def index(request):
    form = form_builder()
    """context = {
        'form': form,
        'project_name': settings.project_name
    }
    """

    #TODO: Need to apply logic that will filter report types from reportlist based on user roles
    reportsref = {'Fiscal':[],'Acquisition':[],'Stewardship':[],'Planning':[]}
    for k,v in reporttypes.reportlist.iteritems():
        try:
            reportsref[v['type']].append(v)
        except:
            pass
    context = {
        "reportsref": reportsref
    }

    # return HttpResponse(template.render(context, request))
    return render(request, 'reports/index.html', context)


def repfilter(request):
    form = form_builder()

    reptype = ''
    reptype = request.GET['repid']
    try:
        reptitle = reporttypes.reportlist[reptype]['title']
    except:
        reptitle = ''
    context = {"report":reptype,
               "title": reptitle,
               "form":form,
               "project_name": settings.project_name}

    return render_to_response('reports/filterbase.html', context)


def search(request):
    # if this is a POST request we need to process the form data
    if request.method == 'POST':
        cd = request.POST
        q_lookup = {
            'SADC_GUID': 'exact',
            'ADDRESS': 'contains',
            'PRESERVED_DATE_after': 'gte',
            'PRESERVED_DATE_before': 'lte',
            'PRIMARY_COUNTY': 'exact',
            'PRIMARY_MUNI': 'exact',
            'ZIP': 'exact'
        }
        q_list = []
        for k,v in cd.iteritems():
            if k in q_lookup.keys() and v:
                kstrip = k.strip('_after').strip('_before')
                q_list.append((kstrip + '__' + q_lookup[k], v))

        Qlist = [Q(x) for x in q_list]
        if Qlist:
            farm_query = Farm.objects.values().filter(reduce(operator.and_, Qlist))
        else:
            farm_query = Farm.objects.values().all()



        farmheader = Farm._meta.get_fields(include_parents=False)
        #farmheader = list(farm_query)[0].keys()

        return render(request, 'reports/search.html', {
            'tableheaders': farmheader,
            'queryoutput': list(farm_query),
            'static_prefix': settings.get_prop('STATIC_PREFIX')
        })

    # if a GET (or any other method) we'll create a blank form
    else:
        form = form_builder()

    return render(request, 'reports/search.html', {'form': form})

def csvdownload(request):
    # logger.debug("XXXXXXXXXXXXXXXXXXXXXX {0}".format(request.POST))
    # Create the HttpResponse object with the appropriate CSV header.
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="somefilename.csv"'

    writer = csv.writer(response)
    writer.writerow(['First row', 'Foo', 'Bar', 'Baz'])
    writer.writerow(['Second row', 'A', 'B', 'C', '"Testing"', "Here's a quote"])

    return response




    #
    # return render(request, 'reports/search.html', {'form': form})

# def search(request):
#     # if this is a POST request we need to process the form data
#     if request.method == 'POST':
#         # create a form instance and populate it with data from the request:
#         # form = SearchForm(request.POST)
#         form = form_builder(request.POST)
#
#
#         # check whether it's valid:
#         if form.is_valid():
#             cd = request.POST
#
#             q_lookup = {
#                 'SADC_GUID': '',
#                 'ADDRESS': 'contains'
#             }
#
#             q_list = []
#             for k,v in cd.iteritems():
#                 if k in q_lookup.keys() and v:
#                     q_list.append((k + '__' + q_lookup[k], v))
#
#             Qlist = [Q(x) for x in q_list]
#             farm_query = FARM.object.filter(reduce(operator.and_, Qlist))
#
#
#             # process the data in form.cleaned_data as required
#             # ...
#             # redirect to a new URL:
#             # return HttpResponseRedirect('/search/')
#             return render(request, 'reports/search.html', {
#                 'queryoutput': cd,
#                 'other': request.POST
#             })
#
#     # if a GET (or any other method) we'll create a blank form
#     else:
#         form = form_builder()
#
#     return render(request, 'reports/search.html', {'form': form})