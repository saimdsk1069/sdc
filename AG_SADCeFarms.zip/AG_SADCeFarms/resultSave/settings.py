import os
import json

mapprops = "/opt/djangoappsconfig/props/OGIS_AGS.props"


def get_mapstuff():
    with open(mapprops) as f:
        mapinfo = json.loads(f.read())
    return mapinfo
