import logging
import json
from django.shortcuts import get_object_or_404, render
from django.http import HttpResponse
from django.views.decorators.http import require_http_methods
from AG_SADCeFarms import settings as basesettings
from django.views.decorators.csrf import csrf_exempt
import settings as mapsettings
import requests

@require_http_methods(["GET", "POST"])
@csrf_exempt
# Create your views here.

def save(request):
    '''
    This view will handle the writing of features data to the AGS feature services. It will look for a JSON object in the request body that should contain the following:
    -[layer] (the feature layer to be updated)- reference props file for layer url information)
    -[applicationid]  (the current application id that the features are associated with)
    -[deletes]  (the OIDs of the existing features to be deleted)
    -[adds]  (the geometries of the features to be created)


    VALIDATIONS:
    -Is user credential allowed to edit?
    -->On this application ID?
    -->On this layer?
    -->Are deletes valid? (Check for nefarious OID > 1, etc)
    -->Are adds valid?

    Were features successfully updated on the feature service? Y/N

    -Responses (False, True)
    '''
    baseurl = basesettings.get_prop('AGS_TOKEN_SERVER')
    mapstuff = mapsettings.get_mapstuff()
    baseurl = "http://geodata.state.nj.us"

    if request.method == 'POST':
        cd = json.loads(request.body)
        layername = cd['layer'].upper() # 'PROJECT_AREAS

        responsedata = {}
        valid = True
        # Check if layer is listed in features
        layerinfo = mapstuff['FEATURES'].get(layername,False)
        data = ""
        if layerinfo:
            featserviceurl = '/'.join([baseurl,layerinfo['url'],'applyEdits'])
            try:
                print cd['adds']
                headers = {'content-type': 'application/json'}
                response = requests.post(featserviceurl,  data={'adds':str(cd['adds']),'deletes': str(cd['deletes']),'f':'pjson'})
                data = json.loads(response.content)
                print 'Success!'




        #print featserviceurl
        #print mapstuff['FEATURES']
        #print 'Received save request data!'
        #print cd['adds'][0]['attributes']
                return HttpResponse({'true':data})
            except Exception as e:
                print 'Exception!'
                print e
                return HttpResponse({'false':e})