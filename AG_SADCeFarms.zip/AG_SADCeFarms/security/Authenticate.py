from django.http import HttpResponse, HttpResponseRedirect
from django.core.exceptions import ObjectDoesNotExist
from database.models import AuthUserSadc, AuthRoleSadc, AuthUiComponent, AuthUiPermission
import NJSSO
import OGISMessages
import admin_authAdmin.AGSTokenRequestor as AGST
from AG_SADCeFarms import settings
import logging
import copy
import datetime

logger = logging.getLogger(__name__)

def get_session_credential(request):
    #print "%%%%SESSION EXPIRING IN", request.session.get_expiry(),"SECONDS."
    logger.debug("SESSION EXPIRING IN %s SECONDS" % request.session.get_expiry())
    user_credential = request.session.get('USER_CREDENTIAL', None)
    return user_credential

class PublicAuthenticatedRoleInfo:
    """
        Class to retrieve guid for public and authenticated roles.
    """
    def __init__(self):
        try:
            # Get guid for PUBLIC and AUTHENTICATED ROLES
            self.public_guid = AuthRoleSadc.objects.get(auth_role_name='PUBLIC').auth_role_guid
            logger.debug("Retrieved GUID for Public role: %s" % self.public_guid)
        except ObjectDoesNotExist:
            logger.debug("*** Error retrieving GUID for PUBLIC role during init method of RequestSecurityProcessor middleware.")
            self.init_ok = False
            self.init_message = "An error occurred while starting the application."
        try:
            self.authenticated_guid = AuthRoleSadc.objects.get(auth_role_name='AUTHENTICATED USER').auth_role_guid
            logger.debug("Retrieved GUID for Authenticated role: %s" % self.authenticated_guid)
        except ObjectDoesNotExist:
            logger.debug("*** Error retrieving GUID for AUTHENTICATED role during init method of RequestSecurityProcessor middleware.")
            self.init_ok = False
            self.init_message = "An error occurred while starting the application."

    def get_public_guid(self):
        return self.public_guid

    def get_authenticated_guid(self):
        return self.authenticated_guid

# Initalize the values for public role guid and authenticated role guid for subsequent function calls
PUBAUTHROLEINFO = PublicAuthenticatedRoleInfo()

def get_ui_component_access(user_roles):
    """
    Take a list of user_roles and determine the ui components that they have access to.

    :param user_roles: - list of AuthRoleSadcs
    :return: list of ui component names for access in client app
    """
    auth_ui_comp_access = []
    try:
        aup = AuthUiPermission.objects.filter(auth_role_guid__in=user_roles)
        for ui_perm in aup:
            auth_ui_comp_access.append(ui_perm.auth_ui_component_guid.auth_ui_component_name)
    except Exception as e:
        logger.debug("Error retrieving ui permissions:", e)
    # Remove dups by converting to set and back to list
    return list(set(auth_ui_comp_access))

def build_public_credential(message, mynj):
    """
    Build a credential object with only Public Role assigned.

    :param message: - message to be retured in the credential
    :return:
    """
    # cred_dict = { "status": "", "message": "",  "username": "", "roles": [] }
    cred_dict = {}
    cred_dict['status'] = "NOT AUTHENTICATED"
    cred_dict['message'] = message
    if mynj:
        cred_dict['mynj'] = settings.get_prop('MYNJ_HOST')+settings.get_prop('MYNJ_APP_REDIRECT_URL')
    else:
        cred_dict['mynj'] = ''
    cred_dict['roles'] = [{
                    "role_name": 'PUBLIC',
                    "role_guid": PUBAUTHROLEINFO.get_public_guid(),
                    "county_code": '',
                    "county": '',
                    "municipality_code": '',
                    "municipality": '',
                    "tier_desc": 'PUBLIC',
                    "tier_group_desc": '',
                    "tier_subgroup_desc": '',
                    "partner_guid": '',
                    "partner_name": '',
                    "partner_type_desc": '' }]
    return cred_dict

def get_authenticated_role_info():
    """
    Return role information for a user that is authenticated.  This will be built upon by other roles that the
    user may have.

    :return:
    """
    return {
        "role_name": 'AUTHENTICATED USER',
        "role_guid": PUBAUTHROLEINFO.get_authenticated_guid(),
        "county_code": '',
        "county": '',
        "municipality_code": '',
        "municipality": '',
        "tier_desc": 'AUTHENTICATED USER',
        "tier_group_desc": '',
        "tier_subgroup_desc": '',
        "partner_guid": '',
        "partner_name": '',
        "partner_type_desc": ''
    }

def get_session_credentials(request):
    # just return what is stored in the session.  If session is invalid, return None
    return request.session.get('USER_CREDENTIAL', None)

def get_session_username(request):
    cred = request.session.get('USER_CREDENTIAL', None)
    if cred is not None:
        return cred['username']
    else:
        return None

def get_session_roles(request):
    cred = request.session.get('USER_CREDENTIAL', None)
    if cred is not None:
        return cred['roles']
    else:
        return None

def get_user_sadc(request):
    cred = request.session.get('USER_CREDENTIAL', None)
    if cred is not None:
        sadcflag = False
        for role in cred['roles']:
            if role["tier_desc"] in ["SADC STAFF","SADC MANAGEMENT"]:
                sadcflag = True

        return sadcflag
    else:
        return None

def get_credentials(request):
    # Get myNewJersey Portal url
    mynjurl = settings.get_prop('MYNJ_HOST')
    # Get application support email address
    support_email = settings.get_prop('AG_SUPPORT_EMAIL')
    # Define return dictionary
    cred_dict = { "status": "", "message": "",  "username": "", "roles": [] }

    # logger.debug("SETTING SESSION TIMEOUT TO %i" % int(settings.get_prop('SESSION_TIMEOUT')) )
    # request.session.set_expiry( int(settings.get_prop('SESSION_TIMEOUT')) )
    roleName = settings.get_prop('APPROLE')
    appID = settings.get_prop('APPID')
    #
    user_credential = request.session.get('USER_CREDENTIAL', None)
    if user_credential is not None:
        logger.debug("%%SESSION IS STILL VALID")
        return user_credential
    else:
        logger.debug("%%SESSION IS NOT VALID")
    #
    # Validate that user is logged into portal and has the role associated with the application
    #
    #------------------------------PORTAL CHECK --------------------------------------------------------------------
    if settings.get_platform() == 'DEVELOPMENT':
        logger.debug("On Development Platform")
        if eval(settings.get_prop('AUTH_DISABLE_PORTAL_CHECK')):
            logger.debug("***Portal Authentication Check is Disabled!!!!")
            portal_user_key = settings.get_prop('AUTH_ADMIN_USER')
            if eval(settings.get_prop('AUTH_ADMIN_AUTHENTICATED')): # Fake authenticated
                portalLoginStatus = OGISMessages.msg['PORTAL_USER_IS_ROLE_MEMBER']
            else:
                portalLoginStatus = OGISMessages.msg["PORTAL_SESSION_NOT_VALID"]  # Fake not authenticated
        else:
            logger.debug('Validating portal user with role %s and appID %s' % ( roleName, appID  ) )
            portalLoginStatus, portal_user_key = NJSSO.validatePortalUser( request, roleName, appID )
            logger.debug( "Portal Login Status: %s" % portalLoginStatus )
            logger.debug( "Portal User Keys: %s" % str(portal_user_key) )
    else: # Not on development platform
        # Validate portal user.  Only returns portal_user_key if portal login is valid and user key is set
        logger.debug('Validating portal user with role %s and appID %s' % ( roleName, appID  ) )
        portalLoginStatus, portal_user_key = NJSSO.validatePortalUser( request, roleName, appID )
        logger.debug( "Portal Login Status: %s" % portalLoginStatus )
        logger.debug( "Portal User Keys: %s" % str(portal_user_key) )
    #---------------------------------------------------------------------------------------------------------------
    if portalLoginStatus == OGISMessages.msg["PORTAL_SESSION_NOT_VALID"]:
        logger.debug("Portal Session Not valid")
        #
        # TODO?????? Return a response that provides the portal url to redirect to
        #
        request.session['USER_CREDENTIAL'] = None
        return build_public_credential('You do not have a valid myNewJersey session. Please log into the myNewJersey Portal.',mynj=True)
    elif portalLoginStatus == OGISMessages.msg['PORTAL_USER_IS_ROLE_MEMBER']:
        try:
            theUser = AuthUserSadc.objects.get(auth_user_name=portal_user_key)
            # Make sure they are not deactivated
            if theUser.auth_user_status_desc.auth_user_status_sadc_desc != 'Registered':
                logger.debug("USER %s HAS ROLE BUT USER IS NOT REGISTERED" % portal_user_key)
                request.session['USER_CREDENTIAL'] = None
                return build_public_credential("You are not registered to use this application. Please contact " +
                    support_email + " for assistance.", mynj=False)
        except ObjectDoesNotExist:
            logger.debug("USER %s HAS ROLE, NO ENTRY IN USER DATABASE" % portal_user_key)
            request.session['USER_CREDENTIAL'] = None
            return build_public_credential("You have not been granted access to this application. Please contact " +
                    support_email + " for assistance.", mynj=False)
        logger.debug( "PASSED USER CHECK" )

        #
        # Get portal user's roles and include them in the response, unless portal_user_key
        # is not defined.
        #
        logger.debug("FROM PORTAL REQUEST: PORTAL USER KEYS: %s" % portal_user_key )
        role_list = []
        role_list.append(get_authenticated_role_info())
        try:
            user_roles = theUser.role.filter(active_flg=1)
            cred_dict['ui_access'] = get_ui_component_access(user_roles)
            # if len(user_roles) != 0:
            #     cred_dict['ui_components'] = get_ui_component_access(user_roles)
            for role in user_roles:
                new_role = role.auth_role_name
                role_guid = role.auth_role_guid
                if role.county_code is not None:
                    county_code = role.county_code.county_code
                    county = role.county_code.county_name
                else:
                    county_code = ''
                    county = ''
                if role.muni_code is not None:
                    muni_code = role.muni_code.muni_code
                    muni = role.muni_code.name
                else:
                    muni_code = ''
                    muni = ''
                if role.tier_desc is not None:
                    tier_desc = role.tier_desc
                else:
                    tier_desc = ''
                if role.tier_group_desc is not None:
                    tier_group_desc = role.tier_group_desc
                else:
                    tier_group_desc = ''
                if role.tier_subgroup_desc is not None:
                    tier_subgroup_desc = role.tier_subgroup_desc
                else:
                    tier_subgroup_desc = ''
                if role.partner_guid is not None:
                    partner_guid = role.partner_guid.partner_guid
                    partner_name = role.partner_guid.partner_name
                    partner_type_desc = role.partner_guid.partner_type_desc.partner_type_desc
                else:
                    partner_guid = ''
                    partner_name = ''
                    partner_type_desc = ''

                #print "USER's ROLE:", new_role
                role_list.append( {
                    "role_name": new_role,
                    "role_guid": role_guid,
                    "county_code": county_code,
                    "county": county,
                    "municipality_code": muni_code,
                    "municipality": muni,
                    "tier_desc": tier_desc,
                    "tier_group_desc": tier_group_desc,
                    "tier_subgroup_desc": tier_subgroup_desc,
                    "partner_guid": partner_guid,
                    "partner_name": partner_name,
                    "partner_type_desc": partner_type_desc })
        except Exception as e:
            logger.debug("Error getting user's roles for credential object.")
        cred_dict['status'] = "AUTHENTICATED"
        cred_dict['message'] = "VALID APPLICATION USER", portal_user_key
        cred_dict['username'] = portal_user_key
        cred_dict['first_name'] = theUser.first_name
        cred_dict['last_name'] = theUser.last_name
        cred_dict['user_guid'] = theUser.auth_user_guid
        cred_dict['roles'] = copy.copy(role_list)
        logger.debug("CREDENTIALS:")
        logger.debug(cred_dict)
        # Save credential to session
        # Set the session timeout
        session_timeout_minutes = int(settings.get_prop('SESSION_TIMEOUT'))
        logger.debug(">>>SESSION TIMEOUT SET TO: %i" % session_timeout_minutes )
        expire_time = datetime.timedelta(minutes=session_timeout_minutes)
        request.session.set_expiry(expire_time)
        logger.debug("%%%%%SETTING USER_CREDENTIAL IN SESSION")
        # Add session timeout to the credential object
        cred_dict['session_timeout'] = session_timeout_minutes
        # Session must be  < 2000 bytes or > 4000 bytes or Oracle error
        # ORA-01461: can bind a LONG value only for insert into a LONG column will occur
        bigstring = 4000 * '*'
        request.session['ANY_STUFF'] = bigstring
        request.session['USER_CREDENTIAL'] = cred_dict
        return cred_dict

    elif portalLoginStatus == OGISMessages.msg['PORTAL_USER_NOT_ROLE_MEMBER']:
        logger.debug("PORTAL USER NOT ROLE MEMBER")
        return build_public_credential("Your current myNewJersey login does not allow to access this application. Please contact " +
            support_email + " for assistance.", mynj=False)
    elif portalLoginStatus == OGISMessages.msg['PORTAL_CONNECTION_ERROR']:
        logger.debug("PORTAL CONNECTION ERROR")
        return build_public_credential("There was an error connecting to the myNewJersey Portal. Please contact " +
            support_email + " for assistance.", mynj=False)

def get_token(tokenDuration):
    # Get user information from database
    try:
        agsTokenServer = settings.get_prop('AGS_TOKEN_SERVER')
        agsproxy = settings.get_prop('AGSProxyHost')
        agsproxytype = settings.get_prop('AGSProxyType')
        agsuser = settings.get_prop('AGS_EDIT_USER')
        agspassword = settings.get_prop('AGS_EDIT_PASSWORD')
        agst = AGST.AGSTokenRequestor(agsTokenServer, agsproxy, agsproxytype, agsuser, agspassword)
        serviceToken = agst.getAGSToken(tokenDuration)
        return serviceToken
    except:
        return { 'error': { 'message': 'Could not acquire token' } }

