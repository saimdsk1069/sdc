from suds.client import Client
from suds.wsse import *
import urllib2
from AG_SADCeFarms import settings
import OGISMessages
import logging

logger = logging.getLogger(__name__)

def __getPortalSession(request):
    logger.debug("Inside getPortalSession")
    #
    # Create a SUDS client to get SSO Cookie Name
    #
    WSDL = settings.get_prop('SINGLESIGNONWSDL')
    try:
        client = Client(WSDL)
    except urllib2.URLError as e:
        logger.error("Error creating client from WSDL %s" % WSDL )
        logger.error( e.reason )
        return None
    client = Client( WSDL )
    #
    # Get the cookie Name
    #
    try:
        SSOCookieName = client.service.getCookieName()
    except urllib2.URLError as e:
        logger.error(e)
        logger.error("*** Error getting SSO Cookie Name")
        return None
    except WebFault, e:
        logger.error(e)
        logger.error("*** Error getting SSO Cookie Name" )
        return None
    # Get cookies from request
    cookies = request.COOKIES
    logger.debug("COOKIES IN REQUEST:")
    #
    # See if SSO Cookie is in the request cookies
    #
    for cookiename in cookies:
        logger.debug("Cookie Name: %s Value: %s" % (cookiename, cookies[cookiename]) )
    if SSOCookieName in cookies:
        return cookies[SSOCookieName]
    else:
        return None

def validatePortalUser( request, roleName, appID ):
    """
        Validate if user is logged into portal

        Input:
            request - HTTP request
            roleName - The portal role to check for for that user
            appID - The portal application idexit


        Returns:
            statusMessage - Indicating if portal session is valid
            UserKey -  Portal User Key associated with the portal user
    """
    logger.debug("Inside validatePortalUser")

    portalSession = __getPortalSession(request)
    if portalSession is None:
        logger.debug("Portal Session is None")
        return OGISMessages.msg["PORTAL_SESSION_NOT_VALID"], None
    elif portalSession is not None:
        # With django looks like no need to encode portal session
        logger.debug("Portal Session: %s" % portalSession )
        #
        # Replaced request to server for WSDL with local copy of WSDL
        #
        WSDL = settings.get_prop('SINGLESIGNONWSDL')
        try:
            client = Client(WSDL)
        except urllib2.URLError as e:
            logger.error("Error creating client from WSDL %s" % WSDL )
            logger.error( e.reason )
            return OGISMessages.msg['PORTAL_CONNECTION_ERROR'], None
        includeUserName = True
        includeEmail = True
        try:
            logger.debug("Validating user:")
            logger.debug("Role: [%s]" % roleName)
            logger.debug("appID: [%s]" % appID )
            mynjUser = client.service.validate( portalSession, includeUserName, includeEmail, roleName, appID )
            logger.debug(mynjUser)
            if not mynjUser.ValidSession:
                logger.debug("No valid session for mynjUser")
                return OGISMessages.msg["PORTAL_SESSION_NOT_VALID"], None
            if mynjUser.InRole:
                logger.debug("User has the role, let's check for the user key")
                # If user has a valid role, return the application id ( User key ) if it exists.
                # It's a list so only return the first key
                try:
                    userKey = mynjUser.UserKeys[0]
                except AttributeError, e:
                    userKey = None

                logger.debug("Returning userkey:" + userKey)
                return OGISMessages.msg['PORTAL_USER_IS_ROLE_MEMBER'], userKey
            else:
                logger.debug("Returning None since user does not have the role")
                return OGISMessages.msg['PORTAL_USER_NOT_ROLE_MEMBER'], None
        except urllib2.URLError as e:
            logger.error(e)
            logger.error('*** Error Validating Portal Session')
            return None
        except WebFault, e:
            logger.error(e)
            logger.error('*** Error Validating Portal Session')
            return None
    else:
        logger.debug("Not sure why here since portal session is either None or not None")
        return OGISMessages.msg['PORTAL_CONNECTION_ERROR'], None
