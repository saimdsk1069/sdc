from django.core.exceptions import ObjectDoesNotExist
from AG_SADCeFarms import settings
import Authenticate
import logging

logger = logging.getLogger(__name__)

# TODO: SAVE AUTH STUFF TO SESSION
def is_authenticated( request ):
    response = Authenticate.get_credentials(request)
    if response['status'] == 'SUCCESS':
        return True
    else:
        return False

def is_valid_admin_user( request ):
    # Go no further if user is not authenticated
    response = Authenticate.get_credentials(request)
    if response['status'] != 'SUCCESS':
        return False
    logger.debug("VALID USER")
    # build user's role list as concatenated string separated by : so it will be easy to
    # compare user's roles with admin roles
    user_role_list = []
    for user_role in response['roles']:
        logger.debug("USER HAS ROLE: " + user_role['tier_type'] + ":" + user_role['tier_group'] + ":" + user_role['tier_subgroup'])
        user_role_list.append( user_role['tier_type'] + ":" + user_role['tier_group'] + ":" + user_role['tier_subgroup'] )
    # Check to see if user has admin role
    for role in settings.get_prop("USER_ADMIN_ROLES"):
        chk_role = role['tier_type'] + ":" + role['tier_group'] + ":" + role['tier_subgroup']
        logger.debug("XXX CHK ROLE " + chk_role)
        if chk_role in user_role_list:
            return True
    return False

def is_tier_group_ogis( request ):
    response = Authenticate.get_credentials(request)
    if response['status'] != 'SUCCESS':
        return False
    # check to see if user's roles include the group 'OGIS'. If not, return false
    for user_role in response['roles']:
        if user_role['tier_group'] == 'OGIS':
            return True
    return False

def logout( request ):
    request.session.flush()
    #request.session['APP_CONNECTED'] = 'NONE'
    #request.session['USER_KEY'] = Null

def get_userid( request ):
    return request.session.get('USER_KEY', 'NONE')

def get_roles(request):
    pass

def get_permissions( request ):
    pass

def has_permissions( request, permission ):
    pass

def has_role( request, therole ):
    pass



