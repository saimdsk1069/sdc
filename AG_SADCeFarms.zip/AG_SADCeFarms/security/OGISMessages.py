msg = { 
    'APPLICATION_NOT_REGISTERED': 'The application is not registered.',
    'PORTAL_SESSION_NOT_VALID': 'Not logged in.',
    'PORTAL_USER_NOT_ROLE_MEMBER': 'The portal user is not authorized to run this application.',
    'PORTAL_USER_IS_ROLE_MEMBER': 'The portal user is a member of the role.',
    'PORTAL_CONNECTION_ERROR': 'Error connecting to portal.'
    }

    
    
    
    