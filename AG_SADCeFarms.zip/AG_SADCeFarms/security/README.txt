This is the location for the security related code.  Not sure if it will remain here permanently but
a location is needed.