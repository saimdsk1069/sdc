from threading import local

_user = local()

class CurrentUserMiddleware(object):
    def process_request(self, request):
        _user.value = request.session.get('USER_CREDENTIAL', None)

def get_current_user():
    if _user.value:
        return _user.value.get('user_guid',None)
    else:
        return None
