from database.models import AuthUrl, AuthUrlPermission, AuthRoleSadc
from django.core.exceptions import ObjectDoesNotExist, ImproperlyConfigured
from django.http import HttpResponse
from AG_SADCeFarms import settings
from rest_framework import status
from rest_framework.response import Response
import Authenticate
import logging

logger = logging.getLogger(__name__)


class RequestSecurityProcessor(object):

    init_ok = True
    init_message = ''

    # Take a url and a method and return the role guids that have access to the url
    def get_role_guids_for_resource_and_method(self, resource, method):
        role_guids = []
        try:
            url_permission = AuthUrlPermission.objects.filter(auth_url_guid__auth_url_address=resource,permission_type=method)
            for perm in url_permission:
                role_guids.append(perm.auth_role_guid.auth_role_guid)
        except Exception as e:
            logger.debug("Error retrieving url permission: %s" % e.message)
        return role_guids

    # Take a uri path and strip off anything past the base url
    def get_base_resource(self, path):
        second_slash = path.find('/',1)
        if second_slash == -1:
            return path
        else:
            return path[:second_slash]

    def access_allowed(self, role_guids, credentials):
        """
        Test to see if user's credential role guids match any permission role guids

        :param role_guids:
        :param credentials:
        :return:
        """
        for role in role_guids:
            for cred_role in credentials['roles']:
                logger.debug("Checking role guild %s against %s" % ( role, cred_role['role_guid']))
                if role == cred_role['role_guid']:
                    return True
        return False

    def process_request(self, request):

        logger.debug("+++       REQUEST METHOD: %s" % request.method)
        method = request.method
        base_resource = self.get_base_resource(request.path)
        request_path = request.path_info
        # search for second slash at character 1
        second_slash_pos = request_path.find('/',1)
        if second_slash_pos != -1:
            request_path = request_path[:second_slash_pos]
        logger.debug("+++         REQUEST PATH: %s" % base_resource)
        logger.debug("+++    REQUEST PATH_INFO: %s" % request_path)
        role_guids = self.get_role_guids_for_resource_and_method(request_path, method)
        # For testing purposes, if on development and the PERMISSION_DENIED_URL is set, return a permission denied msg.
        if settings.get_platform() == 'DEVELOPMENT':
            try:
                perm_denied_url = settings.get_prop('PERMISSION_DENIED_URL')
                if perm_denied_url == request_path:
                    logger.debug("PERMISSION_DENIED_URL is preventing access to %s with method %s is not permitted." % (request_path, method))
                    return HttpResponse('{ "result":"error","message":"Access Denied."}' , content_type="application/json", status=status.HTTP_403_FORBIDDEN )
            except ImproperlyConfigured:
                pass
        if len(role_guids) == 0:
            logger.debug("Access to %s with method %s is not permitted." % (request_path, method))
            return HttpResponse('{ "result":"error","message":"Access Denied."}' , content_type="application/json", status=status.HTTP_403_FORBIDDEN )
        else:
            logger.debug("----> Role GUIDs with access to resource %s with method %s is/are %s" % (request_path,method,','.join(role_guids)))
            # Check credentials
            credentials = Authenticate.get_credentials(request)
            logger.debug("---> Authenticate Credentials: %s" % credentials)
            access_status = self.access_allowed(role_guids, credentials)
            logger.debug("----> URL Access is: %s" % access_status)
            if not access_status:
                logger.debug("Access status is false for %s with method %s." % (base_resource, method))
                return HttpResponse('{ "result":"error","message":"Access Denied."}' , content_type="application/json", status=status.HTTP_403_FORBIDDEN )
            logger.debug("----> SESSION TIMEOUT IN %s SECONDS" % str(request.session.get_expiry_age()))
            # logger.debug("--> SESSION CREDENTIAL OBJECT: %s" % str(request.session.get('USER_CREDENTIAL','INVALID!')))
        return None

    def process_response(self, request, response):
        if not self.init_ok:
            return HttpResponse('{"result":"error" "message": "' + self.init_message + '" }', content_type="application/json", status=status.HTTP_400_BAD_REQUEST )
        return response



