from suds.client import Client
from suds.wsse import *
import urllib2
import logging

logger = logging.getLogger(__name__)

class ClientCreateException( Exception ):
    pass

class GrantFailureException( Exception ):
    pass

class ResumeFailureException( Exception ):
    pass

class myNJAuth:
    def __init__(self, wsdl, regtoken):
        self.wsdl = wsdl
        self.regtoken = regtoken

        try:
            self.client = Client(self.wsdl)
        except urllib2.URLError as e:
            raise ClientCreateException(e.reason)

    def grant(self, roleName, businessName, contactName, email, userKey, reGrantRevoked, serviceToken ):
        try:
            grantResponse = self.client.service.grant( roleName, businessName, contactName, email, userKey, reGrantRevoked, serviceToken )
            if not grantResponse.Success:
                logger.debug("Grant returned False %s" % grantResponse.Errors)
                #print grantResponse.Errors

                errors = ",".join(grantResponse.Errors)
                raise GrantFailureException( errors )
            logger.debug("Grant returned Success")
            return grantResponse
        except WebFault as e:
            raise GrantFailureException( e.reason )
        except Exception as e:
            #print e
            logger.debug("grant failure exception message %s" % e)
            raise GrantFailureException( e.message )

    def resume(self, authID, serviceToken ):
        try:
            resumeResponse = self.client.service.resume( authID, serviceToken )
            if not resumeResponse.Success:
                logger.debug("Resume returned False")
                errors = ",".join(resumeResponse.Errors)
                raise GrantFailureException( errors )
            logger.debug("Resume returned Success")
            return resumeResponse
        except WebFault as e:
            raise ResumeFailureException( e.reason )
        except Exception as e:
            raise ResumeFailureException( e.message )


