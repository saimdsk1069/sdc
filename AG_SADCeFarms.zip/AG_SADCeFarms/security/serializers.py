from rest_framework import serializers
from rest_framework.validators import UniqueValidator
from database.models import (
    AuthUrl,
    AuthUrlPermission,
    AuthUiComponent,
    AuthUiPermission,
    AuthRoleSadc,
)

import logging

logger = logging.getLogger(__name__)
# #*************************************************************************************
# # Auth Urls
# #*************************************************************************************

class AuthUrlSerializer(serializers.ModelSerializer):
    auth_url_address = serializers.CharField(validators=[UniqueValidator(queryset=AuthUrl.objects.all())])
    class Meta:
        model = AuthUrl
        fields = (
            'auth_url_guid',
            'auth_url_address',
        )
        read_only_fields = ('auth_url_guid',)

    def create(self, validated_data):
        #print "Attempting to create url with:", validated_data
        logger.debug("Attempting to create url with: %s" % validated_data)
        url = AuthUrl.objects.create(**validated_data)
        url.save()
        return url

class PermSerializer(serializers.ModelSerializer):
    role_guids = serializers.SerializerMethodField()

    def get_role_guids(self, url_perm):
        role_guid_list = []
        role_guid_list.append(url_perm.auth_role_guid.auth_role_guid)
        return role_guid_list

    class Meta:
        model = AuthUrlPermission
        fields = (
            'role_guids',
            'auth_role_guid',
            'permission_type',
        )
        read_only_fields = ('auth_url_guid',)

class AuthUrlPermissionSerializer(serializers.ModelSerializer):
    roles_and_perms = serializers.SerializerMethodField()

    def get_roles_and_perms(self, url_perm):
        roles_and_perms = {}
        url_perms = AuthUrlPermission.objects.filter(auth_url_guid=url_perm.auth_url_guid)
        for role_perm in url_perms:
            role_guid = role_perm.auth_role_guid.auth_role_guid
            perm = role_perm.permission_type
            if role_guid not in roles_and_perms:
                roles_and_perms[role_guid] = {'role_guid':role_guid,'permission':[perm]}
            else:
                roles_and_perms[role_guid]['permission'].append(perm)
        # convert the values of the dictionary into a list to return
        role_guid_list  = []
        for role_guid, role_dict in roles_and_perms.items():
            role_guid_list.append(role_dict)
        return role_guid_list

    class Meta:
        model = AuthUrl
        fields = (
            'auth_url_guid',
            'roles_and_perms',
            # 'permissions',
        )

    def update(self, instance, validated_data):
        return instance

class AuthUiComponentSerializer(serializers.ModelSerializer):
    auth_ui_component_name = serializers.CharField(validators=[UniqueValidator(queryset=AuthUiComponent.objects.all())])
    class Meta:
        model = AuthUiComponent
        fields = (
            'auth_ui_component_guid',
            'auth_ui_component_name',
            'auth_ui_component_desc',

        )
        read_only_fields = ('auth_ui_component_guid',)

    def create(self, validated_data):
        #print "Attempting to create ui component with:", validated_data
        logger.debug("Attempting to create ui component with: %s" % validated_data)
        ui_component = AuthUiComponent.objects.create(**validated_data)
        ui_component.save()
        return ui_component


class AuthUiPermissionSerializer(serializers.ModelSerializer):
    roles = serializers.SerializerMethodField()

    def get_roles(self, ui_perm):
        ui_perms = AuthUiPermission.objects.filter(auth_ui_component_guid=ui_perm.auth_ui_component_guid)
        role_guid_list = []
        for ui_perm in ui_perms:
            role_guid = ui_perm.auth_role_guid.auth_role_guid
            role_guid_list.append({'role_guid': role_guid })
        return role_guid_list

    class Meta:
        model = AuthUiComponent
        fields = (
            'auth_ui_component_guid',
            'roles',
        )

    def update(self, instance, validated_data):
        return instance

class AuthRoleUiPermissionSerializer(serializers.ModelSerializer):
    perms = serializers.SerializerMethodField()

    def get_perms(self,role):
        #print "EACH ROLE:", role.auth_role_guid
        perm_list = []
        aup = role.authuipermission_set.all()
        if len(aup) != 0:
            for a in aup:
                perm_list.append({'component_name': a.auth_ui_component_guid.auth_ui_component_name })
        return perm_list

    class Meta:
        model = AuthRoleSadc
        fields = (
            'auth_role_name',
            'perms',
        )

class AuthUiPermissionRoleSerializer(serializers.ModelSerializer):
    ui_component_name = serializers.SerializerMethodField()
    roles = serializers.SerializerMethodField()

    def get_ui_component_name(self, ui_component):
        return ui_component.auth_ui_component_name

    def get_roles(self, ui_component):
        role_names = []
        ui_comp_guid = ui_component.auth_ui_component_guid
        ui_perms = AuthUiPermission.objects.filter(auth_ui_component_guid=ui_comp_guid)
        for perm in ui_perms:
            role_name = perm.auth_role_guid.auth_role_name
            role_names.append({'role_name': role_name })
        return role_names

    class Meta:
        model = AuthUiPermission
        fields = (
            'ui_component_name',
            'roles',
        )


