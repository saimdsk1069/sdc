from django.conf.urls import url
import views

urlpatterns = [
    url(r'^authenticate$', views.AuthenticateUser.as_view(), name='authenticate'),
    url(r'^logoff$', views.Logoff.as_view(), name='logoff'),
    url(r'^keepalive$', views.RefreshSession.as_view(), name='refreshsession'),
    url(r'^permissions/(?P<auth_url_guid>[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$', views.Permissions.as_view(), name='permissions'),
    url(r'^rolesanduipermissions$', views.RolesAndUIPermissions.as_view(), name='roleuiperms'),
    url(r'^rolesandurlpermissions$', views.RolesAndURLPermissions.as_view(), name='rolerlperms'),
    url(r'^setuser/(?P<newuser>.*)$', views.SetUser.as_view(), name='setuser'),
    url(r'^uicomponents$', views.UIComponents.as_view(), name='uicomponents'),
    url(r'^uicomponents/(?P<auth_ui_component_guid>[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$', views.UIComponents.as_view(), name='uicomponents'),
    url(r'^uipermissions/(?P<auth_ui_component_guid>[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$', views.UIPermissions.as_view(), name='uipermissions'),
    url(r'^uipermissionsandroles$', views.UIPermissionsAndRoles.as_view(), name='uipermissionsandroles'),
    url(r'^urlpermissionsandroles$', views.URLPermissionsAndRoles.as_view(), name='allurlpermissions'),
    url(r'^urls$', views.Url.as_view(), name="urls" ),
    url(r'^urls/(?P<auth_url_guid>[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$', views.Url.as_view(), name="urls" ),

]