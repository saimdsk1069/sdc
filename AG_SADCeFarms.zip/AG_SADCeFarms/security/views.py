from AG_SADCeFarms import settings
from database.models import (
    AuthRoleSadc,
    AuthUiComponent,
    AuthUiPermission,
    AuthUrl,
    AuthUrlPermission,
    AuthUserSadc,
)
from .serializers import (
    AuthUrlSerializer,
    AuthUrlPermissionSerializer,
    AuthUiComponentSerializer,
    AuthUiPermissionSerializer,
    AuthRoleUiPermissionSerializer,
    AuthUiPermissionRoleSerializer,
)
from django.http import Http404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
import logging
import Authenticate
import datetime
import collections
from common.error_messages import authAdminErrors

logger = logging.getLogger(__name__)

class Logoff(APIView):
    def get(self, request, format=None):
        logger.debug("----- Before killing session")
        cookies = request.COOKIES
        if settings.SESSION_COOKIE_NAME in cookies:
            logger.debug("COOKIE: %s" % cookies['myNJAGSADCeFarms'] )
        else:
            logger.debug("No cookie found. Session has been terminated")
        cred = request.session.get('USER_CREDENTIAL', None)
        if cred is not None:
            logger.debug("----- Credential from session before killing %s" % str(cred))
        else:
            logger.debug("----- Credential from session before killing is None")
        logger.debug("----- Killing Session")
        request.session.flush()
        logger.debug("----- After killing session")
        cred = request.session.get('USER_CREDENTIAL', None)
        if cred is not None:
            logger.debug("----- Credential from session after killing%s" % str(cred))
        else:
            logger.debug("----- Credential from session after killing is None")

        return Response({"result":"success","message":'Session Terminated'})

class AuthenticateUser(APIView):
    def post(self, request):
        credentials = Authenticate.get_credentials(request)
        return Response(credentials, status=status.HTTP_200_OK)

class RefreshSession(APIView):
    def get(self, request):
        session_timeout_minutes = int(settings.get_prop('SESSION_TIMEOUT'))
        expire_time = datetime.timedelta(minutes=session_timeout_minutes)
        request.session.set_expiry(expire_time)
        session_expires = request.session.get_expiry_age()
        #print "REFRESH SESSION. EXPIRES IN ", request.session.get_expiry_age(), "SECONDS"
        logger.debug("REFRESH SESSION. EXPIRES IN %s SECONDS" % request.session.get_expiry_age())
        cookies = request.COOKIES
        if settings.SESSION_COOKIE_NAME in cookies:
            #print "COOKIE:", cookies['myNJAGSADCeFarms']
            logger.debug("COOKIE: %s" %cookies['myNJAGSADCeFarms'])
        else:
            #print "SESSION TERMINATED"
            logger.debug( "SESSION TERMINATED")
        # print "Current Credentials:", request.session.get('USER_CREDENTIAL','INVALID!!!!')
        return Response({"result":"success","message": str(session_expires)}, status=status.HTTP_200_OK)

class URLPermissionsAndRoles(APIView):
        def get(self, request, format=None):
            # urls_and_perms = { 'urls_and_perms': [] }
            urls_and_perms = []
            urls = AuthUrl.objects.filter(active_flg=1).order_by('auth_url_address')
            for url in urls:
                url_address = url.auth_url_address
                url_dict ={'url': url_address, 'roles': []}
                url_perms = AuthUrlPermission.objects.filter(auth_url_guid=url.auth_url_guid).order_by('auth_role_guid__auth_role_name')
                role_dict = collections.OrderedDict()
                role_list = []
                for url_perm in url_perms:
                    role_name = url_perm.auth_role_guid.auth_role_name
                    perm = url_perm.permission_type
                    if role_name in role_list:
                        role_dict[role_name][perm]= 'Y'
                    else:
                        role_list.append(role_name)
                        role_dict[role_name] = { 'GET': 'N', 'PUT': 'N', 'POST': 'N', 'DELETE': 'N'}
                        role_dict[role_name][perm]= 'Y'
                url_out = { 'url': url_address, 'roles': [] }
                for role_name in role_list:
                    role_out = { 'role': role_name, 'perms': role_dict[role_name]}
                    url_out['roles'].append(role_out)
                # urls_and_perms['urls_and_perms'].append(url_out)
                urls_and_perms.append(url_out)
                # print "URL:", url_address, "ROLE DICT:", role_dict
            return Response(urls_and_perms)

class RolesAndURLPermissions(APIView):
        def get(self, request, format=None):
            roles_urls_and_permissions = collections.OrderedDict()
            aup = AuthUrlPermission.objects.select_related()\
                .order_by('auth_role_guid__auth_role_name','auth_url_guid__auth_url_address')
            #print "Query is done"
            logger.debug("Query is done")
            for a in aup:
                role_name = a.auth_role_guid.auth_role_name
                url = a.auth_url_guid.auth_url_address
                permission = a.permission_type
                # print a.auth_role_guid.auth_role_name, a.auth_url_guid.auth_url_address, a.permission_type
                if role_name not in roles_urls_and_permissions:
                    roles_urls_and_permissions[role_name] = collections.OrderedDict()
                    roles_urls_and_permissions[role_name][url] = {'GET':'N','PUT':'N','POST':'N','DELETE':'N'}
                    roles_urls_and_permissions[role_name][url][permission]='Y'
                else:
                    if url not in roles_urls_and_permissions[role_name]:
                        roles_urls_and_permissions[role_name][url] = {'GET':'N','PUT':'N','POST':'N','DELETE':'N'}
                        roles_urls_and_permissions[role_name][url][permission]='Y'
                    else:
                        roles_urls_and_permissions[role_name][url][permission]='Y'

            results = []
            for role_name, urls_and_perms in roles_urls_and_permissions.items():
                role_to_add = {'role':role_name,'urls': []}
                for url,perms in urls_and_perms.items():
                    # print "role:", role_name, "url:", url, 'Perms:',perms
                    url_to_add = { 'url': url, 'perms': perms }
                    role_to_add['urls'].append(url_to_add)
                results.append(role_to_add)

            return Response(results)

class Permissions(APIView):

    def get(self, request, auth_url_guid=None, format=None):
        if auth_url_guid is not None:
            try:
                the_url = AuthUrl.objects.get(auth_url_guid=auth_url_guid)
                # print "Survived getting the permission",auth_url_guid
                serializer = AuthUrlPermissionSerializer(the_url)
                return Response(serializer.data)
            except AuthUrl.DoesNotExist:
                raise Http404
        else:
            logger.debug('Auth URL GUID Not specified')
            return Response({"result":"error","message":'Bad permission request'}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, auth_url_guid=None):
        if auth_url_guid == None:
            error = "err-a014"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        try:
            the_url = AuthUrl.objects.get(auth_url_guid=auth_url_guid)
            #print "The url during put:", the_url
            logger.debug( "The url during put: %s" % the_url)
            #print "The request during put:", request.data
            logger.debug( "The request during put: %s" % request.data)
            if the_url.auth_url_guid != request.data['auth_url_guid']:
                # guid in url string doesn't match guid in request body
                error = "err-a018"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            # First delete all permission records with that auth_url_guid
            try:
                AuthUrlPermission.objects.filter(auth_url_guid=auth_url_guid).delete()
            except Exception as e:
                error = "err-a019"
                logger.debug(authAdminErrors[error]['d_msg'])
                logger.debug(e.message)
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            # Now create new records for that auth_url_guid with role guids and individual permissions
            for role_and_perm in request.data['roles_and_perms']:
                #print "Doing ", role_and_perm
                logger.debug("Doing %s" % role_and_perm)
                role_guid = role_and_perm['role_guid']
                try:
                    the_role = AuthRoleSadc.objects.get(auth_role_guid=role_guid)
                except Exception as e:
                    error = "err-a020"
                    #print e.message
                    logger.debug(authAdminErrors[error]['d_msg'])
                    logger.debug("Error getting role for update to permission")
                    logger.debug(e.message)
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                perms = role_and_perm['permission']
                for perm in perms:
                    try:
                        #print "Creating new permission"
                        logger.debug("Creating new permission")
                        aup = AuthUrlPermission(auth_url_guid=the_url,auth_role_guid=the_role,permission_type=perm)
                        aup.save()
                    except Exception as e:
                        error = "err-a021"
                        #print e.message
                        logger.debug(authAdminErrors[error]['d_msg'])
                        logger.debug(e.message)
                        return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            return Response({"result":"success","message": request.data})
        except AuthUrl.DoesNotExist:
            error = "err-a015"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

class Url(APIView):
    def get(self, request, auth_url_guid=None, format=None):
        if auth_url_guid is not None:
            try:
                the_url = AuthUrl.objects.get(auth_url_guid=auth_url_guid,active_flg=True)
                serializer = AuthUrlSerializer(the_url)
                return Response(serializer.data)
            except AuthUrl.DoesNotExist:
                error = "err-a015"
                logger.debug(authAdminErrors[error]['d_msg'])
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            urls = AuthUrl.objects.filter(active_flg=True).order_by('auth_url_address')
            serializer = AuthUrlSerializer(urls, many=True)
            return Response(serializer.data)

    def post(self, request, format=None):
        serializer = AuthUrlSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        else:
            logger.debug("INVALID SERIALIZER MESSAGE FOR URL POST: |%s|" % serializer.errors)
            if serializer.errors['auth_url_address'][0] == 'This field must be unique.':
                error = "err-a016"
            else:
                error = "err-a013"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, auth_url_guid=None):
        if auth_url_guid == None:
            error = "err-a014"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        try:
            the_url = AuthUrl.objects.get(auth_url_guid=auth_url_guid)
            serializer = AuthUrlSerializer(the_url, data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            else:
                # It's possible that the url could be updated to duplicate an already existing url
                logger.debug("INVALID SERIALIZER MESSAGE: |%s|" % serializer.errors)
                if serializer.errors['auth_url_address'][0] == 'This field must be unique.':
                    error = "err-a016"
                else:
                    error = "err-a017"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        except AuthUrl.DoesNotExist:
            error = "err-a015"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, auth_url_guid=None):
        if auth_url_guid == None:
            error = "err-a014"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        try:
            the_url = AuthUrl.objects.get(auth_url_guid=auth_url_guid)
            the_url.delete()
            return Response({"result":"success","message":""}, status=status.HTTP_200_OK )
        except AuthUrl.DoesNotExist:
            error = "err-a015"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)


class UIComponents(APIView):
    def get(self, request, auth_ui_component_guid=None, format=None):
        if auth_ui_component_guid is not None:
            try:
                the_ui_component = AuthUiComponent.objects.get(auth_ui_component_guid=auth_ui_component_guid)
                serializer = AuthUiComponentSerializer(the_ui_component)
                return Response(serializer.data)
            except AuthUiComponent.DoesNotExist:
                error = "err-a023"
                logger.debug(authAdminErrors[error]['d_msg'])
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            ui_components = AuthUiComponent.objects.all().order_by('auth_ui_component_name')
            serializer = AuthUiComponentSerializer(ui_components, many=True)
            return Response(serializer.data)

    def post(self, request, format=None):
        serializer = AuthUiComponentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        else:
            logger.debug("INVALID SERIALIZER MESSAGE FOR UI COMPONENT POST: |%s|" % serializer.errors)
            if serializer.errors['auth_ui_component_name'][0] == 'This field must be unique.':
                error = "err-a024"
            else:
                error = "err-a028"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, auth_ui_component_guid=None):
        if auth_ui_component_guid == None:
            error = "err-a029"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        try:
            the_ui_component = AuthUiComponent.objects.get(auth_ui_component_guid=auth_ui_component_guid)
            serializer = AuthUiComponentSerializer(the_ui_component, data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            else:
                # It's possible that the url could be updated to duplicate an already existing url
                logger.debug("INVALID SERIALIZER MESSAGE: |%s|" % serializer.errors)
                if serializer.errors['auth_url_address'][0] == 'This field must be unique.':
                    error = "err-a024"
                else:
                    error = "err-a025"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        except AuthUiComponent.DoesNotExist:
            error = "err-a023"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

class UIPermissions(APIView):

    def get(self, request, auth_ui_component_guid=None, format=None):
        #print "Inside uipermissions"
        logger.debug("Inside uipermissions")
        if auth_ui_component_guid is not None:
            try:
                the_ui_component = AuthUiComponent.objects.get(auth_ui_component_guid=auth_ui_component_guid)
                #print "Survived getting the permission",auth_ui_component_guid
                logger.debug("Survived getting the permission %s" % auth_ui_component_guid)
                serializer = AuthUiPermissionSerializer(the_ui_component)
                return Response(serializer.data)
            except AuthUiComponent.DoesNotExist:
                error = "err-a023"
                logger.debug(authAdminErrors[error]['d_msg'])
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        else:
            error = "err-a029"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, auth_ui_component_guid=None):
        if auth_ui_component_guid == None:
            error = "err-a029"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        try:
            the_ui_component = AuthUiComponent.objects.get(auth_ui_component_guid=auth_ui_component_guid)
            logger.debug("The ui component during put: %s" % the_ui_component)
            #print "The ui component during put:", the_ui_component
            #print "The request during put:", request.data
            logger.debug( "The request during put: %s" % request.data)
            if the_ui_component.auth_ui_component_guid != request.data['auth_ui_component_guid']:
                # guid in ui component string doesn't match guid in request body
                error = "err-a026"
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            # First delete all permission records with that auth_url_guid
            try:
                AuthUiPermission.objects.filter(auth_ui_component_guid=auth_ui_component_guid).delete()
            except Exception as e:
                error = "err-a027"
                logger.debug(authAdminErrors[error]['d_msg'])
                logger.debug(e.message)
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            # Now create new records for that auth_url_guid with role guids and individual permissions
            #print "INCOMING REQUEST DATA", request.data
            logger.debug("INCOMING REQUEST DATA %s" % request.data)
            for role in request.data['roles']:
                role_guid = role['role_guid']
                #print "Doing ", role_guid
                logger.debug( "Doing %s" % role_guid)
                try:
                    the_role = AuthRoleSadc.objects.get(auth_role_guid=role_guid)
                except Exception as e:
                    error = "err-a020"
                    #print e.message
                    logger.debug(authAdminErrors[error]['d_msg'])
                    logger.debug("Error getting role for update to ui permission")
                    logger.debug(e.message)
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                try:
                    #print "Creating new permission"
                    logger.debug("Creating new permission")
                    auiperm = AuthUiPermission(auth_ui_component_guid=the_ui_component,auth_role_guid=the_role)
                    auiperm.save()
                except Exception as e:
                    error = "err-a021"
                    print e.message
                    logger.debug(authAdminErrors[error]['d_msg'])
                    logger.debug(e.message)
                    return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
            return Response(request.data)
        except AuthUiComponent.DoesNotExist:
            error = "err-a023"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

class RolesAndUIPermissions(APIView):

    def get(self, request, format=None):
        # print "Inside rolesanduipermissions"
        roles = AuthRoleSadc.objects.order_by('tier_desc','auth_role_name')
        serializer = AuthRoleUiPermissionSerializer(roles, many=True)
        return Response(serializer.data)

class UIPermissionsAndRoles(APIView):

    def get(self, request, format=None):
        # ui_components = AuthUiPermission.objects.all().select_related()\
        #     .order_by('auth_ui_component_guid__auth_ui_component_name')
        ui_components = AuthUiComponent.objects.all().order_by('auth_ui_component_name')
        serializer = AuthUiPermissionRoleSerializer(ui_components, many=True)
        return Response(serializer.data)

class SetUser(APIView):

    def post(self, request, newuser=None):
        platform = settings.get_platform()
        if platform != 'DEVELOPMENT':
            logger.debug("Not on DEVELOPMENT platform.")
            raise Http404
        if newuser == None:
            return Response({"result":"error","message":"username not specified"}, status=status.HTTP_400_BAD_REQUEST)
        else:
            try:
                newuser = newuser.lower()
                the_user = AuthUserSadc.objects.get(auth_user_name=newuser)
            except AuthUserSadc.DoesNotExist:
                logger.debug("Invalid user chosen: %s" % newuser )
                raise Http404
            logger.debug("Setting user to %s", newuser)
            settings.set_prop('AUTH_ADMIN_USER',newuser)
            portal_user_key = settings.get_prop('AUTH_ADMIN_USER')
            logger.debug("AUTH_ADMIN_USER now set to %s" % portal_user_key)
            return Response({"result":"success","message":"User successfully changed to %s" % newuser})



