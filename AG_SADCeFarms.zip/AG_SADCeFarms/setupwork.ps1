cd C:\Users\oaxfarr\.virtualenvs
Import-Module virtualenvwrapper
workon DjangoDevDesktop
cd C:\Users\oaxfarr\Documents\web\AG_SADCeFarms