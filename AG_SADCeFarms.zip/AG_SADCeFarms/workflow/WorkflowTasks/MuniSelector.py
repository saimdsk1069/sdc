import admin_authAdmin.Authenticate as Auth
from database.models import AuthRoleSadc

import logging

logger = logging.getLogger(__name__)

class MuniSelector:

    def __init__(self):
        logger.debug("Instantiating the MuniSelector")

    def build_request_data(self, request):
        # First get credentials
        credentials = Auth.get_fake_credentials(request)
        # Save any county codes in a list to determine the municipality partners for that county
        county_list = []
        # logger.debug("---CREDENTIALS:", credentials
        for role in credentials['roles']:
            if role['partner_guid'] != '':
                county = role['county_code']
                if county == '':
                    logger.debug("Error: County Partner doesn't have a county code.")
                else:
                    county_list.append(county)
        logger.debug("COUNTY LIST FOR PARTNER: %s" % county_list)
        for county in county_list:
            # Get all muni roles that start with the county code, and are partners
            muni_roles = AuthRoleSadc.objects.filter(muni_code__muni_code__startswith=county,tier_desc='PARTNER',tier_subgroup_desc='COORDINATOR')
            # Build unique list of muni codes and names by putting into a dictionary.  Duplicates will be handled
            # by just overlaying the key value pair
            # *** May not be needed anymore since tier_subgroup_desc'COORDINATOR' is included in the query
            muni_dict = {}
            for role in muni_roles:
                mun_code = role.muni_code.muni_code
                mun_name = role.muni_code.name
                muni_dict[mun_code] = mun_name
        # take non-dup muni dictionary, convert it to a list of muni codes and names, and sort
        sorted_mun_codes = sorted(muni_dict.keys())
        # From the sorted mun codes, build list of dictionaries of mun_codes and mun_names
        mun_list = []
        for mc in sorted_mun_codes:
            mun_list.append({'id': mc, 'value': muni_dict[mc]})
        # mun_list = sorted([ {k:v} for k, v in muni_dict.items() ])
        logger.debug("MUNLIST: %s" % mun_list)
        return mun_list

    def convert_answer_response(self, request, muni_codes):
        # Get list of muni codes and determine the muni parter role associated with them.
        muni_roles = AuthRoleSadc.objects.filter(muni_code__muni_code__in=muni_codes,tier_desc='PARTNER',tier_subgroup_desc='COORDINATOR')
        for muni in muni_roles:
            logger.debug("MUNI ROLE NAME: %s" % muni.auth_role_name)

