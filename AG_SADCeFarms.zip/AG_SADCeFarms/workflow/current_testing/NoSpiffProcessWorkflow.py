import json
import sys
import uuid
import copy
import logging
import workflow_execute_functions as wef

# Logging setup
logger = logging.getLogger(__name__)
logger.setLevel((logging.DEBUG))
fh = logging.FileHandler('process_workflow.log')
fh.setLevel(logging.DEBUG)
# formatter = logging.Formatter('%(asctime)s - %(name)s - %(lineno)d- %(levelname)s - %(message)s')
formatter = logging.Formatter('%(funcName)35s- %(lineno)d- %(levelname)s - %(message)s')
fh.setFormatter(formatter)
logger.addHandler(fh)

class ProcessWorkflowError(Exception):

    def __init__(self, value):
        self.value = value

    def __str__(self):
        return repr(self.value)

class ProcessWorkflow(object):

    # Hold the permisssions for each task id
    # task_id_permissions = {}
    dump_indent = 0

    def __init__(self):
        print "Executing "

    def set_up(self, wfdoc, init_perms={}, init_data = {} ):
        self.workflow = {}
        self.init_perms = init_perms
        with open(wfdoc) as fp:
            workflow_json = fp.read()
        try:
            self.hydrate_workflow(workflow_json, init_perms, init_data)
            self.dump_workflow()
            self.dump_workflow_data()
        except Exception as e:
            print "Exception:", e
            print "Error occurred creating workflow"
            exit(1)
        # self.complete_task_by_name('Start')
        self.start_workflow()

    def dump_workflow(self):
        """

        Dump out the workflow

        :return:
        """
        for id, task_stuff in self.workflow['tasks'].items():
            logger.debug("%32s %25s %30s %10s" % (id, task_stuff['name'], task_stuff['description'], task_stuff['state']))
            if 'execute_permissions' in task_stuff:
                execute_permissions = task_stuff['execute_permissions']
            else:
                execute_permissions = 'Not Defined'
            logger.debug("    execute_perms: %s assigned_perms %s" % (execute_permissions, task_stuff['assigned_permissions']))
            logger.debug("    outputs: %s" % (task_stuff['outputs']))
            logger.debug("    output_guids: %s" % (task_stuff['output_guids']))

    def dump_workflow_sequence(self):
        """

        Dump out the workflow

        :return:
        """
        logger.debug("---------------WORKFLOW SEQUENCE-------------------")
        for id, task_stuff in self.workflow['tasks'].items():
            logger.debug("%-25s %-30s %32s %10s" % (task_stuff['name'], task_stuff['description'], id, task_stuff['state']))
            logger.debug("    outputs: %s" % (task_stuff['outputs']))
            logger.debug("    output_guids: %s" % (task_stuff['output_guids']))
        logger.debug("---------------END WORKFLOW SEQUENCE-------------------")

    def dump_workflow_data(self):
        """

        Dump out workflow data that is stored

        :return:
        """
        logger.debug("Dumping workflow data")
        wf_data = self.workflow['data']
        for key, value in wf_data.items():
            logger.debug("key: %20s value: %20s" % (key, str(value)))

    def hydrate_workflow(self,workflow_json, init_perms, init_data):
        """
        Take workflow document and create a workflow structure with keys of uuids and values of the actual task

        :param workflow_json:
        :return:
        """
        logger.debug("init_perms: %s" % str(init_perms))
        logger.debug("init_data: %s" % str(init_data))
        workflow_as_dict = json.loads(workflow_json)['task_specs']
        self.workflow = {'tasks': {}, 'data': {}}
        self.workflow['data'] = init_data
        for task_id, task_data in workflow_as_dict.items():
            task_key = str(uuid.uuid4())
            self.workflow['tasks'][task_key] = task_data
            self.workflow['tasks'][task_key]['state'] = 'FUTURE'
            self.workflow['tasks'][task_key]['assigned_permissions'] = {'users': [], 'roles': [], 'contact_types': []}
            self.workflow['tasks'][task_key]['permission_type'] = ''
        self.validate_init_and_dynamic_perms(init_perms)
        self.set_output_guids()
        logger.debug("HYDRATED WORKFLOW %s" % str(self.workflow))

    def set_output_guids(self):
        """

        Take the names of the output tasks, get the guid of that output task, and save it to the task.  This will be
        used later if multiple tasks need to be created with the same name.

        :return:
        """
        for task_id, task_stuff in self.workflow['tasks'].items():
            output_guids = []
            for otask in task_stuff['outputs']:
                task_ids = self.get_task_ids_for_task_name(otask)
                for task_id in task_ids:
                    output_guids.append(task_id)
            task_stuff['output_guids'] = output_guids

    def validate_init_and_dynamic_perms(self, init_perms):
        '''

        Make sure that all workflow lanes defined with init_perm: and dynamic_perms: are defined in the init permissions

        '''

        for task_id, task_stuff in self.workflow['tasks'].items():
            logger.debug("VALIDATE INIT: %s %s"  % ( task_id, task_stuff))
            logger.debug("           name: %s" % task_stuff['name'])
            logger.debug("    description: %s" % task_stuff['description'])
            logger.debug("          state: %s" % task_stuff['state'])
            logger.debug("          class: %s" % task_stuff['class'])
            if 'execute_permissions' in task_stuff:
                exec_perm = task_stuff['execute_permissions']
                if task_stuff['execute_permissions'].startswith('init_perm:'):
                    perm_only = exec_perm[exec_perm.find(':')+1:]
                    logger.debug("init perm for %s is %s" % ( task_stuff['name'], perm_only))
                    if perm_only not in init_perms:
                        logger.debug("init permissions: %s" % str(init_perms))
                        logger.debug("permission %s not found in init_perms")
                        exit(1)
                    task_stuff['permission_type'] = 'DYNAMIC'
                    task_stuff['execute_permissions'] = perm_only
                    task_stuff['assigned_permissions'] = init_perms[perm_only]
                elif task_stuff['execute_permissions'].startswith('dynamic_perm:'):
                    perm_only = exec_perm[exec_perm.find(':')+1:]
                    logger.debug("dynamic permission for %s is %s" % ( task_stuff['name'], perm_only))
                    task_stuff['permission_type'] = 'DYNAMIC'
                    task_stuff['execute_permissions'] = perm_only
                else:
                    task_stuff['permission_type'] = 'DATABASE'
                    logger.debug("Not init_perm or dynamic_perm. Assign from database")

    def determine_ready_tasks(self):
        logger.debug("Inside determine_ready_tasks")
        while True:
            # TODO Can probably be pared down a a bit
            # Get list of current READY tasks
            logger.debug("READY TASKS BEFORE:")
            ready_tasks = self.get_ready_task_ids()
            logger.debug("READY TASKS AFTER:")
            new_ready_tasks = self.get_ready_task_ids()
            # Do any auto execute tasks that have gone READY
            self.do_auto_execute_tasks(new_ready_tasks)
            logger.debug("READY TASKS AFTER AUTO EXEC TASKS:")
            new_ready_tasks = self.get_ready_task_ids()
            # break out if the lists match ( meaning no new ready tasks occurred )
            ready_tasks.sort()
            new_ready_tasks.sort()
            # Keep going until all tasks that are in flux are completed.
            if ready_tasks == new_ready_tasks:
                break
        logger.debug("Done with determine_ready_tasks ")


    def get_output_task_names_and_ids(self,output_tasks):
        logger.debug("Checking for output tasks and ids")
        output_task_dict = {}
        for otask in output_tasks:
            logger.debug("Checking task %s against all tasks" % otask)
            for task_id, task_stuff in self.workflow['tasks'].items():
                if task_stuff['name'] == otask:
                    logger.debug("match on otask with real task")
                    output_task_dict[otask] = task_id
        return output_task_dict

    def get_task_state(self, task_name):
        logger.debug("Searching for task %s" % task_name)
        for task, task_stuff in self.workflow['tasks'].items():
            logger.debug("Checking task %s" % task_stuff['name'])
            if task_stuff['name'] == task_name:
                logger.debug("Match found for task %s" % task_name)
                task_stuff['state'] = 'COMPLETE'
                self.determine_ready_tasks()
                return
        logger.debug("Task %s not found in the workflow" % task_name)
        exit(1)

    def set_task_ready(self, task_id):
        logger.debug("Checking to see if task %s of type %s will be set to READY" % ( task_id, self.workflow['tasks'][task_id]['class']))
        self.workflow['tasks'][task_id]['state'] = 'READY'

    def get_ready_task_ids(self):
        logger.debug("Getting All READY Tasks")
        ready_tasks = []
        for task_id, task_stuff in self.workflow['tasks'].items():
            logger.debug("GRT: %25s %30s %30s %10s" % (self.workflow['tasks'][task_id]['name'], task_id, self.workflow['tasks'][task_id]['description'],  self.workflow['tasks'][task_id]['state']))
            if self.workflow['tasks'][task_id]['state'] == 'READY':
                ready_tasks.append(task_id)
        return ready_tasks

    def do_auto_execute_tasks(self, ready_tasks):
        logger.debug("AAAAA Firing Auto Execute Tasks")
        for task_id in ready_tasks:
            if 'auto_execute' in self.workflow['tasks'][task_id]:
                logger.debug("Task %s is auto_execute" % task_id )
                if self.workflow['tasks'][task_id]['class'] == 'ogis_custom.OgisMultiChoice':
                    logger.debug("Using workflow data %s for evaluation" % str(self.workflow['data']))
                if 'conditions' in self.workflow['tasks'][task_id]:
                    conditions = self.workflow['tasks'][task_id]['conditions']
                    logger.debug("Conditions exist for the task %s" % task_id)
                    if self.all_condition_values_found(task_id):
                        logger.debug("All task conditions were found")
                        task_data = self.workflow['data']
                        # More than one condition might evaluate as true so set each task ready
                        for condition in conditions:
                            expression = condition['expression']
                            logger.debug("Evaluating expression %s" % expression)
                            branch_task = condition['task']
                            if eval(expression):
                                logger.debug("=================== Evaluation based setting task %s to READY" % branch_task)
                                task_ids = self.get_task_ids_for_task_name(branch_task)
                                for tid in task_ids:
                                    self.set_task_ready(tid)
                        self.complete_task(task_id)
                    else:
                        logger.debug("Error: Missing task conditions for task %s" % task_id)
                        exit(1)
                else:
                    logger.debug("No conditions in auto execute task %s. Completing task." % task_id)
                    self.complete_task(task_id)
                    logger.debug("Determining output tasks and setting them to ready.")
                    outputs = self.workflow['tasks'][task_id]['outputs']
                    self.set_outputs_to_ready(outputs)

    def get_task_ids_for_task_name(self, task_name):
        task_ids = []
        for task_id, task_stuff in self.workflow['tasks'].items():
            if task_stuff['name'] == task_name:
                task_ids.append(task_id)
        return task_ids

    def start_workflow(self):
        """

        Get the id of the 'Start' task and set it to COMPLETE, then get all children of Start, and set them

        """
        logger.debug("Starting workflow")
        for task_id, task_stuff in self.workflow['tasks'].items():
            if task_stuff['name'] == 'Start':
                self.complete_task(task_id)
                # Get the children task names of Start task
                otasks = task_stuff['outputs']
                self.set_outputs_to_ready(otasks)

    def get_task_name_from_id(self, task_id):
        return self.workflow['tasks'][task_id]['name']

    def set_outputs_to_ready(self, outputs):
        for otask in outputs:
            otask_ids = self.get_task_ids_for_task_name(otask)
            for oid in otask_ids:
                # First create the multi tasks, then set them to ready.  Only do that for the first set of
                # tasks.  After that, process the multi tasks to update the output_guids field of the task.
                if self.workflow['tasks'][oid]['class'] == 'ogis_custom.OgisMultiInstance':
                    # self.create_multi_tasks_again(oid)
                    self.create_multi_tasks(oid)
                    self.dump_workflow_sequence()
                    # Set all of the tasks with that name to be READY
                    task_name = self.get_task_name_from_id(oid)
                    # get all task ids with that name
                    task_ids = self.get_task_ids_for_task_name(task_name)
                    # set each one to ready
                    for tid in task_ids:
                        self.set_task_ready(tid)
                else:
                    logger.debug("+++Setting %s to READY" % ( oid ))
                    self.set_task_ready(oid)


    # def create_multi_tasks_again(self, task_id, parent_id=None):
    #     """
    #
    #     Recursive function to create all multi tasks in sequence until no more multi tasks are encounterd in the
    #     task path.
    #
    #     :param task_id:
    #     :return:
    #     """
    #     logger.debug("  MMM Creating multi tasks for %s %s" % (self.get_task_name_from_id(task_id), task_id))
    #     task_stuff = self.workflow['tasks'][task_id]
    #     parent_task_name = self.get_parent_task_name(task_stuff['name'])
    #     logger.debug("  MMM Parent task name: %s" % parent_task_name )
    #     parent_task_guids = self.get_task_ids_for_task_name(parent_task_name)
    #     num_parent_tasks = len(parent_task_guids)
    #     logger.debug("  MMM Parent task guids: %s" % parent_task_guids)
    #     if 'count' not in task_stuff:
    #         logger.debug("ERROR: Count not defined in task %s" % task_id)
    #         exit(1)
    #     task_count_var = task_stuff['count']
    #     if task_count_var not in self.workflow['data']:
    #         logger.debug("ERROR: Could not find %s in task data" % task_count_var)
    #         exit(1)
    #     multi_count_for_each = self.workflow['data'][task_count_var]
    #     num_tasks_to_create = num_parent_tasks * multi_count_for_each - 1
    #     # num_tasks_to_create = self.workflow['data'][task_count_var]
    #     logger.debug("  MMM Going to generate %i new tasks (%i * %i - 1)" % (num_tasks_to_create, num_parent_tasks, multi_count_for_each))
    #     for new_task in range(num_tasks_to_create):
    #         # TODO Don't forget to set permissions!!!
    #         logger.debug("  MMM Creating new task with name %s" % task_stuff['name'])
    #         task_key = str(uuid.uuid4())
    #         self.workflow['tasks'][task_key] = copy.copy(task_stuff)
    #     # get the entire list of guids for the newly created tasks with that name
    #     new_task_guids = self.get_task_ids_for_task_name(task_stuff['name'])
    #     logger.debug("  MMM New task guids for task %s: %s" % ( task_stuff['name'], new_task_guids ))
    #     self.assign_output_guids_to_parents( parent_task_guids, new_task_guids)
    #     # Get the outputs of the task and repeat until output task is no longer 'ogis_custom.OgisMultiInstance'
    #     outputs = task_stuff['outputs']
    #     for otask_name in outputs:
    #         otask_ids = self.get_task_ids_for_task_name(otask_name)
    #         for oid in otask_ids:
    #             logger.debug("  MMM Examining task %s to see if a task should be created" % oid)
    #             if self.workflow['tasks'][oid]['class'] == 'ogis_custom.OgisMultiInstance': # TODO And permission is the same?
    #                 logger.debug("  MMM Creating new multi tasks for task id %s %s" % (oid,self.workflow['tasks'][oid]['class']))
    #                 self.create_multi_tasks_again(oid, task_id)
    #             else:
    #                 logger.debug("  MMM returning to task_id %s:" % task_id)
    #                 return
    #     logger.debug("  MMM At end of create multi tasks, returning to task_id %s:" % task_id)


    def create_multi_tasks(self, task_id, parent_id=None):
        """

        Recursive function to create all multi tasks in sequence until no more multi tasks are encounterd in the
        task path.

        :param task_id:
        :return:
        """
        logger.debug("  MMM Creating multi tasks for %s %s" % (self.get_task_name_from_id(task_id), task_id))
        task_stuff = self.workflow['tasks'][task_id]
        parent_task_name = self.get_parent_task_name(task_stuff['name'])
        logger.debug("  MMM Parent task name: %s" % parent_task_name )
        parent_task_guids = self.get_task_ids_for_task_name(parent_task_name)
        logger.debug("  MMM Parent task guids: %s" % parent_task_guids)
        if 'count' not in task_stuff:
            logger.debug("ERROR: Count not defined in task %s" % task_id)
            exit(1)
        task_count_var = task_stuff['count']
        if task_count_var not in self.workflow['data']:
            logger.debug("ERROR: Could not find %s in task data" % task_count_var)
            exit(1)
        # set this task READY, subsequent created tasks will be set READY since copying stuff
        num_tasks_to_create = self.workflow['data'][task_count_var] - 1 # one less than the count since already have 1
        logger.debug("  MMM Going to generate %i new tasks" % num_tasks_to_create)
        for new_task in range(num_tasks_to_create):
            # TODO Don't forget to set permissions!!!
            logger.debug("  MMM Creating new task with name %s" % task_stuff['name'])
            task_key = str(uuid.uuid4())
            self.workflow['tasks'][task_key] = copy.copy(task_stuff)
        # get the entire list of guids for the newly created tasks with that name
        new_task_guids = self.get_task_ids_for_task_name(task_stuff['name'])
        logger.debug("  MMM New task guids for task %s: %s" % ( task_stuff['name'], new_task_guids ))
        self.assign_output_guids_to_parents( parent_task_guids, new_task_guids)
        # Get the outputs of the task and repeat until output task is no longer 'ogis_custom.OgisMultiInstance'
        outputs = task_stuff['outputs']
        for otask_name in outputs:
            otask_ids = self.get_task_ids_for_task_name(otask_name)
            for oid in otask_ids:
                logger.debug("  MMM Examining task %s to see if a task should be created" % oid)
                if self.workflow['tasks'][oid]['class'] == 'ogis_custom.OgisMultiInstance': # TODO And permission is the same?
                    logger.debug("  MMM Creating new multi tasks for task id %s %s" % (oid,self.workflow['tasks'][oid]['class']))
                    self.create_multi_tasks(oid, task_id)
                else:
                    logger.debug("  MMM returning to task_id %s:" % task_id)
                    return
        logger.debug("  MMM At end of create multi tasks, returning to task_id %s:" % task_id)

    def get_parent_task_name(self,task_name):
        for task_id, task_stuff in self.workflow['tasks'].items():
            if task_name in task_stuff['outputs']:
                parent_task_name = task_stuff['name']
                # logger.debug("   +++Parent task name: %s" % parent_task_name)
                return parent_task_name

    def assign_output_guids_to_parents(self, parent_task_guids, new_task_guids):
        for pid in parent_task_guids:
            logger.debug("    AAA PPP parent guid: %s" % pid)
        for ntid in new_task_guids:
            logger.debug("    AAA NNN new task guid: %s " % ntid)
        outputs_per_parent = len(new_task_guids) / len(parent_task_guids)
        for id_num in range(len(parent_task_guids)):
            logger.debug("    PPP Adding to output guids on task %s" % parent_task_guids[id_num])
            task_o_guids = self.workflow['tasks'][parent_task_guids[id_num]]['output_guids']
            logger.debug("    PPP parent task output guids: %s" % task_o_guids)
            range_of_newtask_guids = new_task_guids[id_num*outputs_per_parent:id_num*outputs_per_parent+outputs_per_parent]
            logger.debug("    RRR range of new task guids: %s" % range_of_newtask_guids)
            self.workflow['tasks'][parent_task_guids[id_num]]['output_guids'] = range_of_newtask_guids

    def complete_task(self,task_id):
        logger.debug("Searching for task with id %s" % task_id)
        if task_id not in self.workflow['tasks']:
            logger.debug("Task id %s not found in the workflow" % task_id)
            exit(1)
        self.workflow['tasks'][task_id]['state'] = 'COMPLETE'

    def get_all_ready_tasks_with_permissions(self):
        ready_tasks = []
        for task_id, task_stuff in self.workflow['tasks'].items():
            # logger.debug("GART TASK ID: %25s %30s State: %20s" % (self.workflow['tasks'][task_id]['name'],
            #     task_id, self.workflow['tasks'][task_id]['state']))
            logger.debug("GART: %25s %30s %30s %10s" % (self.workflow['tasks'][task_id]['name'], task_id, self.workflow['tasks'][task_id]['description'],  self.workflow['tasks'][task_id]['state']))

            if self.workflow['tasks'][task_id]['state'] == 'READY':
                # print "TASK STUFF:", task_stuff
                if 'execute_permissions' in task_stuff:
                    permissions = task_stuff['execute_permissions']
                else:
                    permissions = ''
                if 'auto_execute' in task_stuff:
                    auto_execute = 'True'
                else:
                    auto_execute = 'False'
                ready_tasks.append({ 'id': task_id, 'task_name': task_stuff['name'], 'description': task_stuff['description'],
                    'permissions': permissions, 'auto_execute': auto_execute })
        return ready_tasks

    def execute_task(self, task_id, task_input={}):
        logger.debug("+++Executing task %s" % task_id)
        # TODO Make sure task is ready to run
        # TODO Make sure user has credentials to execute
        if 'execute_function' not in self.workflow['tasks'][task_id]:
            logger.debug("No execute function defined for task %s" % task_id)
            exit(1)
        execute_function = self.workflow['tasks'][task_id]['execute_function']
        response = eval('wef.'+execute_function+'('+str(task_input)+')')
        if response['submit'] == True:
            if self.all_condition_values_found(task_id):
                logger.debug("Workflow data before: %s" % str(self.workflow['data']))
                logger.debug("Setting workflow data to %s" % str(response))
                self.workflow['data'].update(response)
                logger.debug("Workflow data is now: %s" % str(self.workflow['data']))
                self.complete_task(task_id)
                # If this task is not of type OgisMultiChoice, set all outputs to READY
                # if self.workflow['tasks'][task_id]['class'] != 'ogis_custom.OgisMultiChoice':
                self.set_outputs_to_ready(self.workflow['tasks'][task_id]['outputs'])
                self.determine_ready_tasks()
            else:
                logger.debug("All condition values for task %s were not met" % task_id)
        else:
            logger.debug("Execute function cancelled.")

    def all_condition_values_found(self,task_id):
        task_data = self.workflow['data']
        #logger.debug("Evaluating conditions with task_data %s" % str(task_data))
        if 'conditions' in self.workflow['tasks'][task_id]:
            for condition in self.workflow['tasks'][task_id]['conditions']:
                logger.debug("Examining Condition %s" % condition)
                try:
                    response = eval(condition['expression'])
                    #logger.debug("Condition %s evaluated successfully" % condition['expression'])
                except Exception as e:
                    #logger.debug("Condition failed to evaluate: %s" % condition['expression'])
                    return False
        return True