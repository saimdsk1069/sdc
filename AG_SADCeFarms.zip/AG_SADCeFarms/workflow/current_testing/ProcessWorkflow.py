import json
import sys
import uuid
import copy
import logging
import workflow_execute_functions as wef
from SpiffWorkflow import Workflow, Task
from SpiffWorkflow.specs import *
from SpiffWorkflow.serializer.json import JSONSerializer
from ogis_custom_serializer import OgisCustomSerializer
from ogis_custom import OgisMultiChoice, OgisExclusiveChoice, OgisMultiInstance, OgisSimple, OgisJoin #, OgisGate

# Logging setup
logger = logging.getLogger(__name__)
logger.setLevel((logging.DEBUG))
fh = logging.FileHandler('process_workflow.log')
fh.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(lineno)d- %(levelname)s - %(message)s')
fh.setFormatter(formatter)
logger.addHandler(fh)

class ProcessWorkflowError(Exception):

    def __init__(self, value):
        self.value = value

    def __str__(self):
        return repr(self.value)

class ProcessWorkflow(object):

    # Hold the permisssions for each task id
    # task_id_permissions = {}

    def __init__(self):
        print "Executing "
        self.serializer = OgisCustomSerializer()

    def set_up(self, wfdoc, init_data={'init_permissions': {}} ):
        # Store init permissions for each task.
        # print "WFDOC:", wfdoc
        self.init_data = init_data
        logger.debug("+++in set_up show init_data: %s" % str(self.init_data))
        with open(wfdoc) as fp:
            workflow_json = fp.read()
        try:
            init_perms, dynamic_perms = self.validate_init_and_dynamic_perms(workflow_json)
            # print "<< Init Perms:", init_perms
            # print "<< Dynamic Perms:", dynamic_perms
        except Exception as e:

            print "Exception:", e
            print "Missing execute permissions on init data"
            raise ProcessWorkflowError('Missing execute permissions on init data')
        try:
            self.wf_spec = WorkflowSpec.deserialize(self.serializer, workflow_json)
        except:
            print "Exception while deserializing workflow doc."
            raise ProcessWorkflowError('Exception while deserializing workflow doc.')
        # Build the task order list
        #++++++++++++++++++++++++++++++++++++-
        # COMMENTED OUT TO SIMPLIFY
        # self.build_task_order_list()
        #++++++++++++++++++++++++++++++++++++-
        # self.taken_path = self.track_workflow(self.wf_spec)
        #print "Creating workflow"
        try:
            self.workflow  = Workflow(self.wf_spec)
        except Exception as wfexcept:
            raise
        # Get Start Task ( Theoretically there could be more than one Start task so get the first since a list
        # is returned.
        start_task = self.workflow.get_tasks_from_spec_name('Start')[0]
        # Set initial data for task ( it should carry through to all of the other tasks )
        start_task.set_data(**{'init_perms': init_perms})
        # Set dynamic permissions for any tasks with dynamic permissions.
        start_task.set_data(**{'dynamic_perms': dynamic_perms})
        # assigned_dynamic_perms will hold any dynamic permissions assigned during the running of a workflow
        assigned_dynamic_perms = {}
        start_task.set_data(**{'assigned_dynamic_perms': assigned_dynamic_perms})
        # Executue the 'Start' task
        self.workflow.complete_task_from_id(start_task.id)

    def validate_init_and_dynamic_perms(self, workflow_json):
        '''

        Make sure that all workflow lanes defined with init_perm: are defined in the init_data value
        for 'init_permission'

        :param workflow_json:
        :return:
        '''
        # print "+++Inside validate_init_perms, init_data:", self.init_data
        doc_json = json.loads(workflow_json)['task_specs']
        # create a set of workflow permissions that are init_perms from all of the tasks
        # init_perm_list = []
        init_perm_dict = {}
        dynamic_perm_dict = {}
        init_data_exec_perms =  self.init_data['init_permissions']
        # print "INIT DATA EXEC PERMS:", init_data_exec_perms
        for task_id,task_stuff in doc_json.items():
            if 'execute_permissions' in task_stuff:
                exec_perm = task_stuff['execute_permissions']
                # create a set of workflow permissions that are init_perms from all of the tasks
                if exec_perm.startswith('init_perm:'):
                    perm_only = exec_perm[exec_perm.find(':')+1:]
                    if perm_only not in init_data_exec_perms:
                        logger.debug("NO MATCH FOR %s in init_data execute_permissions" % perm_only)
                        raise
                    init_perm_dict[task_id] = { perm_only: init_data_exec_perms[perm_only] }
                if exec_perm.startswith('dynamic_perm:'):
                    perm_only = exec_perm[exec_perm.find(':')+1:]
                    dynamic_perm_dict[task_id] = { perm_only: [] }
        return init_perm_dict, dynamic_perm_dict

    def dump_workflow(self):
        self.workflow.dump()

    def show_tasks(self):
        all_tasks = self.workflow.get_tasks()
        logger.debug("Dumping All Tasks:")
        for at in all_tasks:
            logger.debug("All Tasks: %20s %30s %15s %30s " % (at.get_name(), at.get_description(), at.get_state_name(), at.id))
        logger.debug("End Dumping All Tasks:")

    def do_autoexec_tasks(self):
        """
        Check for auto_execute tasks and do them until no more are ready.  One autoexec task
        may fire and make other autoexec tasks ready.
        :return:
        """
        while True:
            autoexec_fired = False
            ready_tasks = self.workflow.get_tasks(Task.READY)
            for rt in ready_tasks:
                task_name = rt.get_name()
                task_id = rt.id
                t_spec = self.workflow.get_task_spec_from_name(task_name)
                try:
                    auth_exec = t_spec.auto_execute
                    logger.debug("Firing autoexec task: %s " % task_name )
                    autoexec_fired = True
                    if self.found_all_params(rt, t_spec):
                        self.workflow.complete_task_from_id(task_id)
                    else:
                        # Throw an error since not all task parameters were set
                        raise ProcessWorkflowError('Missing parameters for ' + task_name)
                except AttributeError as e:
                    pass
            # If no autoexec tasks fired, return
            if not autoexec_fired:
                break

    def found_all_params(self, task, spec):
        """
        Check the task spec to see if it contains all of the required data to execute correctly.
        :param task:
        :param spec:
        :return:
        """
        if isinstance(spec, OgisMultiChoice) or isinstance(spec, OgisExclusiveChoice):
            all_found = True
            conditions = spec.cond_task_specs
            for condition, name in conditions:
                # logger.debug("CONDTION: %s" % condition)
                # serialize the conditions and search for attributes
                ser_cond = condition.serialize(self.serializer)
                for cond in ser_cond:
                    if cond[0] == 'Attrib':
                        # If condition is an attribute, make sure it exists
                        # print ">>>Found Attrib:", cond[1]
                        value = task.get_data(cond[1],'NotFound')
                        # print ">>>TASK DATA VALUE:", value
                        if value == 'NotFound':
                            all_found = False
            return all_found
        elif isinstance(spec, OgisMultiInstance):
            # logger.debug("Checking MultiInstance")
            times = spec.times.serialize(self.serializer)
            value = task.get_data(times,'NotFound')
            # logger.debug("TASK DATA VALUE: %s" % value)
            if value == 'NotFound':
                return False
            return True
        else:
            # logger.debug("Task parameters not being checked")
            return True

    def __get_task_spec_execute_perm(self, task):

        # At this point, only OgisSimple tasks can have the execute_permission function so only check that type
        task_name = task.get_name()
        task_spec = self.workflow.get_task_spec_from_name(task_name)
        if isinstance(task_spec, OgisSimple):
            exec_perm = task_spec.execute_permissions
            return exec_perm
        else:
            logger.debug("Not an OgisSimple Task")
            return ""

    def __get_parent_perm(self,ready_task):
        """

        Take a ready task and get the parent task.  Extract the name, and id to determine if parent has
        permissions assigned.  If so, assign the same permission as the parent.

        :param ready_task:
        :return:
        """
        parent_task = ready_task.parent
        parent_id = parent_task.id
        parent_name = parent_task.get_name()
        # Generate a permission key for the parent
        parent_perm_key = self.__generate_perm_key( parent_name, parent_id)
        logger.debug("+++Parent Perm Key: %s" % parent_perm_key )
        dyn_task_perm = ready_task.get_data( parent_perm_key, 'Undefined')
        logger.debug("+++Task permission for parent task: %s" % dyn_task_perm )
        return dyn_task_perm

    def __check_for_merge_task_completion(self, task_name, ready_tasks_response):
        """

        Check task for merge_task attribute.  If it has it, check to see if all tasks with that name are in a ready
        state.  If all are ready, return true, else return false.

        :param task_name: name of the task to check to see if it is a simple task and all of them that are merge_tasks
            are ready
        :param ready_tasks_response: All tasks currently considered ready.
        :return: True if task is merge task and all with same name are complete.  Also return true if task is not
            an OgisSimple Task.  Return false if task is a merge task and all tasks with the same name are not complete
        """
        task_spec = self.workflow.get_task_spec_from_name(task_name)
        if isinstance(task_spec, OgisSimple):
            logger.debug("---It's an OgisSimple Task, checking for merge_task")
            if hasattr(task_spec, 'merge_task'):
                # It's a merge task.  So check all tasks with that name to make sure they are ready
                logger.debug("---Merge_Task: %s" % task_spec.merge_task)
                same_tasks = self.workflow.get_tasks_from_spec_name(task_name)
                saved_same_task_ids = []
                a_task_is_complete = False
                for t in same_tasks:
                    logger.debug("--- Task %s Task ID: %s State: %s" % ( t.get_name(), t.id, t.get_state_name() ))
                    state = t.get_state_name()
                    saved_same_task_ids.append({'id': t.id, 'state': state})
                    if state == 'COMPLETED':
                        a_task_is_complete = True
                    if state != 'COMPLETED' and state != 'READY':
                        logger.debug("---State not READY or COMPLETED")
                        return False
                logger.debug("---All tasks either READY or COMPLETED")
                if a_task_is_complete:
                    logger.debug("---One of the merge tasks are COMPLETE, the rest should be marked as complete")
                    logger.debug("---saved tasks %s" % str(saved_same_task_ids))
                    for st in saved_same_task_ids:
                        logger.debug("---ID: %s" % st['id'])
                        if st['state'] == 'READY':
                            logger.debug("---Completing task %s" % st['id'])
                            self.workflow.complete_task_from_id(st['id'])
                # All of the merge tasks are in READY state. If a task with that name has already been declared READY,
                # return False so it doesn't get added to the list of ready tasks returned to the client. First set
                # any matching tasks to complete
                logger.debug("---Ready Task ids: %s" % str(saved_same_task_ids))
                for task in ready_tasks_response:
                    if task['task_name'] == task_name:
                        return False
                return True
            else:
                logger.debug("---Not a Merge_Task")
                return True
        else:
            logger.debug("---Not an OgisSimple Task")
            return True

    def get_all_ready_tasks_with_permissions(self):
        # First check to see if any autoexec tasks can be executed
        self.do_autoexec_tasks()
        # Initalize the ready task response
        ready_tasks_response = []
        ready_tasks_dict_resp = {}
        ready_tasks = self.workflow.get_tasks(Task.READY)

        for rt in ready_tasks:
            task_name = rt.get_name()
            logger.debug(">>> Checking ready task %s" % task_name)
            task_description = rt.get_description()
            task_id = rt.id
            # Let's see if we can get init permissiona and dynamic permissions
            init_perms = rt.get_data( 'init_perms', {})
            logger.debug("READY TASK INIT PERMS: %s" % str(init_perms))
            dynamic_perms = rt.get_data( 'dynamic_perms', {})
            logger.debug("READY TASK DYNAMIC PERMS: %s" % str(dynamic_perms))
            # perm_key is the key for a task permission.  In order to be unique, it combines the task name with
            # the task id and the word 'permissions'.  The actual permission is assigned as a value for the key.
            # This is required since multiple tasks with the same name can be created.  Permissions must be assigned
            # to the individual task
            perm_key = self.__generate_perm_key( task_name, task_id)
            logger.debug("Generating Permission Key: %s" % perm_key)
            #
            # TODO Check to see if there are permissions already for that permission key!!!!!!!!
            tpd = rt.get_data( perm_key, 'NotFound')
            logger.debug("SHOWING PERMISSION KEY AFTER GENERATING IT: %s" % tpd)
            #
            # if the task name is in init_perms, get the actual roles from the init_perms for the task,
            # generate a permission key, and assign the permissions to that key by storing in task data
            if task_name in init_perms:
                logger.debug("TASK %s is in INIT PERMS" % task_name)
                role_key = init_perms[task_name].keys()[0]
                logger.debug("Assigning %s to %s" % ( init_perms[task_name][role_key], perm_key ))
                rt.set_data( **{ perm_key: init_perms[task_name]})
            elif task_name in dynamic_perms:
                logger.debug("TASK %s is in DYNAMIC PERMS" % task_name)
                # Permission may have been assigned before, so don't re-do it.
                if rt.get_data( perm_key, 'NotFound') == 'NotFound':
                    # Get a permission from the dynamic_perms for the task, and assign it to the current permission key.
                    # There may be multiple permissions assigned in the case where multiple tasks with the same name
                    # are created.  The number of permissions and their names are assigned when a previous task is
                    # executed.  The data is added in the value for assigned_dynamic_permissions when a task is executed.
                    # Here you only need to get the permission, and pop that value off of the dynamic permission array
                    # so it can't be used again during the workflow.
                    #
                    # Example dynamic_perms ( only one permission per task, but possibly many roles for that permissison ):
                    #
                    # dynamic_perms: { 'task1': { 'MUNI REVIEWER': [ 'muni1', 'muni2', 'muni3' ] } }
                    # get all items for a task name.  There is only one, so it is index 0.  Index 1 is the array of roles
                    logger.debug("dynamic_perms: %s" % str(dynamic_perms[task_name].items()[0]))
                    dyn_perm_values = dynamic_perms[task_name].items()[0]
                    dyn_role = dyn_perm_values[0]
                    logger.debug("dyn_role: %s" % dyn_role)
                    dyn_perms = dyn_perm_values[1]
                    logger.debug("dyn_perms: %s" % dyn_perms)
                    # For a dynamic permission task, check the parent to make sure this task gets the same dynamic
                    # permission that it's parent got, if it is the same role.
                    parent_dyn_perm = self.__get_parent_perm(rt)
                    if parent_dyn_perm != 'Undefined':
                        # Get the key of the permission.  If it matches the dynamic permission of this task, assign
                        # it to this task
                        parent_dyn_role = parent_dyn_perm.items()[0][0]
                        logger.debug("+++ Parent dyn role: %s" % str(parent_dyn_role) )
                        if parent_dyn_role == dyn_role:
                            perm_to_assign = parent_dyn_perm[parent_dyn_role]
                            logger.debug("+++Assigning %s to task" % str(perm_to_assign))
                            logger.debug("Setting task permission to: %s" % { dyn_role: perm_to_assign})
                            logger.debug("Removing permission from task dynamic permissions")
                            # Future could be hold more than one permission type per task
                            for p in perm_to_assign:
                                dynamic_perms[task_name][dyn_role].remove(p)
                            logger.debug("Dynamic perms for task are now: %s" % str(dynamic_perms[task_name].items()[0]))
                            logger.debug("Perm Key is: %s" % perm_key)
                            rt.set_data( **{ perm_key: copy.copy({ dyn_role: perm_to_assign})})
                    else:
                        perm_to_assign = dynamic_perms[task_name][dyn_role].pop(0) # assign it and remove it from the array
                        logger.debug("Popped perm to assign: %s" % perm_to_assign)
                        logger.debug("Updated dynamic perms: %s" % dynamic_perms[task_name])
                        logger.debug("Setting task permission to: %s" % { dyn_role: [perm_to_assign]})
                        logger.debug("Perm Key is: %s" % perm_key)
                        rt.set_data( **{ perm_key: copy.copy({ dyn_role: [perm_to_assign ]})})
                    logger.debug("SHOWING PERMISSION KEY SETTING PERMISSIONS: %s" % rt.get_data( perm_key, 'NotFound'))
            else:
                logger.debug("Task name not in dynamic perms or init perms")
                # task does not have init permissions or dynamic permissions.  The task spec should be checked to see
                # if it has a execute_permissions defined. It will be empty for tasks that are not OgisSimple tasks
                task_exec_perm = self.__get_task_spec_execute_perm(rt)
                logger.debug("Got task exec perm of %s" % task_exec_perm)
                if task_exec_perm == "":
                    logger.debug("EMPTY TASK EXECUTE PERMISSION, SO NOT SETTING IT")
                    logger.debug("!! WARNING, THIS MIGHT INDICATE A MISCONFIGURATION OF THE WORKFLOW.")
                else:
                    logger.debug("GOT THIS TASK EXECUTE PERMISSION. FIND ROLES IN DATABASE %s" % task_exec_perm)
                    rt.set_data( **{ perm_key: { task_exec_perm: [task_exec_perm+':SUBSTITUTE_REAL_ROLE_HERE'] }})
                    # TODO Look up in database the roles associated with the task execute permissions
            task_perm_data = rt.get_data( perm_key, 'NotFound')
            if task_perm_data == 'NotFound':
                logger.debug("??? IS THIS AN ERROR ???")

            task_perms = rt.get_data(perm_key,'NotFound')
            if task_perms == 'NotFound':
                logger.debug("!!! ERROR OCCURRED. NO PERMISSIONS FOR TASK !!!")
            else:
                logger.debug("task_perms: %s" % task_perms)
                task_permissions = task_perms.items()[0][1]
                logger.debug("TASK PERMISSIONS: %s" % task_permissions)
            # Check to see if task is a OgisSimple with merge_task:true.  If so, make sure all tasks with that name
            # are ready.  if not, don't include it in the list.  Also don't include it if it's a merge task with the
            # same name as one added previously.
            if self.__check_for_merge_task_completion(task_name, ready_tasks_response):
                ready_task = { 'task_name': task_name, 'description': task_description, 'id': str(task_id), 'permissions': task_permissions}
                ready_tasks_response.append(ready_task)

        # DEBUG: SHOW ALL TASKS THAT ARE READY
        self.show_tasks()
        # Go through entire list of tasks and return them
        for task in ready_tasks_response:
            logger.debug("READY TASK: %20s %30s %32s %32s" % (task['task_name'], task['description'], task['id'], task['permissions']) )
        return ready_tasks_response

    def get_ready_tasks(self, credentials=None):
        """
             Permissions for a task might also be specified in the 'execute_permissions' task specification.  If that
            is the case, the value for that is used to look up in the 'execute_permissions' dictionary that was loaded
            when the workflow was created.

            Example:

                task spec has "execute_permissions": "workflow_permission"

                The value for the execute permission for the key "workflow_permission" is searched for in the
                execute_permissions workflow dictionary.  If found, the value for that is assigned as the task
                permission.

            Permissions may be assigned when the workflow is created by setting them in the 'execute_permissions'
            dictionary that is passed in when the workflow is created. The values will be another dictionary with
            keys of task names.  The values will be the role ( or user )that has permission to execute that task.

            Permissions for a task might also be assigned dynamically when multiple tasks are created.

        :param credentials:
        :return:
        """
        # First check to see if any autoexec tasks can be executed
        self.do_autoexec_tasks()
        # Debug info
        self.show_tasks()
        # Initalize the ready task response
        ready_tasks_response = []
        ready_tasks_dict_resp = {}
        ready_tasks = self.workflow.get_tasks(Task.READY)

        for rt in ready_tasks:
            task_name = rt.get_name()
            logger.debug("Checking ready task %s" % task_name)
            task_description = rt.get_description()
            task_id = rt.id
            # Let's see if we can get init permissiona and dynamic permissions
            init_perms = rt.get_data( 'init_perms', {})
            logger.debug("READY TASK INIT PERMS: %s" % str(init_perms))
            dynamic_perms = rt.get_data( 'dynamic_perms', {})
            logger.debug("READY TASK DYNAMIC PERMS: %s" % str(dynamic_perms))
            # perm_key is the key for a task permission.  In order to be unique, it combines the task name with
            # the task id and the word 'permissions'.  The actual permission is assigned as a value for the key.
            # This is required since multiple tasks with the same name can be created.  Permissions must be assigned
            # to the individual task
            perm_key = self.__generate_perm_key( task_name, task_id)
            logger.debug("Generating Permission Key: %s" % perm_key)
            #
            # TODO Check to see if there are permissions already for that permission key!!!!!!!!
            tpd = rt.get_data( perm_key, 'NotFound')
            logger.debug("SHOWING PERMISSION KEY AFTER GENERATING IT: %s" % tpd)
            #
            # if the task name is in init_perms, get the actual roles from the init_perms for the task,
            # generate a permission key, and assign the permissions to that key by storing in task data
            if task_name in init_perms:
                logger.debug("TASK %s is in INIT PERMS" % task_name)
                role_key = init_perms[task_name].keys()[0]
                logger.debug("Assigning %s to %s" % ( init_perms[task_name][role_key], perm_key ))
                rt.set_data( **{ perm_key: init_perms[task_name]})
            elif task_name in dynamic_perms:
                logger.debug("TASK %s is in DYNAMIC PERMS" % task_name)
                # Permission may have been assigned before, so don't re-do it.
                if rt.get_data( perm_key, 'NotFound') == 'NotFound':
                    # Get a permission from the dynamic_perms for the task, and assign it to the current permission key.
                    # There may be multiple permissions assigned in the case where multiple tasks with the same name
                    # are created.  The number of permissions and their names are assigned when a previous task is
                    # executed.  The data is added in the value for assigned_dynamic_permissions when a task is executed.
                    # Here you only need to get the permission, and pop that value off of the dynamic permission array
                    # so it can't be used again during the workflow.
                    #
                    # Example dynamic_perms ( only one permission per task, but possibly many roles for that permissison ):
                    #
                    # dynamic_perms: { 'task1': { 'MUNI REVIEWER': [ 'muni1', 'muni2', 'muni3' ] } }
                    # get all items for a task name.  There is only one, so it is index 0.  Index 1 is the array of roles
                    logger.debug("dynamic_perms: %s" % str(dynamic_perms[task_name].items()[0]))
                    dyn_perm_values = dynamic_perms[task_name].items()[0]
                    dyn_role = dyn_perm_values[0]
                    logger.debug("dyn_role: %s" % dyn_role)
                    dyn_perms = dyn_perm_values[1]
                    logger.debug("dyn_perms: %s" % dyn_perms)
                    perm_to_assign = dynamic_perms[task_name][dyn_role].pop(0) # assign it and remove it from the array
                    logger.debug("Perm to assign: %s" % perm_to_assign)
                    logger.debug("Updated dynamic perms: %s" % dynamic_perms[task_name])
                    logger.debug("Setting task permission to: %s" % { dyn_role: [perm_to_assign ]})
                    logger.debug("Perm Key is: %s" % perm_key)
                    rt.set_data( **{ perm_key: copy.copy({ dyn_role: [perm_to_assign ]})})
                    logger.debug("SHOWING PERMISSION KEY SETTING PERMISSIONS: %s" % rt.get_data( perm_key, 'NotFound'))
            else:
                # task does not have init permissions or dynamic permissions.  The task spec should be checked to see
                # if it has a execute_permissions defined. It will be empty for tasks that are not OgisSimple tasks
                task_exec_perm = self.__get_task_spec_execute_perm(rt)
                if task_exec_perm == "":
                    logger.debug("EMPTY TASK EXECUTE PERMISSION, SO NOT SETTING IT")
                    logger.debug("!! WARNING, THIS MIGHT INDICATE A MISCONFIGURATION OF THE WORKFLOW.")
                else:
                    logger.debug("GOT THIS TASK EXECUTE PERMISSION. FIND ROLES IN DATABASE %s" % task_exec_perm)
                    rt.set_data( **{ perm_key: { task_exec_perm: [task_exec_perm+':SUBSTITUTE_REAL_ROLE_HERE'] }})
                    # TODO Look up in database the roles associated with the task execute permissions
            task_perm_data = rt.get_data( perm_key, 'NotFound')
            if task_perm_data == 'NotFound':
                logger.debug("??? IS THIS AN ERROR ???")

            # Check user's roles against task's allowed roles
            credential_roles = credentials['roles']
            task_perms = rt.get_data(perm_key,'NotFound')
            if task_perms == 'NotFound':
                logger.debug("!!! ERROR OCCURRED. NO PERMISSIONS FOR TASK !!!")
            else:
                logger.debug("task_perms: %s" % task_perms)
                task_permissions = task_perms.items()[0][1]
                logger.debug("TASK PERMISSIONS: %s" % task_permissions)
            access_allowed = False
            for perm in task_permissions:
                logger.debug("Checking permission: %s" % perm)
                for role in credential_roles:
                    logger.debug("Checking role: %s" % role)
                    if role == perm:
                        access_allowed = True
            logger.debug("ACCESS: %s" % access_allowed)

            if access_allowed:
                # Check to see if task is a OgisSimple with merge_task:true.  If so, make sure all tasks with that name
                # are ready.  if not, don't include it in the list
                if self.__check_for_merge_task_completion(task_name, ready_tasks_response):
                    ready_task = { 'task_name': task_name, 'description': task_description, 'id': str(task_id)}
                    ready_tasks_response.append(ready_task)
        # DEBUG: SHOW ALL TASKS THAT ARE READY
        self.show_tasks()
        for task in ready_tasks_response:
            logger.debug("--- READY TASK: %20s %40s %32s" % (task['task_name'], task['description'], task['id']))
        return ready_tasks_response

    def __generate_perm_key(self, task_name, task_id):
        """
        Generate a unique permission key

        :param task_name:
        :param task_id:
        :return:
        """
        return task_name + ':' + str(task_id) + ':permissions'

    def get_all_ready_tasks(self):
        """
             Return all tasks that are ready, regardless of permissions

        :return:
        """
        # First check to see if any autoexec tasks can be executed
        self.do_autoexec_tasks()
        # Debug info
        self.show_tasks()
        # Initalize the ready task response
        ready_tasks_response =  []
        ready_tasks = self.workflow.get_tasks(Task.READY)
        for rt in ready_tasks:
            task_name = rt.get_name()
            task_description = rt.get_description()
            task_id = rt.id
            ready_tasks_response.append( { 'name': task_name, 'id': str(task_id), 'description': task_description })
        return ready_tasks_response

    def get_execute_task_name(self, task_id_to_execute ):
        logger.debug("Requesting execute task for id: %s" % task_id_to_execute)
        try:
            task_id_to_execute = uuid.UUID(task_id_to_execute)
        except ValueError:
            logger.debug("Error converting task id into uuid")
            return
        task_to_run = self.workflow.get_task(task_id_to_execute)
        if task_to_run is None:
            logger.debug("No task found for that task id")
            return
        # Get the task spec from the name of the task to execute.  Use the task spec to get the execute function.
        task_spec = self.workflow.get_task_spec_from_name(task_to_run.get_name())
        try:
            execute_function = task_spec.execute_function
            logger.debug("Exec function defined as %s" % execute_function)
            return execute_function
        except AttributeError as e:
            msg = "Execute function "+execute_function+"() is not defined"
            logger.debug(msg)
            logger.debug(e)
            raise ProcessWorkflowError(msg)
            exit(1)

    def execute_task(self, task_id_to_execute, task_input={} ):
        logger.debug("Task execute input: %s" % str(task_input))
        #####  TODO Add logic to test that user has credentials to execute the task
        try:
            task_id_to_execute = uuid.UUID(task_id_to_execute)
        except ValueError:
            logger.debug("Error converting task id into uuid")
            return
        task_to_run = self.workflow.get_task(task_id_to_execute)
        if task_to_run is None:
            logger.debug("No task found for that task id")
            return
        # Get the task spec from the name of the task to execute.  Use the task spec to get the execute function.
        task_spec = self.workflow.get_task_spec_from_name(task_to_run.get_name())
        try:
            execute_function = task_spec.execute_function
            logger.debug("Exec function defined as %s" % execute_function)
            # Execute the function.
            response = eval('wef.'+execute_function+'('+str(task_input)+')')
            if response['submit'] == True:
                logger.debug("Setting workflow data to %s" % response)
                logger.debug("Setting task data to %s" % response)
                # Do stuff if the execute task assigned dynamic permissions
                if 'assigned_dynamic_perms' in response:
                    # Get the dynamic permissions that were assigned in the execute response task
                    assigned_dyn_perms = response['assigned_dynamic_perms']
                    # Get the currently assigned dynamic permissions
                    dynamic_perms = task_to_run.get_data( 'dynamic_perms', {})
                    logger.debug("Before Dynamic Task Perms: %s" % dynamic_perms)
                    logger.debug("Assigning dynamic perms to tasks:")
                    for task,perms in dynamic_perms.items():
                        logger.debug("Looking at task: %s" % task)
                        for role,perm_list in perms.items():
                            logger.debug("role: %s permlist: %s" % ( role, perm_list ) )
                            for assigned_role, assigned_perm in assigned_dyn_perms.items():
                                logger.debug("Checking %s assigned_perm: %s" % ( assigned_role, assigned_perm) )
                                if role == assigned_role:
                                    logger.debug("Matched perm: %s" % dynamic_perms[task][role])
                                    dynamic_perms[task][role] = copy.copy(assigned_perm)
                    dynamic_perms = task_to_run.get_data( 'dynamic_perms', {})
                    logger.debug("After Dynamic Task Perms: %s" % dynamic_perms)

                task_to_run.set_data(**response)
                # TODO: Determine if task should complete if no execute function was done.
                if self.found_all_params(task_to_run, task_spec):
                    logger.debug("Found all parameters, completing task %s" % task_id_to_execute)
                    logger.debug("Completing task %s" % task_id_to_execute)
                    self.complete_task(task_id_to_execute)
                    logger.debug("After completing task")
                else:
                    # Throw an error since not all task parameters were set
                    logger.debug("++++ERROR!! Not all parameters were found, not completing task %s" % task_id_to_execute)
                    raise ProcessWorkflowError('Missing parameters for ' + task_to_run.get_name)
            else:
                # Submit was false ( Cancel was hit instead????)
                logger.debug("Execute function was canceled.")
        except AttributeError as e:
            msg = "Execute function "+execute_function+"() is not defined"
            logger.debug(msg)
            logger.debug(e)
            raise ProcessWorkflowError(msg)
            exit(1)

    def complete_task(self, task_id_to_run):
        logger.debug("Inside complete_task Completing task: %s" % task_id_to_run)
        self.workflow.complete_task_from_id(task_id_to_run)


