import json
import sys
import uuid
import workflow_execute_functions as wef
from SpiffWorkflow import Workflow, Task
from SpiffWorkflow.specs import *
from SpiffWorkflow.serializer.json import JSONSerializer
from ogis_custom_serializer import OgisCustomSerializer
from ogis_custom import OgisMultiChoice, OgisExclusiveChoice, OgisMultiInstance, OgisSimple, OgisJoin #, OgisGate

class ProcessWorkflowError(Exception):

    def __init__(self, value):
        self.value = value

    def __str__(self):
        return repr(self.value)

class ProcessWorkflow(object):

    # Hold the permisssions for each task id
    # task_id_permissions = {}

    def __init__(self):
        print "Executing "
        self.serializer = OgisCustomSerializer()

    def set_up(self, wfdoc, init_data={'execute_permissions': {}} ):
        # Store init permissions for each task.
        # print "WFDOC:", wfdoc
        self.init_data = init_data
        print "+++in set_up show init_data:", self.init_data
        with open(wfdoc) as fp:
            workflow_json = fp.read()
        try:
            self.validate_init_perms(workflow_json)
        except:
            print "Missing execute permissions on init data"
            raise ProcessWorkflowError('Missing execute permissions on init data')
        try:
            self.wf_spec = WorkflowSpec.deserialize(self.serializer, workflow_json)
        except:
            print "Exception while deserializing workflow doc."
            raise ProcessWorkflowError('Exception while deserializing workflow doc.')
        # Build the task order list
        #++++++++++++++++++++++++++++++++++++-
        # COMMENTED OUT TO SIMPLIFY
        # self.build_task_order_list()
        #++++++++++++++++++++++++++++++++++++-
        # self.taken_path = self.track_workflow(self.wf_spec)
        #print "Creating workflow"
        try:
            self.workflow  = Workflow(self.wf_spec)
        except Exception as wfexcept:
            raise
        # Execute 'Start' task
        start_task = self.workflow.get_tasks_from_spec_name('Start')
        self.workflow.complete_task_from_id(start_task[0].id)
        # self.task_ids_for_data = []
        # self.workflow_data_dict = init_data

    def validate_init_perms(self, workflow_json):
        print "+++Inside validate_init_perms, init_data:", self.init_data
        doc_json = json.loads(workflow_json)['task_specs']
        # create a set of workflow permissions that are init_perms from all of the tasks
        init_perm_list = []
        for task_id,task_stuff in doc_json.items():
            if 'execute_permissions' in task_stuff:
                exec_perm = task_stuff['execute_permissions']
                # print "Task ID:", task_id
                # print "    Task Name:", task_stuff['description']
                # print "    Execute Permissions:", task_stuff['execute_permissions']
                # create a set of workflow permissions that are init_perms from all of the tasks
                if exec_perm.startswith('init_perm:'):
                    perm_only = exec_perm[exec_perm.find(':')+1:]
                    # print "+++PermOnly:",perm_only
                    init_perm_list.append(perm_only)
        init_perm_set = set(init_perm_list)
        # print "INIT PERM SET:", init_perm_set
        init_data_exec_perms =  self.init_data['execute_permissions']
        for perm in init_perm_set:
            if perm not in init_data_exec_perms:
                print "NO MATCH FOR %s in init_data execute_permissions" % perm
                raise

    def dump_workflow(self):
        self.workflow.dump()

    def show_tasks(self):
        all_tasks = self.workflow.get_tasks()
        for at in all_tasks:
            print "All Tasks: %20s %15s %30s " % (at.get_name(), at.get_state_name(), at.id)

    def __check_task_for_creds(self, credentials, current_task_permissions):
        print "+++Current Task Permissions:", current_task_permissions
        if credentials['id'] == current_task_permissions:
            return True
        for role in credentials['roles']:
            if role == current_task_permissions:
                return True
        return False

    def do_autoexec_tasks(self):
        """
        Check for auto_execute tasks and do them until no more are ready.  One autoexec task
        may fire and make other autoexec tasks ready.
        :return:
        """
        while True:
            autoexec_fired = False
            ready_tasks = self.workflow.get_tasks(Task.READY)
            for rt in ready_tasks:
                task_name = rt.get_name()
                task_id = rt.id
                # print "+++ task name:", task_name
                t_spec = self.workflow.get_task_spec_from_name(task_name)
                try:
                    auth_exec = t_spec.auto_execute
                    print "+++Firing autoexec task:", task_name
                    autoexec_fired = True
                    if self.found_all_params(rt, t_spec):
                        self.workflow.complete_task_from_id(task_id)
                    else:
                        # Throw an error since not all task parameters were set
                        raise ProcessWorkflowError('Missing parameters for ' + task_name)
                except AttributeError as e:
                    pass
            # If no autoexec tasks fired, return
            if not autoexec_fired:
                # print "+++No more autoexec tasks"
                break

    def found_all_params(self, task, spec):
        """
        Check the task spec to see if it contains all of the required data to execute correctly.
        :param task:
        :param spec:
        :return:
        """
        if isinstance(spec, OgisMultiChoice) or isinstance(spec, OgisExclusiveChoice):
            # print ">> Checking MultiChoice"
            all_found = True
            conditions = spec.cond_task_specs
            for condition, name in conditions:
                # print "CONDTION:", condition
                # serialize the conditions and search for attributes
                ser_cond = condition.serialize(self.serializer)
                for cond in ser_cond:
                    if cond[0] == 'Attrib':
                        # If condition is an attribute, make sure it exists
                        # print ">>>Found Attrib:", cond[1]
                        value = task.get_data(cond[1],'NotFound')
                        # print ">>>TASK DATA VALUE:", value
                        if value == 'NotFound':
                            all_found = False
            return all_found
        elif isinstance(spec, OgisMultiInstance):
            # print ">> Checking MultiInstance"
            times = spec.times.serialize(self.serializer)
            value = task.get_data(times,'NotFound')
            # print ">>>TASK DATA VALUE:", value
            if value == 'NotFound':
                return False
            return True
        else:
            # print "+++Task parameters not being checked"
            return True


    def __get_task_spec_execute_perm(self, perm_key, task):
        """
        Check the task specification for the key 'execute_permission'.  If found,
        get the value and then look it up in the workflow 'execute_permissions' dictionary.

        :param perm_key:
        :param task:
        :return:
        """
        # At this point, only OgisSimple tasks can have the execute_permission function so only check that type
        task_name = task.get_name()
        task_spec = self.workflow.get_task_spec_from_name(task_name)
        if isinstance(task_spec, OgisSimple):
            try:
                exec_perm = task_spec.execute_permissions
                print "+++Found Execute Permission on the task:", exec_perm
                # Strip off 'init_perm:' if it is on the task's execute_permission
                if exec_perm.startswith('init_perm:'):
                    exec_perm = exec_perm[exec_perm.find(':')+1:]
                # Look up the value in the workflow init data
                print "+++INIT DATA:", self.init_data
                if exec_perm in self.init_data['execute_permissions']:
                    task_perm = self.init_data['execute_permissions'][exec_perm]
                    print "Found permission in init data:",task_perm
                    # Assign the permission to the task data
                    task.set_data(**{perm_key: task_perm})
                    return True
                else:
                    print "+++No match for execute permissions on init_data"
                    return False
            except Exception as e:
                print "+++Execute Permission not found for task"
                return False
        else:
            print "+++Not an OgisSimple Task"
            return False

    def __inputs_are_completed(self, workflow, task):
        """

        Determine if input tasks for a ready tasks are all completed.

        :param task: Task to extract incoming task names from
        :return:
        """
        task_name = task.get_name()
        task_description = task.get_description()
        # Get the task spec associated with the task name
        task_spec = self.workflow.get_task_spec_from_name(task_name)
        # Process only OgisSimple tasks
        if not isinstance(task_spec, OgisSimple):
            return True
        else:
            for i_task_name in task_spec.input_tasks:
                # print "INPUTS FOR TASK %s: %s" % (task_description, i_task_name)
                # Check input tasks to make sure that all inputs are in 'COMPLETED' state.  If any are not,
                # return False
                i_tasks = workflow.get_tasks_from_spec_name(i_task_name)
                for task in i_tasks:
                    # print "STATUS OF TASK %s is %s" % (i_task_name, Task.state_names[task.get_state()])
                    if Task.state_names[task.get_state()] != 'COMPLETED':
                        return False
            return True

    def get_ready_tasks(self, credentials=None):
        """
             Permissions for a task might also be specified in the 'execute_permissions' task specification.  If that
            is the case, the value for that is used to look up in the 'execute_permissions' dictionary that was loaded
            when the workflow was created.

            Example:

                task spec has "execute_permissions": "workflow_permission"

                The value for the execute permission for the key "workflow_permission" is searched for in the
                execute_permissions workflow dictionary.  If found, the value for that is assigned as the task
                permission.

            Permissions may be assigned when the workflow is created by setting them in the 'execute_permissions'
            dictionary that is passed in when the workflow is created. The values will be another dictionary with
            keys of task names.  The values will be the role ( or user )that has permission to execute that task.

            Permissions for a task might also be assigned dynamically when multiple tasks are created.

        :param credentials:
        :return:
        """
        # First check to see if any autoexec tasks can be executed
        self.do_autoexec_tasks()
        # Debug info
        self.show_tasks()
        # Initalize the ready task response
        ready_tasks_response = []
        ready_tasks_dict_resp = {}
        ready_tasks_foo = {}
        ready_tasks = self.workflow.get_tasks(Task.READY)
        # print "+++Processing Ready Tasks."

        for rt in ready_tasks:

            task_name = rt.get_name()
            task_description = rt.get_description()
            task_id = rt.id
            # for foo in dir(rt):
            #     print "rtstuff:", foo
            # perm_key is the key for a task permission.  In order to be unique, it combines the task name with
            # the task id and the word 'permissions'.  The actual permission is assigned as a value for the key.
            # This is required since multiple tasks with the same name can be created.  Permissions must be assigned
            # to the individual task
            perm_key = self.__generate_perm_key( task_name, task_id)
            print "+++Generating Permission Key:", perm_key
            # Check the task to see if a permission key has been assigned
            task_perm_data = rt.get_data( perm_key, 'NotFound')
            # Try to assign permissions if the task hasn't had any assigned yet.
            if task_perm_data == 'NotFound':
                # Check to see if execute_permissions is set on the task spec
                if self.__get_task_spec_execute_perm(perm_key, rt):
                    # print "+++Got execute permission from task spec"
                    print ""
                # Permission not set on task spec so check for initial data and dynamic permissions
                else:
                    print "+++No execute perm in task spec"
                    print "+++Self init data:", self.init_data
                    # Check the initial 'execute_permssions' dictionary for the task name.  If found, it contains
                    # the permssion to assign to the task
                    if task_name in self.init_data['execute_permissions']:
                        print "+++Task name in execute permissions"
                        perm = self.init_data['execute_permissions'][task_name]
                        print "+++Task permission:", perm
                        rt.set_data( **{ perm_key: perm})
                    else:
                        # Set a dynamic task permission.  This can be found if the task name was saved to
                        # task data previously.
                        dyn_task_perm = rt.get_data( task_name, 'NotFound')
                        if dyn_task_perm == 'NotFound':
                            # Check the parent for a dynamic task permission.  If found, assign it to this task.
                            # print "+++Dynamic task permission for", task_name, "not found."
                            # print "+++PARENT TASK ID:", rt.parent.id
                            perm = self.__get_parent_dyn_perm(rt)
                            # print "+++New dynamic task permission:", perm
                            rt.set_data( **{ perm_key: perm})
                        else:
                            # There may be several dynamic permissions for a given task name.  This is because
                            # there may be multiple tasks created with the same task name for different roles.
                            # Example would be when multiple municipality review tasks are created and each one
                            # must be assigned execute permission by a different role.
                            # print "+++Dynamic task permissions for", task_name, "is ", dyn_task_perm
                            # print "+++Number of dynamic task permissions:", len(dyn_task_perm)
                            # For the current task, assign the first element of dyn_task_perm list to that task
                            # Then remove the task from the array
                            # print "+++---Workflow data before pop", self.workflow.data
                            perm = dyn_task_perm.pop(0)
                            # print "+++---Workflow data after pop", self.workflow.data
                            # print "+++Number of task permissions after removing:", len(dyn_task_perm)
                            # Set the permission for that task by adding to the task data
                            rt.set_data( **{ perm_key: perm})
                # Permission was initally not set.  Now the permission for the task has been set so re-retrieve it
                task_perm_data = rt.get_data( perm_key, 'NotFound')
                # print "+++SHOWING TASK PERM:", perm_key, task_perm_data
            # Check the task to see if the user's credentials allows the task to be seen by the user
            # TODO TEST WITH MULTI PARALLEL TASKS ( e.g. Multiple muni review tasks )!!!!!!!!
            if self.__is_task_ready(rt):
                # print "\\\ READY: %17s %30s %36s %s" % ( task_name, task_description, str(task_id), task_perm_data)
                if credentials is not None:
                    if self.__check_task_for_creds(credentials, task_perm_data):
                        # if task_name in ready_tasks_dict_resp:
                        #     ready_tasks_dict_resp[task_name]['perm'].append({str(task_id): task_perm_data})
                        # else:
                        #     ready_tasks_dict_resp[task_name] = {'description': task_description, 'perm': [{str(task_id):task_perm_data}]}
                        if task_perm_data in ready_tasks_dict_resp:
                            # Permission key has been added to the response
                            if task_name in ready_tasks_dict_resp[task_perm_data]:
                                ready_tasks_dict_resp[task_perm_data][task_name]['id'].append(str(task_id))
                            else:
                                ready_tasks_dict_resp[task_perm_data][task_name] = { 'description': task_description, 'id': []}
                        else:
                            print "---Perm %s not in ready tasks" % task_perm_data
                            ready_tasks_dict_resp[task_perm_data] = {}
                            ready_tasks_dict_resp[task_perm_data][task_name] = { 'description': task_description, 'id': [str(task_id)]}

                else:
                    # if task_name in ready_tasks_dict_resp:
                    #     ready_tasks_dict_resp[task_name]['perm'].append({str(task_id): task_perm_data})
                    # else:
                    #     ready_tasks_dict_resp[task_name] = {'description': task_description, 'perm': [{str(task_id):task_perm_data}]}
                    #---NEW
                    if task_perm_data in ready_tasks_dict_resp:
                        # Permission key has been added to the response
                        if task_name in ready_tasks_dict_resp[task_perm_data]:
                            ready_tasks_dict_resp[task_perm_data][task_name]['id'].append(str(task_id))
                        else:
                            ready_tasks_dict_resp[task_perm_data][task_name] = { 'description': task_description, 'id': [str(task_id)]}
                    else:
                        print "---Perm %s not in ready tasks" % task_perm_data
                        ready_tasks_dict_resp[task_perm_data] = {}
                        ready_tasks_dict_resp[task_perm_data][task_name] = { 'description': task_description, 'id': [str(task_id)]}

        print "%%% READY TASKS:"
        for perm, tasks in ready_tasks_dict_resp.items():
            for task_name, details in tasks.items():
                print "%%% READY:", perm, task_name, details['description'], details['id']
        return ready_tasks_dict_resp

    def __is_task_ready(self, ready_task):
        task_name = ready_task.get_name()
        task_spec = self.workflow.get_task_spec_from_name(task_name)
        try:
            mt = task_spec.merge_task
            # It's a merge task, so make sure all tasks with that name are complete before saying it is ready
            all_tasks_with_this_name = self.workflow.get_tasks_from_spec_name(task_name)
            for task in all_tasks_with_this_name:
                task_state = Task.state_names[task.get_state()]
                if task_state != 'READY':
                    # print "+++Task %s is not ready" % task_name
                    return False
            # print "+++Task %s is ready" % task_name
            return True
        except Exception as e:
            # Not a merge task, so assume it is ready
            # print "+++Task %s is ready" % task_name
            return True

    def __determine_actual_ready_tasks(self, ready_dict):
        new_r_dict = {}
        for task_name, details in ready_dict.items():
            print "+++Checking task", task_name
            all_tasks_with_this_name = self.workflow.get_tasks_from_spec_name(task_name)
            for task in all_tasks_with_this_name:
                task_state = Task.state_names[task.get_state()]
                print "  +++Checking task", task.get_name(), task.id, task_state
                parent_task = task.parent
                parent_id = parent_task.id
                parent_name = parent_task.get_name()
                print "      +++Parent Task:", parent_name, parent_id, Task.state_names[parent_task.get_state()]


    def __get_parent_dyn_perm(self,ready_task):
        """

        Take a ready task and get the parent task.  Extract the name, and id to determine if parent has
        dynamic permissions assigned.  If so, assign the same permission as the parent.

        :param ready_task:
        :return:
        """
        parent_task = ready_task.parent
        parent_id = parent_task.id
        parent_name = parent_task.get_name()
        # Generate a permission key for the parent
        parent_perm_key = self.__generate_perm_key( parent_name, parent_id)
        # print "+++Parent Perm Key:", parent_perm_key
        dyn_task_perm = ready_task.get_data( parent_perm_key, 'NotFound')
        # print "+++Dynamic task permission for parent task:", dyn_task_perm
        return dyn_task_perm


    def __generate_perm_key(self, task_name, task_id):
        """
        Generate a unique permission key

        :param task_name:
        :param task_id:
        :return:
        """
        return task_name + ':' + str(task_id) + ':permissions'

    def get_ids_for_credentials(self, task_to_do, ready_tasks_for_perm):
        """

        Currently not needed.

        :param task_to_do: the task to execute
        :param ready_tasks_for_perm: - list of tasks already filtered by permission
        :return:
        """

        # List of tasks that can be executed with the credentials supplied
        #tasks_to_execute = []
        # print "+++CHECK TASK PERMS:", check_task_perms
        # print "+++CREDENTIALS:", credentials
        # # check_task_perms is a list of dictionaries in the form of [{ task_id: task_permission }, ...]
        # # Loop through the task_perms and check against credentials to see if it matches
        # for id_perm in check_task_perms:
        #     print "+++ID_PERM:", id_perm
        #     for t_id, perm in id_perm.items():
        #         for role in credentials['roles']:
        #             if perm == role:
        #                 print "+++MATCH ON CREDS:", t_id, perm
        #                 tasks_to_execute.append(t_id)
        #             else:
        #                 print "+++NO MATCH ON CREDS:", t_id, perm
        #
        # return tasks_to_execute
        print "GOT IDS FOR CREDS:", ready_tasks_for_perm[task_to_do]['id']
        return ready_tasks_for_perm[task_to_do]['id']

    def get_all_ready_tasks(self):
        """
             Return all tasks that are ready, regardless of permissions

        :return:
        """
        # First check to see if any autoexec tasks can be executed
        self.do_autoexec_tasks()
        # Debug info
        self.show_tasks()
        # Initalize the ready task response
        ready_tasks_response =  []
        ready_tasks = self.workflow.get_tasks(Task.READY)
        for rt in ready_tasks:
            task_name = rt.get_name()
            task_description = rt.get_description()
            task_id = rt.id
            ready_tasks_response.append( { 'name': task_name, 'id': str(task_id), 'description': task_description })
        return ready_tasks_response

    def execute_task(self, task_ids_to_execute ):
        """
        Multiple tasks with the same name might be in 'READY' state.  An example would be on an implicit merge from
        a previous branch.  When both taskB and taskA complete, 2 taskC's will go ready.

                / taskB \
        task1 -          ---- TaskC X 2
                \ taskA /

        :param task_ids_to_execute:
        :return:
        """
        # Get the first id from the task id list. That is the task that will be used to run the execute_function.
        # The rest of the ids in the list will be used to complete the task.
        task_id_to_run = task_ids_to_execute[0]
        try:
            task_id_to_run = uuid.UUID(task_id_to_run)
        except ValueError:
            #TODO: Error Message???
            return
        # Get the task for that id
        task_to_run = self.workflow.get_task(task_id_to_run)
        if task_to_run is None:
            #TODO: Error Message????
            return
        # Get the task spec from the name of the task to execute.  Use the task spec to get the execute function.
        task_spec = self.workflow.get_task_spec_from_name(task_to_run.get_name())
        try:
            execute_function = task_spec.execute_function
            print "+++Exec function defined as", execute_function
            # Execute the function.  If user does submit from the function,
            response = eval('wef.'+execute_function+'()')
            if response['submit'] == True:
                # print "+++>>>Setting workflow data to ", response
                # self.set_workflow_data(response)
                print "+++>>>Setting task data to ", response
                task_to_run.set_data(**response)
                # TODO: Determine if task should complete if no execute function was done.
                print "Completing task", task_id_to_run
                if self.found_all_params(task_to_run, task_spec):
                    print "++++Found all parameters, completing task(s)", task_ids_to_execute
                    # Since there may be multiple tasks with the same name, complete all of those tasks at the same
                    # time.
                    print "THERE ARE %i tasks to execute" % len(task_ids_to_execute), task_ids_to_execute
                    for t_id in task_ids_to_execute:
                        print "+++++Completing task", t_id
                        self.complete_task(uuid.UUID(t_id))
                        print "+++++After completing task", t_id
                    self.show_tasks()
                else:
                    # Throw an error since not all task parameters were set
                    raise ProcessWorkflowError('Missing parameters for ' + task_to_run.get_name)
            else:
                # Submit was false ( Cancel was hit instead????)
                print "Execute function was canceled."
        except AttributeError as e:
            msg = "Execute function "+execute_function+"() is not defined"
            print msg
            print e
            raise ProcessWorkflowError(msg)
            exit(1)


    def set_workflow_data(self, data_to_set):
        """

        :param data_to_set: Dictionary of data to add to the workflow
        :return:
        """
        print "---WORKFLOW DATA TO SET:", data_to_set
        for key, value in data_to_set.items():
            self.workflow.data.update({key:value})


    def complete_task(self, task_id_to_run):
        print "Completing task:", task_id_to_run
        self.workflow.complete_task_from_id(task_id_to_run)


