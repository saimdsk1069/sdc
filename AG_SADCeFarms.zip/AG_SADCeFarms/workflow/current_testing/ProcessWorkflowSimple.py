import json
import sys
import uuid
import workflow_execute_functions as wef
from SpiffWorkflow import Workflow, Task
from SpiffWorkflow.specs import *
from SpiffWorkflow.serializer.json import JSONSerializer
from ogis_custom_serializer import OgisCustomSerializer
from ogis_custom import OgisMultiChoice, OgisExclusiveChoice, OgisMultiInstance, OgisSimple, OgisJoin #, OgisGate

class ProcessWorkflowError(Exception):

    def __init__(self, value):
        self.value = value

    def __str__(self):
        return repr(self.value)

class ProcessWorkflow(object):

    # Hold the permisssions for each task id
    # task_id_permissions = {}

    def __init__(self):
        print "Executing "
        self.serializer = OgisCustomSerializer()

    def set_up(self, wfdoc, init_data={} ):
        # Store init permissions for each task.
        # print "WFDOC:", wfdoc
        self.init_data = init_data
        with open(wfdoc) as fp:
            workflow_json = fp.read()
        try:
            self.wf_spec = WorkflowSpec.deserialize(self.serializer, workflow_json)
        except:
            print "Exception while deserializing workflow doc."
            raise
        # Build the task order list
        #++++++++++++++++++++++++++++++++++++-
        # COMMENTED OUT TO SIMPLIFY
        # self.build_task_order_list()
        #++++++++++++++++++++++++++++++++++++-
        # self.taken_path = self.track_workflow(self.wf_spec)
        #print "Creating workflow"
        try:
            self.workflow  = Workflow(self.wf_spec)
        except Exception as wfexcept:
            raise
        # Execute 'Start' task
        start_task = self.workflow.get_tasks_from_spec_name('Start')
        start_task[0].set_data(**self.init_data)
        self.workflow.complete_task_from_id(start_task[0].id)
        # self.task_ids_for_data = []
        # self.workflow_data_dict = init_data

    def dump_workflow(self):
        self.workflow.dump()

    def show_tasks(self):
        all_tasks = self.workflow.get_tasks()
        for at in all_tasks:
            print "All Tasks: %20s %15s %30s " % (at.get_name(), at.get_state_name(), at.id)

    def __check_task_for_creds(self, credentials, current_task_permissions):
        if credentials['id'] == current_task_permissions:
            return True
        for role in credentials['roles']:
            if role == current_task_permissions:
                return True
        return False

    def do_autoexec_tasks(self):
        """
        Check for auto_execute tasks and do them until no more are ready.  One autoexec task
        may fire and make other autoexec tasks ready.
        :return:
        """
        while True:
            autoexec_fired = False
            ready_tasks = self.workflow.get_tasks(Task.READY)
            for rt in ready_tasks:
                task_name = rt.get_name()
                task_id = rt.id
                # print "+++ task name:", task_name
                t_spec = self.workflow.get_task_spec_from_name(task_name)
                try:
                    auth_exec = t_spec.auto_execute
                    print "+++Firing autoexec task:", task_name
                    autoexec_fired = True
                    if self.found_all_params(rt, t_spec):
                        self.workflow.complete_task_from_id(task_id)
                    else:
                        # Throw an error since not all task parameters were set
                        raise ProcessWorkflowError('Missing parameters for ' + task_name)
                except AttributeError as e:
                    pass
            # If no autoexec tasks fired, return
            if not autoexec_fired:
                # print "+++No more autoexec tasks"
                break

    def found_all_params(self, task, spec):
        """
        Check the task spec to see if it contains all of the required data to execute correctly.
        :param task:
        :param spec:
        :return:
        """
        if isinstance(spec, OgisMultiChoice) or isinstance(spec, OgisExclusiveChoice):
            # print ">> Checking MultiChoice"
            all_found = True
            conditions = spec.cond_task_specs
            for condition, name in conditions:
                # print "CONDTION:", condition
                # serialize the conditions and search for attributes
                ser_cond = condition.serialize(self.serializer)
                for cond in ser_cond:
                    if cond[0] == 'Attrib':
                        # If condition is an attribute, make sure it exists
                        # print ">>>Found Attrib:", cond[1]
                        value = task.get_data(cond[1],'NotFound')
                        # print ">>>TASK DATA VALUE:", value
                        if value == 'NotFound':
                            all_found = False
            return all_found
        elif isinstance(spec, OgisMultiInstance):
            # print ">> Checking MultiInstance"
            times = spec.times.serialize(self.serializer)
            value = task.get_data(times,'NotFound')
            # print ">>>TASK DATA VALUE:", value
            if value == 'NotFound':
                return False
            return True
        else:
            # print "+++Task parameters not being checked"
            return True

    def __get_task_spec_execute_perm(self, perm_key, task):
        """
        Check the task specification for the key 'execute_permission'.  If found,
        get the value and then look it up in the workflow 'execute_permissions' dictionary.

        :param perm_key:
        :param task:
        :return:
        """
        # At this point, only OgisSimple tasks can have the execute_permission function so only check that type
        task_name = task.get_name()
        task_spec = self.workflow.get_task_spec_from_name(task_name)
        if isinstance(task_spec, OgisSimple):
            try:
                exec_perm = task_spec.execute_permissions
                # print "+++Found Execute Permission on the task:", exec_perm
                # Look up the value in the workflow init data
                # print "+++INIT DATA:", self.init_data
                if exec_perm in self.init_data['execute_permissions']:
                    task_perm = self.init_data['execute_permissions'][exec_perm]
                    # print "Found permission in init data:",task_perm
                    # Assign the permission to the task data
                    task.set_data(**{perm_key: task_perm})
                    return True
            except Exception as e:
                # print "+++Execute Permission not found for task"
                return False
        else:
            # print "+++Not an OgisSimple Task"
            return False

    def get_ready_tasks(self, credentials=None):
        """
             Permissions for a task might also be specified in the 'execute_permissions' task specification.  If that
            is the case, the value for that is used to look up in the 'execute_permissions' dictionary that was loaded
            when the workflow was created.

            Example:

                task spec has "execute_permissions": "workflow_permission"

                The value for the execute permission for the key "workflow_permission" is searched for in the
                execute_permissions workflow dictionary.  If found, the value for that is assigned as the task
                permission.

            Permissions may be assigned when the workflow is created by setting them in the 'execute_permissions'
            dictionary that is passed in when the workflow is created. The values will be another dictionary with
            keys of task names.  The values will be the role ( or user )that has permission to execute that task.

            Permissions for a task might also be assigned dynamically when multiple tasks are created.

        :param credentials:
        :return:
        """
        # First check to see if any autoexec tasks can be executed
        self.do_autoexec_tasks()
        # Debug info
        self.show_tasks()
        # Initalize the ready task response
        ready_tasks_response =  []
        ready_tasks = self.workflow.get_tasks(Task.READY)
        for rt in ready_tasks:
            task_name = rt.get_name()
            task_description = rt.get_description()
            task_id = rt.id
            ready_tasks_response.append( { 'name': task_name, 'id': str(task_id), 'description': task_description })
        return ready_tasks_response

    def __generate_perm_key(self, task_name, task_id):
        """
        Generate a unique permission key

        :param task_name:
        :param task_id:
        :return:
        """
        return task_name + ':' + str(task_id) + ':permissions'

    def user_has_execute_permission(self, check_task_id, credentials):
        """

        From the task id and user credentials, check to see if that user has execute permission on the task.

        :param check_task_id:
        :param credentials:
        :return: True if user's credentials allow execute permission.  False if not.
        """
        # Get the task name from task_id
        # convert string id to uuid
        try:
            check_task_id = uuid.UUID(check_task_id)
        except ValueError:
            #TODO: Error Message??? Only way this could happen is if id was faked
            return
        task_to_check = self.workflow.get_task(check_task_id)
        task_name_to_check = task_to_check.get_name()
        print "CHECKING TASK:", task_to_check.get_name()
        # Generate a permission key for the task
        perm_key = self.__generate_perm_key(task_name_to_check, check_task_id)
        print "Permission key:", perm_key
        task_perm_data = task_to_check.get_data( perm_key, 'NotFound')
        print "B4 check task for creds:", credentials, task_perm_data
        if self.__check_task_for_creds(credentials, task_perm_data):
            return True
        else:
            return False

    def get_all_ready_tasks(self):
        """
             Return all tasks that are ready, regardless of permissions

        :return:
        """
        # First check to see if any autoexec tasks can be executed
        self.do_autoexec_tasks()
        # Debug info
        self.show_tasks()
        # Initalize the ready task response
        ready_tasks_response =  []
        ready_tasks = self.workflow.get_tasks(Task.READY)
        for rt in ready_tasks:
            task_name = rt.get_name()
            task_description = rt.get_description()
            task_id = rt.id
            ready_tasks_response.append( { 'name': task_name, 'id': str(task_id), 'description': task_description })
        return ready_tasks_response

    # def execute_task(self, task_id_to_run, UserSelection):
    def execute_task(self, task_id_to_run ):
        """

        :param task_id_to_run:
        :return:
        """
        # TODO Check Permissions!!!!!!!
        # convert string id to uuid
        try:
            task_id_to_run = uuid.UUID(task_id_to_run)
        except ValueError:
            #TODO: Error Message???
            print "ERROR CONVERTING TASK ID TO UUID"
            return
        task_to_run = self.workflow.get_task(task_id_to_run)
        if task_to_run is None:
            #TODO: Error Message????
            return

        self.complete_task(task_id_to_run)


    def complete_task(self, task_id_to_run):
        self.workflow.complete_task_from_id(task_id_to_run)

