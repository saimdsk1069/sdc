import xml.etree.ElementTree as ET
import sys
import json
import pickle
import copy
from base64 import b64encode, b64decode

def encode_threshold(raw_type, value):
    """
    Encode a value for threshold

    :param raw_type: 's' for string, 'i' for integer
    :param value: the string or integer to be converted
    :return: the base64 pickled string
    """
    if raw_type != 's' and raw_type != 'i':
        print "Invalid input, must be 's' or 'i'"
        exit()
    if raw_type == 's':
        e_string = b64encode(pickle.dumps(value, protocol=pickle.HIGHEST_PROTOCOL))
    else:
        e_string = b64encode(pickle.dumps(int(value), protocol=pickle.HIGHEST_PROTOCOL))
    print "Encoded value:", e_string
    return e_string

def get_annotation_info( parent, annotations_tag):
    """

    :param parent: the parent element in the workflow
    :param annotations: annotation tag
    :return:
    """
    possible_annotations = ['execute_function','auto_execute','class','times','merge_task']
    all_responses = {}
    for tag in parent.findall(annotations_tag, ns):
        id = tag.attrib['id']
        # print "+++Annotation ID:", id
        text_tags = tag.findall('bpmstuff:text', ns)
        # Only allow one text tag per annotation
        if len(text_tags) != 1:
            print "ERROR: More than one text tag specified for annotation", id
            exit(0)
        ann_params = {}
        for text in text_tags:
            # Split text by ',' and add to the annotation element
            for param_val in text.text.split(','):
                pv_split = param_val.split(':')
                param = pv_split[0]
                value = pv_split[1]
                if param not in possible_annotations:
                    print "ERROR: Invalid parameter", param
                    exit(1)
                ann_params[param] = value
            # print "+++Annotation Text:", text.text
            all_responses[id] = copy.copy(ann_params)
    return all_responses


def get_association_info( parent, associations_tag):
    """

    :param parent: the parent element in the workflow
    :param associations_tag: annotation tag
    :return:
    """
    all_responses = {}
    for tag in parent.findall(associations_tag, ns):
        id = tag.attrib['id']
        task_id = tag.attrib['sourceRef']
        annotation_id = tag.attrib['targetRef']
        all_responses[task_id] = annotation_id
    return all_responses


def get_event_info( parent, event_type ):
    print "EVENT TYPE:", event_type
    all_responses = {}
    for tag in parent.findall(event_type, ns):
        response = {}
        response_id = tag.attrib['id']
        # print "  >>>ID:", tag.attrib['id']
        # print "  >>>Name:", tag.attrib['name']
        # For textAnnotations and Associations, don't check name
        if event_type not in ['bpmstuff:textAnnotation', 'bpmstuff:association']:
            response['name'] = tag.attrib['name']
        else:
            response['name'] = ''
        response['id'] = response_id
        response['incoming'] = []
        response['outgoing'] = []
        for incoming in tag.findall('bpmstuff:incoming', ns):
            # print "  >>>>Incoming source:", incoming.text
            response['incoming'].append(incoming.text)
        for outgoing in tag.findall('bpmstuff:outgoing', ns):
            # print "  >>>>Outgoing source:", outgoing.text
            response['outgoing'].append(outgoing.text)
        # print "++++RESPONSE:", response
        all_responses[response_id] = response
    return all_responses

def get_real_start_event(parent):
    all_responses = {}
    for startEvent in parent.findall('bpmstuff:startEvent', ns):
        response = {}
        # Make sure startEvent doesn't have a messageEventDefinition tag.
        # If it does, reject it as a start event
        if startEvent.find('bpmstuff:messageEventDefinition', ns) is None:
            start_event_id = startEvent.attrib['id']
            response['id'] = start_event_id
            response['name'] = startEvent.attrib['name']
            response['outgoing'] = []
            for outgoing in startEvent.findall('bpmstuff:outgoing', ns):
                # print "  >>>>Outgoing source:", outgoing.text
                response['outgoing'].append(outgoing.text)
            # TODO: Maybe not needed since start event could branch to two tasks
            # if len(response['outgoing']) != 1:
            #     print "****ERROR: ONLY 1 OUTGOING EVENT IS ALLOWED"
            #     exit(1)
            all_responses[start_event_id] = response
    return all_responses


def get_start_message_event(parent):
    all_responses = {}
    for startEvent in parent.findall('bpmstuff:startEvent', ns):
        response = {}
        # Make sure startEvent does have a messageEventDefinition tag.
        # If it does not, it is not a start with a message event.
        if startEvent.find('bpmstuff:messageEventDefinition', ns) is not None:
            start_event_id = startEvent.attrib['id']
            response['id'] = start_event_id
            response['name'] = startEvent.attrib['name']
            response['outgoing'] = []
            for outgoing in startEvent.findall('bpmstuff:outgoing', ns):
                # print "  >>>>Outgoing source:", outgoing.text
                response['outgoing'].append(outgoing.text)
            if len(response['outgoing']) != 1:
                print "****ERROR: ONLY 1 OUTGOING EVENT IS ALLOWED"
                exit(1)
            all_responses[start_event_id] = response
    return all_responses


def get_sequence_flow(parent):
    all_responses = {}
    for sequenceFlow in parent.findall('bpmstuff:sequenceFlow', ns):
        response = {}
        response_id = sequenceFlow.attrib['id']
        response['name'] = sequenceFlow.attrib.get('name','')
        response['sourceRef'] = sequenceFlow.attrib['sourceRef']
        response['targetRef'] = sequenceFlow.attrib['targetRef']
        all_responses[response_id] = response
    return all_responses

def process_annotations( textAnnotations, associations):
    """
    Reformat text annotations so they can be accessed by task id

    :param textAnnotations: dict with key of annotation id, value of task spec attribute stuff
    :param associations: dict with key of task id, and value of annotation id
    :return: task_info - Dictionary with a key of task id and values of stuff that should be applied to in
      the task spec
    """
    task_info = {}
    for task_id, annotation_id in associations.items():
        # Get the annotation information for that annotation id
        ann_info = textAnnotations[annotation_id]
        task_info[task_id] = ann_info
    # print "+++Text Annotations:", textAnnotations
    # print "+++Associations:", associations
    return task_info

def process_parsed_workflow(task_specs, workflow_parsed):
    # print "****************"
    # print json.dumps(workflow_parsed, sort_keys=False, indent=4, separators=(',', ': '))
    # print "****************"
    for process_id, data in workflow_parsed['processes'].items():
        print "+++ID:", process_id
        # print "+++Data:", json.dumps(data, sort_keys=False, indent=4, separators=(',', ': '))
        task_info = process_annotations( data['textAnnotations'], data['associations'])
        # print "+++TASK INFO", task_info
        # Check for sequence flow element.  Set to empty dictionary if no sequence flows for the process id
        if 'sequenceFlow' in data:
            sequenceFlows = data['sequenceFlow']
        else:
            sequenceFlows = {}
        # Process every event type and extract detail.  Process each event type differently.
        for event_type, event_details in data.items():
            print "  Event Type:", event_type
            if event_type == 'tasks':
                # At this time, only tasks are assigned permissions and messagesFlows are
                # between tasks.
                pool_permissions = workflow_parsed['pool_permissions']
                lane_permissions = workflow_parsed['lane_permissions']
                message_flows = workflow_parsed['messageFlow']
                # formerly used data['sequenceFlow']
                build_task_task(task_specs, event_details, sequenceFlows, message_flows, pool_permissions, lane_permissions, process_id, task_info)
            elif event_type == 'startEvent':
                build_start_task(task_specs, event_details, sequenceFlows)
            elif event_type == 'endEvent':
                print "---+++Processing end event"
                build_end_task(task_specs, event_details, sequenceFlows)
            elif event_type == 'intermediateCatchEvent':
                build_intermediate_catch_event(task_specs, event_details, sequenceFlows)
            elif event_type == 'parallelGateway':
                build_parallel_gateway(task_specs, event_details, sequenceFlows)
            elif event_type == 'exclusiveGateway':
                build_exclusive_gateway(task_specs, event_details, sequenceFlows)
            elif event_type == 'inclusiveGateway':
                build_inclusive_gateway(task_specs, event_details, sequenceFlows)
            elif event_type == 'startMessageEvent':
                build_start_message_event(task_specs, event_details, sequenceFlows)
            # if event_details is not None:
            #     for event_key, event_value in event_details.items():
            #         print "    ", event_key, event_value

def build_intermediate_catch_event(task_specs, task_details, sequence_flows):
    print "+++Intermediate Catch Event", task_details

def build_parallel_gateway(task_specs, task_details, sequence_flows):
    '''
    For a parallel gateway, if more than one outgoing flow, consider it a simple task that autoexecutes.
    If more than one input, consider it a join with a threshold and autoexecute.

    :param task_specs:
    :param task_details:
    :param sequence_flows:
    :return:
    '''
    for task_id, detail in task_details.items():
        task_dict = ({
            'inputs': [],
            'outputs': [],
            'description': '',
            'name': '',
            'class': '',
            # 'auto_execute': 'True',
            # 'context': '' # previous task that must complete before this task can execute
            'auto_execute': 'True',
            'split_task': None
        })
        # 'ogis_custom.OgisSplit'
        # 'ogis_custom.OgisJoin'
        #TODO Figure out better way to determine the threshold. Text Attribute?
        #TODO For now, if it is a join, set the threshold to the number of incoming tasks
        #print "PG:", detail
        task_dict['name'] = task_id
        task_dict['description'] = detail['name']
        incoming_flows = detail['incoming']
        outgoing_flows = detail['outgoing']
        for flow_id in incoming_flows:
            sf = sequence_flows[flow_id]
            # for incoming flows use sourceRef
            # If it is a StartEvent, change input to 'Start'
            if  sf['sourceRef'].startswith('StartEvent'):
                task_dict['inputs'].append('Start')
            else:
                task_dict['inputs'].append(sf['sourceRef'])
        for flow_id in outgoing_flows:
            sf = sequence_flows[flow_id]
            # for outgoing flows use sourceRef
            task_dict['outputs'].append(sf['targetRef'])
        # TODO: Confirm that OgisGate works for this kind of event.  If so, no need to create this
        #----Use custom Join for this to test.
        task_dict['class'] = 'ogis_custom.OgisJoin'
        # Set the context task that defines which task must complete before this task can execute
        # Probably a good fake out is to pick the first incoming task since we
        # TODO: This may not work right since we want to require all incoming tasks to complete before
        # executing the merge.
        # --- dont set context if using Join
        # as a custom OgisJoin
        incoming_count = len(incoming_flows)
        # outgoing_count = len(outgoing_flows)
        if incoming_count > 1:
            # get threshold and encode it
            threshold = encode_threshold('i', incoming_count)
            task_dict['threshold'] = threshold
        # elif outgoing_count > 1:
        #     task_dict['class'] = 'ogis_custom.OgisSplit'
        # else:
        #     print "****ERROR: Incoming and outgoing tasks are both only 1 for a parallel gateway"
        task_specs['task_specs'][task_id] = task_dict

def build_exclusive_gateway(task_specs, task_details, sequence_flows):
    # print "+++Exclusive Gateway", task_details
    for task_id, detail in task_details.items():
        # Format of json for a task
        task_dict = ({
            'inputs': [],
            'outputs': [],
            'description': '',
            'name': '',
            'class': 'ogis_custom.OgisMultiChoice',
            'cond_task_specs': [],
            'auto_execute': 'True'
        })
        task_dict['name'] = task_id
        task_dict['description'] = detail['name']
        # TODO PERMISSIONS!
        incoming_flows = detail['incoming']
        outgoing_flows = detail['outgoing']
        # get the sequence flow from the dict of sequence_flows
        for flow_id in incoming_flows:
            # print "BT I FLOWID:", flow_id
            sf = sequence_flows[flow_id]
            # for incoming flows use sourceRef
            # If it is a StartEvent, change input to 'Start'
            if sf['sourceRef'].startswith('StartEvent'):
                task_dict['inputs'].append('Start')
            else:
                task_dict['inputs'].append(sf['sourceRef'])
            # print "BTSF I:", sf
        for flow_id in outgoing_flows:
            # print "BT O FLOWID:", flow_id
            sf = sequence_flows[flow_id]
            # print ">>>>>>Exclusive Gateway Out Sequence:", sf
            # for outgoing flows use sourceRef
            branch_task = sf['targetRef']
            task_dict['outputs'].append(branch_task)
            # attach sequence flow name to condition task specs
            condition_string = sf.get('name', '')
            # if name is defined in sequence flow, extract condition from it
            if condition_string != '':
                condition = parse_condition_string(condition_string, branch_task)
                task_dict['cond_task_specs'].append(condition)
            else:
                print "***WARNING, NO CONDITION SPECIFIED FOR TASK", task_id, "BRANCH TO", branch_task
        task_specs['task_specs'][task_id] = task_dict

def build_inclusive_gateway(task_specs, task_details, sequence_flows):
    # print "+++Inclusive Gateway", task_details
    for task_id, detail in task_details.items():
        # Format of json for a task
        task_dict = ({
            'inputs': [],
            'outputs': [],
            'description': '',
            'name': '',
            'class': 'ogis_custom.OgisMultiChoice',
            'cond_task_specs': [],
            'auto_execute': 'True'
        })
        task_dict['name'] = task_id
        task_dict['description'] = detail['name']
        # TODO PERMISSIONS!
        incoming_flows = detail['incoming']
        outgoing_flows = detail['outgoing']
        # get the sequence flow from the dict of sequence_flows
        for flow_id in incoming_flows:
            # print "BT I FLOWID:", flow_id
            sf = sequence_flows[flow_id]
            # for incoming flows use sourceRef
            # If it is a StartEvent, change input to 'Start'
            if sf['sourceRef'].startswith('StartEvent'):
                task_dict['inputs'].append('Start')
            else:
                task_dict['inputs'].append(sf['sourceRef'])
            # print "BTSF I:", sf
        for flow_id in outgoing_flows:
            # print "BT O FLOWID:", flow_id
            sf = sequence_flows[flow_id]
            # print ">>>>>>Inclusive Gateway Out Sequence:", sf
            # for outgoing flows use sourceRef
            branch_task = sf['targetRef']
            task_dict['outputs'].append(branch_task)
            # attach sequence flow name to condition task specs
            condition_string = sf.get('name', '')
            # if name is defined in sequence flow, extract condition from it
            if condition_string != '':
                condition = parse_condition_string(condition_string, branch_task)
                task_dict['cond_task_specs'].append(condition)
            else:
                print "***WARNING, NO CONDITION SPECIFIED FOR TASK", task_id, "BRANCH TO", branch_task
        task_specs['task_specs'][task_id] = task_dict

def parse_condition_string(condition_string, branch_task):
    # TODO Value format string:actual string?? Probably not since it will have spaces
    # TODO REWORK THIS value number:43
    # Condition should be in the format of "variablename condition value"
    cond = condition_string.split()
    if len(cond) != 3:
        print "***ERROR: INVALID FORMAT FOR CONDITION STRING:", condition_string
    var_name = cond[0]
    cond_name = cond[1].upper()
    val_name = cond[2]
    if cond_name == '=':
        cond_class = 'SpiffWorkflow.operators.Equal'
    elif cond_name == '!=':
        cond_class = 'SpiffWorkflow.operators.NotEqual'
    elif cond_name == '>':
        cond_class = 'SpiffWorkflow.operators.GreaterThan'
    elif cond_name == '<':
        cond_class = 'SpiffWorkflow.operators.LessThan'
    elif cond_name == 'MATCH':
        cond_class = 'SpiffWorkflow.operators.Match'
    # TODO DEF REDO THIS!!!!!
    operands = [['Attrib', var_name], ['value', val_name]]
    condition_list = [[cond_class, operands], branch_task]
    # print "CONDTION-TASK-SPEC", condition_list
    return condition_list



def build_start_message_event(task_specs, task_details, sequence_flows):
    print "+++Start Message Event", task_details

def build_start_task(task_specs, task_details, sequence_flows):
    for task_id, detail in task_details.items():
        # Format of json for a task
        task_dict = ({
            'inputs': [], 'outputs': [], 'description': '',
            'name': '', 'class': 'SpiffWorkflow.specs.StartTask.StartTask'
        })
        # task_dict['name'] = task_id
        # Task name needs to be 'Start'
        task_dict['name'] = 'Start'
        task_dict['description'] = detail['name']
        # TODO PERMISSIONS!
        outgoing_flows = detail['outgoing']
        # get the sequence flow from the dict of sequence_flows
        for flow_id in outgoing_flows:
            sf = sequence_flows[flow_id]
            # for outgoing flows use sourceRef
            task_dict['outputs'].append(sf['targetRef'])
        # task_specs['task_specs'][task_id] = task_dict
        # Task needs to be named 'Start'
        task_specs['task_specs']['Start'] = task_dict

def build_end_task(task_specs, task_details, sequence_flows):
    for task_id, detail in task_details.items():
        # Format of json for a task
        #TODO: May need to be an autoexecute task, therfore needing a different class
        task_dict = ({
            'inputs': [], 'outputs': [], 'description': '',
            'name': '',
            'auto_execute': 'True',
            'class': 'ogis_custom.OgisEndTask'
        })
        task_dict['name'] = task_id
        task_dict['description'] = detail['name']
        # TODO PERMISSIONS!
        incoming_flows = detail['incoming']
        # get the sequence flow from the dict of sequence_flows
        for flow_id in incoming_flows:
            # print "BT I FLOWID:", flow_id
            sf = sequence_flows[flow_id]
            # for incoming flows use sourceRef
            # If it is a StartEvent, change input to 'Start'
            if  sf['sourceRef'].startswith('StartEvent'):
                task_dict['inputs'].append('Start')
            else:
                task_dict['inputs'].append(sf['sourceRef'])
        task_specs['task_specs'][task_id] = task_dict

def build_task_task(task_specs, task_details, sequence_flows, message_flows, pool_permissions, lane_permissions, process_id, task_info):
    # print "BT:", task_details
    for task_id, detail in task_details.items():
        # Format of json for a task
        task_dict = ({
            'inputs': [],
            'outputs': [],
            'description': '',
            'name': '',
            'class': 'ogis_custom.OgisSimple',
            # 'execute_function': '',
            # Assign execute permission only if permission is not dynamic_perm
            # 'execute_permissions': ''
        })
        # Get task info for the task and assign it to the task
        task_stuff = task_info.get(task_id,None)
        if task_stuff is not None:
            merge_task = task_stuff.get('merge_task', '')
            if merge_task != '':
                task_dict['merge_task'] = 'True'
            # Execute function might not be defined if task_stuff has defined a class of type OgisMultiInstance
            execute_function = task_stuff.get('execute_function', '')
            if execute_function == '':
                print "WARNING: execute_function for task %s is not defined." % task_id
            else:
                task_dict['execute_function'] = execute_function
            task_class = task_stuff.get('class', '')
            if task_class != '':
                task_dict['class'] = 'ogis_custom.' + task_class
            # If task class is OgisMultiInstance, then set the value on the task for
            # the times attribute, and auto_execute
            if task_class == 'OgisMultiInstance':
                # Don't assign permissions to this type of task
                multi_times = task_stuff.get('times', '')
                if multi_times == '':
                    print "ERROR: times value not defined for task %s" % task_id
                    exit(1),
                task_dict['times'] = ["Attrib",multi_times]
                auto_execute = task_stuff.get('auto_execute','')
                if auto_execute == '':
                    print "ERROR: auto_execute value not defined for task %s" % task_id
                task_dict['auto_execute'] = "True"
            else: # Regular task so assign permissions
                pool_perm = pool_permissions.get(process_id, '')
                lane_perm = lane_permissions.get(task_id, '')
                if lane_perm == '':
                    e_perm = pool_perm
                else:
                    e_perm = pool_perm + ':' + lane_perm
                # # Permission might be 'dynamic_perm' so don't assign a permission to the task
                # if e_perm != 'dynamic_perm':
                #     task_dict['execute_permissions'] = e_perm
                # Temp change?
                task_dict['execute_permissions'] = e_perm


        else:
            print "ERROR: Couldn't find task stuff for task %s" % task_id
            exit(1)
        task_dict['name'] = task_id
        task_dict['description'] = detail['name']

        # TODO PERMISSIONS!
        incoming_flows = detail['incoming']
        outgoing_flows = detail['outgoing']
        # get the sequence flow from the dict of sequence_flows
        for flow_id in incoming_flows:
            sf = sequence_flows[flow_id]
            # for incoming flows use sourceRef
            # If it is a StartEvent, change input to 'Start'
            if  sf['sourceRef'].startswith('StartEvent'):
                task_dict['inputs'].append('Start')
            else:
                task_dict['inputs'].append(sf['sourceRef'])
        for flow_id in outgoing_flows:
            sf = sequence_flows[flow_id]
            # for outgoing flows use sourceRef
            task_dict['outputs'].append(sf['targetRef'])
        # After checking for incoming and outgoing flows, there is still a need to
        # check the message flows for task ids since there may not be any incoming
        # or outgoing flows if the only communication from/to the task is via message flows.
        mf_incoming = get_message_flow_incoming(task_id, message_flows)
        if mf_incoming != '':
            task_dict['inputs'].append(mf_incoming)
        mf_outgoing = get_message_flow_outgoing(task_id, message_flows)
        if mf_outgoing != '':
            task_dict['outputs'].append(mf_outgoing)
        # Assign permissions to task
        # Permission at this point will be a concatenation of pool permission and lane permission
        # Either may be blank so the permission will end up as ''
        # Get pool permission from the process_id
        # pool_perm = pool_permissions.get(process_id, '')
        # lane_perm = lane_permissions.get(task_id, '')
        # if lane_perm == '':
        #     e_perm = pool_perm
        # else:
        #     e_perm = pool_perm + '_' + lane_perm
        # # Permission might be 'dynamic_perm' so don't assign a permission to the task
        # if e_perm != 'dynamic_perm':
        #     task_dict['execute_permissions'] = e_perm
        # Add task to all task specs
        task_specs['task_specs'][task_id] = task_dict

def get_message_flow_incoming(task_id, message_flows):
    # Scan message flows. Return the targetRef for a task_id that matches the sourceRef
    for mf in message_flows:
        if mf['targetRef'] == task_id:
            return mf['sourceRef']
    return ''


def get_message_flow_outgoing(task_id, message_flows):
    # Scan message flows. Return the sourceRef for a task_id that matches the targetRef
    for mf in message_flows:
        if mf['sourceRef'] == task_id:
            return mf['targetRef']
    return ''

ns = {'bpmstuff': 'http://www.omg.org/spec/BPMN/20100524/MODEL'}

# Dict to hold all task specs.  Gets appended to by the taskprocessing logic
# task_specs = {'task_specs':{}}
task_specs = {'description':'', 'file':'', 'name':'', 'task_specs':{}}
if len(sys.argv) != 2:
    print "Usage: %s bmmn_file.xml" % sys.argv[0]
    exit()
xml_file = 'real_workflow_samples/'+sys.argv[1]
output_json_file = xml_file[:xml_file.rfind('.')]+'.json'
print "OUTPUT FILE:",output_json_file
tree = ET.parse(xml_file)
root = tree.getroot()
print "Root:", root


workflow_parsed = { 'messageFlow': [], 'processes': {}, 'lane_permissions': {}, 'pool_permissions': {}}
for collab in root.findall('bpmstuff:collaboration', ns):
    print "Collaberation ID:",collab.attrib['id']
    for participant in collab.findall('bpmstuff:participant', ns):
        print "Participant id:", participant.attrib['id']
        print "Participant name:", participant.attrib['name']
        print "Participant processRef:", participant.attrib['processRef']
        workflow_parsed['pool_permissions'][participant.attrib['processRef']]= participant.attrib['name']
    for msgflow in collab.findall('bpmstuff:messageFlow', ns):
        print "MessageFlow id:", msgflow.attrib['id']
        print "MessageFlow sourceRef:", msgflow.attrib['sourceRef']
        print "MessageFlow targetRef:", msgflow.attrib['targetRef']
        # Add all message flows to the parsed workflow so it can be accesses when creating tasks
        workflow_parsed['messageFlow'].append(
            {'id': msgflow.attrib['id'], 'sourceRef': msgflow.attrib['sourceRef'], 'targetRef': msgflow.attrib['targetRef']})


for process in root.findall('bpmstuff:process', ns):
    process_id = process.attrib['id']
    print "Process ID:", process_id
    workflow_parsed['processes'][process_id] = {}
    # get all lane info permissions:
    laneSets = process.findall('bpmstuff:laneSet', ns)
    for laneSet in process.findall('bpmstuff:laneSet', ns):
        print "laneSet found"
        for lane in laneSet.findall('bpmstuff:lane', ns):
            lane_perm = lane.attrib['name']
            print "lane perm found:", lane_perm
            print "--Lane ID:", lane.attrib['id']
            print "--Lane Name:", lane.attrib['name']
            for flowNodeRef in lane.findall('bpmstuff:flowNodeRef', ns):
                print "----Flow Node Reference:", flowNodeRef.text
                task_name = flowNodeRef.text
                workflow_parsed['lane_permissions'][task_name] = lane_perm

    intermediateCatchEvents = get_event_info(process, 'bpmstuff:intermediateCatchEvent')
    if intermediateCatchEvents:
        workflow_parsed['processes'][process_id]['intermediateCatchEvent'] = intermediateCatchEvents
    parallelGateways = get_event_info(process, 'bpmstuff:parallelGateway')
    if parallelGateways:
        workflow_parsed['processes'][process_id]['parallelGateway'] = parallelGateways
    tasks = get_event_info(process, 'bpmstuff:task')
    if tasks:
        workflow_parsed['processes'][process_id]['tasks'] = tasks
    exclusiveGateways = get_event_info(process, 'bpmstuff:exclusiveGateway')
    if exclusiveGateways:
        workflow_parsed['processes'][process_id]['exclusiveGateway'] = exclusiveGateways
    inclusiveGateways = get_event_info(process, 'bpmstuff:inclusiveGateway')
    if inclusiveGateways:
        workflow_parsed['processes'][process_id]['inclusiveGateway'] = inclusiveGateways
    endEvent = get_event_info(process, 'bpmstuff:endEvent')
    if endEvent:
        workflow_parsed['processes'][process_id]['endEvent'] = endEvent
    sequenceFlows = get_sequence_flow(process)
    if sequenceFlows:
        workflow_parsed['processes'][process_id]['sequenceFlow'] = sequenceFlows
    startEvent = get_real_start_event(process)
    if startEvent:
        workflow_parsed['processes'][process_id]['startEvent'] = startEvent
    startMessageEvent = get_start_message_event(process)
    if startMessageEvent:
        workflow_parsed['processes'][process_id]['startMessageEvent'] = startMessageEvent

    textAnnotations = get_annotation_info(process, 'bpmstuff:textAnnotation')
    if textAnnotations:
        # print "+++TEXT ANNOTATIONS:", textAnnotations
        workflow_parsed['processes'][process_id]['textAnnotations'] = textAnnotations
    associations = get_association_info(process, 'bpmstuff:association')
    if associations:
        # print "+++ASSOCIATIONS:", associations
        workflow_parsed['processes'][process_id]['associations'] = associations

# print "WORKFLOW:", workflow_parsed
print "CREATING OUTPUT WORKFLOW FILE..."
process_parsed_workflow(task_specs, workflow_parsed)
result = json.dumps(task_specs, sort_keys=False, indent=4, separators=(',', ': '))
ofile = open(output_json_file, 'w')
print "WRITING OUT WORKFLOW FILE..."
ofile.write(result)
ofile.close()

