

def determine_path( task, task_data):
    conditions = task['conditions']
    for condition in conditions:
        expression = condition['expression']
        resp = eval(expression)
        if resp:
            print "Branching to %s" % condition['task']

tasks = {
    "task_specs": {
        "ExclusiveGateway_1e28uz7": {
            "inputs": [
                "Task_11149af"
            ],
            "description": "CheckValue",
            "outputs": [
                "Task_1o9hmpj",
                "Task_00aofip",
                "Task_1sdp0hs"
            ],
            "auto_execute": "True",
            "class": "ogis_custom.OgisMultiChoice",
            "conditions": [
                { "expression": "task_data['answer'] == task_data['count']", "task": "Task_1o9hmpj" },
                { "expression": "task_data['answer'] < task_data['count']", "task": "Task_00aofip" },
                { "expression": "task_data['answer'] > task_data['count']", "task": "Task_1sdp0hs" }
            ],
            "name": "ExclusiveGateway_1e28uz7"
        }
    }
}

task_data = { 'answer': 3, 'count': 3 }
determine_path( tasks['task_specs']['ExclusiveGateway_1e28uz7'], task_data)
task_data = { 'answer': 2, 'count': 3 }
determine_path( tasks['task_specs']['ExclusiveGateway_1e28uz7'], task_data)
task_data = { 'answer': 4, 'count': 3 }
determine_path( tasks['task_specs']['ExclusiveGateway_1e28uz7'], task_data)


