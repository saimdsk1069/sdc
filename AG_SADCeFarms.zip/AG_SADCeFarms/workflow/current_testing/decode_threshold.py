import pickle
from base64 import b64encode, b64decode

b64_string = raw_input("Enter the encoded string -> ")
b64_string = b64_string.strip()
print "B64STRING:",b64_string
o_val = pickle.loads(b64decode(b64_string))
print "Decoded value:", o_val