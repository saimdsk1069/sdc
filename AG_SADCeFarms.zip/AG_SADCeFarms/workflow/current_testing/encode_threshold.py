import pickle
from base64 import b64encode, b64decode

s_or_i = raw_input("Encode string (s) or integer (i) -> ").strip()
if s_or_i != 's' and s_or_i != 'i':
    print "Invalid input, must be 's' or 'i'"
    exit()
input_string = raw_input("Enter the information to be encoded -> ").strip()
if s_or_i == 's':
    e_string = b64encode(pickle.dumps(input_string, protocol=pickle.HIGHEST_PROTOCOL))
else:
    e_string = b64encode(pickle.dumps(int(input_string), protocol=pickle.HIGHEST_PROTOCOL))
print "Encoded value:", e_string
