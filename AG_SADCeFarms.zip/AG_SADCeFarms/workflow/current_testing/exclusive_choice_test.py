from ProcessWorkflow import ProcessWorkflow

user_cred = {
    'id': 'abcdef12345',
    'roles': [ 'oit_admin']
 }


init_permissions = {
    'execute_permissions': { 'workflow_tester': 'oit_admin' }
}

def show_ready(ready_tasks):
    print "\n"
    for task in ready_tasks:
        print "READY TASK:", task['name'], task['description'], task['id']
    print "\n"

pw = ProcessWorkflow()
# pw.set_up('multi_variable_autoexecute.json', init_permissions)
pw.set_up('workflow_data/exclusive_choice.json', init_permissions)
print "\nFirst time:"
ready_tasks = pw.get_ready_tasks(user_cred)
show_ready(ready_tasks)
task_id = raw_input("Enter id of task to execute -> ")
pw.execute_task(task_id)
ready_tasks = pw.get_ready_tasks(user_cred)
show_ready(ready_tasks)

#
# print "\nTest as partner, getting ready tasks. If 0 entered during multi_count, this should execute"
# ready_tasks = pw.get_ready_tasks( user_cred_partner)
# show_ready(ready_tasks)
# task_id = raw_input("Enter id of task to execute -> ")
# pw.execute_task(task_id)
# ready_tasks = pw.get_ready_tasks( user_cred_partner)
# show_ready(ready_tasks)

