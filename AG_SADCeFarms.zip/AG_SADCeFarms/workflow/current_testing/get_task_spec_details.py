import json
# Format task specs into something readable

ifile = open('workflow_build.json', 'r')
jsonstuff = ifile.read()
wfdict = json.loads(jsonstuff)['task_specs']
# print "WFDICT:", wfdict
for task_id, the_rest in wfdict.items():
    # print "ID:", task_id
    # print "THE REST:", the_rest
    print "%25s %15s %s" % ( task_id, the_rest['description'], the_rest.get('execute_permissions', 'Permission not set'))
