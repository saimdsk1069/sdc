import json

from NoSpiffProcessWorkflow import ProcessWorkflow

def get_execute_permissions(wf_doc):
    wf_file = open(wf_doc, 'r')
    the_doc = wf_file.read()
    doc_json = json.loads(the_doc)['task_specs']
    for task_id,task_stuff in doc_json.items():
        if 'execute_permissions' in task_stuff:
            print "Task ID:", task_id
            print "    Task Name:", task_stuff['description']
            print "    Execute Permissions:", task_stuff['execute_permissions']

def show_ready(ready_tasks):
    print "\n"
    for task in ready_tasks:
        print "READY TASK:", task['task_name'], task['id'], task['description']
    print "\n"

def show_all_ready(ready_tasks):
    print "----------------------------------------------------------------------------"
    print "ALL READY TASKS:"
    task_count = 1
    for task in ready_tasks:
        print ("\n")
        print ("%30s %-5i" % ( "Task Number:", task_count) )
        print ("%30s %-40s" % ( "Task Name:", task['task_name']) )
        print ("%30s %-40s" % ("Task Description:", task['description']) )
        print ("%30s %-40s"  % ("Task ID:", task['id']) )
        print ("%30s %-40s"  % ("Auto Execute:", task['auto_execute']) )
        print ("%30s %-s" % ( "Permission:", task['permissions'] ))

        # print "ALL READY TASK:", task['task_name'], task['id'], task['description'], task['permissions']
        print ("\n")
        task_count += 1
    print "----------------------------------------------------------------------------"

def check_ready_task_for_execute( chosen_task, ready_tasks ):
    # print "|%s|" % chosen_task
    for task in ready_tasks:
        # print "Checking task description", task['description']
        if chosen_task == task['description']:
            return task['id']
    return ''

workflow_docs = [
    {
        'document': 'multi_variable_autoexecute_muni_review.json',
        'init_permissions': {
            'County Partner': { 'users': [], 'roles': ['Camden County Partner Role'], 'contact_types': [] }
        },
        'init_data': {
            'answer': 3,
            'count': 3
        }
    },
    {
        'document': 'multi_lane_sample.json',
        'init_permissions': {
            'County Partner': { 'users': [], 'roles': ['Camden County Partner Role'], 'contact_types': [] }
        },
        'init_data': {
            'answer': 3,
            'count': 3
        }
    },
    {
        'document': 'multi_variable_test.json',
        'init_permissions': {
            'County Partner': { 'users': [], 'roles': ['Camden County Partner Role'], 'contact_types': [] }
        },
        'init_data': {
            'answer': 3,
            'muni_count': 3
        }
    },
    {
        'document': 'multi_multi_test.json',
        'init_permissions': {
            'County Partner': { 'users': [], 'roles': ['Camden County Partner Role'], 'contact_types': [] }
        },
        'init_data': {
            'answer': 3,
            'multi_count1': 2,
            'multi_count2': 3
        }
    }

]

print "\nAvailable test workflows:\n"
wfcount = 1
for doc in workflow_docs:
    print "%2i) %s" % ( wfcount, doc['document'] )
    wfcount += 1
do_wf = raw_input("\nSelect a workflow document number: ")
wf_doc = workflow_docs[int(do_wf)-1]

init_permissions = wf_doc['init_permissions']
init_data = wf_doc['init_data']

wf_document = 'real_workflow_samples/'+wf_doc['document']
pw = ProcessWorkflow()
print ">>>> Loading workflow %s" % wf_document
pw.set_up(wf_document, init_permissions, init_data)

while True:
    all_ready_tasks = pw.get_all_ready_tasks_with_permissions()
    show_all_ready(all_ready_tasks)
    task_number = raw_input("Select a task number -> ")
    if task_number == '':
        continue
    task_number = int(task_number) - 1
    if task_number <0 or task_number >= len(all_ready_tasks):
        print "Bad task number chosen"
        continue
    do_task = raw_input("Execute task '%s' (%s) [y]|n -> " % ( all_ready_tasks[task_number]['description'], all_ready_tasks[task_number]['id']) ).strip()
    if do_task == '' or do_task == 'y':
        pw.execute_task(all_ready_tasks[task_number]['id'])
    # pw.complete_task(all_ready_tasks[task_number]['id'])

