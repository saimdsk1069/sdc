python init_test_nospiff.py <<EOF
3
1
y

1
y
3
muni1
muni2
muni3
EOF