from ProcessWorkflow import ProcessWorkflow

user_cred_partner = {
                        'id': 'abcdef12345',
                        'roles': [ 'oit_admin']
                    }
user_cred_muni1 = {
                        'id': '339ab8dfd',
                        'roles': ['muni1', 'partner2', 'admin4' ]
                    }

user_cred_muni2 = {
                        'id': '339ab8dfd',
                        'roles': ['muni2', 'partner2', 'admin4' ]
                    }

user_cred_muni3 = {
                        'id': '339ab8dfd',
                        'roles': ['muni3', 'partner2', 'admin4' ]
                    }

init_permissions = { 'execute_permissions': { 'future_task_permission': 'nobody', 'workflow_permission': 'oit_admin' } }

def show_ready(ready_tasks):
    print "\n"
    for task in ready_tasks:
        print "READY TASK:", task['name'], task['description'], task['id']
    print "\n"

pw = ProcessWorkflow()

pw.set_up('workflow_data/multi_variable_autoexecute.json', init_permissions)
# pw.dump_workflow()
print "\nFirst time: Should return a ready task for muni_count"
ready_tasks = pw.get_ready_tasks( user_cred_partner)
show_ready(ready_tasks)

print "Execute Task"
print "Enter count of 3, and for munis, enter muni1, muni2 and muni3. This will match the creds for the next request"
task_id = raw_input("Enter id of task to execute -> ")
pw.execute_task(task_id)

print "\nTest as muni1, getting ready tasks"
ready_tasks = pw.get_ready_tasks( user_cred_muni1)
show_ready(ready_tasks)
print "\nTest as muni2, getting ready tasks"
ready_tasks = pw.get_ready_tasks( user_cred_muni2)
show_ready(ready_tasks)
print "\nTest as muni3, getting ready tasks"
ready_tasks = pw.get_ready_tasks( user_cred_muni3)
show_ready(ready_tasks)

print "\nTest as partner, getting ready tasks. If 0 entered during multi_count, this should execute"
ready_tasks = pw.get_ready_tasks( user_cred_partner)
show_ready(ready_tasks)
task_id = raw_input("Enter id of task to execute -> ")
pw.execute_task(task_id)
ready_tasks = pw.get_ready_tasks( user_cred_partner)
show_ready(ready_tasks)

