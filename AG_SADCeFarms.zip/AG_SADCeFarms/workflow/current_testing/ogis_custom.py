from __future__ import print_function
from SpiffWorkflow.specs import Simple, MultiInstance, MultiChoice, ExclusiveChoice, Join

class OgisEndTask(Simple):

    def serialize(self, serializer):
        return serializer.serialize_ogis_end_task(self)

    @classmethod
    def deserialize(self, serializer, wf_spec, s_state):
        return serializer.deserialize_ogis_end_task(wf_spec, s_state)

class OgisSimple(Simple):

    def serialize(self, serializer):
        return serializer.serialize_ogis_simple(self)

    @classmethod
    def deserialize(self, serializer, wf_spec, s_state):
        return serializer.deserialize_ogis_simple(wf_spec, s_state)


class OgisMultiInstance(MultiInstance):

    def serialize(self, serializer):
        return serializer.serialize_ogis_multi_instance(self)

    @classmethod
    def deserialize(self, serializer, wf_spec, s_state):
        return serializer.deserialize_ogis_multi_instance(wf_spec, s_state)

class OgisMultiChoice(MultiChoice):
    """
        This is used for both exclusive choice and multi choice to
        avoid the need for specifying a default task.
    """
    def serialize(self, serializer):
        return serializer.serialize_ogis_multi_choice(self)

    @classmethod
    def deserialize(self, serializer, wf_spec, s_state):
        return serializer.deserialize_ogis_multi_choice(wf_spec, s_state)

class OgisExclusiveChoice(ExclusiveChoice):

    def serialize(self, serializer):
        return serializer.serialize_ogis_exclusive_choice(self)

    @classmethod
    def deserialize(self, serializer, wf_spec, s_state):
        return serializer.deserialize_ogis_exclusive_choice(wf_spec, s_state)

class OgisJoin(Join):

    def serialize(self, serializer):
        print("Serializing Ogis Join")
        return serializer.serialize_ogis_join(self)

    @classmethod
    def deserialize(self, serializer, wf_spec, s_state):
        # print("De-serializing Ogis Join")
        return serializer.deserialize_ogis_join(wf_spec, s_state)


