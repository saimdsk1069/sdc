from SpiffWorkflow.serializer.json import JSONSerializer
from ogis_custom import OgisSimple, OgisMultiInstance, OgisMultiChoice, OgisExclusiveChoice, OgisJoin, OgisEndTask

class OgisCustomSerializer(JSONSerializer):

    # - OgisEndTask

    def serialize_ogis_end_task(self, task_spec):
        return self.serialize_task_spec(task_spec)

    def deserialize_ogis_end_task(self, wf_spec, s_state):
        spec = OgisEndTask(wf_spec, s_state['name'])
        spec.input_tasks = s_state['inputs']
        spec.auto_execute = s_state['auto_execute']
        self.deserialize_task_spec(wf_spec, s_state, spec=spec)
        return spec

    # - OgisSimple
    def serialize_ogis_simple(self, task_spec):
        return self.serialize_task_spec(task_spec)

    def deserialize_ogis_simple(self, wf_spec, s_state):
        spec = OgisSimple(wf_spec, s_state['name'])
        # print "---+++Processing %s" % s_state['name']
        spec.execute_function = s_state['execute_function']
        # for some reason the spec has to rename inputs to input_tasks.  Otherwise they can't be extracted
        # from the task spec
        spec.input_tasks = s_state['inputs']
        # Merge task is optional
        if s_state.get('merge_task') is not None:
            # print "+++Setting merge task"
            spec.merge_task = s_state['merge_task']
        # else:
            # print "+++Not a merge task"
        # Execute permission is optional
        if s_state.get('execute_permissions') is not None:
            spec.execute_permissions = s_state['execute_permissions']
        self.deserialize_task_spec(wf_spec, s_state, spec=spec)
        return spec

    # - OgisMultiInstance
    def serialize_ogis_multi_instance(self, task_spec):
        return self.serialize_task_spec(task_spec)

    def deserialize_ogis_multi_instance(self, wf_spec, s_state):
        spec = OgisMultiInstance(wf_spec,
                             s_state['name'],
                             times=self.deserialize_arg(s_state['times']))
        spec.auto_execute = s_state['auto_execute']
        self.deserialize_task_spec(wf_spec, s_state, spec=spec)
        return spec

    # - OgisMultiChoice
    def serialize_ogis_multi_choice(self, task_spec):
        s_state = self.serialize_multi_choice(task_spec)
        return s_state

    def deserialize_ogis_multi_choice(self, wf_spec, s_state):
        spec = OgisMultiChoice(wf_spec, s_state['name'])
        self.deserialize_multi_choice(wf_spec, s_state, spec=spec)
        spec.auto_execute = s_state['auto_execute']
        return spec

    # - OgisExclusiveChoice
    def serialize_ogis_exclusive_choice(self, task_spec):
        s_state = self.serialize_multi_choice(task_spec)
        return s_state

    def deserialize_ogis_exclusive_choice(self, wf_spec, s_state):
        spec = OgisExclusiveChoice(wf_spec, s_state['name'])
        self.deserialize_multi_choice(wf_spec, s_state, spec=spec)
        spec.default_task_spec = s_state['default_task_spec']
        spec.auto_execute = s_state['auto_execute']
        return spec

    # - OgisJoin

    def serialize_ogis_join(self, task_spec):
        print "Serializing Join"
        s_state = self.serialize_join(task_spec)
        return s_state

    def deserialize_ogis_join(self, wf_spec, s_state):
        # print "WFSPEC:", wf_spec
        # print "WFSPEC NAME:", s_state
        spec = OgisJoin(wf_spec, s_state['name'])
        # print "AFTER CREATING NEW OGIS JOIN"
        # self.deserialize_join(wf_spec, s_state)
        self.deserialize_task_spec(wf_spec, s_state, spec=spec)
        # print "AFTER DESERIAlIZE JOIN"
        spec.auto_execute = s_state['auto_execute']
        return spec


