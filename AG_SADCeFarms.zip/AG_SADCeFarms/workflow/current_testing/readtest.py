# test reading from stdin
line1 = raw_input("Enter stuff for line1 -> ")
line2 = raw_input("Enter stuff for line2 -> ")
line3 = raw_input("Enter stuff for line3 -> ")
line4 = raw_input("Enter stuff for line4 -> ")
print "You entered %s for line1" % line1
print "You entered %s for line2" % line2
print "You entered %s for line3" % line3
print "You entered %s for line4" % line4



