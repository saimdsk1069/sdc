import json
import sys
import uuid
from SpiffWorkflow import Workflow, Task
from SpiffWorkflow.specs import WorkflowSpec, MultiInstance, StartTask, MultiChoice
from SpiffWorkflow.serializer.json import JSONSerializer
from ogis_custom_serializer import OgisCustomSerializer


def do_dump(msg, workflow):
    print "\n>>>>>>>>>>>>> " + msg + " DUMPING WORKFLOW"
    workflow.dump()
    print ">>>>>>>>>>>>>> WORKFLOW DUMP COMPLETE\n"

def do_autoexec_tasks(workflow):
    '''
    Check for auto_execute tasks and do them until no more are ready.  One autoexec task
    make fire and make other autoexec tasks ready.
    :param workflow:
    :return:
    '''
    while True:
        autoexec_fired = False
        ready_tasks = workflow.get_tasks(Task.READY)
        for rt in ready_tasks:
            task_name = rt.get_name()
            task_id = rt.id
            print "+++ task name:", task_name
            t_spec = workflow.get_task_spec_from_name(task_name)
            try:

                auth_exec = t_spec.auto_execute
                print "---Firing autoexec task:", task_name
                autoexec_fired = True
                workflow.complete_task_from_id(task_id)
            except AttributeError as e:
                pass
        # If no autoexec tasks fired, return
        if not autoexec_fired:
            print "---No more autoexec tasks"
            break

def found_all_params(task, spec, serializer ):
    '''
    Check the task spec to see if it contains all of the required data to execute correctly.
    :param task:
    :param spec:
    :param serializer:
    :return:
    '''
    # print ">>MultiInstance:", isinstance(spec, MultiInstance)
    # print ">>MultiChoice:", isinstance(spec, MultiChoice)
    if isinstance(spec, MultiChoice):
        # print ">> Checking MultiChoice"
        all_found = True
        conditions = spec.cond_task_specs
        for condition, name in conditions:
            print "CONDTION:", condition
            # serialize the conditions and search for attributes
            ser_cond = condition.serialize(serializer)
            for cond in ser_cond:
                if cond[0] == 'Attrib':
                    # If condition is an attribute, make sure it exists
                    # print ">>>Found Attrib:", cond[1]
                    value = task.get_data(cond[1],'NotFound')
                    # print ">>>TASK DATA VALUE:", value
                    if value == 'NotFound':
                        all_found = False
        return all_found
    elif isinstance(spec, MultiInstance):
        # print ">> Checking MultiInstance"
        times = spec.times.serialize(serializer)
        value = task.get_data(times,'NotFound')
        # print ">>>TASK DATA VALUE:", value
        if value == 'NotFound':
            return False
        return True
    else:
        return True

if len(sys.argv) < 2:
    print "Usage: %s json_workflow_file <optional-input>" % sys.argv[0]
    exit()
with open(sys.argv[1]) as fp:
    workflow_json = fp.read()
# serializer = JSONSerializer()
serializer = OgisCustomSerializer()
spec = WorkflowSpec.deserialize(serializer, workflow_json)

# Set input values
task_data = {}
if len(sys.argv) == 3:
    task_data = eval(sys.argv[2])
    print "TASK DATA:", task_data
# Create the workflow.
workflow = Workflow(spec)
# do_dump("Before Execute", workflow)
# Add task data to tasks
for task in workflow.get_tasks():
    task.set_data(**task_data)

while True:
    all_tasks = workflow.get_tasks()
    for at in all_tasks:
        print "Task %10s %15s %30s" % (at.get_name(), at.get_state_name(), at.id)
        # print "Task Data:", at.get_data('mi1_times', 'Not Defined')

    # Execute any ready tasks that are auto execute
    do_autoexec_tasks(workflow)

    ready_tasks = workflow.get_tasks(Task.READY)
    print "Now displaying ready tasks "
    for r_task in ready_tasks:
        print "READY TASK:", r_task.get_name(), r_task.id
    task_id_to_run = raw_input("\nENTER TASK ID TO EXECUTE > ")
    # Convert task id to uuid
    try:
        task_id_to_run = uuid.UUID(task_id_to_run)
    except ValueError:
        print "Invalid Task ID"
        continue

    spec = workflow.get_task_spec_from_name(workflow.get_task(task_id_to_run).get_name())
    if found_all_params(workflow.get_task(task_id_to_run),spec,serializer):
        workflow.complete_task_from_id(task_id_to_run)
    else:
        print "Task not executed, missing parameters"
    print "After completing task"


    if workflow.is_completed():
        print "Workflow is complete"
        break
