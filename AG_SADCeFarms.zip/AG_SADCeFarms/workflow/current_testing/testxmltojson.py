import xml.etree.ElementTree as ET

def get_event_info( parent, event_type ):
    print "EVENT TYPE:", event_type
    all_responses = {}
    for tag in parent.findall(event_type, ns):
        response = {}
        response_id = tag.attrib['id']
        # print "  >>>ID:", tag.attrib['id']
        # print "  >>>Name:", tag.attrib['name']
        response['name'] = tag.attrib['name']
        response['id'] = response_id
        response['incoming'] = []
        response['outgoing'] = []
        for incoming in tag.findall('bpmstuff:incoming', ns):
            # print "  >>>>Incoming source:", incoming.text
            response['incoming'].append(incoming.text)
        for outgoing in tag.findall('bpmstuff:outgoing', ns):
            # print "  >>>>Outgoing source:", outgoing.text
            response['outgoing'].append(outgoing.text)
        # print "++++RESPONSE:", response
        all_responses[response_id] = response
    return all_responses

def get_real_start_event(parent):
    all_responses = {}
    for startEvent in parent.findall('bpmstuff:startEvent', ns):
        response = {}
        # Make sure startEvent doesn't have a messageEventDefinition tag.
        # If it does, reject it as a start event
        if startEvent.find('bpmstuff:messageEventDefinition', ns) is None:
            start_event_id = startEvent.attrib['id']
            response['id'] = start_event_id
            response['name'] = startEvent.attrib['name']
            response['outgoing'] = []
            for outgoing in startEvent.findall('bpmstuff:outgoing', ns):
                # print "  >>>>Outgoing source:", outgoing.text
                response['outgoing'].append(outgoing.text)
            if len(response['outgoing']) != 1:
                print "****ERROR: ONLY 1 OUTGOING EVENT IS ALLOWED"
                exit(1)
            all_responses[start_event_id] = response
    return all_responses


def get_start_message_event(parent):
    all_responses = {}
    for startEvent in parent.findall('bpmstuff:startEvent', ns):
        response = {}
        # Make sure startEvent does have a messageEventDefinition tag.
        # If it does not, it is not a start with a message event.
        if startEvent.find('bpmstuff:messageEventDefinition', ns) is not None:
            start_event_id = startEvent.attrib['id']
            response['id'] = start_event_id
            response['name'] = startEvent.attrib['name']
            response['outgoing'] = []
            for outgoing in startEvent.findall('bpmstuff:outgoing', ns):
                # print "  >>>>Outgoing source:", outgoing.text
                response['outgoing'].append(outgoing.text)
            if len(response['outgoing']) != 1:
                print "****ERROR: ONLY 1 OUTGOING EVENT IS ALLOWED"
                exit(1)
            all_responses[start_event_id] = response
    return all_responses



def get_sequence_flow(parent):
    all_responses = {}
    for sequenceFlow in parent.findall('bpmstuff:sequenceFlow', ns):
        response = {}
        response_id = sequenceFlow.attrib['id']
        response['name'] = sequenceFlow.attrib.get('name','')
        response['sourceRef'] = sequenceFlow.attrib['sourceRef']
        response['targetRef'] = sequenceFlow.attrib['targetRef']
        all_responses[response_id] = response
    return all_responses

def display_parsed_workflow(workflow_parsed):
    print "*********************************"
    for id, stuff in workflow_parsed.items():
        print "ID:", id
        for event_type, event_details in stuff.items():
            print "  Event Type:", event_type
            if event_details is not None:
                for event_key, event_value in event_details.items():
                    print "    ", event_key, event_value
                    if event_type == 'task':
                        build_task_task( event_value, stuff['sequenceFlow'])


def build_task_task( task, sequence_flows):
    print "---Processing task:", task['name'], task['id']
    incoming_sequence = task['incoming']
    print "------Incoming sequence flows:", incoming_sequence
    outgoing_sequence = task['outgoing']
    print "------Outgoing sequence flows:", outgoing_sequence
    # Look up each sequence flow to get the source and target
    # print "------SequenceFlows:", sequence_flows
    for incoming in incoming_sequence:
        seq = sequence_flows['incoming']
        print "----------SEQ FOR TASK:", seq
    for outgoing in outgoing_sequence:
        seq = sequence_flows['outgoing']
        print "----------SEQ FOR TASK:", seq

ns = {'bpmstuff': 'http://www.omg.org/spec/BPMN/20100524/MODEL'}

workflow_parsed = {}
tree = ET.parse('multi_lane_sample_nodiagram.xml')
root = tree.getroot()
print "Root:", root

for collab in root.findall('bpmstuff:collaboration', ns):
    print "Collaberation ID:",collab.attrib['id']
    for participant in collab.findall('bpmstuff:participant', ns):
        print "Participant id:", participant.attrib['id']
        print "Participant name:", participant.attrib['name']
        print "Participant processRef:", participant.attrib[
            'processRef']
    for msgflow in collab.findall('bpmstuff:messageFlow', ns):
        print "MessageFlow id:", msgflow.attrib['id']
        print "MessageFlow sourceRef:", msgflow.attrib['sourceRef']
        print "MessageFlow targetRef:", msgflow.attrib['targetRef']

workflow_parsed = {}
for process in root.findall('bpmstuff:process', ns):
    process_id = process.attrib['id']
    print "Process ID:", process_id
    # get all lane info:
    for laneSet in process.findall('bpmstuff:laneSet', ns):
        print "laneSet found"
        for lane in laneSet.findall('bpmstuff:lane', ns):
            print "lane found"
            print "--Lane ID:", lane.attrib['id']
            print "--Lane Name:", lane.attrib['name']
            for flowNodeRef in lane.findall('bpmstuff:flowNodeRef', ns):
                print "----Flow Node Reference:", flowNodeRef.text
    intermediateCatchEvents = get_event_info(process, 'bpmstuff:intermediateCatchEvent')
    parallelGateways = get_event_info(process, 'bpmstuff:parallelGateway')
    tasks = get_event_info(process, 'bpmstuff:task')
    exclusiveGateways = get_event_info(process, 'bpmstuff:exclusiveGateway')
    endEvent = get_event_info(process, 'bpmstuff:endEvent')
    sequenceFlows = get_sequence_flow(process)
    startEvent = get_real_start_event(process)
    startMessageEvent = get_start_message_event(process)

    workflow_parsed[process_id] = {
        'intermediateCatchEvent': intermediateCatchEvents,
        'parallelGateway': parallelGateways,
        'task': tasks,
        'exclusiveGateway': exclusiveGateways,
        'endEvent': endEvent,
        'startEvent': startEvent,
        'startMessageEvent': startMessageEvent,
        'sequenceFlow': sequenceFlows
    }
#print "WORKFLOW:", workflow_parsed
display_parsed_workflow(workflow_parsed)