import copy

def get_multi_count(input):
    if input == {}:
        assigned_munis = []
        submit = False
        multi_count = raw_input("\n\n\nEnter the number of multiple tasks to create: > ").strip()
        for muni in range(int(multi_count)):
            get_muni = raw_input("Enter a muni name: > ").strip()
            assigned_munis.append(get_muni)
        if multi_count != 0:
            submit = True
    else:
        assigned_munis = input['assigned_munis']
        submit = False
        multi_count = len(assigned_munis)
        if multi_count != 0:
            submit = True
    response = {'submit': submit, 'm1_times': int(multi_count), 'assigned_dynamic_perms': {'Municipality Reviewer': assigned_munis}}
    return response

def final_review(input):
    if input == {}:
        submit = raw_input("\n\n\nSubmit application (y|n): > ").strip()
    else:
        submit = input['submit']
    if submit == 'y':
        response = {'submit': True}
    else:
        response = {'submit': False}
    return response

def do_task_1(input):
    return { "submit": True, "test_attribute1": 6, "test_attribute2": 6 }

# Test function to execute for testing purposes.
def just_hit_enter(input):
    if input == {}:
        raw_input("JUST HIT ENTER TO EXECUTE THE TASK --> ")
    return  {'submit': True}

# test function for exclusive choice and multi choice
def enter_value(input):
    if input == {}:
        value = raw_input("Enter the value to change the flow --> ")
    else:
        value = input['value']
    return {'submit': True, 'answer': int(value)}

def enter_prebranch_count(input):
    if input == {}:
        value = raw_input("Enter the pre-branch count --> ")
    else:
        value = input['value']
    return {'submit': True, 'answer': int(value)}

