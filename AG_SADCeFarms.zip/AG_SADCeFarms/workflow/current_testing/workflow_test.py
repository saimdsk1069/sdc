"""
    Test for workflow
"""
import json
import sys
from collections import OrderedDict
from ProcessWorkflow import ProcessWorkflow


def get_workflow_task_perms(wfdoc):
    """

    :param wfdoc:
    :return:
    """
    # Format task specs into something readable
    ifile = open(wfdoc, 'r')
    jsonstuff = ifile.read()
    wfdict = json.loads(jsonstuff)['task_specs']
    # print "WFDICT:", wfdict
    t_dict = {}
    for task_id, the_rest in wfdict.items():
        if not the_rest.get('execute_permissions', u'Permission not set').startswith('Permission not set'):
            t_dict[task_id] = {'description': the_rest['description'],
                               'execute_permissions': the_rest.get('execute_permissions', u'Permission not set')}
            # print "%25s %15s %s" % ( task_id, the_rest['description'], the_rest.get('execute_permissions',
            # 'Permission not set'))
    return t_dict

def get_perm_list(t_dict):
    """

    :param t_dict:
    :return:
    """
    p_list = []
    for pid, det in t_dict.items():
        if not det['execute_permissions'].startswith('Permission not set'):
            p_list.append(det['execute_permissions'])
    p_list.sort()
    reduced_perms = list(OrderedDict.fromkeys(p_list))
    # print "REDUCED PERMS:", reduced_perms
    return reduced_perms

def show_perm_list(p_list):
    """

    :param p_list:
    :return:
    """
    index = 0
    print "%5s %s" % ('ID', 'Permission')
    print "%5s %s" % ('-----', '------------------------------')
    for the_perm in p_list:
        print "%5i %s" % (index, the_perm)
        index += 1


def show_workflow_task_perms(r_tasks):
    """

    :param r_tasks: All ready tasks
    :return: role_list - a list of role names that can be chosen for  executing a task
    """
    role_list = []
    print "Tasks and Permissions:\n"
    print "%3s %-15s %-35s %-25s" % ('Idx', 'Permission', 'Task Name', 'Description')
    print "%3s %15s %35s %25s" % ('-'*3, '-'*15, '-'*35, '-'*25)
    idx = 0
    # for tid, details in r_tasks.items():
    #     task_name = details['description']
    #     perms = details['perm']
    #     for id_and_role in perms:
    #         id, role = id_and_role.items()[0]
    #         print "%3i %-15s %-35s %-36s %-20s" % (idx, tid, task_name, id, role)
    #         role_list.append(role)
    #         idx += 1
    for perm, tasks in r_tasks.items():
        for task_name, details in tasks.items():
            print "%3i %-15s %-35s %-25s" % (idx, perm, task_name, details['description'])
            role_list.append(perm)
            # print idx, perm, task_name, details['description'], details['id']
            idx += 1
    print "\n"
    return role_list

def show_ready(r_tasks):
    """

    :param r_tasks:
    :return:
    """
    print "\n"
    for task in r_tasks:
        print "READY TASK:", task['name'], task['description'], task['id']
    print "\n"

def complete_task(workflow, r_tasks, p_list, t_dict):
    """

    :param workflow:
    :param r_tasks:
    :return:
    """
    while True:
        # Loop until the user has the right credentials
        print "*************************************************************************************\n"
        role_list = show_workflow_task_perms(r_tasks)
        for perm, tasks in r_tasks.items():
            for task_name, details in tasks.items():
                print "%%% READY:", perm, task_name, details['description'], details['id']
        # for task_name, task_details in r_tasks.items():
        #     print "READY:", task_name, task_details
        print "\n*************************************************************************************\n"
        role_to_assume = raw_input("Choose a role index number: --> ")
        if int(role_to_assume) < len(role_list):
            the_perm = role_list[int(role_to_assume)]
        else:
            raw_input("Bad role index number. Press 'Enter' to continue")
            continue
        task_to_do = raw_input("\nEnter Task to Execute: --> ")
        if task_to_do.strip() == '':
            continue
        print "+++Doing task", task_to_do
        # TODO: Select role to execute the task as
        credential = {'id': 'abcdefg', 'roles': [the_perm]}
        # ids_to_execute = workflow.get_ids_for_credentials(r_tasks[task_to_do]['perm'], credential)
        if the_perm not in r_tasks:
            print "User with %s credentials is not allowed to execute task %s" % (credential['roles'], task_to_do )
        else:
            print "CHECKING TASKS:", r_tasks[the_perm]
            # ids_to_execute = workflow.get_ids_for_credentials(task_to_do, r_tasks[the_perm][task_to_do]['id'])
            ids_to_execute = r_tasks[the_perm][task_to_do]['id']
            print "IDS TO EXECUTE:", ids_to_execute
            workflow.execute_task(ids_to_execute)
            break



if len(sys.argv) != 2:
    print "Usage: %s workflow_file.json" % sys.argv[0]
    exit()
wf_doc = 'test_data/'+sys.argv[1]
print "USING WORKFLOW DOC %s" % wf_doc
# wf_doc = 'workflow_build.json'
task_dict = get_workflow_task_perms(wf_doc)
perm_list = get_perm_list(task_dict)

# Create init_permissions
init_permissions = {'execute_permissions': {}}
for perm in perm_list:
    init_permissions['execute_permissions'][perm] = perm

print "INIT PERMS:", init_permissions

user_cred = {
    'id': 'abcdef12345',
    'roles': ['SADC Planning_Planning Manager']
}

# show_workflow_task_perms(task_dict)
pw = ProcessWorkflow()
pw.set_up(wf_doc, init_permissions)
while True:
    # Don't include permission so that we can see all ready tasks and execute a task based on credentials we set.1
    ready_tasks = pw.get_ready_tasks()
    complete_task(pw, ready_tasks, perm_list, task_dict)
