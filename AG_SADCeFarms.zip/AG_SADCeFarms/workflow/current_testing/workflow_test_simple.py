"""
    Test for workflow
"""
import json
import sys
from collections import OrderedDict
from ProcessWorkflowSimple import ProcessWorkflow


def get_workflow_task_perms(wfdoc):
    """

    :param wfdoc:
    :return:
    """
    # Format task specs into something readable
    ifile = open(wfdoc, 'r')
    jsonstuff = ifile.read()
    wfdict = json.loads(jsonstuff)['task_specs']
    # print "WFDICT:", wfdict
    t_dict = {}
    for task_id, the_rest in wfdict.items():
        if not the_rest.get('execute_permissions', u'Permission not set').startswith('Permission not set'):
            t_dict[task_id] = {'description': the_rest['description'],
                               'execute_permissions': the_rest.get('execute_permissions', u'Permission not set')}
            # print "%25s %15s %s" % ( task_id, the_rest['description'], the_rest.get('execute_permissions',
            # 'Permission not set'))
    return t_dict

def get_perm_list(t_dict):
    """

    :param t_dict:
    :return:
    """
    p_list = []
    for pid, det in t_dict.items():
        if not det['execute_permissions'].startswith('Permission not set'):
            p_list.append(det['execute_permissions'])
    p_list.sort()
    reduced_perms = list(OrderedDict.fromkeys(p_list))
    # print "REDUCED PERMS:", reduced_perms
    return reduced_perms

def show_perm_list(p_list):
    """

    :param p_list:
    :return:
    """
    index = 0
    print "%5s %s" % ('ID', 'Permission')
    print "%5s %s" % ('-----', '------------------------------')
    for the_perm in p_list:
        print "%5i %s" % (index, the_perm)
        index += 1


def show_workflow_task_perms(t_dict):
    """

    :param t_dict:
    :return:
    """
    print "%-25s %15s %s" % ('Task ID', 'Task Name', 'Task Execute Permission')
    print "%25s %15s %s" % ('-'*25, '-'*15, '-'*35)
    for tid, det in t_dict.items():
        print "%-25s %15s %s" % (tid, det['description'], det['execute_permissions'])
    print "\n"

def show_ready(r_tasks):
    """

    :param r_tasks:
    :return:
    """
    print "\n"
    for task in r_tasks:
        print "READY TASK:", task['name'], task['description'], task['id']
    print "\n"

def complete_task_noperms(workflow, r_tasks):
    """

    :param workflow:
    :param r_tasks:
    :return:
    """
    while True:
        task_to_do = raw_input("\nEnter Task to Execute: --> ")
        if task_to_do.strip() == '':
            continue
        workflow.execute_task(task_to_do)
        break

if len(sys.argv) != 2:
    print "Usage: %s workflow_file.json" % sys.argv[0]
    exit()
wf_doc = sys.argv[1]
print "USING WORKFLOW DOC %s" % wf_doc
# wf_doc = 'workflow_build.json'
task_dict = get_workflow_task_perms(wf_doc)
perm_list = get_perm_list(task_dict)

# Create init data

init_data = {'test_attribute1': '1', 'test_attribute2': '2', 'test_attribute3': '3'}


# show_workflow_task_perms(task_dict)
pw = ProcessWorkflow()
pw.set_up(wf_doc, init_data)
while True:
    show_workflow_task_perms(task_dict)
    # show_perm_list(perm_list)
    #TODO Force creds to be passed in for executing a task
    # ready_tasks = pw.get_ready_tasks(user_cred)
    #ready_tasks = pw.get_all_ready_tasks()
    # Don't include permission so that we can see all ready tasks and execute a task based on credentials we set.1
    ready_tasks = pw.get_ready_tasks()
    complete_task_noperms(pw, ready_tasks)
