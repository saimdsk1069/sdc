import json
import uuid
ifile_name = 'views.py'
qf = open( ifile_name, 'r')
qout = open( ifile_name+'.withguids', 'w')
for line in qf:
    theline = line.rstrip()
    if "##GUID##" in theline:
        # gen new guid
        newguid = str(uuid.uuid4())
        theline = theline.replace('##GUID##', newguid )
    qout.write("%s\n" % theline)
qf.close()
qout.close()


