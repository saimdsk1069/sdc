from django.conf.urls import url
import views

urlpatterns = [

    url(r'^readytasks$',
        views.ReadyTasks.as_view(), name="ready_tasks" ),
    url(r'^taskquestions/(?P<workflow_guid>[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})/(?P<task_id>.*)$',
        views.TaskQuestions.as_view(), name="task_questions" ),

]
