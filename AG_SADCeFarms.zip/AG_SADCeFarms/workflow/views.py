from django.shortcuts import render
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.http import Http404, HttpResponse
from django.core.exceptions import PermissionDenied, ObjectDoesNotExist
import json
import importlib
import os
import logging
from common.error_messages import authAdminErrors

logger = logging.getLogger(__name__)

class ReadyTasks(APIView):
    def get(self, request):
        testfile = open('/opt/djangoappsconfig/props/AG_SADCeFarms_workflow_test.data', 'r')
        testdata = json.loads(testfile.read())
        print "TESTDATA:", testdata
        return Response(testdata['ready_tasks'])

class TaskQuestions(APIView):

            # {
            # "id": "34049403-857f-4d2e-b6b1-33b5158c4fc1",
            # "msg": "Municipality Review",
            # "text": "Select Municipalities To Review The Application",
            # "type": "selection",
            # "from_msg": "Available Municipalities",
            # "to_msg": "Selected Municipalities",
            # "valueClass": "workflow.WorkflowTasks.MuniSelector",
            # }

    def get_class_from_module(self, valueClass):
        module_stuff = valueClass.split('.')
        module_name = '.'.join(module_stuff[:-1])
        class_name = module_stuff[-1]
        logger.debug("----MODULE: %s" % module_name)
        logger.debug("----CLASS: %s" % class_name)
        theClass = getattr(importlib.import_module(module_name), class_name)
        return theClass

    def get(self, request, workflow_guid=None, task_id=None):
        testfile = open('/opt/djangoappsconfig/props/AG_SADCeFarms_workflow_test.data', 'r')
        testdata = json.loads(testfile.read())
        # print "TESTDATA:", testdata
        if workflow_guid is None or task_id is None:
            error = "err-w001"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        # make sure workflow_guid and task id show as ready
        for task in testdata['ready_tasks']:
            if task['workflow_guid'] == workflow_guid and task['task_id'] == task_id:
                # find the task question and return it to the user
                for question in testdata['task_questions']:
                    if question['id'] == task_id:
                        # theClass = self.get_class_from_module(valueClass)
                        # instance = theClass()
                        return Response(question)
                # No match in questions
                error = "err-w002"
                logger.debug(authAdminErrors[error]['d_msg'])
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        # No match for workflow guid and task id
        error = "err-w003"
        logger.debug(authAdminErrors[error]['d_msg'])
        return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, workflow_guid=None, task_id=None):
        responsefile = open('/opt/djangoappsconfig/props/AG_SADCeFarms_workflow_test_response.data', 'a')
        testfile = open('/opt/djangoappsconfig/props/AG_SADCeFarms_workflow_test.data', 'r')
        testdata = json.loads(testfile.read())
        # print "TESTDATA:", testdata
        if workflow_guid is None or task_id is None:
            error = "err-w001"
            logger.debug(authAdminErrors[error]['d_msg'])
            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        # make sure workflow_guid and task id show as ready
        for task in testdata['ready_tasks']:
            if task['workflow_guid'] == workflow_guid and task['task_id'] == task_id:
                # find the task question and return it to the user
                for question in testdata['task_questions']:
                    if question['id'] == task_id:
                        # Make sure type matches the question
                        if question['type'] != request.data['type']:
                            error = "err-w004"
                            logger.debug(authAdminErrors[error]['d_msg'])
                            return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
                        out_response = {'workflow_guid': workflow_guid, 'task_id': task_id,
                            'type': request.data['type'], 'response': request.data['response']}
                        responsefile.write(json.dumps(out_response))
                        responsefile.write('\n')
                        responsefile.close()
                        return Response(request.data)
                # No match in questions
                error = "err-w002"
                logger.debug(authAdminErrors[error]['d_msg'])
                return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)
        # No match for workflow guid and task id
        error = "err-w003"
        logger.debug(authAdminErrors[error]['d_msg'])
        return Response({"result":"error","message":error}, status=status.HTTP_400_BAD_REQUEST)





