(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    .controller('HeaderController', ['$scope', '$log', '$state', 'AuthService', 'handleError',
        'modalService', 'modalMessageService', 'agSupportEmail', '$window',
        function( $scope, $log, $state, AuthService, handleError,
                  modalService, modalMessageService, agSupportEmail, $window ) {

            $log.debug("=========<><><><><><> Starting Header Controller");
            $scope.$watchCollection(function(){
                return AuthService.authState;
            }, function() {
                if ( ! AuthService.authState ) {
                    $log.debug("=========<><><><><><> Header Controller: AuthService.authState changed to:", AuthService.authState);
                    disable_ui_components();
                    $scope.current_user = "";
                    $scope.logged_in = false;
                    //$scope.logoff();
                }
            });

            $scope.ui_components = {
                'ui_adminmenu': false,
                'ui_appadmin': false,
                'ui_sysadmin': false,
                'ui_fiscal': false,
                'ui_useradmin': false
            };

            //var disable_ui_components = function(ui_access) {
            var disable_ui_components = function() {
                // reset all ui_components values to false
                angular.forEach( Object.keys($scope.ui_components), function(comp_key) {
                    //$log.debug("Setting", comp_key, "to false");
                    $scope.ui_components[comp_key] = false;
                });
            };

            var set_ui_values = function(ui_access){
                // first reset all ui_components values to false
                disable_ui_components();
                //disable_ui_components(ui_access);
                // set the value for each ui_component to true for each value in ui_access
                angular.forEach( ui_access, function(comp_key) {
                    //$log.debug("Setting", comp_key, "to true");
                    $scope.ui_components[comp_key] = true;
                });
                // Determine if user should see admin menu
                if ( $scope.ui_components.ui_appadmin || $scope.ui_components.ui_sysadmin ||
                    $scope.ui_components.ui_fiscal || $scope.ui_components.ui_useradmin ) {
                    $log.debug("User is allowed to see admin menu");
                    $scope.ui_components.ui_adminmenu = true;
                }
            };

            var checkAuthentication = function(redirect) {
                AuthService.authenticate()
                    .then(
                    function(response) {
                        var return_status = {'auth': false, 'mynj': ''};
                        $log.debug("======AUTHENTICATE RESPONSE:", response);
                        // Valid call to authenticate.  So set the AuthService response.
                        AuthService.setAuthenticateResponse(response);
                        if (response.status == 'AUTHENTICATED'){
                            AuthService.setAuthenticatedState(true);
                            // User is authenticated via portal so track session idleness
                            $log.debug("++++++User is authenticated.  Starting to track session.");
                            var session_timeout_minutes = response.session_timeout;
                            $log.debug("++++++Session timeout is set to ", session_timeout_minutes, "minutes.");
                            AuthService.startIdleWatch();
                            // Allow 30 minutes of idle time
                            AuthService.setSessionIdleTimeout(30*60);
                            // Warn user 30 seconds before terminating session
                            AuthService.setSessionIdleWarningTimeout(30);
                            // Set keepalive at 1 minute less than server session timeout
                            //AuthService.setKeepaliveInterval((session_timeout_minutes-1)*60);
                            //AuthService.setKeepaliveInterval(15);
                            return_status.auth = true;
                            return_status.mynj = AuthService.authResponse.mynj;

                        } else {
                            // User is not authenticated via portal
                            AuthService.setAuthenticatedState(false);
                            $log.debug("User is not authenticated via portal");
                            return_status.auth = false;
                            return_status.mynj = AuthService.authResponse.mynj;

                        }
                        if (AuthService.authResponse.status !== 'AUTHENTICATED'){
                            // Get the message for why user is not authenticated
                            $log.debug("AuthService.authResponse:", AuthService.authResponse);
                            var no_auth_message = AuthService.authResponse.message;
                            var mynj = AuthService.authResponse.mynj;
                            $log.debug("myNewJersey:", mynj);
                            $log.debug("UNAUTHORIZED MESSAGE:", no_auth_message);
                            return_status.auth = false;
                            return_status.mynj = mynj;
                            if ( redirect ) {
                                $log.debug("+++Redirecting to portal");
                                $window.location.href = mynj;
                            }
                        } else {
                            set_ui_values(AuthService.authResponse.ui_access);
                        }
                        showHeader();
                        $log.debug("return status before return:", return_status);
                        return return_status;
                    },
                    function(response) {
                        handleError.notify(response,'');                    });
            };

            var showHeader = function(){
                if (AuthService.authResponse.status == 'AUTHENTICATED') {
                    $scope.logged_in = true;
                    $scope.current_user = "Welcome: " + AuthService.authResponse.first_name + ' ' + AuthService.authResponse.last_name;
                }
            };

            //Use a function to change state.  This way, clicks on the header menu will refresh the view
            $scope.change_state = function(state_name){
                // reload:state_name is needed so that header controller doesn't reload
                $state.go(state_name,{},{reload:state_name});
            };

            $scope.login = function() {
                if ( ! $scope.logged_in ) {
                    checkAuthentication(true);
                }

            };

            $scope.logoff = function() {
                disable_ui_components();
                AuthService.stopIdleWatch();
                AuthService.logoff();
                $scope.current_user = "";
                $scope.logged_in = false;
                $state.go('app');
            };

            // Do initial auth check
            checkAuthentication(false);

    }])
;
