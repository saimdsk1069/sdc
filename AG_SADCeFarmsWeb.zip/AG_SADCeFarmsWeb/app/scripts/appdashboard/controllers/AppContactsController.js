(function () {
    'use strict';
}());
angular.module('agSADCeFarms')
        .controller('AppContactsController', ['$scope', '$state', '$log',  'agSupportEmail', 'applicationService','handleError', '$sce', '$http', '$window', 'modalService', 'modalMessageService', '$uibModal', '$rootScope',
            function ($scope, $state, $log,  agSupportEmail, applicationService,handleError, $sce, $http, $window, modalService, modalMessageService, $uibModal, $rootScope) {

                var checkID = applicationService.checkAppID($state.params.ID);

                if (checkID) {
                    $rootScope.getAppContacts = function () {
                        applicationService.fetchAppContacts($state.params.ID).then(
                                function (response) {
                                    $rootScope.appContacts = response;
                                },
                                function (errResponse) {
                                   handleError.notify(errResponse,'');
                                }
                        );
                    };
                    $scope.email = agSupportEmail;
                    $scope.APPID = $state.params.ID;
                    $scope.onlreadyInEdit = false;

                    $rootScope.getAppContacts();

                    applicationService.fetchAppContactsTypes($state.params.ID).then(
                            function (response) {
                                $scope.appContactTypes = response;
                            },
                            function (errResponse) {
                                console.error('Error while fetching App Contacts Types');
                                return {};
                            }
                    );

                    $scope.onContactRowClick = function (index, row) {
                        $scope.selectedContact = row;
                        $('.appContactsRow').removeClass('highlighted');
                        $('.appContactsRow-' + index).addClass('highlighted');
                        //console.log(row, index);
                    };

                    $scope.appNewContactType = [];

                    $scope.editContact = function (index, contact) {
                        var modalInstance = $uibModal.open({
                            templateUrl: 'views/application/appEditContact.html',
                            controller: 'editAppContactCtrl',
                            size: 'lg',
                            backdrop: 'static',
                            resolve: {
                                selectedItem : function(){
                                    return contact;
                                }
                            }
                        });

                        modalInstance.result.then(function (selectedItem) {
                            //$scope.selected = selectedItem;
                        }, function () {
                            console.log('Modal dismissed at: ' + new Date());
                        });

                    };


                    $scope.deleteContact = function () {
                        $('tr.appContactsRow').eq(parseInt($('input[name="selectContactsRow"]:checked').val()));

                        var rowData = $rootScope.appContacts[parseInt($('input[name="selectContactsRow"]:checked').val())];

                        applicationService.deleteAppContacts(rowData.application_contact_guid).then(
                                function (response) {
                                    $rootScope.getAppContacts();
                                    toastr.clear();
                                    toastr.success('Success', 'App Contact successfully Deleted');
                                },
                                function (errResponse) {
                                    toastr.clear();
                                    toastr.error('Bad Connectivity / Server Down', 'Error while Deleting App Contact');
                                }
                        );
                    };

                    $scope.addNewContact = function () {
                        var modalInstance = $uibModal.open({
                            templateUrl: 'views/application/appAddContact.html',
                            controller: 'addAppContactCtrl',
                            size: 'lg',
                            backdrop: 'static',
                            resolve: {}
                        });

                        modalInstance.result.then(function (selectedItem) {
                            //$scope.selected = selectedItem;
                        }, function () {
                            console.log('Modal dismissed at: ' + new Date());
                        });

                    };
                } else {
                    $scope.IDfailed = true;
                }
            }
        ]).controller('addAppContactCtrl', function ($rootScope, $scope, $filter, $window, $uibModalInstance, applicationService, $state) {

    $scope.contactsGrid = {
        paginationPageSizes: [25, 50, 75, 100],
        enableFiltering: true,
        enableRowSelection: true,
        multiSelect: false,
        enableFullRowSelection: true,
        paginationPageSize: 25,
        columnDefs: [
            {name: 'first_name'},
            {name: 'last_name'},
            {name: 'title'},
            {name: 'organization'},
            {name: 'email_primary', displayName: 'Email'},
            {name: 'phone_primary', displayName: 'Phone'}
        ]
    };

    $scope.contactsGrid.onRegisterApi = function (gridApi) {
        $scope.gridApi2 = gridApi;
    };

    $scope.addNewContact = function () {

        var selectedData = $scope.gridApi2.selection.getSelectedRows();

        var postData = {
            "application_id": $state.params.ID,
            "auth_user_guid": selectedData.length > 0 ? selectedData[0].auth_user_guid : '',
            "contact_type_desc": $scope.appNewContactType ? $scope.appNewContactType.contact_type_desc : '',
            "note": $scope.appNewContactNote ? $scope.appNewContactNote : ''
        };

        if (postData.auth_user_guid == '' || postData.auth_user_guid == null || postData.auth_user_guid == undefined ||
                postData.contact_type_desc == '' || postData.contact_type_desc == null || postData.contact_type_desc == undefined) {

            toastr.clear();
            toastr.warning('Please select Contact Type and Contact from Table', 'Warning');
        } else {

            applicationService.postAppNewContact(postData).then(
                    function (response) {
                        $rootScope.getAppContacts();
                        toastr.clear();
                        toastr.success('New Contact updated successfully', 'Success');

                        $uibModalInstance.close('save');
                    },
                    function (errResponse) {
                        console.error('Error while posting App Contact');
                        return {};
                    }
            );
        }


//        console.log(userData);
    };

    $scope.cancelContact = function () {
        $uibModalInstance.dismiss('Close');
    };
$scope.app_users=function(){
$scope.loading_data=true;
    applicationService.fetchAppContactsUsers($state.params.ID).then(
            function (response) {
                $scope.contactsGrid.data = response;
                $scope.loading_data=false;
            },
            function (errResponse) {
                console.error('Error while fetching App Contacts User List');
                return {};
            }
    );
};
$scope.app_users();
    applicationService.fetchAppContactsTypes($state.params.ID).then(
            function (response) {
                $scope.appContactTypes = response;
            },
            function (errResponse) {
                console.error('Error while fetching App Contacts Types');
                return {};
            }
    );
}).controller('editAppContactCtrl', function ($rootScope, $scope,selectedItem, $filter, $window, $uibModalInstance, applicationService, $state) {

    $scope.selectedItem = selectedItem;

    $scope.editNewContact = function () {
        var putData = {
            "application_contact_guid" : $scope.selectedItem ? $scope.selectedItem.application_contact_guid : '',
            "application_id": $state.params.ID,
            "auth_user_guid": $scope.selectedItem ? $scope.selectedItem.auth_user_guid : '',
            "contact_type_desc": $scope.appEditContactType ? $scope.appEditContactType.contact_type_desc : $scope.selectedItem.contact_type_desc,
            "note": $scope.appEditContactNote ? $scope.appEditContactNote : ''
        };

        if(putData.application_contact_guid == '' || putData.application_contact_guid == null || putData.application_contact_guid == undefined){
            toastr.clear();
            toastr.warning('Error in updating contact.. Please try again', 'Warning');

        $uibModalInstance.dismiss('Cancel');
        }else if(putData.auth_user_guid == '' || putData.auth_user_guid == null || putData.auth_user_guid == undefined){
            toastr.clear();
            toastr.warning('Error in updating contact.. Please try again', 'Warning');

        $uibModalInstance.dismiss('Cancel');
        }else if (putData.contact_type_desc == '' || putData.contact_type_desc == null || putData.contact_type_desc == undefined) {
            toastr.clear();
            toastr.warning('Please select Contact Type', 'Warning');
        } else {

            applicationService.putAppContact(putData).then(
                    function (response) {
                        $rootScope.getAppContacts();
                        toastr.clear();
                        toastr.success('Contact updated successfully', 'Success');
                        $uibModalInstance.dismiss('Cancel');
                         $window.location.reload();
                    },
                    function (errResponse) {
                        console.error('Error while editing App Contact');
                        return {};
                    }
            );
        }


        //console.log(userData);
    };

    $scope.userCancel = function () {
        $uibModalInstance.dismiss('Cancel');
    };

    $scope.cancelContact = function () {
        $uibModalInstance.dismiss('Cancel');
    };

    applicationService.fetchAppContactsTypes($state.params.ID).then(
            function (response) {
                $scope.appContactTypes = response;
            },
            function (errResponse) {
                console.error('Error while fetching App Contacts Types');
                return {};
            }
    );
});