(function() {
    'use strict';
}());
angular.module('agSADCeFarms')
        .controller('AppExpenseController', ['$scope', '$uibModal','$stateParams','$state','$location','$filter','ExpenseDataService','GetAppExpense','applicationService','AuthService','handleError','agSupportEmail','GetExpenseData','GetFarmIDList','GetExpense','$log','modalService','modalMessageService', function($scope,$uibModal,$stateParams,$state,$location,$filter,ExpenseDataService,GetAppExpense,applicationService,AuthService,handleError,agSupportEmail,GetExpenseData,GetFarmIDList,GetExpense,$log,modalService,modalMessageService) {

  $scope.ui_components = {
            'ui_appdashboard_expenses': false

        };

         var disable_ui_components = function() {
        $scope.ui_components['ui_appdashboard_expenses'] = false;
    };
    var setUIValues = function(){
        var ui_access = AuthService.authResponse.ui_access;
        angular.forEach( ui_access, function(comp_key) {
                if($scope.ui_components.hasOwnProperty(comp_key)){
                      $scope.ui_components[comp_key] = true;
                }
            });
    };

//AuthService
    if ( AuthService.isAuthenticated() ) {
    console.log("++++++User is authenticated");
    console.log("++++++Users ui access:", AuthService.getUserUIAccess());
    setUIValues();

    } else {
        console.log("++++++User is not authenticated");
        disable_ui_components();
    }

    $scope.$watchCollection(function(){
                return AuthService.authState;
            }, function() {
                if ( ! AuthService.authState ) {
                    $log.debug("+++AuthService.authState changed to:", AuthService.authState);
                    disable_ui_components();

                }else{
                    setUIValues();
                }
            });



var applicationid = $state.params.ID;
var appExpLink = "<div class='ui-grid-cell-contents'> <a class='myFAppLink' href='#application/{{row.entity.application_id}}/expense_details/{{row.entity.expense_guid}}'><u>{{row.entity.expense_description}}</u></a> </div>";
//  Expenses
$scope.gridExpenses = {
            enableSorting :true,
            enablePaginationControls: true,
            paginationPageSize: 25,
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: false,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            showGridFooter:false,
            selectedItems: [],
            enableGridMenu: true,
            exporterCsvFilename: 'Application_Expenses.csv',
            exporterPdfDefaultStyle: {fontSize: 12},
            exporterMenuVisibleData : true,
            exporterPdfTableStyle: {margin: [40, 40, 40, 40]},
            exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
            exporterPdfHeader: { text: "Application Expenses Details", style: 'headerStyle' },
            exporterPdfFooter: function ( currentPage, pageCount ) {
              return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function ( docDefinition ) {
              docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
              docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
              return docDefinition;
            },
            exporterPdfOrientation: 'landscape',
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 500,
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            exporterExcelFilename: 'Application_Expenses.xlsx',
            exporterExcelSheetName: 'Sheet1',
            enableRowSelection: true,
            enableFullRowSelection: true,
            appScopeProvider: $scope,
            rowTemplate: '<div ng-click="grid.appScope.viewselExp(row)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell" ng-class="col.colIndex()" ui-grid-cell></div>',

            columnDefs: [
                  { name:'Expense Description', field: 'expense_description', width: 200,resizable: true,  pinnedLeft:false,cellTemplate: appExpLink },
                  { name:'Expense Type', field: 'expense_type', width: 200,resizable: true,pinnedLeft:false},
                  { name:'Expense Amount', field: 'expense_amount', width: 200, cellFilter:'currency', pinnedLeft:false },
                  { name:'Municipality', field: 'municipality', width: 250,resizable: true,  pinnedLeft:false},
                  { name:'County', field: 'county', width: 170, resizable: true, pinnedLeft:false},
                  { name:'Status', field: 'expense_status_desc', width: 125, pinnedLeft:false },
                  { name:'Farm ID', field: 'farm_id', width: 250,  pinnedLeft:false },
                  { name:'Farm Name', field: 'farm_name', width: 250,  pinnedLeft:false },


        ],

    };

            $scope.viewselExp = function(row) {
                //console.log('FROM EXPENSE CONTROLLER');
                var itemguid = row.entity.expense_guid;

                $scope.selecteddataexpense = itemguid;
                //console.log("expense Guid", itemguid);
                if (itemguid) {
                    //$location.path('/finance/expenses/expensedetail/'+itemguid);
                    var appguid =  $stateParams.ID;
                    //console.log("Application Guid",appguid);
                    $location.path('/application/'+ appguid + '/expense_details/'+itemguid);
                      //$state.go('app.application.expensedetails',{ID:appguid,expense_guid:itemguid});
                }
            };

// Register the grid for API calls like clearSelectedRows() and getSelectedRows()
$scope.gridExpenseHeight = 'height: ' + ($scope.gridExpenses.paginationPageSize * 35 + 150) + 'px';
$scope.gridExpenses.onRegisterApi = function(gridApiExpenses){
    $scope.gridApiExpenses = gridApiExpenses;
    gridApiExpenses.selection.on.rowSelectionChanged($scope,function(row){
    var msg = 'row selected'+row.isSelected;
     $scope.selectedRows = $scope.gridApiExpenses.selection.getSelectedRows()[0];
     $scope.selectedguidexpense = $scope.selectedRows.expense_guid;
    });
};




// Get Expenses  from service
$scope.getExpenseDetails = function() {
    $scope.loading_data = true;
    var appguid =  $stateParams.ID;
//    console.log("Application Guid",appguid);
    GetAppExpense.getappexpense(appguid).query()
    .$promise.then(
    function(response){
       $scope.expensedetails = response;
        $scope.gridExpenses.data = response;
//        console.log("gridReapprops.data:",$scope.gridExpenses.data );
        $scope.loading_data = false;
    },
    function(response) {
        // If there is an error getting user statuses from database,
        // this will have an error as well.  If so, put the message in the error modal.
       handleError.notify(response,'');
    }
    );
};

// Do Initial Expense   load
$scope.getExpenseDetails();

//Expenses Payments Costshare details
$scope.gridExpenseCostshare = {
            enableSorting :true,
            enablePaginationControls: true,
            paginationPageSize: 25,
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: true,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            showGridFooter:false,
            selectedItems: [],
            enableGridMenu: true,
            exporterCsvFilename: 'Application_ExpensesCostshare.csv',
            exporterPdfDefaultStyle: {fontSize: 12},
            exporterMenuVisibleData : true,
            exporterPdfTableStyle: {margin: [40, 40, 40, 40]},
            exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
            exporterPdfHeader: { text: "Application Expenses Costshare Details", style: 'headerStyle' },
            exporterPdfFooter: function ( currentPage, pageCount ) {
              return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function ( docDefinition ) {
              docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
              docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
              return docDefinition;
            },
            exporterPdfOrientation: 'landscape',
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 500,
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            exporterExcelFilename: 'Application_ExpensesCostshare.xlsx',
            exporterExcelSheetName: 'Sheet1',
            columnDefs: [
                  { name:'Cost Per Acre', field: 'cost_per_acre', width: 300, pinnedLeft:false,enableCellEdit:true,},
                  { name:'Source', field: 'payment_source', width: 300,  pinnedLeft:false,enableCellEdit:true,},
                  { name:'Amount', field: 'share_amount', width: 250, cellFilter:'currency', pinnedLeft:false, enableCellEdit:true,},
                  { name:'Description', field: 'share_description', width: 170,  pinnedLeft:false,enableCellEdit:true,},
        ],
    };




// Expense cost share grid table data from the guid
$scope.gridExpenseCostshareDetails = function() {
    //loading image

    if(!!$scope.selecteddataexpense && !!$scope.selecteddataexpense.expense_guid){
            var expguid = $scope.selecteddataexpense.expense_guid;
            $scope.expguid = $scope.selecteddataexpense.expense_guid;
            var expensedetailsid = GetExpenseData.getexpensedata(expguid).get()
                                  .$promise.then(
                                    function(response){

                                        $scope.selectedexpensedetails = response;
                                        $scope.selecteddatacostshareexpense = _.get($scope.selectedexpensedetails, 'cost_share_json');
                                        $scope.gridExpenseCostshare.data = $scope.selecteddatacostshareexpense;
//                                        console.log($scope.gridExpenseCostshare.data);
                                            var costShareArr = [];
                                            $.each(response.cost_share_json, function (indexCost, valueCost) {
                                                costShareArr.push(valueCost);
                                            });
                                            $scope.gridExpenseCostshare.data = costShareArr;
                                        },
                                        function (err) {
                                            alert("error");
                                        }
                                );
                    }
                };

            // Do Initial Cost share   load
            $scope.gridExpenseCostshareDetails();

// Expenses Payments details
$scope.gridExpensePayments = {
            enableSorting :true,
            enablePaginationControls: true,
            paginationPageSize: 25,
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: true,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            showGridFooter:false,
            selectedItems: [],
            enableGridMenu: true,
            exporterCsvFilename: 'Application_ExpensesPayments.csv',
            exporterPdfDefaultStyle: {fontSize: 12},
            exporterMenuVisibleData : true,
            exporterPdfTableStyle: {margin: [40, 40, 40, 40]},
            exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
            exporterPdfHeader: { text: "Application Expenses Payment Details", style: 'headerStyle' },
            exporterPdfFooter: function ( currentPage, pageCount ) {
              return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function ( docDefinition ) {
              docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
              docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
              return docDefinition;
            },
            exporterPdfOrientation: 'landscape',
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 500,
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            exporterExcelFilename: 'Application_ExpensesPayment.xlsx',
            exporterExcelSheetName: 'Sheet1',
            enableRowSelection: true,
            enableFullRowSelection: true,
            appScopeProvider: $scope,
            columnDefs: [
                  { name:'Payment Amount', field: 'payment_amount', width: 300,cellFilter:'currency', pinnedLeft:false},
                  { name:'Payment Source', field: 'payment_source_type', width: 170,  pinnedLeft:false},
                  { name:'Payment Status', field: 'payment_status_desc', width: 170,  pinnedLeft:false},
                  { name:'Payment Comment', field: 'payment_comment', width: 250,  pinnedLeft:false },
                  { name:'Appropriation', field: 'appropriation_name', width: 250,pinnedLeft:false },
                  { name:'From Reappropriation', field: 'reapprop_flag', width: 170, pinnedLeft:false},
                  { name:'Activity Code', field: 'activity_code', width: 170, pinnedLeft:false},
                  { name:'Object Code', field: 'object_code', width: 170,  pinnedLeft:false},
                  { name:'Vendor Code', field: 'vendor_code', width: 170,  pinnedLeft:false},
                  { name:'Vendor Name', field: 'vendor_name', width: 170,  pinnedLeft:false},
        ],

    };




 if(!!$stateParams){
      $scope.selecteddataexpense = $stateParams;
//      console.log("Expense Guid",$scope.selecteddataexpense);
    }





//Expenses  Details
    $scope.viewSelectedExpense = function(){
    if(!!$scope.selecteddataexpense && !!$scope.selecteddataexpense.expense_guid){
        var expguid = $scope.selecteddataexpense.expense_guid;
        $scope.expguid = $scope.selecteddataexpense.expense_guid;
    //                        console.log($scope.expguid);
        var expensedetailsid = GetExpenseData.getexpensedata(expguid).get()
                              .$promise.then(
                                function(response){

                                            $scope.selectedexpensedetails = response;
                                            $scope.selecteddatacostshareexpense = _.get($scope.selectedexpensedetails, 'cost_share_json');
                                            //$scope.gridExpenseCostshare.data = $scope.selecteddatacostshareexpense;
                                            var costShareArr = [];
                                            $.each(response.cost_share_json, function (indexCost, valueCost) {
                                                costShareArr.push(valueCost);
                                            });
                                            $scope.gridExpenseCostshare.data = costShareArr;
                                            $scope.selecteddatapaymentexpense = _.get($scope.selectedexpensedetails, 'expense_payments');
                                            $scope.gridExpensePayments.data = $scope.selecteddatapaymentexpense;
//                                    $location.path('/finance/expenses/expensedetail/'+expguid);
                                },
                                function(err){
                                  alert("Service error");
                                }
                             );
        }
    };
    $scope.viewSelectedExpense();



// Register the grid for API calls like clearSelectedRows() and getSelectedRows()
    $scope.gridExpensePayments.onRegisterApi = function(gridApiExpensePayments){
        $scope.gridApiExpensePayments = gridApiExpensePayments;

        gridApiExpensePayments.selection.on.rowSelectionChanged($scope,function(row){
        var msg = 'row selected'+row.isSelected;
         $scope.selectedRows = $scope.gridApiExpensePayments.selection.getSelectedRows()[0];
         $scope.selectedguidreapprops = $scope.selectedRows.reappropriation_guid;
        });
    };
// Delete Expenses  here
    $scope.deleteExpense = function(){
//                $scope.currentselectedexpense = getExpenseSelection();
//                $scope.delexpid =   Object.values($scope.currentselectedexpense.selectedExpense)[0];
                $scope.expenseguid = $scope.selectedguidexpense;
                console.log($scope.expenseguid);
                 var modalOptions = {
                closeButtonText: 'No',
                actionButtonText: 'Yes',
                headerText: 'Warning',
                bodyText: 'Are you sure you want to delete this item?'
             };
                 modalService.showModal({}, modalOptions)
                    .then(function (result) {
                 DeleteExpense.deleteexpense().delete({expense_guid:$scope.expenseguid})
                    .$promise.then(
                       function(){
                          modalMessageService.showMessage( "Success:","Expense deleted Successfully");
                          $state.reload();
                       },
                       function(response) {
                            $log.debug("ERROR Deleting Expense:", response);
                           if (response.data.result === 'error' ) {
                               modalMessageService.showMessage( "Error:", response.data.message);
                            } else {
                                modalMessageService.showMessage( "Error:", "This Expense cannot be deleted");
                            }
                            $log.debug("Error: "+response.status + " " + response.statusText);
                        }
                  );
                   });
            };

 var checkID = applicationService.checkAppID($state.params.ID);

        if (checkID) {
            applicationService.fetchAppInfo($state.params.ID).then(
                    function(response) {
                        //console.log(response);
                        $scope.appInfo = response;
//                        console.log("application Information", $scope.appInfo);
                        $scope.farm_id = $scope.appInfo.farm_id;
                    },
                    function(errResponse) {
                        console.error('Error while fetching Currencies');
                    }
            );
        }else{
            $scope.IDfailed = true;
        }


//Edit the Expense  here
    $scope.EditExpense = function(){
    var modalInstance = $uibModal.open({
        templateUrl:'views/application/expenseedit.html',
        controller:'AppExpenseModalController',
        backdrop: 'static',
        resolve: {
            fundtransitems: function () {
                return null;
            },
        },
    });
    modalInstance.result.then(function (modalResponse) {
                console.log("modalResponse", modalResponse);
            }, function () {
                        $log.debug("cancelled the Expense Edit entry");
            });
    };

    //Add new Expenses
$scope.addExpense = function() {
        var modalInstance = $uibModal.open({
        templateUrl:'views/application/newexpense.html',
        controller:'AppExpenseModalController',
        backdrop: 'static',
        });
        modalInstance.result.then(function (modalResponse) {
            //console.log("modalResponse", modalResponse);
        }, function () {
                    $log.debug("cancelled the Expense  entry");
        });
};

}])

.controller('AppExpenseModalController',function($scope,$stateParams,$log,$state,$filter,$location,FundDataService,$uibModalInstance,GetAppID,GetAppList,applicationService,PaymentDataService,GetPartner,GetExpenseData,UpdateExpense,ExpenseDataService,GetPaymentSource,GetFarmIDList,GetTransactiontype,GetExpensetype,GetExpensestatus,AddExpense,modalService,modalMessageService){



 var checkID = applicationService.checkAppID($state.params.ID);

        if (checkID) {
            applicationService.fetchAppInfo($state.params.ID).then(
                    function(response) {
                        //console.log(response);
                        $scope.appInfo = response;
//                        console.log("application Information", $scope.appInfo);
                        $scope.farm_id = $scope.appInfo.farm_id;
                    },
                    function(errResponse) {
                        console.error('Error while fetching Currencies');
                    }
            );
        }else{
            $scope.IDfailed = true;
        }


        // Get Expense Status
 var expensestatus = GetExpensestatus.getexpensestatus().query()
      .$promise.then(
        function(response){
            $scope.expenseststatuslist = response;
        });

    // Get Expense Types
GetExpensetype.getexpensetype().query()
  .$promise.then(
    function(response){
        $scope.expensetypelist = response;
    });


// Get Expense Status
GetExpensestatus.getexpensestatus().query()
  .$promise.then(
    function(response){
        $scope.expenseststatuslist = response;
    });



// Get Farm ID List
GetFarmIDList.getfarmidlist().query()
  .$promise.then(
    function(response){
        $scope.farmidlist = response;
    });

    $scope.close = function(){
    $uibModalInstance.dismiss();
    };

$scope.appID = $stateParams.ID;

GetAppList.getapplist().query()
  .$promise.then(
    function(response){
    $scope.applist = response;
});

$scope.isAppIDReadonly = true;

//Expenses Payments Costshare details
$scope.gridExpenseCostshare = {
            enableSorting :true,
            enablePaginationControls: true,
            paginationPageSize: 25,
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: true,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            showGridFooter:false,
            selectedItems: [],
            columnDefs: [
                  { name:'Source', field: 'payment_source', width: 300,  pinnedLeft:false},
                  { name:'Amount', field: 'share_amount', width: 250,cellFilter:'currency', pinnedLeft:false },
                  { name:'Description', field: 'share_description', width: 170, pinnedLeft:false},
        ],

    };

if(!!$stateParams){
      $scope.selecteddataexpense = $stateParams;
//      console.log("Expense Guid",$scope.selecteddataexpense);
    }


//Expenses  Details
    $scope.viewSelectedExpense = function(){
    if(!!$scope.selecteddataexpense && !!$scope.selecteddataexpense.expense_guid){
        var expguid = $scope.selecteddataexpense.expense_guid;
        $scope.expguid = $scope.selecteddataexpense.expense_guid;
    //                        console.log($scope.expguid);
        var expensedetailsid = GetExpenseData.getexpensedata(expguid).get()
                              .$promise.then(
                                function(response){

                                    $scope.selectedexpensedetails = response;
//                                    console.log($scope.selectedexpensedetails);
                                        $scope.selecteddatacostshareexpense = _.get($scope.selectedexpensedetails, 'cost_share_json');
                                        //$scope.gridExpenseCostshare.data = $scope.selecteddatacostshareexpense;
                                        var costShareArr = [];
                                        $.each(response.cost_share_json, function (indexCost, valueCost) {
                                            costShareArr.push(valueCost);
                                        });
                                        $scope.gridExpenseCostshare.data = costShareArr;
                                },
                                function(err){
                                  alert("Service error");
                                }
                             );
        }
    };
    $scope.viewSelectedExpense();




//  Post request for new expenses
$scope.submitAppExpense = function(){
  var response = {"expense_type":$scope.Appexpense_type,"expense_description":$scope.Appexpense_desc,"expense_status_desc":$scope.Appexpense_status,"expense_amount":$scope.Appexpense_amount,"application_id":$scope.appID,"farm_id":$scope.farm_id};
  AddExpense.addexpense().save(response)
    .$promise.then(
       function(response){
          $state.reload();
          $uibModalInstance.close(response);
          modalMessageService.showMessage( "Success:","Added New Expense Successfully");
       },
       function(response) {
            $log.debug("ERROR ADDING New Expense :", response);
           if (response.data.result === 'error' ) {
               modalMessageService.showMessage( "Error:", response.data.message);
            } else {
                modalMessageService.showMessage( "Error:", "An error occurred. ");
            }
            $log.debug("Error: "+response.status + " " + response.statusText);
        }
  );
//    $uibModalInstance.close(response);
};



 // Submit Edit  Expense
    $scope.submitEditExpense = function(){
      var data={
          "expense_guid": $scope.selectedexpensedetails.expense_guid,
          "expense_amount": $scope.selectedexpensedetails.expense_amount,
          "expense_description":$scope.selectedexpensedetails.expense_description,
          "expense_status_desc":$scope.selectedexpensedetails.expense_status_desc,
          "farm_id":$scope.farm_id,
          "application_id":$scope.selectedexpensedetails.application_id,
          "cost_share_json":$scope.gridExpenseCostshare.data,
      };
      console.log(data);
      UpdateExpense.updateexpense().update({guid:data.expense_guid},data)
            .$promise.then(
               function(response){
                  $state.reload();
                  $uibModalInstance.dismiss();
                  modalMessageService.showMessage( "Success:","Expense Edited Successfully");
               },
               function(response) {
                    $log.debug("ERROR Editing Expense:", response);
                   if (response.data.result === 'error' ) {
                       modalMessageService.showMessage( "Error:", response.data.message);
                    } else {
                        modalMessageService.showMessage( "Error:", "An error occurred. ");
                    }
                    $log.debug("Error: "+response.status + " " + response.statusText);
                }
            );
    };



// Payments  Details
    $scope.viewSelectedPayment = function(){
      PaymentDataService.setSelectedPayment($scope.gridApiPayments.selection.getSelectedRows());
      $scope.selectedRows = $scope.gridApiPayments.selection.getSelectedRows()[0];
      $scope.selectedguidpayment = $scope.selectedRows.expense_payment_guid;
      var expense_payment_guid = $scope.selectedguidpayment;
      $location.path('/finance/payments/paymentdetail/'+expense_payment_guid);

    };


    $scope.viewSelectedPaymentd = function(){
        console.log('modalinstancectrl-viewSelectedPaymentd');
        if(!!$stateParams){
            $scope.selecteddatapayment = $stateParams;
        }
        if(!!$scope.selecteddatapayment && !!$scope.selecteddatapayment.expense_payment_guid){
            var paymentguid = $scope.selecteddatapayment.expense_payment_guid;
            $scope.paymentguid = $scope.selecteddatapayment;
            var paymentdetailsid = GetPaymentInfo.getpaymentinfo(paymentguid).get()
                .$promise.then(
                    function(response){

                        $scope.selectedpaymentdetails = response;
                        console.log('paymentdetails',$scope.selectedpaymentdetails);
                    },
                    function(err){
                        $scope.selectedpaymentdetails = null;
                    }
                );
        }
    };
    $scope.viewSelectedPaymentd();

    if(!!$stateParams){
        $scope.selecteddatapayment = $stateParams;
    }




    var newcostsharerow = {
                "cost_per_acre": "",
                "payment_source":"" ,
                "share_description": "",
                "share_amount":"",
            };
     $scope.addNewcostshare = function(row){
      $scope.gridReapPay.data.push({
                "cost_per_acre": "",
                "payment_source":"" ,
                "share_description": "",
                "share_amount":"",
            });
    };



//Adding empty row  and deleting empty row

   $scope.addNewRow = function(){
      $scope.gridExpenseCostshare.data.push({});
    };

    $scope.deleteRow = function(){
       // $scope.gridApiFunds.selection.getSelectedRows()
        angular.forEach($scope.gridApiExpenseCostshare.selection.getSelectedRows(), function (data, index) {
          $scope.gridExpenseCostshare.data.splice($scope.gridExpenseCostshare.data.lastIndexOf(data), 1);
        });

   };


// Register the grid for API calls like clearSelectedRows() and getSelectedRows()

    $scope.gridExpenseCostshare.onRegisterApi = function(gridApiExpenseCostshare){
        $scope.gridApiExpenseCostshare = gridApiExpenseCostshare;
        gridApiExpenseCostshare.selection.on.rowSelectionChanged($scope,function(row){
        var msg = 'row selected'+row.isSelected;
         $scope.selectedRows = $scope.gridApiExpenseCostshare.selection.getSelectedRows()[0];
         $scope.selectedguidfund = $scope.selectedRows.fund_guid;
          console.log($scope.selectedguidfund);
        });
    };


});
