(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    .controller('EmailActionController', ['$scope', '$log', '$uibModalInstance', '$timeout', 'clipboard', 'users',
        function($scope, $log, $uibModalInstance, $timeout, clipboard, users ) {

            //$scope.users = users;
            // Break email_users into emails to display ( email@email.com ( firstname, lastname) )
            // and actual emails
            $scope.real_emails = users.emails;
            $scope.display_emails = users.display_emails;

            $scope.textCopied = false;
            $scope.clipboardNotSupported = false;

            // Changes the delimiter for the display emails
            $scope.delimit_display_emails = function() {
                if ($scope.delim_value === 'semicolon') {
                    $log.debug("CHANGING TO SEMICOLON FOR DISPLAY EMAILS");
                    return $scope.display_emails.join('; ');
                } else if ($scope.delim_value === 'comma') {
                    $log.debug("CHANGING TO COMMA FOR DISPLAY EMAILS");
                    return $scope.display_emails.join(', ');
                }
            };

            // Changes the delimiter for the real email list
            $scope.delimit_real_emails = function() {
                if ($scope.delim_value === 'semicolon') {
                    $log.debug("CHANGING TO SEMICOLON FOR REAL EMAILS");
                    return $scope.real_emails.join('; ');
                } else if ($scope.delim_value === 'comma') {
                    $log.debug("CHANGING TO COMMA FOR REAL EMAILS");
                    return $scope.real_emails.join(', ');
                }
            };

            // Set init value for delimiter
            $scope.delim_value = 'semicolon';
            $log.debug("BEFORE CALLING DELIMIT DISPLAY EMAILS:", $scope.display_emails);
            $scope.display_delimited_emails = $scope.delimit_display_emails();
            $log.debug("AFTER CALLING DELIMIT DISPLAY EMAILS:", $scope.display_emails);
            $scope.actual_delimited_emails = $scope.delimit_real_emails();

            $scope.change_delim = function(delim_value){
                $scope.delim_value = delim_value;
                $scope.display_delimited_emails = $scope.delimit_display_emails();
                $scope.actual_delimited_emails = $scope.delimit_real_emails();
            };

            $scope.copyToClipboard = function(){
                if (!clipboard.supported) {
                    $scope.clipboardNotSupported = true;
                }
                $log.debug("COPYING TO CLIPBOARD");
                clipboard.copyText($scope.actual_delimited_emails);
                $scope.textCopied = true;
                $timeout(function(){
                    $log.debug("TIMEOUT FIRED:");
                    $scope.textCopied = false;
                }, 2000);

            };

            $scope.close = function () {
                $uibModalInstance.close();
            };
        }])
;