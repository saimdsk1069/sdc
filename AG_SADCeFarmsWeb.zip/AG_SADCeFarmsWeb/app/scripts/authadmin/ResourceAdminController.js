(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    .controller('ResourceAdminController', ['$scope', '$log', '$state', '$timeout', '$uibModal', '$sce',
            'userFactory', 'resourceFactory', 'allResourceFactory', 'resourcePermissionFactory',
            'allRoleAndURLPermissionFactory', 'inviteFactory',
            'activateFactory', 'deactivateFactory', 'unregisterFactory', 'statusFactory',
            'orgtypeFactory', 'rolesFactory', 'partnersFactory', 'tiersFactory', 'groupsFactory', 'subgroupsFactory',
            'countiesFactory', 'municipalitiesFactory', 'userSkeleton', 'uiGridConstants', 'modalService',
            'modalMessageService', 'agSupportEmail', 'SharedRoleService', 'AuthService',
        function($scope, $log, $state, $timeout, $uibModal, $sce,
            userFactory, resourceFactory, allResourceFactory, resourcePermissionFactory,
            allRoleAndURLPermissionFactory, inviteFactory,
            activateFactory, deactivateFactory, unregisterFactory, statusFactory,
            orgtypeFactory, rolesFactory, partnersFactory, tiersFactory, groupsFactory, subgroupsFactory,
            countiesFactory, municipalitiesFactory, userSkeleton, uiGridConstants, modalService,
            modalMessageService, agSupportEmail, SharedRoleService, AuthService ) {

            var error_message = '';

            $scope.resource = { 'resource_name': ''};
            $scope.message = "";
            $scope.roles_and_perms = [];
            SharedRoleService.clearRoles();

            // **************************************************************************************************
            //**************************** WATCHED VARIABLE FUNCTIONS *******************************************
            // **************************************************************************************************

            // Check for changes in selected roles to init the assigned roles box
            $scope.$watchCollection(function(){
                return SharedRoleService.selectedRoleGuids;
            }, function() {
                $scope.disableEditButton = true;
                $scope.permChangeDisabled = true;
                //$log.debug("+++Selected Role Change in ResourceAdminController", SharedRoleService.selectedRoleGuids);
                if ( SharedRoleService.selectedRoleGuids.length > 1 ) {
                    $scope.selectedRoleMessage = "Only one Assigned Role should be selected in order to edit permissions.";
                } else if ( SharedRoleService.selectedRoleGuids.length == 0 ) {
                    $scope.selectedRoleMessage = "";
                } else {
                    // Only one selected so get the permissions
                    $scope.selectedRoleMessage = "";
                    $scope.disableEditButton = false;
                    clearPerms();
                    setResourcePermsInUi();
                }
            });
            // Check for changes as roles are added to selected roles from all roles and add them to roles_and_perms
            $scope.$watchCollection(function(){
                return SharedRoleService.allSelectedRoleGuids;
            }, function() {
                var new_roles_and_perms = [];
                // create new array of roles and permissions based the selected roles.  If a selected
                // role is already in $scope.roles_and_perms, copy over the permissions to the new array.
                // If it is not already in $scope.roles_and_perms, create empty permission.
                angular.forEach( SharedRoleService.allSelectedRoleGuids, function(new_role_guid) {
                    // Search existing $scope.roles_and_perms and move over any existing roles and perms
                    existingRoleIndex = getGuidIndexInExistingRolesAndPerms(new_role_guid);
                    if (existingRoleIndex != -1){
                        new_roles_and_perms.push($scope.roles_and_perms[existingRoleIndex]);
                    } else {
                        new_roles_and_perms.push({'role_guid': new_role_guid, 'permission': [] });
                    }
                });
                // Clear any current permissions
                clearPerms();
                // Disable edit permission button and permissions
                $scope.disableEditButton = true;
                $scope.permChangeDisabled = true;
                //$log.debug("+-+-+New Roles and Permissions:", new_roles_and_perms);
                $scope.roles_and_perms = new_roles_and_perms;
            });

            var getGuidIndexInExistingRolesAndPerms = function(role_guid) {
                for ( var i = 0; i < $scope.roles_and_perms.length; ++i) {
                    if ( role_guid == $scope.roles_and_perms[i].role_guid) {
                        return i;
                    }
                }
                return -1;
            };

            // Set the permissions in the UI for editing
            var setResourcePermsInUi = function() {
                angular.forEach( $scope.roles_and_perms, function(role_perm) {
                    if ( role_perm.role_guid == SharedRoleService.selectedRoleGuids[0] ){
                        //$log.debug("Matched selected role with role permission response");
                        angular.forEach( role_perm.permission, function(permission) {
                            //$log.debug("Permission for Role GUID", role_perm.role_guid,permission);
                            // Set the permission in the UI
                            $scope.chkbox_perms[permission] = true;
                        });
                    }
                });
                $log.debug("CURRENT STATUS OF permission checkboxes:", $scope.chkbox_perms);
            };

            var clearPerms = function() {
                $scope.chkbox_perms = {
                    'GET': false,
                    'POST': false,
                    'PUT': false,
                    'DELETE': false
                };
            };

            // **************************************************************************************************
            //********************************* UI Functions and variables **************************************
            // **************************************************************************************************

            $scope.manageResource = false;
            $scope.modresource = false;
            $scope.showmessage = false;
            $scope.disableEditButton = true;
            $scope.permChangeDisabled = true;
            $scope.selectedRoleMessage = '';

            $scope.manageResourcePermissions = function() {
                var selectedCount = $scope.gridApiResource.selection.getSelectedCount();
                $log.debug("SELECTED COUNT:", selectedCount);
                if (selectedCount == 0) {
                    $scope.message = 'No resource was selected. Please select one.';
                } else {
                    var selectedRows = $scope.gridApiResource.selection.getSelectedRows();
                    $scope.manageThisResource = selectedRows[0].auth_url_address;
                    $log.debug("Requesting permissions associated with resource", selectedRows[0].auth_url_guid);
                    resourcePermissionFactory.doResources().get({auth_url_guid:selectedRows[0].auth_url_guid})
                        .$promise.then(
                        function(response){
                            $log.debug("RESPONSE FOR RESOURCE PERMISSION:",response);
                            $scope.roles_and_perms = response.roles_and_perms;
                            $scope.currently_managed_resource = response.auth_url_guid;
                            var init_role_guids = [];
                            angular.forEach( $scope.roles_and_perms, function(role_perm) {
                                init_role_guids.push(role_perm.role_guid);
                            });
                            $log.debug("+++SETTING VALUE FOR ROLE CONTROLLER:", init_role_guids);
                            // First clear them out, then reset them.
                            SharedRoleService.initialRoleGuids = init_role_guids;
                        },
                        function(response) {
                            if ( response.status == 403 ) {
                                $state.go('app.autherror');
                                modalMessageService.showMessage( "Error:", "You do not have permission to access this page.");
                            } else {
                                // If there is an error getting resources from datbase,
                                // this will have an error as well.  If so, put the message in the error modal.
                                $log.debug("AFTER GETING ERROR FROM DETAILS:", $scope.userdetails);
                                $log.debug("Error: "+response.status + " " + response.statusText);
                                modalMessageService.showMessage( "Error:", response.status + " " +
                                    response.statusText + '. Please contact ' + agSupportEmail);
                            }
                            // Turn off loading data image
                            $scope.loading_data = false;
                        }
                    );
                    $scope.manageResource = true;
                }
                $scope.showmessage = true;

            };


            $scope.addResource = function() {
                $scope.state = 'add';
                $scope.clearResourceSelection();
                $scope.message = 'Enter a new resource name.';
                $scope.modresource = true;
                $scope.showmessage = true;
            };

            $scope.updateResource = function() {
                $scope.state = 'update';
                var selectedCount = $scope.gridApiResource.selection.getSelectedCount();
                $log.debug("SELECTED COUNT:", selectedCount);
                if (selectedCount == 0) {
                    $scope.message = 'No resource was selected. Please select one.';
                } else {
                    $scope.message = 'Update the resource name.';
                    $scope.modresource = true;
                    var selectedRows = $scope.gridApiResource.selection.getSelectedRows();
                    $log.debug("SELECTED ROWS:", selectedRows);
                    $scope.resource.resource_name = selectedRows[0].auth_url_address;
                }
                $scope.showmessage = true;
            };

            $scope.disableResource = function() {
            };

            $scope.enableResource = function() {
            };

            $scope.showAllURLAndRolePermissions = function() {
                $scope.loading_data = true;
                allResourceFactory.getResourcePermissions().query()
                    .$promise.then(
                    function(response){
                        $scope.loading_data = false;
                        $scope.urls_and_perms = response;
                        $log.debug("RESPONSE FOR GETTING ALL RESOURCE PERMISSSIONS:", $scope.urls_and_perms);
                        var modalInstance = $uibModal.open({
                            templateUrl: 'templates/authadmin/allUrlPermissions.html',
                            controller: 'URLRolePermissionModalController',
                            backdrop: 'static',
                            size: 'lg',
                            resolve: {
                                urls_and_perms: function () {
                                    return $scope.urls_and_perms;
                                }
                            }
                        });
                        modalInstance.result.then(function (modalResponse) {
                            $log.debug("RESOURCE PERMISSION FILTER MODAL RESPONSE:", modalResponse);
                        }, function () {
                            $log.debug("CANCELED ROLE FILTER MODAL:");
                        });
                    },
                    function(response) {
                        $scope.loading_data = false;
                        if ( response.status == 403 ) {
                            $state.go('app.autherror');
                            modalMessageService.showMessage( "Error:", "You do not have permission to access this page.");
                        } else {
                            // If there is an error getting resources from database,
                            // this will have an error as well.  If so, put the message in the error modal.
                            $log.debug("Error getting resource permissions");
                            $log.debug("Error: "+response.status + " " + response.statusText);
                            modalMessageService.showMessage( "Error:", response.status + " " +
                                response.statusText + '. Please contact ' + agSupportEmail);
                        }
                    }
                );
            };

            $scope.showAllRoleAndURLPermissions = function() {
                $scope.loading_data = true;
                allRoleAndURLPermissionFactory.getAllRoleAndURLComponentPermissions().query()
                    .$promise.then(
                    function(response){
                        $scope.loading_data = false;
                        $scope.roles_and_urls = response;
                        $log.debug("RESPONSE FOR GETTING ALL RESOURCE PERMISSSIONS:", $scope.roles_and_urls);
                        var modalInstance = $uibModal.open({
                            templateUrl: 'templates/authadmin/allRoleAndURLPermissions.html',
                            controller: 'RoleURLPermissionModalController',
                            backdrop: 'static',
                            size: 'lg',
                            resolve: {
                                roles_and_urls: function () {
                                    return $scope.roles_and_urls;
                                }
                            }
                        });
                        modalInstance.result.then(function (modalResponse) {
                            $log.debug("RESOURCE PERMISSION FILTER MODAL RESPONSE:", modalResponse);
                        }, function () {
                            $log.debug("CANCELED ROLE FILTER MODAL:");
                        });
                    },
                    function(response) {
                        $scope.loading_data = false;
                        if ( response.status == 403 ) {
                            $state.go('app.autherror');
                            modalMessageService.showMessage( "Error:", "You do not have permission to access this page.");
                        } else {
                            // If there is an error getting resources from database,
                            // this will have an error as well.  If so, put the message in the error modal.
                            $log.debug("Error getting resource permissions");
                            $log.debug("Error: "+response.status + " " + response.statusText);
                            modalMessageService.showMessage( "Error:", response.status + " " +
                                response.statusText + '. Please contact ' + agSupportEmail);
                        }
                    }
                );
            };

            $scope.submitCommand = function() {
                $scope.message = '';
                $scope.modresource = false;
                $scope.showmessage = false;
                if ( $scope.state == 'add' ) {
                    $scope.doResourceAdd();

                } else if ( $scope.state == 'update') {
                    $scope.doResourceUpdate();
                }
                $scope.resource.resource_name = '';

            };

            $scope.cancelCommand = function() {
                $scope.message = '';
                $scope.modresource = false;
                $scope.showmessage = false;
                $scope.resource.resource_name = '';

            };

            // Function to handle editing permission on a resource
            $scope.editPermissions = function(){
                // Only allow setting of permissions if one role is selected
                if ( SharedRoleService.selectedRoleGuids.length > 1 ) {
                    $scope.selectedRoleMessage = "Only one Assigned Role should be selected in order to edit permissions.";
                    $scope.permChangeDisabled = true;
                    clearPerms();
                } else if ( SharedRoleService.selectedRoleGuids.length == 0 ) {
                    $scope.selectedRoleMessage = "One Assigned Role should be selected in order to edit permissions.";
                    $scope.permChangeDisabled = true;
                } else {
                    $log.debug("NUMBER OF SELECTED ROLES:", SharedRoleService.selectedRoleGuids.length);
                    $log.debug("Selected Role::", SharedRoleService.selectedRoleGuids);
                    $log.debug("Current Roles and Perms:", $scope.roles_and_perms);
                    $scope.selectedRoleMessage = 'Edit permisssions for ' + SharedRoleService.selectedRoleNames[0];
                    $scope.permChangeDisabled = false;
                }
            };
            // Function that fires when a permission is toggled.
            $scope.selectPerm = function(perm) {
                //$log.debug("Toggling perm for ", perm);
                //$log.debug("Value for perm from UI:", $scope.chkbox_perms[perm]);
                //$log.debug("Current value of all perm checkboxes:", $scope.chkbox_perms);
                $log.debug("Current keys in perm checkboxes:", Object.keys($scope.chkbox_perms));
                var permKeys = Object.keys($scope.chkbox_perms);
                var permArray = [];
                angular.forEach( permKeys, function(permKey) {
                    if ($scope.chkbox_perms[permKey] == true) {
                        permArray.push(permKey);
                    }
                });
                $log.debug("permkey array after toggling", permArray);
                updateResourcePermission(permArray);
                $log.debug("Roles and perms after update of permissions:",$scope.roles_and_perms);
            };

            // Saves the updated roles and permissions to database for a resource
            $scope.savePermissions = function(){
                $log.debug("savePermission executed");
                //Create a new object to hold updated roles and permissions
                $scope.updated_resource_roles_and_perms = {'auth_url_guid': $scope.currently_managed_resource, 'roles_and_perms': [] };
                // Loop through each role_and_perm and if permissions are empty, don't include it when saving
                angular.forEach( $scope.roles_and_perms, function(role_and_perms) {
                    if ( role_and_perms.permission.length != 0 ) {
                        $scope.updated_resource_roles_and_perms.roles_and_perms.push(role_and_perms);
                    }
                });
                $log.debug("REQUEST FOR UPDATE", $scope.updated_resource_roles_and_perms);
                $scope.updateResourcePermissions();
            };

            // Cancels the updating of resource permissions
            $scope.cancelUpdatePermissions = function() {
                // Clear permission check boxes
                clearPerms();
                // Disable edit permission button and permissions
                $scope.disableEditButton = true;
                $scope.permChangeDisabled = true;
                // Clear selected roles
                SharedRoleService.selectedRoleGuids = [];
                SharedRoleService.selectedRoleNames = [];
                SharedRoleService.initialRoleGuids = [];
                $log.debug("cancelUpdatePermissions executed");
                // Hide permission stuff
                $scope.manageThisResource = '';
                $scope.manageResource = false;

            };

            // **************************************************************************************************
            // ********************* SUPPORTING FUNCTIONS *******************************************************
            // **************************************************************************************************

            //********************* UPDATE RESOURCE *******************************
            $scope.doResourceUpdate = function(){
                // Get the value for the url from the form text field
                $log.debug("UPDATED FIELD:", $scope.resource.resource_name);
                var resource_url = { "auth_url_address": $scope.resource.resource_name };
                // Get the url guid from the currently selected row
                var auth_url_guid = $scope.gridApiResource.selection.getSelectedRows()[0].auth_url_guid;
                $log.debug("Updating", auth_url_guid, "with", resource_url);
                resourceFactory.doResources().update( {auth_url_guid:auth_url_guid}, resource_url )
                    .$promise.then(
                    function(response){
                        $log.debug("RESPONSE FROM doResources", response);
                        // Update field on grid ( only one row can be selected )
                        var selectedRow = $scope.gridApiResource.selection.getSelectedRows()[0];
                        updateGridWithResponse( selectedRow, response);
                        $scope.clearResourceSelection();
                        $scope.loading_data = false;
                    },
                    function(response) {
                        if ( response.status == 403 ) {
                            $state.go('app.autherror');
                            modalMessageService.showMessage( "Error:", "You do not have permission to access this page.");
                        } else {
                            $log.debug("AFTER GETING ERROR FROM UPDATE:", response);
                            $log.debug("Error: "+response.status + " " + response.statusText);
                            $log.debug("ERROR DATA MESSAGE:", response.data.message );
                            if ( response.data.message == 'err-a016') {
                                $log.debug("match with err-a016:", response.data.message );
                                error_message = "A resource with that name already exists.";
                            } else {
                                $log.debug("no match with err-a016:", response.data.message );
                                error_message = "An error occurred updating the resource.";
                            }
                            modalMessageService.showMessage( "Error:", error_message);
                        }
                        $scope.loading_data = false;
                    }
                );
            };

            // ********************** ADD RESOURCE **************************************
            $scope.doResourceAdd = function() {
                // Save currently selected rows
                $log.debug("Inside doAddResource:");
                var resource_url = { "auth_url_address": $scope.resource.resource_name };
                $log.debug("POST BODY TO SEND:", resource_url);
                resourceFactory.doResources().save( resource_url )
                    .$promise.then(
                    function(response){
                        $log.debug("RESPONSE FROM doAddResource", response);
                        // Add user to grid
                        $scope.gridResource.data.push(response);
                        refreshGrid();
                    },
                    function(response) {
                        if ( response.status == 403 ) {
                            $state.go('app.autherror');
                            modalMessageService.showMessage( "Error:", "You do not have permission to access this page.");
                        } else {
                            $log.debug("AFTER GETING ERROR FROM ADD:", response);
                            $log.debug("Error: "+response.status + " " + response.statusText);
                            if ( response.data.message == 'err-a016') {
                                error_message = "A resource with that name already exists";
                            } else {
                                error_message = "An error occurred creating the resource.";
                            }
                            modalMessageService.showMessage( "Error:", error_message);
                        }

                        $scope.loading_data = false;
                    }
                );
            };

            // Take a permission array containing GET, PUT, POST, and/or DELETE and update the permission element
            // of the current role_and_permission object
            var updateResourcePermission = function(permArray){
                // Current role being edited is: SharedRoleService.selectedRoleGuids
                // All currently selected roles and perms are stored in:$scope.roles_and_perms
                angular.forEach( $scope.roles_and_perms, function(role_and_perm) {
                    if ( role_and_perm.role_guid == SharedRoleService.selectedRoleGuids ) {
                        role_and_perm.permission = permArray;
                    }
                });
            };

            // ******************************* UPDATE PERMISSIONS *********************************************
            $scope.updateResourcePermissions = function() {
                $scope.loading_data = true;
                resourcePermissionFactory.doResources().update({auth_url_guid:$scope.currently_managed_resource}, $scope.updated_resource_roles_and_perms)
                    .$promise.then(
                    function(response){
                        $log.debug("RESPONSE FOR UPDATE RESOURCE PERMISSION:",response);
                        modalMessageService.showMessage( "Success:", "Permissions updated successfully");
                        $scope.loading_data = false;
                        $scope.selectedRoleMessage = '';
                        $scope.permChangeDisabled = true;
                    },
                    function(response) {
                        if ( response.status == 403 ) {
                            $state.go('app.autherror');
                            modalMessageService.showMessage( "Error:", "You do not have permission to access this page.");
                        } else {
                            $log.debug("Error: ",response);
                            modalMessageService.showMessage( "Error:", response.status + " " +
                                response.statusText + '. Please contact ' + agSupportEmail + ' and mention Error ' + response.data.message + '.');
                        }
                        // Turn off loading data image
                        $scope.loading_data = false;
                    }
                );
            };

            // **************************************************************************************************
            // ********************* GRID RELATED FUNCTIONS *****************************************************
            // **************************************************************************************************

            var updateGridWithResponse = function( gridRow, response ){
                $log.debug("RESPONSE FROM UPDATE:",response);
                $log.debug("ROW TO UPDATE:", gridRow);
                var entityKeys = Object.keys(gridRow);
                $log.debug("ENTITY KEYS:", entityKeys);
                angular.forEach( entityKeys, function(key) {
                    //$log.debug("ENTITY KEY:", key);
                    if ( ! key.startsWith('$$') ) {
                        gridRow[key] = response[key];
                    }
                });
                //Refresh grid to keep sort intact
                refreshGrid();
            };


            // ***************** DEFINE SORT ORDER *************************************************
            var setInitSort = function(){
                $log.debug("INSIDE setInitSort");
                var url_col = $scope.gridApiResource.grid.getColumn('auth_url_address');
                $scope.gridApiResource.grid.sortColumn(url_col, uiGridConstants.ASC );
            };

            // **************** GRID REFRESH ****************************************************
            var refreshGrid = function() {
                $log.debug("Inside refreshGrid()");
                $scope.gridApiResource.grid.notifyDataChange(uiGridConstants.dataChange.ALL);
            };

            // Executed when row is selected
            var rowResourceSelectionWasChanged = function(row){
                // Clear message and hide resource text box
                $scope.message = '';
                $scope.showmessage = false;
                $scope.modresource = false;
                var selected_count = $scope.gridApiResource.selection.getSelectedCount();
                if ( selected_count == 0 ) {
                    $log.debug("++SELECTED COUNT = 0");
                    $scope.rows_selected = false;
                } else {
                    $log.debug("++SELECTED COUNT > 0");
                    $scope.rows_selected = true;
                }
            };

            //******************** RESOURCE GRID *************************************
            $scope.gridResource = {
                enablePaginationControls: false,
                //paginationPageSize: 5,
                enableFiltering: true,
                saveSelection: true,
                enableRowHeaderSelection: true,
                selectionRowHeaderWidth: 30,
                multiSelect: false,
                rowHeight: 30,
                showGridFooter:false,
                columnDefs: [
                    {field: 'auth_url_guid', visible: false },
                    {field: 'auth_url_address', displayName: 'Resource Name', width: 200, enableHiding: false, pinnedLeft:true }
                ]
            };
            // Register the grid for API calls like clearSelectedRows() and getSelectedRows()
            $scope.gridResource.onRegisterApi = function(gridApiResource){
                $log.debug("INSIDE onRegisterApi call");
                $scope.gridApiResource = gridApiResource;
                // Register callback function for when a single row selection or all row selection toggles
                gridApiResource.selection.on.rowSelectionChanged($scope,rowResourceSelectionWasChanged);
                gridApiResource.selection.on.rowSelectionChangedBatch($scope,rowResourceSelectionWasChanged);
            };

            $scope.clearResourceSelection = function(){
                $scope.gridApiResource.selection.clearSelectedRows();
            };

            // ****************** FETCH ALL ROWS AND FILL THE GRID *********************************
            $scope.getResourceDetails = function() {
                // Display loading image while fetching data
                $log.debug("INSIDE getResourceDetails");
                $scope.loading_data = true;
                resourceFactory.doResources().query()
                    .$promise.then(
                    function(response){
                        $log.debug("RESPONSE FROM GETTING RESOURCES:", response);
                        $scope.gridResource.data = response;
                        setInitSort();
                        //$log.debug("gridResource.data:",$scope.gridResource.data );
                        // Turn off loading data image
                        $scope.loading_data = false;

                    },
                    function(response) {
                        if ( response.status == 403 ) {
                            $state.go('app.autherror');
                            modalMessageService.showMessage( "Error:", "You do not have permission to access this page.");
                        } else {
                            // If there is an error getting resources from datbase,
                            // this will have an error as well.  If so, put the message in the error modal.
                            $log.debug("AFTER GETING ERROR FROM DETAILS:", $scope.userdetails);
                            $log.debug("Error: "+response.status + " " + response.statusText);
                            modalMessageService.showMessage( "Error:", response.status + " " +
                                response.statusText + '. Please contact ' + agSupportEmail);
                        }
                        // Turn off loading data image
                        $scope.loading_data = false;

                    }
                );
            };

            // *********************************************************************************
            // ************************ Initial load of data to start it all off ***************
            // *********************************************************************************
            $scope.getResourceDetails();

        }])
;
