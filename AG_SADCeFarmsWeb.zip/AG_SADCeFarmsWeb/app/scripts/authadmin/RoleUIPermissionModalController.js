(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    .controller('RoleUIPermissionModalController', ['$scope', '$log', '$uibModalInstance', 'ui_roles_and_components',
        function($scope, $log, $uibModalInstance, ui_roles_and_components ) {

            $scope.today = new Date();

            $scope.ui_roles_and_components = ui_roles_and_components;

            $scope.Close = function () {
                $uibModalInstance.dismiss();
            };

            $scope.print = function () {
                window.print();
            };
        }]);
