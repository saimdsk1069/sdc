(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    .controller('RoleURLPermissionModalController', ['$scope', '$log', '$uibModalInstance', 'roles_and_urls',
        function($scope, $log, $uibModalInstance, roles_and_urls ) {

            $scope.today = new Date();

            $scope.roles_and_urls = roles_and_urls;
            $log.debug("INSIDE MODAL:", $scope.roles_and_urls);

            $scope.Close = function () {
                $uibModalInstance.dismiss();
            };

            $scope.print = function () {
                window.print();
            };
        }]);
