(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    .controller('UIPermissionModalController', ['$scope', '$log', '$uibModalInstance', 'ui_components_and_perms',
        function($scope, $log, $uibModalInstance, ui_components_and_perms ) {

            $scope.today = new Date();

            $scope.ui_components_and_perms = ui_components_and_perms;

            $scope.Close = function () {
                $uibModalInstance.dismiss();
            };

            $scope.print = function () {
                window.print();
            };
        }]);

