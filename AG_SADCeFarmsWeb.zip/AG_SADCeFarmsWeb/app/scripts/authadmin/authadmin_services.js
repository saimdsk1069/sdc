(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    //.constant("baseURL", "/AG_SADCeFarms/")
    //.constant("agSupportEmail", "efarmssupport@ag.nj.gov")
    //.service('authAdminErrors', function(){
    //    var errors = {
    //        'err-a001': {'d_msg': 'Missing Auth User GUID', 'ui_msg': ''},
    //        'err-a002': {'d_msg': 'User does not exist.', 'ui_msg': ''},
    //        'err-a003': {'d_msg': 'Email field missing', 'ui_msg': ''},
    //        'err-a004': {'d_msg': 'Email is empty', 'ui_msg': ''},
    //        'err-a005': {'d_msg': 'User already exists.', 'ui_msg': ''},
    //        'err-a006': {'d_msg': 'Error Serializing User.', 'ui_msg': ''},
    //        'err-a007': {'d_msg': 'User status Created not found.', 'ui_msg': ''},
    //        'err-a008': {'d_msg': 'User status Invited not found', 'ui_msg': ''},
    //        'err-a009': {'d_msg': 'User status Pre-Registered not found.', 'ui_msg': ''},
    //        'err-a010': {'d_msg': 'User status Registered not found.', 'ui_msg': ''},
    //        'err-a011': {'d_msg': 'User is already registered.', 'ui_msg': ''},
    //        'err-a012': {'d_msg': 'Error creating proxy client from WSDL.', 'ui_msg': ''},
    //        'err-a013': {'d_msg': 'Error granting role to user.', 'ui_msg': ''},
    //        'err-a014': {'d_msg': 'Error resuming registration.', 'ui_msg': ''},
    //        'err-a015': {'d_msg': 'Unknown (other) registration error.', 'ui_msg': ''},
    //        'err-a016': {'d_msg': 'Error while saving user.', 'ui_msg': ''}
    //    };
    //    this.getMessage = function(error){
    //        if (!(error in errors)) {
    //            return 'Unknown Error';
    //        }
    //        return errors[error];
    //    };
    //})


    //This service is used for communicating between the role controller and any controller that must set
    //selected role information.
    .service('SharedRoleService', ['$log', function( $log) {

        this.clearRoles = function(){
            this.initialRoleGuids = [];
            this.selectedRoleGuids = [];
            this.selectedRoleNames = [];
            this.allSelectedRoleGuids = [];

        };

        this.initialRoleGuids = [];
        this.selectedRoleGuids = [];
        this.selectedRoleNames = [];
        this.allSelectedRoleGuids = [];

    }])
    .service('AuthService', ['$resource', '$state', 'baseURL', '$log', 'Idle', 'Keepalive', 'Title', 'logoffService',
        'modalMessageService', 'agSupportEmail', 'handleError',
        function($resource, $state, baseURL, $log, Idle, Keepalive, Title, logoffService,
                 modalMessageService, agSupportEmail, handleError ) {

            // Holds value for whether user is authenticated against portal or not
            this.authState = false;
            // Holds value signifying that authentication call has been made once.  Limits calls to server for authentication
            this.authChecked = false;
            // Holds the response from the server for the authorization call.
            this.authResponse = undefined;
            // An array to hold the ui access permissions defined in the app.js states data.ui_access element
            this.currentStateAccess = undefined;

            // Initiate Idle watch
            this.startIdleWatch = function(){
                Title.timedOutMessage('eFarms');
                Idle.watch();
            };

            // Initiate Idle watch
            this.stopIdleWatch = function(){
                Idle.unwatch();
            };

                // Set the timeout value for the page to remain idle before warning user
            this.setSessionIdleTimeout = function(timeout) {
                $log.debug("+++Setting SessionIdleTimeout AuthServices.setSessionIdleTimeout to", timeout);
                Idle.setIdle(timeout);
            };

            // Set the timeout between warning the user that session will expire and actually expiring the session
            this.setSessionIdleWarningTimeout = function(timeout) {
                $log.debug("+++Setting SessionIdleWarningTimeout in AuthServices.setIdleTimeout to", timeout);
                Idle.setTimeout(timeout);
            };

            // Set the keepalive interval
            this.setKeepaliveInterval = function(delay) {
                $log.debug("+++Setting KeepaliveProvider.interval in AuthServices.setKeepaliveInterval to",delay );
                Keepalive.setInterval(delay);
                Keepalive.start();
            };

            this.authenticate = function() {
                // Return a promise
                return $resource(baseURL+"authenticate", null,  {'save':{method:'POST' }}).save().$promise;
            };

            // Set the authentication state
            this.setAuthenticatedState = function( value ){
                //$log.debug("SETTING AUTH STATUS TO:", value);
                this.authState = value;
            };

            // Set the authentication response
            this.setAuthenticateResponse = function( response ){
                $log.debug("======SETTING AUTH RESPONSE TO:", response);
                $log.debug("======UI ACCESS IS:", response.ui_access);
                this.authResponse = response;
            };

            // Return the authentication state
            this.isAuthenticated = function() {
                //$log.debug("RETURNING AUTH STATUS:", this.authState);
                return this.authState;
            };

            // Return UI Access info for authenticated user
            this.getUserUIAccess = function() {
                $log.debug("RETURNING USERS UI ACCESS:");
                if ( this.authResponse !== undefined ) {
                    if ( this.authResponse.ui_access !== undefined ) {
                        return this.authResponse.ui_access;
                    } else {
                        return [];  // return empty response denoting no ui access
                    }
                } else {
                    return []; //return empty response denoting no ui access
                }
                //return this.authState;
            };

            this.logoff = function (){
                $log.debug("Executing logoff function in AuthService");
                $log.debug(">>>Executing logoff function");
                logoffService.doLogoff().get()
                    .$promise.then(
                    function(response){
                        $log.debug("+++User is logged off.");
                    },
                    function(response) {
                        handleError.notify(response,'');
                    }
                );
                // deauthorize user
                this.authState = false;
                // set value to signify authorization wasn't checked
                this.authChecked = false;
                // remove saved user response from authenticate
                this.authResponse = undefined;
            };

            this.checkAccess = function(in_state) {
                var state = in_state;
                $log.debug("======Current current_state:",state);
                //this.currentStateAccess = undefined;
                // Start with access as allowed.
                var access_allowed = true;
                if ( state.permdata !== undefined ) {
                    // Check for ui_access and auth_access
                    if ( state.permdata.ui_access !== undefined && state.permdata.auth_access !== undefined ) {
                        $log.debug("======state.permdata.ui_access and state.permdata.auth_access is defined");
                        $log.debug("======state.permdata.ui_access", state.permdata.ui_access);
                        $log.debug("======state.permdata.auth_access", state.permdata.auth_access);
                        // First check to see if the state requires auth_access and the user is authenticated
                        if ( state.permdata.auth_access ) {
                            // auth access is required
                            if ( ! this.isAuthenticated() ) {
                                // User is not authenticated, but authenticated access is required for this _state,
                                // therefore return false for access_allowed
                                access_allowed = false;
                                return access_allowed;
                            }
                        } else {
                            // Authorization for this state is not required ( public state ). Therefore return true
                            // for access_allowed
                            access_allowed = true;
                            return access_allowed;
                        }
                        // At this point, the user has been authenticated.  Now check the state to see if the user has
                        // the permission to access the ui component by checking the ui_component access.
                        //this.currentStateAccess = state.permdata.ui_access;
                        $log.debug("======Looking at auth response to determine access",this.currentStateAccess);
                        access_allowed = this.check_users_ui_access_for_the_state(state.permdata.ui_access);
                    } else {
                        $log.debug("======state.permdata.ui_access or state.permdata.auth_access is not defined");
                        $log.debug("======Denying access to the component.");
                        access_allowed = false;
                    }
                } else {
                    $log.debug("======state.permdata is not defined.  Permission denied.");
                    access_allowed = false;
                }
                // TODO validate whether user should access component
                return access_allowed;
            };

            this.check_users_ui_access_for_the_state = function(currentStateAccess){
                $log.debug("======currentStateAccess:", currentStateAccess);
                $log.debug("======auth_user_ui_access:", this.authResponse.ui_access);
                var access_allowed = false;
                var auth_response_ui_access = this.authResponse.ui_access;
                angular.forEach(currentStateAccess, function(in_ui_access){
                    //$log.debug("======Checking state access", ui_access);
                    var ui_access = in_ui_access;
                    angular.forEach(auth_response_ui_access, function(user_access){
                        //$log.debug("  ======Against user access:", user_access);
                        if ( ui_access == user_access ){
                            access_allowed = true;
                        }
                    });
                });
                return access_allowed;
            };

        }])
    .service('logoffService', ['$resource', 'baseURL', function($resource, baseURL) {

        this.doLogoff = function(){
            return $resource(baseURL+"logoff", null);
        };

    }])
    .service('statusFactory', ['$resource', 'baseURL', function($resource, baseURL) {

        this.getStatusTypes = function(){
            //console.log(">>>>BASE URL:", baseURL);
            return $resource(baseURL+"status", null);
        };

    }])
    .service('orgtypeFactory', ['$resource', 'baseURL', function($resource, baseURL) {

        this.getOrgtypes = function(){
            //console.log(">>>>BASE URL:", baseURL);
            return $resource(baseURL+"orgtypes/:id", null,  {'save':{method:'POST' }});
        };

    }])
    .service('rolesFactory', ['$resource', 'baseURL', function($resource, baseURL) {

        this.getRoles = function(){
            //console.log(">>>>BASE URL:", baseURL);
            return $resource(baseURL+"roles/:id", null,  {'save':{method:'POST' }});
        };

    }])
    .service('partnersFactory', ['$resource', 'baseURL', function($resource, baseURL) {

        this.getPartners = function(){
            //console.log(">>>>BASE URL:", baseURL);
            return $resource(baseURL+"partners/:id",null,  {'save':{method:'POST' }});
        };

    }])
    .service('tiersFactory', ['$resource', 'baseURL', function($resource, baseURL) {

        this.getTiers = function(){
            //console.log(">>>>BASE URL:", baseURL);
            return $resource(baseURL+"tiers/:id",null,  {'save':{method:'POST' }});
        };

    }])
    .service('groupsFactory', ['$resource', 'baseURL', function($resource, baseURL) {

        this.getGroups = function(){
            //console.log(">>>>BASE URL:", baseURL);
            return $resource(baseURL+"groups/:id",null,  {'save':{method:'POST' }});
        };

    }])
    .service('subgroupsFactory', ['$resource', 'baseURL', function($resource, baseURL) {

        this.getSubgroups = function(){
            //console.log(">>>>BASE URL:", baseURL);
            return $resource(baseURL+"subgroups/:id",null,  {'save':{method:'POST' }});
        };

    }])
    .service('countiesFactory', ['$resource', 'baseURL', function($resource, baseURL) {

        this.getCounties = function(){
            //console.log(">>>>BASE URL:", baseURL);
            return $resource(baseURL+"counties/:id",null,  {'save':{method:'POST' }});
        };

    }])
    .service('municipalitiesFactory', ['$resource', 'baseURL', function($resource, baseURL) {

        this.getMunicipalities = function(){
            //console.log(">>>>BASE URL:", baseURL);
            return $resource(baseURL+"municipalities/:id",null,  {'save':{method:'POST' }});
        };

    }])
    .service('userFactory', ['$resource', 'baseURL', function($resource, baseURL) {

        this.getUsers = function(){
            //console.log(">>>>BASE URL:", baseURL);
            return $resource(baseURL+"users/:auth_user_guid", null, {'save':{method:'POST'},'update':{method:'PUT'}});
        };

    }])
    .service('resourceFactory', ['$resource', 'baseURL', function($resource, baseURL) {

        this.doResources = function(){
            return $resource(baseURL+"urls/:auth_url_guid", null, {'save':{method:'POST'},'update':{method:'PUT'}});
        };

    }])
    .service('allResourceFactory', ['$resource', 'baseURL', function($resource, baseURL) {

        this.getResourcePermissions = function(){
            return $resource(baseURL+"urlpermissionsandroles", null);
        };

    }])
    .service('resourcePermissionFactory', ['$resource', 'baseURL', function($resource, baseURL) {

        this.doResources = function(){
            return $resource(baseURL+"permissions/:auth_url_guid", null, {'update':{method:'PUT'}});
        };

    }])
    .service('uiComponentFactory', ['$resource', 'baseURL', function($resource, baseURL) {

        this.doUIComponents = function(){
            return $resource(baseURL+"uicomponents/:auth_ui_component_guid", null, {'save':{method:'POST'},'update':{method:'PUT'}});
        };

    }])
    .service('uiComponentPermissionFactory', ['$resource', 'baseURL', function($resource, baseURL) {

        this.doUIComponents = function(){
            return $resource(baseURL+"uipermissions/:auth_ui_component_guid", null, {'update':{method:'PUT'}});
        };

    }])
    .service('allUiPermissionFactory', ['$resource', 'baseURL', function($resource, baseURL) {

        this.getAllUiComponentPermissions = function(){
            return $resource(baseURL+"uipermissionsandroles", null);
        };

    }])

    .service('allRoleAndUiPermissionFactory', ['$resource', 'baseURL', function($resource, baseURL) {

        this.getAllRoleAndUiComponentPermissions = function(){
            return $resource(baseURL+"rolesanduipermissions", null);
        };

    }])

    .service('allRoleAndURLPermissionFactory', ['$resource', 'baseURL', function($resource, baseURL) {

        this.getAllRoleAndURLComponentPermissions = function(){
            return $resource(baseURL+"rolesandurlpermissions", null);
        };

    }])

    .service('preregFactory', ['$resource', 'baseURL', function($resource, baseURL) {

        this.preregisterUsers = function(){
            //console.log(">>>>BASE URL:", baseURL);
            return $resource(baseURL+"preregister", null, {'save':{method:'POST'}});
        };

    }])
    .service('registerFactory', ['$resource', 'baseURL', function($resource, baseURL) {

        this.registerUsers = function(){
            //console.log(">>>>BASE URL:", baseURL);
            return $resource(baseURL+"register", null, {'save':{method:'POST'}});
        };

    }])
    .service('inviteFactory', ['$resource', 'baseURL', function($resource, baseURL) {

        this.doInvite = function(){
            return $resource(baseURL+"invite",null,  {'save':{method:'POST' }});
        };

    }])
    .service('activateFactory', ['$resource', 'baseURL', function($resource, baseURL) {

        this.doActivate = function(){
            return $resource(baseURL+"activate",null,  {'save':{method:'POST' }});
        };

    }])
    .service('deactivateFactory', ['$resource', 'baseURL', function($resource, baseURL) {

        this.doDeactivate = function(){
            return $resource(baseURL+"deactivate",null,  {'save':{method:'POST' }});
        };

    }])
    .service('unregisterFactory', ['$resource', 'baseURL', function($resource, baseURL) {

        this.doUnregister = function(){
            return $resource(baseURL+"unregister",null,  {'save':{method:'POST' }});
        };

    }])

    .service('userSkeleton', ['$resource', function($resource ) {
        this.getUser = function(){
            return {
                "salutation": "",
                "first_name": "",
                "last_name": "",
                "title": "",
                "organization": "",
                "address": "",
                "address_2": "",
                "city": "",
                "state": "",
                "zip": "",
                "zip4": "",
                "email_primary": "",
                "email_alternate": "",
                "phone_primary": "",
                "phone_primary_ext": "",
                "phone_alternate": "",
                "phone_alternate_ext": "",
                //"auth_user_status_desc": "",
                "contact_type_desc": null,
                "person_type_desc": "",
                "role": []
            };

        };
    }])
    .service('salutationsGetter', ['$resource', function($resource ) {
        this.getSalutations = function(){
            return [
                {value: "", label: "" },
                {value: "Mr.", label: "Mr." },
                {value: "Mrs.", label: "Mrs." },
                {value: "Ms.", label: "Ms." },
                {value: "Mr. & Mrs.", label: "Mr. & Mrs." }
            ];
        };
    }])

    .service('modalService', [ '$log', '$uibModal',  function( $log, $uibModal ) {
        var modalDefaults = {
            backdrop: true,
            keyboard: true,
            modalFade: true,
            templateUrl: 'templates/authadmin/modal.html'

        };

        var modalOptions = {
            closeButtonText: 'Close',
            closeButtonVisible: true,
            actionButtonText: 'OK',
            actionButtonVisible: true,
            headerText: 'Proceed?',
            bodyText: 'Perform this action?'
        };

        this.showModal = function (customModalDefaults, customModalOptions, resultToGet ) {
            if (!customModalDefaults) customModalDefaults = {};
            customModalDefaults.backdrop = 'static';
            if (!resultToGet) resultToGet = {};
            $log.debug("in showModal resultToGet:", resultToGet);
            return this.show(customModalDefaults, customModalOptions, resultToGet );
        };

        this.show = function (customModalDefaults, customModalOptions, resultToGet ) {
            //Create temp objects to work with since we're in a singleton service
            var tempModalDefaults = {};
            var tempModalOptions = {};
            var tmpResultToGet = resultToGet;

            //Map angular-ui modal custom defaults to modal defaults defined in service
            angular.extend(tempModalDefaults, modalDefaults, customModalDefaults);

            //Map modal.html $scope custom properties to defaults defined in service
            angular.extend(tempModalOptions, modalOptions, customModalOptions);

            if (!tempModalDefaults.controller) {
                tempModalDefaults.controller = ('TempModalController', ['$scope', '$uibModalInstance',
                    function ($scope, $uibModalInstance, customModalDefaults) {
                        $scope.resultToGet = tmpResultToGet;
                        $scope.modalOptions = tempModalOptions;
                        $scope.modalOptions.ok = function (resultToGet) {
                            $uibModalInstance.close(resultToGet);
                        };
                        $scope.modalOptions.close = function () {
                            $uibModalInstance.dismiss('cancel');
                        };
                }]);
            }
            return $uibModal.open(tempModalDefaults).result;
        };
    }])

;
