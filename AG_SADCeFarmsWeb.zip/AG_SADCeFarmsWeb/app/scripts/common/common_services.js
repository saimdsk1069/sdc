(function () {
    'use strict';
}());

angular.module('agSADCeFarms')

    .constant("baseURL", "/AG_SADCeFarms/")
    .constant("agSupportEmail", "efarmssupport@ag.nj.gov")

    .service('modalMessageService', [ '$log', 'modalService', '$uibModal',  function( $log, modalService, $uibModal ) {
        this.showMessage = function ( heading, message ) {
            var modalOptions = {
                actionButtonText: 'Close',
                closeButtonVisible: false,
                headerText: heading,
                bodyText: message
            };
            modalService.showModal({}, modalOptions, {})
                // We don't care about the response
                .then( function(response){
                    $log.debug("Finished with modal message service");
                }, function(){
                    $log.debug("Finished with modal message service");
                });
        };

    }])
    .service('handleError', [ '$log', '$state', 'modalMessageService', 'agSupportEmail',
        function( $log, $state, modalMessageService, agSupportEmail ) {
        //Standardized way of handling errors. msg not yet implemented but included so interface won't need changing
        this.notify = function( response, msg ) {
            if ( response.status == 403 ) {
                $state.go('app.autherror');
                $log.debug("Permission Denied.");
                modalMessageService.showMessage( "Error:", "You do not have permission to access this page.");
            } else {
                $log.debug("Error: "+response.status + " " + response.statusText);
                modalMessageService.showMessage( "Error:", response.status + " " +
                    response.statusText + '. Please contact ' + agSupportEmail);
            }

        };


    }]);


