(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    .controller('ExpenseController', ['$scope','$stateParams','$location','$filter', '$uibModal','AuthService','Getfund','GetTransferStatus','GetPaymentSource',
        'DeleteFund','DeletePool','DeleteGrant','DeleteExpense','FundDataService','AppropDataService','PartnerDataService','PoolDataService','ReappropDataService',
        'ExpensePayDataService','PaymentDataService','GetAppropn','UpdateApprop','UpdateReapprop','DeleteAppropriation','GetRelatedappropn','GetTransactiontype',
        'GetReappropn','DeleteReappropn','GetExpense','GetPayment','GetPartnerGrant','AddPartnerGrant','AddCompetitivePool','GetPaymentsHistory','GetAppropPayHistory',
        'GetProgramtype','GetGranttype','AddFund','UpdateFund','UpdatePayment','AddApprop','GetCompetitiveGrant','ExpenseDataService','GetPaymentInfo','GetExpenseData',
        '$state', '$log','modalService','modalMessageService','handleError',
        function($scope,$stateParams,$location,$filter,$uibModal,AuthService,Getfund,GetTransferStatus,GetPaymentSource,
            DeleteFund,DeletePool,DeleteGrant,DeleteExpense,FundDataService,AppropDataService,PartnerDataService,PoolDataService,ReappropDataService,
            ExpensePayDataService,PaymentDataService,GetAppropn,UpdateApprop,UpdateReapprop,DeleteAppropriation,GetRelatedappropn,GetTransactiontype,
            GetReappropn,DeleteReappropn,GetExpense,GetPayment,GetPartnerGrant,AddPartnerGrant,AddCompetitivePool,GetPaymentsHistory,GetAppropPayHistory,
            GetProgramtype,GetGranttype,AddFund,UpdateFund,UpdatePayment,AddApprop,GetCompetitiveGrant,ExpenseDataService,GetPaymentInfo,GetExpenseData,
            $state,$log,modalService,modalMessageService, handleError) {


////ui components
//    $scope.ui_components = {
//            'ui_fiscal_admin': false,
//        };
//
////Check the AuthService here
//if ( AuthService.isAuthenticated() ) {
//    $log.debug("++++++User is authenticated");
//    $log.debug("++++++Users ui access:", AuthService.getUserUIAccess());
//    $scope.ui_components = {
//            'ui_fiscal_admin':true
//        };
//} else {
//    $log.debug("++++++User is not authenticated");
//}

  $scope.ui_components = {
            'ui_fiscal_admin': false

        };

         var disable_ui_components = function() {
        $scope.ui_components['ui_fiscal_admin'] = false;
    };
    var setUIValues = function(){
        var ui_access = AuthService.authResponse.ui_access;
        angular.forEach( ui_access, function(comp_key) {
                if($scope.ui_components.hasOwnProperty(comp_key)){
                      $scope.ui_components[comp_key] = true;
                }
            });
    };

//AuthService
    if ( AuthService.isAuthenticated() ) {
    console.log("++++++User is authenticated");
    console.log("++++++Users ui access:", AuthService.getUserUIAccess());
    setUIValues();

    } else {
        console.log("++++++User is not authenticated");
        disable_ui_components();
    }

    $scope.$watchCollection(function(){
                return AuthService.authState;
            }, function() {
                if ( ! AuthService.authState ) {
                    $log.debug("+++AuthService.authState changed to:", AuthService.authState);
                    disable_ui_components();

                }else{
                    setUIValues();
                }
            });

// Reappropriations  Details
    $scope.viewSelectedReapprop = function(){
      ReappropDataService.setSelectedReapprop($scope.gridApiReapprops.selection.getSelectedRows());
      $scope.selectedRows = $scope.gridApiReapprops.selection.getSelectedRows()[0];
      $scope.selectedguidreapprop = $scope.selectedRows.reappropriation_guid;
        var reappropriation_guid = $scope.selectedguidreapprop;
        $location.path('/finance/reappropriations/reappropdetails/'+reappropriation_guid);
    };

     $scope.selectedReappropData = ReappropDataService.getSelectedReapprop()[0];
     $scope.selectedReappropDetails = _.get($scope.selectedReappropData, 'detail');
     if(!!$stateParams){
      $scope.selecteddataexpense = $stateParams;
    }



//Expenses  Details
    $scope.viewSelectedExpense = function(){
    if(!!$scope.selecteddataexpense && !!$scope.selecteddataexpense.expense_guid){
        var expguid = $scope.selecteddataexpense.expense_guid;
        $scope.expguid = $scope.selecteddataexpense.expense_guid;
    //                        console.log($scope.expguid);
        var expensedetailsid = GetExpenseData.getexpensedata(expguid).get()
                              .$promise.then(
                                function(response){

                                    $scope.selectedexpensedetails = response;
//                                    console.log($scope.selectedexpensedetails);
                                    $location.path('/finance/expenses/expensedetail/'+expguid);
                                },
                                function(response){
                                    $scope.loading_data = false;
                                    handleError.notify(response, '');
                                }
                             );
        }
    };
    $scope.viewSelectedExpense();
    $scope.selectedExpenseData = ExpenseDataService.getSelectedExpense()[0];
    $scope.selectedExpensePayment = _.get($scope.selectedExpenseData, 'expense_payments');
    $scope.selectedExpenseCostshare = _.get($scope.selectedExpenseData, 'cost_share_json');




// Selected Payment details based on the guid
    $scope.viewSelectedPaymentd = function(){
        if(!!$stateParams){
            $scope.selecteddatapayment = $stateParams;
        }
    if(!!$scope.selecteddatapayment && !!$scope.selecteddatapayment.expense_payment_guid){
                        var paymentguid = $scope.selecteddatapayment.expense_payment_guid;
                        $scope.paymentguid = $scope.selecteddatapayment;
                        var paymentdetailsid = GetPaymentInfo.getpaymentinfo(paymentguid).get()
                                              .$promise.then(
                                                function(response){

                                                    $scope.selectedpaymentdetails = response;
                                                        $location.path('/finance/payments/paymentdetail/'+paymentguid);
                                                },
                                                function(response){
                                                    $scope.loading_data = false;
                                                    handleError.notify(response, '');
                                                }
                                             );
                }
        };
    $scope.viewSelectedPaymentd();

      if(!!$stateParams){
          $scope.selecteddatapayment = $stateParams;
        }


// Selected Expense data
    $scope.viewSelectedExp = function(){
      ExpenseDataService.setSelectedExpense($scope.gridApiExpenses.selection.getSelectedRows());
      $scope.selectedRows = $scope.gridApiExpenses.selection.getSelectedRows()[0];
      $scope.selectedguidexpense = $scope.selectedRows.expense_guid;
        var expense_guid = $scope.selectedguidexpense;
        $log.debug("here2");
        console.log("here2");
        $location.path('/finance/expenses/expensedetail/'+expense_guid);
    };


//Expenses Payment Details
    $scope.viewSelectedExpensePayment = function(){
      ExpensePayDataService.setSelectedExpensePay($scope.gridApiExpensePayments.selection.getSelectedRows());
      $scope.selectedRows = $scope.gridApiExpensePayments.selection.getSelectedRows()[0];
      $scope.selectedguidpayment = $scope.selectedRows.expense_payment_guid;
      var expense_payment_guid = $scope.selectedguidpayment;
      $location.path('/finance/payments/paymentdetail/'+expense_payment_guid);
  };
     $scope.selectedExpensePayData = ExpensePayDataService.getSelectedExpensePay()[0];



//Payments  Details
    $scope.viewSelectedPayment = function(){
      PaymentDataService.setSelectedPayment($scope.gridApiPayments.selection.getSelectedRows());
      $scope.selectedRows = $scope.gridApiPayments.selection.getSelectedRows()[0];
      $scope.selectedguidpayment = $scope.selectedRows.expense_payment_guid;
      var expense_payment_guid = $scope.selectedguidpayment;
      $location.path('/finance/payments/paymentdetail/'+expense_payment_guid);

    };
     $scope.selectedPaymentData = PaymentDataService.getSelectedPayment()[0];



// Selected Payment Expense details
   $scope.ViewSelectedPayExpense = function(){
        var expense_guid = $scope.selectedpaymentdetails.expense_guid;
        console.log("selected expense", expense_guid);
        $location.path('/finance/expenses/expensedetail/'+expense_guid);
  };


// Selected Payment Reappropriation details
   $scope.ViewSelectedPayReapprop = function(){
        var reappropriation_guid = $scope.selectedpaymentdetails.reappropriation_guid;
        console.log("selected reappropriation guid", reappropriation_guid);
        $location.path('/finance/reappropriations/reappropdetails/'+reappropriation_guid);
  };


// Add New Payment in track expense
     $scope.openTrackExpenseModal = function() {
         var modalInstance = $uibModal.open({
            templateUrl:'views/finance/trackexpensenewpayment.html',
            controller:'FundsModalInstanceCtrl',
            backdrop: 'static',
             resolve: {
                 fundtransitems: function () {
                     return null;
                 }
             }

          });
            modalInstance.result.then(function (modalResponse) {
                    console.log("modalResponse", modalResponse);
                }, function(response){
                    $scope.loading_data = false;
                    handleError.notify(response, '');
                });
    };



// Expenses Payments details
$scope.gridExpensePayments = {
            enableSorting :true,
            enablePaginationControls: true,
            paginationPageSize: 25,
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: true,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            showGridFooter:false,
            selectedItems: [],
            enableGridMenu: true,
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 550,
            exporterMenuVisibleData : true,
            exporterCsvFilename: 'Expense_Payments.csv',
            exporterPdfDefaultStyle: {fontSize: 12},
            exporterPdfTableStyle: {margin: [30, 30, 30, 30]},
            exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
            exporterPdfHeader: { text: "Expense Payments Details", style: 'headerStyle' },
            exporterPdfFooter: function ( currentPage, pageCount ) {
              return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function ( docDefinition ) {
              docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
              docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
              return docDefinition;
            },
            exporterPdfOrientation: 'landscape',
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            exporterExcelFilename: 'Expense_Payments.xlsx',
            exporterExcelSheetName: 'Sheet1',
            enableRowSelection: true,
            enableFullRowSelection: true,
            appScopeProvider: $scope,
            rowTemplate: '<div ng-click="grid.appScope.viewselPay(row)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell" ng-class="col.colIndex()" ui-grid-cell></div>',

            columnDefs: [
                  { name:'Payment Amount', field: 'payment_amount', width: 300,cellFilter:'currency', pinnedLeft:false},
                  { name:'Payment Source', field: 'payment_source_type', width: 170,  pinnedLeft:false},
                  { name:'Payment Status', field: 'payment_status_desc', width: 170,  pinnedLeft:false},
                  { name:'Payment Comment', field: 'payment_comment', width: 250,  pinnedLeft:false },
                  { name:'Appropriation', field: 'appropriation_name', width: 250,pinnedLeft:false },
                  { name:'From Reappropriation', field: 'reapprop_flag', width: 170, pinnedLeft:false},
                  { name:'Activity Code', field: 'activity_code', width: 170, pinnedLeft:false},
                  { name:'Object Code', field: 'object_code', width: 170,  pinnedLeft:false},
                  { name:'Vendor Code', field: 'vendor_code', width: 170,  pinnedLeft:false},
                  { name:'Vendor Name', field: 'vendor_name', width: 170,  pinnedLeft:false}
        ]

    };
        $scope.viewselPay = function(row) {
            var itemguid = row.entity.expense_payment_guid;
            if (itemguid) {
                $location.path('/finance/payments/paymentdetail/'+itemguid);
            }
        };



//// Expense Payments grid table data from the guid
//$scope.gridExpenseCostshareDetails = function() {
//
//        if(!!$scope.selecteddataexpense && !!$scope.selecteddataexpense.expense_guid){
//        var expguid = $scope.selecteddataexpense.expense_guid;
//        $scope.expguid = $scope.selecteddataexpense.expense_guid;
//        var expensedetailsid = GetExpenseData.getexpensedata(expguid).get()
//                              .$promise.then(
//                                function(response){
//                                    $scope.selectedexpensedetails = response;
//                                    $scope.selecteddatapaymentexpense = _.get($scope.selectedexpensedetails, 'expense_payments');
//                                    $scope.gridExpensePayments.data = $scope.selecteddatapaymentexpense;
//
//                                },
//                                function(err){
//                                  alert("error");
//                                }
//                             );
//        }
//        };
//
//            // Do Initial Cost share   load
//            $scope.gridExpenseCostshareDetails();


// Expense cost share grid table data from the guid
$scope.gridExpenseCostshareDetails = function() {
    //loading image

    if(!!$scope.selecteddataexpense && !!$scope.selecteddataexpense.expense_guid){
            var expguid = $scope.selecteddataexpense.expense_guid;
            $scope.expguid = $scope.selecteddataexpense.expense_guid;
            var expensedetailsid = GetExpenseData.getexpensedata(expguid).get()
                                  .$promise.then(
                                    function(response){

                                        $scope.selectedexpensedetails = response;
                                        $scope.selecteddatacostshareexpense = _.get($scope.selectedexpensedetails, 'cost_share_json');
//                                        $scope.gridExpenseCostshare.data = $scope.selecteddatacostshareexpense;
                                         var costShareArr = [];
                                        $.each(response.cost_share_json, function (indexCost, valueCost) {
                                            costShareArr.push(valueCost);
                                        });
                                        $scope.gridExpenseCostshare.data = costShareArr;
//                                        console.log($scope.gridExpenseCostshare.data);

                                    }, function(response){
                                    $scope.loading_data = false;
                                    handleError.notify(response, '');
                                    }
                                 );
        }
    };

            // Do Initial Cost share   load
            $scope.gridExpenseCostshareDetails();




// Get Payment details  from service
$scope.getPaymentDetails = function() {
    GetPayment.getpayment().query()
        .$promise.then(
        function(response){
            $scope.paymentdetails = response;
            $scope.gridPayments.data = response;
            $log.debug("gridPayments.data:",$scope.gridPayments.data );
        },
        function(response){
            $scope.loading_data = false;
            handleError.notify(response, '');
        }
    );
};

// Do Initial Payment   load
 $scope.getPaymentDetails();



// Delete Payments in the expense details
    $scope.deletePayment = function(){
            $scope.currentselectedpayment = getPaymentSelection();
            $scope.delpayid =   Object.values($scope.currentselectedpayment.selectedPayment)[0];
            $scope.payguid = $scope.delpayid.expense_payment_guid;

                var modalOptions = {
                closeButtonText: 'No',
                actionButtonText: 'Yes',
                headerText: 'Warning',
                bodyText: 'Are you sure you want to delete this item?'
                    };
                 modalService.showModal({}, modalOptions)
                    .then(function (result) {
             DeletePayment.deletepayment().delete({expense_payment_guid:$scope.payguid})
                .$promise.then(
                   function(){
                      modalMessageService.showMessage( "Success:","Payment deleted Successfully");
                      console.log("Deleted from server");
                      $state.reload();
                   },
                   function(response) {
                       $scope.loading_data = false;
                       handleError.notify(response, '');
                    }
              );
            });
        };



 //Payment Source Details
var paymentsourcedetail = GetPaymentSource.getpaymentsource().query()
  .$promise.then(
    function(response){
        $scope.paymentsourcelist = response;
    },function(response){
            $scope.loading_data = false;
            handleError.notify(response, '');
        });


// Selected Payment
      var getPaymentSelection = function(){
            var selectedRows = $scope.gridApiPayments.selection.getSelectedRows();
             var paymentSelection = { selectedPayment: {}};
            angular.forEach( selectedRows, function(row){
                var expense_payment_guid = row.expense_payment_guid;

                paymentSelection.selectedPayment[expense_payment_guid] = row;

            });
            $log.debug("Payment Details:", paymentSelection);
            return paymentSelection;

        };


// Delete Expenses  here
    $scope.deleteExpense = function(){
//                $scope.currentselectedexpense = getExpenseSelection();
                $scope.selectedRows = $scope.gridApiExpenses.selection.getSelectedRows()[0];
                 $scope.selectedguidreapprops = $scope.selectedRows.expense_guid;
                 console.log('CURRENT EXPENSE in Expense Controller: ',$scope.selectedguidreapprops);
                $scope.expenseguid = $scope.selectedRows.expense_guid;
                console.log($scope.expenseguid);
                 var modalOptions = {
                closeButtonText: 'No',
                actionButtonText: 'Yes',
                headerText: 'Warning',
                bodyText: 'Are you sure you want to delete this item?'
             };
                 modalService.showModal({}, modalOptions)
                    .then(function (result) {
                 DeleteExpense.deleteexpense().delete({expense_guid:$scope.expenseguid})
                    .$promise.then(
                       function(){
                          modalMessageService.showMessage( "Success:","Expense deleted Successfully");
                          $state.reload();
                       },
                       function(response) {
                           $scope.loading_data = false;
                           handleError.notify(response, '');
                        }
                  );
                   });
            };



//Add new Expenses
$scope.addExpense = function() {
     var modalInstance = $uibModal.open({
        templateUrl:'views/finance/newexpense.html',
        controller:'ExpenseModalCtrl',
        backdrop: 'static'
      });
        modalInstance.result.then(function (modalResponse) {
                //console.log("modalResponse", modalResponse);
            }, function(response){
                $scope.loading_data = false;
                handleError.notify(response, '');
            });
};



// Transfer Status
    var transferstatus  = GetTransferStatus.gettransferstatus().query()
      .$promise.then(
        function(response){
            $scope.transferstatuslist = response;
        },function(response){
                $scope.loading_data = false;
                handleError.notify(response, '');
            }
        );




// Expenses
$scope.gridExpenses = {
            enableSorting :true,
            enablePaginationControls: true,
            paginationPageSize: 25,
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: true,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            exporterMenuVisibleData : true,
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 550,
            showGridFooter:false,
            selectedItems: [],
            enableGridMenu: true,
            exporterCsvFilename: 'Expenses.csv',
            exporterPdfDefaultStyle: {fontSize: 12},
            exporterPdfTableStyle: {margin: [30, 30, 30, 30]},
            exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
            exporterPdfHeader: { text: "Expense Details", style: 'headerStyle' },
            exporterPdfFooter: function ( currentPage, pageCount ) {
              return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function ( docDefinition ) {
              docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
              docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
              return docDefinition;
            },
            exporterPdfOrientation: 'landscape',
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            exporterExcelFilename: 'Expenses.xlsx',
            exporterExcelSheetName: 'Sheet1',
            enableRowSelection: true,
            enableFullRowSelection: true,
            appScopeProvider: $scope,
            rowTemplate: '<div ng-click="grid.appScope.viewselExp(row)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell" ng-class="col.colIndex()" ui-grid-cell></div>',

            columnDefs: [
                  { name:'Expense Type', field: 'expense_type', width: 200,resizable: true,pinnedLeft:false},
                  { name:'Expense Description', field: 'expense_description', width: 200,resizable: true,  pinnedLeft:false },
                  { name:'Municipality', field: 'municipality', width: 250,resizable: true,  pinnedLeft:false},
                  { name:'County', field: 'county', width: 170, resizable: true, pinnedLeft:false},
                  { name:'Status', field: 'expense_status_desc', width: 125, pinnedLeft:false },
                  { name:'Farm ID', field: 'farm_id', width: 250,  pinnedLeft:false },
                  { name:'Farm Name', field: 'farm_name', width: 250,  pinnedLeft:false },
                  { name:'Application ID', field: 'application_id', width: 125, pinnedLeft:false },
                  { name:'Expense Amount', field: 'expense_amount', width: 200, cellFilter:'currency', pinnedLeft:false }

        ]

    };

            $scope.viewselExp = function(row) {
                //console.log('FROM EXPENSE CONTROLLER');
                var itemguid = row.entity.expense_guid;
                if (itemguid) {
                    $location.path('/finance/expenses/expensedetail/'+itemguid);
                }
            };




// Register the grid for API calls like clearSelectedRows() and getSelectedRows()
$scope.gridExpenseHeight = 'height: ' + ($scope.gridExpenses.paginationPageSize * 35 + 150) + 'px';
$scope.gridExpenses.onRegisterApi = function(gridApiExpenses){
    $scope.gridApiExpenses = gridApiExpenses;
    gridApiExpenses.selection.on.rowSelectionChanged($scope,function(row){
    var msg = 'row selected'+row.isSelected;
     $scope.selectedRows = $scope.gridApiExpenses.selection.getSelectedRows()[0];
     $scope.selectedguidreapprops = $scope.selectedRows.expense_guid;
     console.log('CURRENT EXPENSE in Expense Controller: ',$scope.selectedguidreapprops);
    });
};




// Get Expense details  from service
$scope.getExpenseDetails = function() {
    $scope.loading_data = true;
    GetExpense.getexpense().query()
    .$promise.then(
    function(response){
       $scope.expensedetails = response;
        $scope.gridExpenses.data = response;
        $log.debug("gridReapprops.data:",$scope.gridExpenses.data );
        $scope.loading_data = false;
    },
    function(response){
        $scope.loading_data = false;
        handleError.notify(response, '');
    }
    );
};

// Do Initial Expense   load
$scope.getExpenseDetails();


// Selected Expenses
    var getExpenseSelection = function(){
        var selectedRows = $scope.gridExpenses.selection.getSelectedRows();
         var expenseSelection = { selectedExpense: {}};
        angular.forEach( selectedRows, function(row){
            var expense_guid = row.expense_guid;
            expenseSelection.selectedExpense[expense_guid] = row;
        });
        $log.debug("Expense Details:", expenseSelection);
        return expenseSelection;
    };




// Expenses Payments details
$scope.gridExpensePayments = {
            enableSorting :true,
            enablePaginationControls: true,
            paginationPageSize: 25,
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: true,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            exporterMenuVisibleData : true,
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 550,
            showGridFooter:false,
            selectedItems: [],
            enableGridMenu: true,
            exporterCsvFilename: 'Expense_Payments.csv',
            exporterPdfDefaultStyle: {fontSize: 12},
            exporterPdfTableStyle: {margin: [30, 30, 30, 30]},
            exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
            exporterPdfHeader: { text: "Expense Payment Details", style: 'headerStyle' },
            exporterPdfFooter: function ( currentPage, pageCount ) {
              return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function ( docDefinition ) {
              docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
              docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
              return docDefinition;
            },
            exporterPdfOrientation: 'landscape',
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            exporterExcelFilename: 'Expense_Payments.xlsx',
            exporterExcelSheetName: 'Sheet1',
            enableRowSelection: true,
            enableFullRowSelection: true,
            appScopeProvider: $scope,
            rowTemplate: '<div ng-click="grid.appScope.viewselPay(row)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell" ng-class="col.colIndex()" ui-grid-cell></div>',

            columnDefs: [
                  { name:'Payment Amount', field: 'payment_amount', width: 300,  cellFilter:'currency', pinnedLeft:false},
                  { name:'Payment Source', field: 'payment_source_type', width: 170,  pinnedLeft:false},
                  { name:'Payment Status', field: 'payment_status_desc', width: 170,  pinnedLeft:false},
                  { name:'Payment Comment', field: 'payment_comment', width: 250,  pinnedLeft:false },
                  { name:'Appropriation', field: 'appropriation_name', width: 250,  pinnedLeft:false },
                  { name:'From Reappropriation', field: 'reapprop_flag', width: 170, pinnedLeft:false},
                  { name:'Activity Code', field: 'activity_code', width: 170, pinnedLeft:false},
                  { name:'Object Code', field: 'object_code', width: 170, pinnedLeft:false}
        ]

    };

            $scope.viewselPay = function(row) {
                var itemguid = row.entity.expense_payment_guid;
                if (itemguid) {
                    $location.path('/finance/payments/paymentdetail/'+itemguid);
                }
            };



//Edit the Expense  here
    $scope.EditExpense = function(){
    var modalInstance = $uibModal.open({
        templateUrl:'views/finance/expenseedit.html',
        controller:'ExpenseModalCtrl',
        backdrop: 'static',
        resolve: {
            fundtransitems: function () {
                return null;
            }
        }
    });
    modalInstance.result.then(function (modalResponse) {
                console.log("modalResponse", modalResponse);
            },function(response){
            $scope.loading_data = false;
            handleError.notify(response, '');
        });
    };







// Register the grid for API calls like clearSelectedRows() and getSelectedRows()
    $scope.gridExpensePayments.onRegisterApi = function(gridApiExpensePayments){
        $scope.gridApiExpensePayments = gridApiExpensePayments;

        gridApiExpensePayments.selection.on.rowSelectionChanged($scope,function(row){
        var msg = 'row selected'+row.isSelected;
         $scope.selectedRows = $scope.gridApiExpensePayments.selection.getSelectedRows()[0];
         $scope.selectedguidreapprops = $scope.selectedRows.reappropriation_guid;
        });
    };






//// Get Expense payment details  from service
//    $scope.getExpensePaymentDetails = function() {
//          $scope.gridExpensePayments.data = $scope.selectedExpensePayment;
//    };
//
//    // Do Initial Expense  Payments  load
//    $scope.getExpensePaymentDetails();



// Selected Expenses
//  var getExpenseSelection = function(){
//      var selectedRows = $scope.gridApiExpenses.selection.getSelectedRows();
//      var expenseSelection = { selectedExpense: {}};
//      angular.forEach( selectedRows, function(row){
//          var expense_guid = row.expense_guid;
//          expenseSelection.selectedExpense[expense_guid] = row;
//      });
//      $log.debug("NEW SELECTED EXPENSE:", expenseSelection);
//      return expenseSelection;
//    };


//Expenses Payments Costshare details
$scope.gridExpenseCostshare = {
            enableSorting :true,
            enablePaginationControls: true,
            paginationPageSize: 25,
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: true,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            exporterMenuVisibleData : true,
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 550,
            showGridFooter:false,
            selectedItems: [],
            enableGridMenu: true,
            exporterCsvFilename: 'Expense_Costshare.csv',
            exporterPdfDefaultStyle: {fontSize: 12},
            exporterPdfTableStyle: {margin: [30, 30, 30, 30]},
            exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
            exporterPdfHeader: { text: "Expense Costshare Details", style: 'headerStyle' },
            exporterPdfFooter: function ( currentPage, pageCount ) {
              return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function ( docDefinition ) {
              docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
              docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
              return docDefinition;
            },
            exporterPdfOrientation: 'landscape',
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            exporterExcelFilename: 'Expense_Costshare.xlsx',
            exporterExcelSheetName: 'Sheet1',
            columnDefs: [
                  { name:'Source', field: 'payment_source', width: 300,  pinnedLeft:false},
                  { name:'Amount', field: 'share_amount', width: 250,cellFilter:'currency', pinnedLeft:false },
                  { name:'Description', field: 'share_description', width: 170, pinnedLeft:false}
        ]

    };


// Register the grid for API calls like clearSelectedRows() and getSelectedRows()
$scope.gridExpenseCostshare.onRegisterApi = function(gridApiExpenseCostshare){
    $scope.gridApiExpenseCostshare = gridApiExpenseCostshare;
    gridApiExpenseCostshare.selection.on.rowSelectionChanged($scope,function(row){
    var msg = 'row selected'+row.isSelected;
     $scope.selectedRows = $scope.gridApiExpenseCostshare.selection.getSelectedRows()[0];
     $scope.selectedguidreapprops = $scope.selectedRows.reappropriation_guid;
    });
};


// Get Expense payment details  from service
 $scope.gridExpenseCostshareDetails = function() {
       $scope.gridExpenseCostshare.data = $scope.selectedExpenseCostshare;
//        var costShareArr = [];
//                                        $.each(response.cost_share_json, function (indexCost, valueCost) {
//                                            costShareArr.push(valueCost);
//                                        });
//                                        $scope.gridExpenseCostshare.data = costShareArr;
//        };

// Do Initial Expense  Payments  load
$scope.gridExpenseCostshareDetails();

// Selected Expenses
//  var getPaymentSelection = function(){
//        var selectedRows = $scope.gridPayments.selection.getSelectedRows();
//         var paymentSelection = { selectedPayment: {}};
//        angular.forEach( selectedRows, function(row){
//            var expense_payment_guid = row.expense_payment_guid;
//
//            paymentSelection.selectedPayment[expense_payment_guid] = row;
//
//        });
//        $log.debug("Payment Details:", paymentSelection);
//        return paymentSelection;
//
    };

}])


.controller('ExpenseModalCtrl', function($rootScope,$scope,$stateParams,$log,$state,$filter,$location,FundDataService,$uibModalInstance,UpdateExpense,GetAppID,PaymentDataService,GetPayStatus,GetPartner,GetExpenseData,ExpenseDataService,GetPaymentSource,GetFarmIDList,ReappropDataService,Getfund,UpdateFund,UpdateReapprop,GetTransferStatus,UpdatePayment,GetAppropn,GetTransactiontype,GetExpensetype,GetExpensestatus,AddTrans,AddReapprop,GetPartnerGrant,GetCompetitiveGrant,GetReappropn, AddFund, AddApprop,AddPartnerGrant,AddCompetitivePool,AddExpense,GetProgramtype,GetGranttype,modalService,modalMessageService,handleError){



//Reappropriation based on guid Details
    $scope.viewSelectedReappropriation = function(){
    if(!!$scope.selecteddatareapprop && !!$scope.selecteddatareapprop.reappropriation_guid){
        var reappropguid = $scope.selecteddatareapprop.reappropriation_guid;
        var reappropriationdetailsid = GetReapproprData.getreappropdata(reappropguid).get()
              .$promise.then(
                function(response){

                    $scope.selectedreapppropdetails = response;

                    $location.path('/finance/reappropriations/reappropdetails/'+reappropriation_guid);
                }, function(response){
                    $scope.loading_data = false;
                    handleError.notify(response, '');
                });
    }
    };
    $scope.viewSelectedReappropriation();
  if(!!$stateParams){
              $scope.selecteddataexpense = $stateParams;
            }



//Expenses  Details
     $scope.viewSelectedExpense = function(){
        if(!!$scope.selecteddataexpense && !!$scope.selecteddataexpense.expense_guid){
            var expguid = $scope.selecteddataexpense.expense_guid;
            $scope.expguid = $scope.selecteddataexpense.expense_guid;
            var expensedetailsid = GetExpenseData.getexpensedata(expguid).get()
                                  .$promise.then(
                                    function(response){
                                        $scope.selectedexpensedetails = response;
//                                        console.log("exp details",$scope.selectedexpensedetails);

                                        $location.path('/finance/expenses/expensedetail/'+expguid);
                                    },
                                    function(response){
                                        $scope.loading_data = false;
                                        handleError.notify(response, '');
                                    });
        }
        };
        $scope.viewSelectedExpense();

             $scope.selectedExpenseData = ExpenseDataService.getSelectedExpense()[0];
             //console.log("selected exp guid", $scope.expguid);
              $scope.selectedExpensePayment = _.get($scope.selectedExpenseData, 'expense_payments');
              $scope.selectedExpenseCostshare = _.get($scope.selectedExpenseData, 'cost_share_json');





    $scope.viewselExp = function(row) {
        console.log('FROM Expense CONTROLLER');
        var itemguid = row.entity.expense_guid;
        if (itemguid) {
            console.log("here6");
            $location.path('/finance/expenses/expensedetail/'+itemguid);
        }
    };





//Expenses Payments Costshare details
$scope.gridExpenseCostshare = {
            enableSorting :true,
            enablePaginationControls: true,
            paginationPageSize: 25,
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: true,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            showGridFooter:false,
            selectedItems: [],
            columnDefs: [
                  { name:'Cost Per Acre', field: 'cost_per_acre', width: 300, pinnedLeft:false,enableCellEdit:true},
                  { name:'Source', field: 'payment_source', width: 300,  pinnedLeft:false,enableCellEdit:true},
                  { name:'Amount', field: 'share_amount', width: 250, cellFilter:'currency', pinnedLeft:false, enableCellEdit:true},
                  { name:'Description', field: 'share_description', width: 170,  pinnedLeft:false,enableCellEdit:true}
        ]
    };





// Register the grid for API calls like clearSelectedRows() and getSelectedRows()
            $scope.gridExpenseCostshare.onRegisterApi = function(gridApiExpenseCostshare){
                $scope.gridApiExpenseCostshare = gridApiExpenseCostshare;
                gridApiExpenseCostshare.selection.on.rowSelectionChanged($scope,function(row){
                var msg = 'row selected'+row.isSelected;
                 $scope.selectedRows = $scope.gridApiExpenseCostshare.selection.getSelectedRows()[0];
                 $scope.selectedguidreapprops = $scope.selectedRows.reappropriation_guid;
                //console.log($scope.selectedguidreapprops);
                });
            };

// Expense cost share grid table data from the guid
$scope.gridExpenseCostshareDetails = function() {
    //loading image

    if(!!$scope.selecteddataexpense && !!$scope.selecteddataexpense.expense_guid){
            var expguid = $scope.selecteddataexpense.expense_guid;
            $scope.expguid = $scope.selecteddataexpense.expense_guid;
            var expensedetailsid = GetExpenseData.getexpensedata(expguid).get()
                                  .$promise.then(
                                    function(response){

                                        $scope.selectedexpensedetails = response;
                                        $scope.selecteddatacostshareexpense = _.get($scope.selectedexpensedetails, 'cost_share_json');
//                                        $scope.gridExpenseCostshare.data = $scope.selecteddatacostshareexpense;
                                         var costShareArr = [];
                                        $.each(response.cost_share_json, function (indexCost, valueCost) {
                                            costShareArr.push(valueCost);
                                        });
                                        $scope.gridExpenseCostshare.data = costShareArr;
//                                        console.log("Expense Cost share details",$scope.gridExpenseCostshare.data);

                                    },function(response){
                                    $scope.loading_data = false;
                                    handleError.notify(response, '');
                                });
        }
    };

            // Do Initial Cost share   load
            $scope.gridExpenseCostshareDetails();



// Get Expense Status
 var expensestatus = GetExpensestatus.getexpensestatus().query()
      .$promise.then(
        function(response){
            $scope.expenseststatuslist = response;
        },function(response){
             $scope.loading_data = false;
             handleError.notify(response, '');
         });



// Submit Edit  Expense
    $scope.submitEditExpense = function(){
      var data={
          "expense_guid": $scope.selectedexpensedetails.expense_guid,
          "expense_amount": $scope.selectedexpensedetails.expense_amount,
          "expense_description":$scope.selectedexpensedetails.expense_description,
          "expense_status_desc":$scope.selectedexpensedetails.expense_status_desc,
          "farm_id":$scope.selectedexpensedetails.farm_id,
          "application_id":$scope.selectedexpensedetails.application_id,
          "cost_share_json":$scope.gridExpenseCostshare.data
      };
      console.log(data);
      UpdateExpense.updateexpense().update({guid:data.expense_guid},data)
            .$promise.then(
               function(response){
                  $state.reload();
                  $uibModalInstance.dismiss();
                  modalMessageService.showMessage( "Success:","Expense Edited Successfully");
               }, function(response){
                  $scope.loading_data = false;
                  handleError.notify(response, '');
              });
    };



// Payments  Details
    $scope.viewSelectedPayment = function(){
      PaymentDataService.setSelectedPayment($scope.gridApiPayments.selection.getSelectedRows());
      $scope.selectedRows = $scope.gridApiPayments.selection.getSelectedRows()[0];
      $scope.selectedguidpayment = $scope.selectedRows.expense_payment_guid;
      var expense_payment_guid = $scope.selectedguidpayment;
      $location.path('/finance/payments/paymentdetail/'+expense_payment_guid);

    };


    $scope.viewSelectedPaymentd = function(){
        console.log('modalinstancectrl-viewSelectedPaymentd');
        if(!!$stateParams){
            $scope.selecteddatapayment = $stateParams;
        }
        if(!!$scope.selecteddatapayment && !!$scope.selecteddatapayment.expense_payment_guid){
            var paymentguid = $scope.selecteddatapayment.expense_payment_guid;
            $scope.paymentguid = $scope.selecteddatapayment;
            var paymentdetailsid = GetPaymentInfo.getpaymentinfo(paymentguid).get()
                .$promise.then(
                    function(response){

                        $scope.selectedpaymentdetails = response;
                        console.log('paymentdetails',$scope.selectedpaymentdetails);
                    },
                    function(response){
                        $scope.loading_data = false;
                        handleError.notify(response, '');
                    }
                );
        }
    };
    $scope.viewSelectedPaymentd();

    if(!!$stateParams){
        $scope.selecteddatapayment = $stateParams;
    }




    var newcostsharerow = {
                "cost_per_acre": "",
                "payment_source":"" ,
                "share_description": "",
                "share_amount":""
            };
     $scope.addNewcostshare = function(row){
      $scope.gridReapPay.data.push({
                "cost_per_acre": "",
                "payment_source":"" ,
                "share_description": "",
                "share_amount":""
            });
    };



//Adding empty row  and deleting empty row

   $scope.addNewRow = function(){
      $scope.gridExpenseCostshare.data.push({});
    };

    $scope.deleteRow = function(){
       // $scope.gridApiFunds.selection.getSelectedRows()
        angular.forEach($scope.gridApiExpenseCostshare.selection.getSelectedRows(), function (data, index) {
          $scope.gridExpenseCostshare.data.splice($scope.gridExpenseCostshare.data.lastIndexOf(data), 1);
        });

   };


// Register the grid for API calls like clearSelectedRows() and getSelectedRows()

    $scope.gridExpenseCostshare.onRegisterApi = function(gridApiExpenseCostshare){
        $scope.gridApiExpenseCostshare = gridApiExpenseCostshare;
        gridApiExpenseCostshare.selection.on.rowSelectionChanged($scope,function(row){
        var msg = 'row selected'+row.isSelected;
         $scope.selectedRows = $scope.gridApiExpenseCostshare.selection.getSelectedRows()[0];
         $scope.selectedguidfund = $scope.selectedRows.fund_guid;
          console.log($scope.selectedguidfund);
        });
    };


//on change
$scope.updateFarmId = function(){
    //console.log($scope.farm_id);
  $rootScope.farmId = $scope.farm_id.farm_id;
  $scope.application_id = "";
  //console.log("selected  root scope", $rootScope.farmId);
    GetAppID.getappid($rootScope.farmId).query()
      .$promise.then(
        function(response){
        $scope.appidlist = response;
    },function(response){
            $scope.loading_data = false;
            handleError.notify(response, '');
        });
};

// Get Expense Types
GetExpensetype.getexpensetype().query()
  .$promise.then(
    function(response){
        $scope.expensetypelist = response;
    }, function(response){
        $scope.loading_data = false;
        handleError.notify(response, '');
    });


// Get Expense Status
GetExpensestatus.getexpensestatus().query()
  .$promise.then(
    function(response){
        $scope.expenseststatuslist = response;
    }, function(response){
        $scope.loading_data = false;
        handleError.notify(response, '');
    });



// Get Farm ID List
GetFarmIDList.getfarmidlist().query()
  .$promise.then(
    function(response){
        $scope.farmidlist = response;
    },function(response){
        $scope.loading_data = false;
        handleError.notify(response, '');
    });





// Transaction types here
var transactiontypes  = GetTransactiontype.gettransactiontype().query()
  .$promise.then(
    function(response){
        $scope.transactiontypeslist = response;
    }, function(response){
            $scope.loading_data = false;
            handleError.notify(response, '');
        });

// Transfer Status
var transferstatus  = GetTransferStatus.gettransferstatus().query()
  .$promise.then(
    function(response){
        $scope.transferstatuslist = response;
    },function(response){
            $scope.loading_data = false;
            handleError.notify(response, '');
        });

$scope.refresh = $scope.funddetails;

//Program type list
GetProgramtype.getprogramtype().query()
  .$promise.then(
    function(response){
        $scope.programtypelist = response;
    },
    function(response){
        $scope.loading_data = false;
        handleError.notify(response, '');
    }
 );

$scope.close = function(){
    $uibModalInstance.dismiss();
};

//  Post request for new expeses
    $scope.submitExpense = function(){
      var response = {"expense_type":$scope.expense_type,"expense_description":$scope.expense_desc,"expense_status_desc":$scope.expense_status,"expense_amount":$scope.expense_amount,"application_id":$scope.application_id,"farm_id":$scope.farm_id.farm_id};
      AddExpense.addexpense().save(response)
        .$promise.then(
           function(response){
              $state.reload();
              $uibModalInstance.close(response);
              modalMessageService.showMessage( "Success:","Added New Expense Successfully");
           },
           function(response) {
               $scope.loading_data = false;
               handleError.notify(response, '');
            }
      );
//    $uibModalInstance.close(response);
    };

// Date calendar
 $scope.today = function() {
    $scope.dt = new Date();
  };
  $scope.today();

   $scope.dateOptions = {
    formatYear: 'yy',
    maxDate: new Date(2020, 5, 22),
    minDate: new Date(),
    startingDay: 1
  };
   $scope.open1 = function() {
    $scope.popup1.opened = true;
  };


  $scope.setDate = function(year, month, day) {
    $scope.dt = new Date(year, month, day);
  };

$scope.clear = function() {
    $scope.dt = null;
  };

  $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
  $scope.format = $scope.formats[0];
  $scope.altInputFormats = ['M!/d!/yyyy'];

  $scope.popup1 = {
    opened: false
  };

  $scope.popup2 = {
    opened: false
  };

  var tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  var afterTomorrow = new Date();
  afterTomorrow.setDate(tomorrow.getDate() + 1);
  $scope.events = [
    {
      date: tomorrow,
      status: 'full'
    },
    {
      date: afterTomorrow,
      status: 'partially'
    }
  ];

});
