(function () {
    'use strict';
}());

 angular.module('agSADCeFarms')
    .controller('GrantsController', ['$scope','$stateParams','$location','$filter', '$uibModal','uiGridConstants','AuthService','GetTransferStatus','GetCompetitiveGrant',
        'GetGrantInfo','PartnerDataService','GetPartnerGrant','DeleteGrant','AddPartnerGrant','GetProgramtype','GetGranttype', '$state', '$log','modalService','modalMessageService','handleError',
        function($scope,$stateParams,$location,$filter,$uibModal,uiGridConstants,AuthService,GetTransferStatus,GetCompetitiveGrant,GetGrantInfo,PartnerDataService,GetPartnerGrant,
                 DeleteGrant,AddPartnerGrant,GetProgramtype,GetGranttype,$state,$log,modalService,modalMessageService,handleError) {





////ui components
//    $scope.ui_components = {
//            'ui_fiscal_admin': false,
//        };
//
////Check the AuthService here
//if ( AuthService.isAuthenticated() ) {
//    $log.debug("++++++User is authenticated");
//    $log.debug("++++++Users ui access:", AuthService.getUserUIAccess());
//    $scope.ui_components = {
//            'ui_fiscal_admin':true
//        };
//} else {
//    $log.debug("++++++User is not authenticated");
//}
  $scope.ui_components = {
            'ui_fiscal_admin': false

        };

         var disable_ui_components = function() {
        $scope.ui_components['ui_fiscal_admin'] = false;
    };
    var setUIValues = function(){
        var ui_access = AuthService.authResponse.ui_access;
        angular.forEach( ui_access, function(comp_key) {
                if($scope.ui_components.hasOwnProperty(comp_key)){
                      $scope.ui_components[comp_key] = true;
                }
            });
    };

//AuthService
    if ( AuthService.isAuthenticated() ) {
    console.log("++++++User is authenticated");
    console.log("++++++Users ui access:", AuthService.getUserUIAccess());
    setUIValues();

    } else {
        console.log("++++++User is not authenticated");
        disable_ui_components();
    }

    $scope.$watchCollection(function(){
                return AuthService.authState;
            }, function() {
                if ( ! AuthService.authState ) {
                    $log.debug("+++AuthService.authState changed to:", AuthService.authState);
                    disable_ui_components();

                }else{
                    setUIValues();
                }
            });

//Partner Grants Details
    $scope.viewSelectedPartner = function(){
      PartnerDataService.setSelectedPartner($scope.gridApiPartner.selection.getSelectedRows());
      $scope.selectedRows = $scope.gridApiPartner.selection.getSelectedRows()[0];
      $scope.selectedguidpartner = $scope.selectedRows.partner_grant_guid;
        var partner_grant_guid = $scope.selectedguidpartner;
        $location.path('/finance/grants/grantdetail/'+partner_grant_guid);
        // $state.go('app.finance.grantdetail');
  };
     $scope.selectedPartnerData = PartnerDataService.getSelectedPartner()[0];
     $scope.selectedGrantPayment = _.get($scope.selectedPartnerData, 'grant_payments');




//Add New Partner Grant
    $scope.openPartnerGrantModal = function() {
     var modalInstance = $uibModal.open({
        templateUrl:'views/finance/newpartnergrant.html',
        controller:'GrantsModalCtrl',
        backdrop: 'static'
      });
        modalInstance.result.then(function (modalResponse) {
                console.log("modalResponse", modalResponse);
            },
            function(response){
                $scope.loading_data = false;
                handleError.notify(response, '');
            }
            );
    };



// Delete Partner grants  here
    $scope.deletegrant = function(){

        $scope.currentselectedgrant = getGrantSelection();
        $scope.delgrantid =   Object.values($scope.currentselectedgrant.selectedGrant)[0];
        $scope.grantguid = $scope.delgrantid.partner_grant_guid;
        console.log($scope.grantguid);
        var modalOptions = {
                        closeButtonText: 'No',
                        actionButtonText: 'Yes',
                        headerText: 'Warning',
                        bodyText: 'Are you sure you want to delete this item?'
                     };
                         modalService.showModal({}, modalOptions)
                            .then(function (result) {
         DeleteGrant.deletegrant().delete({partner_grant_guid:$scope.grantguid})
            .$promise.then(
               function(){
                  console.log("Deleted from server");
                   modalMessageService.showMessage( "Success:","Grant deleted Successfully");
                  $state.reload();
               },
             function(response){
                 $scope.loading_data = false;
                 handleError.notify(response, '');
             }
          );
          });
    };


//Partner Grants
$scope.gridPartner = {
            enableSorting :true,
            enablePaginationControls: true,
            paginationPageSize: 50,
            paginationPageSizes:[25,50,100,200,300],
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: true,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 550,
            showGridFooter:false,
            selectedItems: [],
            enableGridMenu: true,
            exporterMenuVisibleData : true,
            exporterCsvFilename: 'Partner_Grants.csv',
            exporterPdfDefaultStyle: {fontSize: 12},
            exporterPdfTableStyle: {margin: [30, 30, 30, 30]},
            exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
            exporterPdfHeader: { text: "Partner Grant Details", style: 'headerStyle' },
            exporterPdfFooter: function ( currentPage, pageCount ) {
              return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function ( docDefinition ) {
              docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
              docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
              return docDefinition;
            },
            exporterPdfOrientation: 'landscape',
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            exporterExcelFilename: 'Partner_Grants.xlsx',
            exporterExcelSheetName: 'Sheet1',
            //Row Selection Enhancement
            enableRowSelection: true,
            enableFullRowSelection: true,
            appScopeProvider: $scope,
            rowTemplate: '<div ng-click="grid.appScope.viewselgrant(row)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell" ng-class="col.colIndex()" ui-grid-cell></div>',
            columnDefs: [
                  { name:'Grant Name', field: 'grant_name', width: 250, pinnedLeft:false, sort: {
                      direction: uiGridConstants.ASC,
                      priority: 0
                  }},
                  { name:'Program Name', field: 'program_name', width: 250, pinnedLeft:false},
                  { name:'Partner', field: 'partner_name', width: 170,  pinnedLeft:false},
                  { name:'Year', field: 'year', width: 125,pinnedLeft:false },
                  { name:'Initial Award', field: 'initial_award', width: 125,cellFilter:'currency', pinnedLeft:false },
                  { name:'Base Balance', field: 'base_balance', width: 125, cellFilter:'currency', pinnedLeft:false },
                  { name:'Base Spent', field: 'base_spent', width: 125, cellFilter:'currency', pinnedLeft:false },
                  { name:'Base Encumbered', field: 'base_encumbered', width: 150, cellFilter:'currency', pinnedLeft:false },
                  { name:'Pending', field: 'pending', width: 150, cellFilter:'currency', pinnedLeft:false },
                  { name:'Competitive Balance', field: 'competitive_balance', width: 170,  cellFilter:'currency', pinnedLeft:false },
                  { name:'Competitive Spent', field: 'competitive_spent', width: 170,  cellFilter:'currency',pinnedLeft:false },
                  { name:'Competitive Encumbered', field: 'competitive_encumbered', width: 200, cellFilter:'currency', pinnedLeft:false },
                  { name:'Reappropriated Out', field: 'reappropriated_out', width: 170, cellFilter:'currency', pinnedLeft:false }
        ]

    };

            $scope.viewselgrant = function(row) {
                var itemguid = row.entity.partner_grant_guid;
                if (itemguid) {
                    $location.path('/finance/grants/grantdetail/'+itemguid);
                }
            };
        //
        //


            $scope.gridPartnerHeight = 'height: ' + ($scope.gridPartner.paginationPageSize * 35 + 150) + 'px';
            // Register the grid for API calls like clearSelectedRows() and getSelectedRows()
            $scope.gridPartner.onRegisterApi = function(gridApiPartner){
                $scope.gridApiPartner = gridApiPartner;
                changegridPartnerHeight($scope.gridPartner.data.length,50);
                $scope.gridApiPartner.pagination.on.paginationChanged($scope, function(newPage,pageSize){
                    changegridPartnerHeight($scope.gridPartner.data.length,pageSize);
                });
                gridApiPartner.selection.on.rowSelectionChanged($scope,function(row){
                var msg = 'row selected'+row.isSelected;
                 $scope.selectedRows = $scope.gridApiPartner.selection.getSelectedRows()[0];
                 $scope.selectedguidpool = $scope.selectedRows.partner_grant_guid;
                });
            };
        function changegridPartnerHeight(newlength,pgsize) {
            $scope.gridPartnerHeight = 'height: ' + ($scope.gridPartner.paginationPageSize * 35 + 150) + 'px';
            $scope.gridApiPartner.grid.handleWindowResize();
            $scope.gridApiPartner.core.refresh();
        }




// Get Partner  grants from service
    $scope.getPartnerDetails = function() {
        // Display loading image while fetching data
         $scope.loading_data = true;
        GetPartnerGrant.getpartnergrant().query()
            .$promise.then(
            function(response){

                $scope.partnerdetails = response;
                $scope.gridPartner.data = response;
                $log.debug("gridPartner.data:",$scope.gridPartner.data );
                $scope.loading_data = false;
            },
            function(response){
                $scope.loading_data = false;
                handleError.notify(response, '');
            }
        );
    };


// Do Initial Pool grants  load
$scope.getPartnerDetails();




//Grant type list
 var grant = GetGranttype.getgranttype().query()
      .$promise.then(
        function(response){
            $scope.granttype = response;
        },
         function(response){
             $scope.loading_data = false;
             handleError.notify(response, '');
         }
     );

// Selected Grant details based on the guid
    $scope.viewSelectedgrant = function(){
    if(!!$scope.selecteddatagrant && !!$scope.selecteddatagrant.partner_grant_guid){
        var grantguid = $scope.selecteddatagrant.partner_grant_guid;
        $scope.grantguid = $scope.selecteddatagrant;
        var grantdetailsid = GetGrantInfo.getgrantinfo(grantguid).get()
                              .$promise.then(
                                function(response){
                                    $scope.selectedgrantdetails = response;
                                        $location.path('/finance/grants/grantdetail/'+grantguid);
                                },
                                function(response){
                                    $scope.loading_data = false;
                                    handleError.notify(response, '');
                                }
                             );
                }
        };
    $scope.viewSelectedgrant();
          if(!!$stateParams){
              $scope.selecteddatagrant = $stateParams;
            }



// Get Grant details grid table data from the guid
$scope.getGrantDetails = function() {
             $scope.loading_data = true;
            if(!!$scope.selecteddatagrant && !!$scope.selecteddatagrant.partner_grant_guid){
                var grantguid = $scope.selecteddatagrant.partner_grant_guid;
                $scope.grantguid = $scope.selecteddatagrant;
                var grantdetailsid = GetGrantInfo.getgrantinfo(grantguid).get()
                                  .$promise.then(
                                    function(response){
                                        $scope.selectedgrantdetails = response;
                                        $scope.selecteddatadetailgrantpay = _.get($scope.selectedgrantdetails, 'grant_payments');
                                        $scope.gridPartnerPayments.data = $scope.selecteddatadetailgrantpay;

                                    },
                                    function(response){
                                        $scope.loading_data = false;
                                        handleError.notify(response, '');
                                    }
                                 );
                    }
            };

            // Do Initial Grants load
            $scope.getGrantDetails();







// Selected Partner Grant
  var getGrantSelection = function(){
        var selectedRows = $scope.gridApiPartner.selection.getSelectedRows();
         var grantSelection = { selectedGrant: {}};
        angular.forEach( selectedRows, function(row){
            var grant_guid = row.partner_grant_guid;
            var grant_name = row.grant_name;
            grantSelection.selectedGrant[grant_guid] = row;

        });
        $log.debug("NEW PARTNER GRANT:", grantSelection);
        return grantSelection;

    };





// Get Partner Grants Payment details
$scope.gridPartnerPayments = {
            enableSorting :true,
            enablePaginationControls: true,
            paginationPageSize: 25,
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: true,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 550,
            showGridFooter:false,
            selectedItems: [],
            enableGridMenu: true,
            exporterMenuVisibleData : true,
            exporterCsvFilename: 'Partner_Payments.csv',
            exporterPdfDefaultStyle: {fontSize: 12},
            exporterPdfTableStyle: {margin: [30, 30, 30, 30]},
            exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
            exporterPdfHeader: { text: "Partner Payments Details", style: 'headerStyle' },
            exporterPdfFooter: function ( currentPage, pageCount ) {
              return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function ( docDefinition ) {
              docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
              docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
              return docDefinition;
            },
            exporterPdfOrientation: 'landscape',
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            exporterExcelFilename: 'Partner_Payments.xlsx',
            exporterExcelSheetName: 'Sheet1',
            enableRowSelection: true,
            enableFullRowSelection: true,
            appScopeProvider: $scope,
            rowTemplate: '<div ng-click="grid.appScope.viewrelpayment(row)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell" ng-class="col.colIndex()" ui-grid-cell></div>',

            columnDefs: [
                  { name:'Expense Guid', field: 'expense_guid', width: 275,  pinnedLeft:false, visible:false},
                  { name:'Expense Type', field: 'expense_type', width: 150, pinnedLeft:false },
                  { name:'Payment Status', field: 'payment_status_desc', width: 150,  pinnedLeft:false},
                  { name:'Payment Amount', field: 'payment_amount', width: 150, cellFilter:'currency', pinnedLeft:false},
                  { name:'Appropriation Name', field: 'appropriation_name', width: 250,  pinnedLeft:false },
                  { name:'Application ID', field: 'application_id', width: 250, pinnedLeft:false },
                  { name:'Farm ID', field: 'farm_id', width: 250,  pinnedLeft:false },
                  { name:'Farm Name', field: 'farm_name', width: 250, pinnedLeft:false }
        ]

    };

    $scope.viewrelpayment = function(row) {
        var itemguid = row.entity.expense_payment_guid;
        if (itemguid) {
            $location.path('/finance/payments/paymentdetail/'+itemguid);
        }
    };


//Competitive Grant
var competitivegrant = GetCompetitiveGrant.getcompetitivegrant().query()
  .$promise.then(
    function(response){
        $scope.competitivegrantslist = response;
    },function(response){
            $scope.loading_data = false;
            handleError.notify(response, '');
        });



// Register the grid for API calls like clearSelectedRows() and getSelectedRows()
    $scope.gridPartnerPayments.onRegisterApi = function(gridApiPartnerPayments){
        $scope.gridApiPartnerPayments = gridApiPartnerPayments;
        gridApiPartnerPayments.selection.on.rowSelectionChanged($scope,function(row){
        var msg = 'row selected'+row.isSelected;
         $scope.selectedRows = $scope.gridApiPartnerPayments.selection.getSelectedRows()[0];
         $scope.selectedguidpool = $scope.selectedRows.partner_grant_guid;
        });
    };

//// Get Grants Payments details API
//     $scope.getGrantsPayDetails = function() {
//        $scope.gridPartnerPayments.data = $scope.selectedGrantPayment;
//        };
//
//// Do Initial Grants Appropriation load
//    $scope.getGrantsPayDetails();

}])



.controller('GrantsModalCtrl', function($scope,$log,$state,$filter,$uibModalInstance,uiGridConstants,GetTransferStatus,GetTransactiontype,GetCompetitiveGrant,
                                        AddPartnerGrant,GetPartner,GetPartnerGrant,GetProgramtype,GetGranttype,modalService,modalMessageService,handleError){




//Partner Grants list
var partnergrant = GetPartnerGrant.getpartnergrant().query()
  .$promise.then(
    function(response){
        $scope.partnergrantslist = response;
    },function(response){
            $scope.loading_data = false;
            handleError.notify(response, '');
        });


//Competitive Grant
var competitivegrant = GetCompetitiveGrant.getcompetitivegrant().query()
  .$promise.then(
    function(response){
        $scope.competitivegrantslist = response;
    },function(response){
            $scope.loading_data = false;
            handleError.notify(response, '');
        });


//Partner List
var partnerlist = GetPartner.getpartner().query()
    .$promise.then(
        function(response){
            $scope.partnerslist = response;
        },function(response){
            $scope.loading_data = false;
            handleError.notify(response, '');
        });

//Grant type list
 var grant = GetGranttype.getgranttype().query()
      .$promise.then(
        function(response){
            $scope.granttype = response;
        },
         function(response){
             $scope.loading_data = false;
             handleError.notify(response, '');
         }
     );




// Post request for new partner grant
    $scope.submitpg = function(){
        var response = {"program_type_guid":$scope.program_type, "year":$scope.grant_year,"partner_guid":$scope.partner,"initial_award":$scope.initial_award, "competitive_balance":$scope.competitive_balance,};
        AddPartnerGrant.addpartnergrant().save(response)
        .$promise.then(
           function(response){
              console.log(response);
              $state.reload();
               $uibModalInstance.close(response);
              modalMessageService.showMessage( "Success:","Added Grants Successfully");
           },
            function(response){
                $scope.loading_data = false;
                handleError.notify(response, '');
            }
        );
    //        $uibModalInstance.close(response);
      };


// Transaction types here
    var transactiontypes  = GetTransactiontype.gettransactiontype().query()
          .$promise.then(
            function(response){
                $scope.transactiontypeslist = response;
            },function(response){
                $scope.loading_data = false;
                handleError.notify(response, '');
            });





//Program type list
    var program = GetProgramtype.getprogramtype().query()
      .$promise.then(
        function(response){
            $scope.programtypelist = response;
        },
            function(response){
                $scope.loading_data = false;
                handleError.notify(response, '');
            }
     );

  $scope.close = function(){
        $uibModalInstance.dismiss();
    };
});