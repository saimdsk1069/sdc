(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    .controller('PoolController', ['$scope','$stateParams','$location','$filter', '$uibModal','uiGridConstants','AuthService','Getfund','GetTransferStatus','GetPoolInfo','DeleteFund',
        'DeletePool','DeleteGrant','DeleteExpense','FundDataService','AppropDataService','PartnerDataService','PoolDataService','ReappropDataService','ExpensePayDataService','PaymentDataService',
        'GetAppropn','UpdateApprop','UpdateReapprop','DeleteAppropriation','GetRelatedappropn','GetTransactiontype','GetReappropn','DeleteReappropn','GetExpense','GetPayment','GetPartnerGrant',
        'AddPartnerGrant','AddCompetitivePool','GetPaymentsHistory','GetAppropPayHistory','GetProgramtype','GetGranttype','AddFund','UpdateFund','UpdatePayment','AddApprop','GetCompetitiveGrant',
        'ExpenseDataService','GetPaymentInfo','GetExpenseData', '$state', '$log','modalService','modalMessageService','handleError',
        function($scope,$stateParams,$location,$filter,$uibModal,uiGridConstants,AuthService,Getfund,GetTransferStatus,GetPoolInfo,DeleteFund,
                 DeletePool,DeleteGrant,DeleteExpense,FundDataService,AppropDataService,PartnerDataService,PoolDataService,ReappropDataService,
                 ExpensePayDataService,PaymentDataService,GetAppropn,UpdateApprop,UpdateReapprop,DeleteAppropriation,GetRelatedappropn,GetTransactiontype,GetReappropn,DeleteReappropn,GetExpense,GetPayment,GetPartnerGrant,
                 AddPartnerGrant,AddCompetitivePool,GetPaymentsHistory,GetAppropPayHistory,GetProgramtype,GetGranttype,AddFund,UpdateFund,UpdatePayment,AddApprop,GetCompetitiveGrant,
                 ExpenseDataService,GetPaymentInfo,GetExpenseData,$state,$log,modalService,modalMessageService,handleError) {





////ui components
//    $scope.ui_components = {
//            'ui_fiscal_admin': false,
//        };
//
////Check the AuthService here
//if ( AuthService.isAuthenticated() ) {
//    $log.debug("++++++User is authenticated");
//    $log.debug("++++++Users ui access:", AuthService.getUserUIAccess());
//    $scope.ui_components = {
//            'ui_fiscal_admin':true
//        };
//} else {
//    $log.debug("++++++User is not authenticated");
//}

  $scope.ui_components = {
            'ui_fiscal_admin': false

        };

         var disable_ui_components = function() {
        $scope.ui_components['ui_fiscal_admin'] = false;
    };
    var setUIValues = function(){
        var ui_access = AuthService.authResponse.ui_access;
        angular.forEach( ui_access, function(comp_key) {
                if($scope.ui_components.hasOwnProperty(comp_key)){
                      $scope.ui_components[comp_key] = true;
                }
            });
    };

//AuthService
    if ( AuthService.isAuthenticated() ) {
    console.log("++++++User is authenticated");
    console.log("++++++Users ui access:", AuthService.getUserUIAccess());
    setUIValues();

    } else {
        console.log("++++++User is not authenticated");
        disable_ui_components();
    }

    $scope.$watchCollection(function(){
                return AuthService.authState;
            }, function() {
                if ( ! AuthService.authState ) {
                    $log.debug("+++AuthService.authState changed to:", AuthService.authState);
                    disable_ui_components();

                }else{
                    setUIValues();
                }
            });


//Competitive Pool Details
    $scope.viewSelectedPool = function(){
      PoolDataService.setSelectedPool($scope.gridApiPool.selection.getSelectedRows());
      $scope.selectedRows = $scope.gridApiPool.selection.getSelectedRows()[0];
      $scope.selectedguidpool = $scope.selectedRows.competitive_pool_guid;
        var competitive_pool_guid = $scope.selectedguidpool;
        $location.path('/finance/pools/pooldetails/'+competitive_pool_guid);
    };
     $scope.selectedPoolData = PoolDataService.getSelectedPool()[0];
     $scope.selectedPoolPayment = _.get($scope.selectedPoolData, 'pool_payments');


// Delete Pool grants  here
    $scope.deletepool = function(){
    $scope.currentselectedpool = getPoolSelection();
    $scope.delpoolid =   Object.values($scope.currentselectedpool.selectedPool)[0];
    $scope.poolguid = $scope.delpoolid.competitive_pool_guid;
    console.log($scope.poolguid);
    var modalOptions = {
                        closeButtonText: 'No',
                        actionButtonText: 'Yes',
                        headerText: 'Warning',
                        bodyText: 'Are you sure you want to delete this item?'
                     };
                         modalService.showModal({}, modalOptions)
                            .then(function (result) {
     DeletePool.deletepool().delete({competitive_pool_guid:$scope.poolguid})
        .$promise.then(
           function(){
              console.log("Deleted from server");
              modalMessageService.showMessage( "Success:","Pool deleted Successfully");
              $state.reload();
           },
             function(response){
                 $scope.loading_data = false;
                 handleError.notify(response, '');
         }
      );
       });
    };


//Add new Competitive pool grant
    $scope.openCompetitveModal = function() {

     var modalInstance = $uibModal.open({
        templateUrl:'views/finance/newcompetitivepool.html',
        controller:'PoolModalCtrl',
        backdrop: 'static',
         resolve: {
             fundtransitems: function () {
                 return null;
             }
         }
      });
        modalInstance.result.then(function (modalResponse) {
                console.log("modalResponse", modalResponse);
            },
            function(response){
                $scope.loading_data = false;
                handleError.notify(response, '');
            }
            );
    };


// Transfer Status
    var transferstatus  = GetTransferStatus.gettransferstatus().query()
      .$promise.then(
        function(response){
            $scope.transferstatuslist = response;
        },function(response){
                $scope.loading_data = false;
                handleError.notify(response, '');
            });


//Competitive Pool Grants
$scope.gridPool = {
            enableSorting :true,
            enablePaginationControls: true,
            paginationPageSize: 25,
            paginationPageSizes:[25,50,100,200],
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: true,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 550,
            showGridFooter:false,
            selectedItems: [],
            enableGridMenu: true,
            exporterMenuVisibleData : true,
            exporterCsvFilename: 'Pools.csv',
            exporterPdfDefaultStyle: {fontSize: 12},
            exporterPdfTableStyle: {margin: [30, 30, 30, 30]},
            exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
            exporterPdfHeader: { text: "Competitive Pools Details", style: 'headerStyle' },
            exporterPdfFooter: function ( currentPage, pageCount ) {
              return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function ( docDefinition ) {
              docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
              docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
              return docDefinition;
            },
            exporterPdfOrientation: 'landscape',
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            exporterExcelFilename: 'Pools.xlsx',
            exporterExcelSheetName: 'Sheet1',
            enableRowSelection: true,
            enableFullRowSelection: true,
            appScopeProvider: $scope,
            rowTemplate: '<div ng-click="grid.appScope.viewselpool(row)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell" ng-class="col.colIndex()" ui-grid-cell></div>',

            columnDefs: [
                  { name:'Pool Name', field: 'pool_name', width: 170, pinnedLeft:false, sort: {
                      direction: uiGridConstants.ASC,
                      priority: 0
                  }},
                  { name:'Program Name', field: 'program_name', width: 250,  pinnedLeft:false},
                  { name:'Year', field: 'year', width: 125,  pinnedLeft:false },
                  { name:'Initial Award', field: 'initial_award', width: 125, cellFilter:'currency', pinnedLeft:false },
                  { name:'Balance', field: 'balance', width: 125, cellFilter:'currency', pinnedLeft:false },
                  { name:'Pending', field: 'pending', width: 125,cellFilter:'currency', pinnedLeft:false },
                  { name:'Spent', field: 'spent', width: 125, cellFilter:'currency', pinnedLeft:false },
                  { name:'Encumbered', field: 'encumbered', width: 125, cellFilter:'currency', pinnedLeft:false },
                  { name:'Competitive Limit', field: 'competitive_limit', width: 200, cellFilter:'currency', pinnedLeft:false }
        ]
    };

            $scope.viewselpool = function(row) {
                var itemguid = row.entity.competitive_pool_guid;
                if (itemguid) {
                    $location.path('/finance/pools/pooldetails/'+itemguid);
                }
            };


    $scope.gridPoolHeight = 'height: ' + ($scope.gridPool.paginationPageSize * 35 + 150) + 'px';
    // Register the grid for API calls like clearSelectedRows() and getSelectedRows()
    $scope.gridPool.onRegisterApi = function(gridApiPool){
        $scope.gridApiPool = gridApiPool;
        changegridPoolHeight($scope.gridPool.data.length,25);
        $scope.gridApiPool.pagination.on.paginationChanged($scope, function(newPage,pageSize){
            changegridPoolHeight($scope.gridPool.data.length,pageSize);
        });
        gridApiPool.selection.on.rowSelectionChanged($scope,function(row){
        var msg = 'row selected'+row.isSelected;
         $scope.selectedRows = $scope.gridApiPool.selection.getSelectedRows()[0];
         $scope.selectedguidpool = $scope.selectedRows.competitive_pool_guid;
        });
    };
        function changegridPoolHeight(newlength,pgsize) {
            $scope.gridPoolHeight = 'height: ' + ($scope.gridPool.paginationPageSize * 35 + 150) + 'px';
            $scope.gridApiPool.grid.handleWindowResize();
            $scope.gridApiPool.core.refresh();
        }


// Get Competitive Pool grants from service
    $scope.getPoolDetails = function() {
    // Display loading image while fetching data
    $scope.loading_data = true;
    GetCompetitiveGrant.getcompetitivegrant().query()
        .$promise.then(
        function(response){

            $scope.pooldetails = response;
            $scope.gridPool.data = response;
            $log.debug("gridPool.data:",$scope.gridPool.data );
            $scope.loading_data = false;
        },
        function(response){
            $scope.loading_data = false;
            handleError.notify(response, '');
        }
    );
    };

// Do Initial Pool grants  load
$scope.getPoolDetails();


// Selected Pool grant
    var getPoolSelection = function(){
        var selectedRows = $scope.gridApiPool.selection.getSelectedRows();
         var poolSelection = { selectedPool: {}};
        angular.forEach( selectedRows, function(row){
            var pool_guid = row.appropriation_guid;
            var pool_id = row.appropriation_id;
            var pool_name = row.approp_name;
            poolSelection.selectedPool[pool_guid] = row;

        });
        $log.debug("NEW SELECTED USERS:", poolSelection);
        return poolSelection;

    };



// Selected Approp details based on the guid
    $scope.viewSelectedpool = function(){

    if(!!$scope.selecteddatapool && !!$scope.selecteddatapool.competitive_pool_guid){
        var poolguid = $scope.selecteddatapool.competitive_pool_guid;
        $scope.poolguid = $scope.selecteddatapool;
        var pooldetailsid = GetPoolInfo.getpoolinfo(poolguid).get()
                              .$promise.then(
                                function(response){
                                    $scope.selectedpooldetails = response;
                                        $location.path('/finance/pools/pooldetails/'+poolguid);
                                },
                                function(response){
                                    $scope.loading_data = false;
                                    handleError.notify(response, '');
                                }
                             );
                }
        };
    $scope.viewSelectedpool();
          if(!!$stateParams){
              $scope.selecteddatapool = $stateParams;
            }



// Get Pool details grid table data from the guid
$scope.getPoolDetails = function() {
            $scope.loading_data = true;
            if(!!$scope.selecteddatapool && !!$scope.selecteddatapool.competitive_pool_guid){
            var poolguid = $scope.selecteddatapool.competitive_pool_guid;
            $scope.poolguid = $scope.selecteddatapool;
            var pooldetailsid = GetPoolInfo.getpoolinfo(poolguid).get()
                              .$promise.then(
                                function(response){
                                    $scope.selectedpooldetails = response;
                                    $scope.selecteddatadetailpoolpay = _.get($scope.selectedpooldetails, 'pool_payments');
                                    $scope.gridPoolPayments.data = $scope.selecteddatadetailpoolpay;

                                },
                                function(response){
                                    $scope.loading_data = false;
                                    handleError.notify(response, '');
                                }
                             );
                }
            };

            // Do Initial Pool load
            $scope.getPoolDetails();


// Get  Grants Payment details
$scope.gridPoolPayments = {
            enableSorting :true,
            enablePaginationControls: true,
            paginationPageSize: 25,
            paginationPageSizes:[25,50,100,200],
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: true,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 550,
            showGridFooter:false,
            selectedItems: [],
            enableGridMenu: true,
            exporterMenuVisibleData : true,
            exporterCsvFilename: 'Pools_payments.csv',
            exporterPdfDefaultStyle: {fontSize: 12},
            exporterPdfTableStyle: {margin: [30, 30, 30, 30]},
            exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
            exporterPdfHeader: { text: "Pool Payment Details", style: 'headerStyle' },
            exporterPdfFooter: function ( currentPage, pageCount ) {
              return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function ( docDefinition ) {
              docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
              docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
              return docDefinition;
            },
            exporterPdfOrientation: 'landscape',
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            exporterExcelFilename: 'Pools_payments.xlsx',
            exporterExcelSheetName: 'Sheet1',
            enableRowSelection: true,
            enableFullRowSelection: true,
            appScopeProvider: $scope,
            rowTemplate: '<div ng-click="grid.appScope.viewrelPayment(row)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell" ng-class="col.colIndex()" ui-grid-cell></div>',

            columnDefs: [
                  { name:'Expense Guid', field: 'expense_guid', width: 270, pinnedLeft:false,visible:false},
                  { name:'Expense Type', field: 'expense_type', width: 125,  pinnedLeft:false },
                  { name:'Payment Status', field: 'payment_status_desc', width: 150,  pinnedLeft:false},
                  { name:'Payment Amount', field: 'payment_amount', width: 150,  cellFilter:'currency', pinnedLeft:false},
                  { name:'Appropriation Name', field: 'appropriation_name', width: 250,  pinnedLeft:false },
                  { name:'Application ID', field: 'application_id', width: 175,  pinnedLeft:false },
                  { name:'Farm ID', field: 'farm_id', width: 200, pinnedLeft:false },
                  { name:'Farm Name', field: 'farm_name', width: 200,  pinnedLeft:false }
        ]

    };

            $scope.viewrelPayment = function(row) {
                var itemguid = row.entity.expense_payment_guid;
                if (itemguid) {
                    $location.path('/finance/payments/paymentdetail/'+itemguid);
                }
            };




    // Register the grid for API calls like clearSelectedRows() and getSelectedRows()
    $scope.gridPoolPayments.onRegisterApi = function(gridApiPoolPayments){
        $scope.gridApiPoolPayments = gridApiPoolPayments;

        gridApiPoolPayments.selection.on.rowSelectionChanged($scope,function(row){
        var msg = 'row selected'+row.isSelected;
         $scope.selectedRows = $scope.gridApiPoolPayments.selection.getSelectedRows()[0];
         $scope.selectedguidpool = $scope.selectedRows.partner_grant_guid;
        });
    };

//// Get Pool Payments details API
//$scope.getPoolPayDetails = function() {
//        $scope.gridPoolPayments.data = $scope.selectedPoolPayment;
//    };
//
//// Do Initial Pool Payments load
//$scope.getPoolPayDetails();

}])


.controller('PoolModalCtrl', function($scope,$log,$state,$filter,$uibModalInstance,PaymentDataService,GetTransferStatus,GetTransactiontype,GetExpensetype,GetExpensestatus,
                                      GetCompetitiveGrant,AddCompetitivePool,AddExpense,GetProgramtype,GetGranttype,modalService,modalMessageService,handleError){



//Competitive Grant
var competitivegrant = GetCompetitiveGrant.getcompetitivegrant().query()
  .$promise.then(
    function(response){
        $scope.competitivegrantslist = response;
    },function(response){
            $scope.loading_data = false;
            handleError.notify(response, '');
        });


// Get Expense Types
var expensetype = GetExpensetype.getexpensetype().query()
    .$promise.then(
    function(response){
        $scope.expensetypelist = response;
    },function(response){
            $scope.loading_data = false;
            handleError.notify(response, '');
        });



// Get Expense Status
 var expensestatus = GetExpensestatus.getexpensestatus().query()
      .$promise.then(
        function(response){
            $scope.expenseststatuslist = response;
        },function(response){
             $scope.loading_data = false;
             handleError.notify(response, '');
         });

// transaction types here
var transactiontypes  = GetTransactiontype.gettransactiontype().query()
      .$promise.then(
        function(response){
            $scope.transactiontypeslist = response;
        },function(response){
            $scope.loading_data = false;
            handleError.notify(response, '');
        });


// Transfer Status
 var transferstatus  = GetTransferStatus.gettransferstatus().query()
      .$promise.then(
        function(response){
            $scope.transferstatuslist = response;
        },function(response){
             $scope.loading_data = false;
             handleError.notify(response, '');
         });

$scope.refresh = $scope.funddetails;


//Program type list
var program = GetProgramtype.getprogramtype().query()
  .$promise.then(
    function(response){
        $scope.programtypelist = response;
    },
        function(response){
            $scope.loading_data = false;
            handleError.notify(response, '');
        }
 );

$scope.close = function(){
    $uibModalInstance.dismiss();
};




// Post request for new Competitive Pool
    $scope.submitcpg = function(){
    var response = {"year":$scope.pool_year,"program_type_guid":$scope.pool_type.trim(),"initial_award":$scope.pool_award,"competitive_limit":$scope.pool_limit};
    AddCompetitivePool.addcompetitivepool().save(response)
    .$promise.then(
       function(response){
          console.log(response);
          $state.reload();
          modalMessageService.showMessage( "Success:","Added Pool Successfully");
       },
        function(response){
            $scope.loading_data = false;
            handleError.notify(response, '');
        }
    );
    $uibModalInstance.close(response);
    };



// Date Format
 $scope.today = function() {
    $scope.dt = new Date();
  };
  $scope.today();

   $scope.dateOptions = {
    formatYear: 'yy',
    maxDate: new Date(2020, 5, 22),
    minDate: new Date(),
    startingDay: 1
  };
   $scope.open1 = function() {
    $scope.popup1.opened = true;
  };


  $scope.setDate = function(year, month, day) {
    $scope.dt = new Date(year, month, day);
  };

$scope.clear = function() {
    $scope.dt = null;
  };

  $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
  $scope.format = $scope.formats[0];
  $scope.altInputFormats = ['M!/d!/yyyy'];

  $scope.popup1 = {
    opened: false
  };

  $scope.popup2 = {
    opened: false
  };

  var tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  var afterTomorrow = new Date();
  afterTomorrow.setDate(tomorrow.getDate() + 1);
  $scope.events = [
    {
      date: tomorrow,
      status: 'full'
    },
    {
      date: afterTomorrow,
      status: 'partially'
    }
  ];



//Add competitive pool detail in the modal
    $scope.cpdetail = [];
    $scope.addPool = function(){
        $scope.cpdetail.push({competitive_pool_guid:$scope.competitive_pool_reap.competitive_pool_guid,pool_name:$scope.competitive_pool_reap.pool_name, amount:$scope.amount1});
        console.log($scope.cpdetail);
    };
    $scope.grantdetail = [];
    $scope.addGrant = function(){
        $scope.grantdetail.push({partner_grant_guid:$scope.partner_grant_detail.partner_grant_guid,grant_name:$scope.partner_grant_detail.grant_name, amount:$scope.amount1});
        console.log($scope.grantdetail);
    };
    });
