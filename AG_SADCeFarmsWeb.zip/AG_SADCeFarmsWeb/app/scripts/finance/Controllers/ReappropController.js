(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    .controller('ReappropController', ['$scope','$stateParams','$location','$filter', '$uibModal','ReappropDataService','AuthService','DeleteReappropn','GetAppropn','GetTransferStatus',
        'UpdateReapprop','GetReappropn','GetReapproprData','GetProgramtype', '$state', '$log','modalService','modalMessageService','handleError',
        function($scope,$stateParams,$location,$filter,$uibModal,ReappropDataService,AuthService,DeleteReappropn,GetAppropn,GetTransferStatus,
                 UpdateReapprop,GetReappropn,GetReapproprData,GetProgramtype,$state,$log,modalService,modalMessageService,handleError) {




//ui components
    $scope.ui_components = {
            'ui_fiscal_admin': false
        };

//Check the AuthService here
    if ( AuthService.isAuthenticated() ) {
        $log.debug("++++++User is authenticated");
        $log.debug("++++++Users ui access:", AuthService.getUserUIAccess());
        $scope.ui_components = {
                'ui_fiscal_admin':true
            };
    } else {
        $log.debug("++++++User is not authenticated");
    }



//Reappropriation based on guid Details
    $scope.viewSelectedReappropriation = function(){

    if(!!$scope.selecteddatareapprop && !!$scope.selecteddatareapprop.reappropriation_guid){
        var reappropguid = $scope.selecteddatareapprop.reappropriation_guid;
        $scope.reappropguid = $scope.selecteddatareapprop;
        var reappropriationdetailsid = GetReapproprData.getreappropdata(reappropguid).get()
                              .$promise.then(
                                function(response){
                                    $scope.selectedreapppropdetails = response;
                                    $location.path('/finance/reappropriations/reappropdetails/'+reappropguid);
                                },
                                function(response){
                                    $scope.loading_data = false;
                                    handleError.notify(response, '');
                                }
                             );
    }
    };
    $scope.viewSelectedReappropriation();

          if(!!$stateParams){
              $scope.selecteddatareapprop = $stateParams;
//              console.log($stateParams);

            }



// Reappropriations  Details
            $scope.viewSelectedReapprop = function(){
              ReappropDataService.setSelectedReapprop($scope.gridApiReapprops.selection.getSelectedRows());
              $scope.selectedRows = $scope.gridApiReapprops.selection.getSelectedRows()[0];
              $scope.selectedguidreapprop = $scope.selectedRows.reappropriation_guid;
                var reappropriation_guid = $scope.selectedguidreapprop;
                $location.path('/finance/reappropriations/reappropdetails/'+reappropriation_guid);

          };
             $scope.selectedReappropData = ReappropDataService.getSelectedReapprop()[0];
             $scope.selectedReappropDetails = _.get($scope.selectedReappropData, 'detail');




 // Delete Reappropriations here
    $scope.deletereappr = function(){
        $scope.selectedRows = $scope.gridApiReapprops.selection.getSelectedRows()[0];
        console.log('REAPPROP: ',$scope.selectedRows);
        $scope.reapid = $scope.selectedRows.reappropriation_guid;//$scope.selectedReApprop.reappropriation_guid;
        console.log('delete reapid:',$scope.reapid);
    var modalOptions = {
                        closeButtonText: 'No',
                        actionButtonText: 'Yes',
                        headerText: 'Warning',
                        bodyText: 'Are you sure you want to delete this item?'
                     };
                         modalService.showModal({}, modalOptions)
                            .then(function (result) {
         DeleteReappropn.deletereappropn().delete({reappropriation_guid:$scope.reapid})
            .$promise.then(
               function(){
                  console.log("Deleted from server");
                  modalMessageService.showMessage( "Success:","Reappropriation deleted Successfully");
                  $state.reload();
               },
                 function(response){
                     $scope.loading_data = false;
                     handleError.notify(response, '');
                 }
          );
          });
    };

//Edit the Reaprop  here
    $scope.EditReapprop = function(){
    var modalInstance = $uibModal.open({
        templateUrl:'views/finance/reappropedit.html',
        controller:'ReappropModalCtrl',
        backdrop: 'static'
    });
    modalInstance.result.then(function (modalResponse) {
                console.log("modalResponse", modalResponse);
            },
            function(response){
                $scope.loading_data = false;
                handleError.notify(response, '');
            }
            );
    };


// Transfer Status
 var transferstatus  = GetTransferStatus.gettransferstatus().query()
      .$promise.then(
        function(response){
            $scope.transferstatuslist = response;
        },function(response){
             $scope.loading_data = false;
             handleError.notify(response, '');
         });


 // Get Appropriation Details here
 var appropslist = GetAppropn.getappropn().query()
      .$promise.then(
        function(response){
            $scope.appropslist = response;
        },function(response){
             $scope.loading_data = false;
             handleError.notify(response, '');
         });


//       Reappropriations
$scope.gridReapprops = {
            enableSorting :true,
            enablePaginationControls:true,
            paginationPageSize: 10,
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: true,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            selectedItems: [],
            enableGridMenu: true,
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 550,
            showGridFooter:false,
            exporterMenuVisibleData : true,
            exporterCsvFilename: 'Reappropriations.csv',
            exporterPdfDefaultStyle: {fontSize: 12},
            exporterPdfTableStyle: {margin: [30, 30, 30, 30]},
            exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
            exporterPdfHeader: { text: "Reappropriation Details", style: 'headerStyle' },
            exporterPdfFooter: function ( currentPage, pageCount ) {
              return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function ( docDefinition ) {
              docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
              docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
              return docDefinition;
            },
            exporterPdfOrientation: 'landscape',
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            exporterExcelFilename: 'Reappropriation.xlsx',
            exporterExcelSheetName: 'Sheet1',
            //Row Selection Enhancement
            enableRowSelection: true,
            enableFullRowSelection: true,
            appScopeProvider: $scope,
            rowTemplate: '<div ng-click="grid.appScope.viewselreApprop(row)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell" ng-class="col.colIndex()" ui-grid-cell></div>',

            columnDefs: [
                  { name:'Reappropriation ID', field: 'reappropriation_guid', width: 300, pinnedLeft:false,visible:false},
                  { name:'Source Appropriation', field: 'source_appropriation', width: 300,  pinnedLeft:false},
                  { name:'Destination Appropriation', field: 'target_appropriation', width: 300, pinnedLeft:false},
                  { name:'Status', field: 'status_transfer_desc', width: 125,  pinnedLeft:false },
                  { name:'Transfer Amount', field: 'transfer_amount', width: 170, cellFilter:'currency', pinnedLeft:false },
                  { name:'Balance', field: 'balance', width: 125,  cellFilter:'currency', pinnedLeft:false },
                  { name:'Note', field: 'note', width: 125,  pinnedLeft:false },
                  { name:'Reappropriation Date', field: 'reappropriation_date', width: 200,cellFilter: 'date:medium',  pinnedLeft:false }

        ]

    };


            //Row Selection Enhancement
            $scope.viewselreApprop = function(row) {
                var itemguid = row.entity.reappropriation_guid;
                if (itemguid) {
                    $location.path('/finance/reappropriations/reappropdetails/'+itemguid);
                }
            };




// Register the grid for API calls like clearSelectedRows() and getSelectedRows()
            $scope.gridReapprops.onRegisterApi = function(gridApiReapprops){
                $scope.gridApiReapprops = gridApiReapprops;

                gridApiReapprops.selection.on.rowSelectionChanged($scope,function(row){
                var msg = 'row selected'+row.isSelected;
                 $scope.selectedRows = $scope.gridApiReapprops.selection.getSelectedRows()[0];
                 $scope.selectedguidreapprops = $scope.selectedRows.reappropriation_guid;
                });
            };

// Get Reappropriations details grid table data from the guid
$scope.getReappropDetails = function() {
//                loading image
                $scope.loading_data = true;
                if(!!$scope.selecteddatareapprop && !!$scope.selecteddatareapprop.reappropriation_guid){
                var reappropguid = $scope.selecteddatareapprop.reappropriation_guid;
                $scope.reappropguid = $scope.selecteddatareapprop;
                var reappropriationdetailsid = GetReapproprData.getreappropdata(reappropguid).get()
                                      .$promise.then(
                                        function(response){
                                            $scope.selectedreapppropdetails = response;
                                            $scope.selecteddatadetailreaprop = _.get($scope.selectedreapppropdetails, 'detail');
                                            $scope.gridReappropsDetails.data = $scope.selecteddatadetailreaprop;

                                        },
                                        function(response){
                                            $scope.loading_data = false;
                                            handleError.notify(response, '');
                                        }
                                     );
                        }
            };

            // Do Initial Reapprops   load
            $scope.getReappropDetails();





// Get Reappropriation   from service
$scope.getReappropDetails = function() {
        $scope.loading_data = true;
        GetReappropn.getreappropn().query()
            .$promise.then(
            function(response){
                $scope.reappropdetails = response;
                $scope.gridReapprops.data = response;
                $log.debug("gridReapprops.data:",$scope.gridReapprops.data );
                $scope.loading_data = false;
           },
            function(response){
                $scope.loading_data = false;
                handleError.notify(response, '');
            }
        );
    };
            // Do Initial Pool grants  load
            $scope.getReappropDetails();



// Selected Reappropriation
  var getReappropSelection = function(){
        var selectedRows = $scope.gridApiReapprops.selection.getSelectedRows();
         var reappropSelection = { selectedReapprop: {}};
        angular.forEach( selectedRows, function(row){
            var reappropriation_guid = row.reappropriation_guid;
            reappropSelection.selectedReapprop[reappropriation_guid] = row;
        });
        $log.debug("Reappropraiation Details:", reappropSelection);
        return reappropSelection;
    };



// Get Reappropriation  details
$scope.gridReappropsDetails = {
            enableSorting :true,
            enablePaginationControls: true,
            paginationPageSize: 25,
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: true,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 550,
            showGridFooter:false,
            selectedItems: [],
            enableGridMenu: true,
            exporterMenuVisibleData : true,
            exporterCsvFilename: 'Reappropriation.csv',
            exporterPdfDefaultStyle: {fontSize: 12},
            exporterPdfTableStyle: {margin: [30, 30, 30, 30]},
            exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
            exporterPdfHeader: { text: "Reappropriation Details", style: 'headerStyle' },
            exporterPdfFooter: function ( currentPage, pageCount ) {
              return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function ( docDefinition ) {
              docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
              docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
              return docDefinition;
            },
            exporterPdfOrientation: 'landscape',
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            exporterExcelFilename: 'Reappropriations.xlsx',
            exporterExcelSheetName: 'Sheet1',
            //Row Selection Enhancement
            enableRowSelection: true,
            enableFullRowSelection: true,

            columnDefs: [
                  { name:'Partner Grant', field: 'grant_name', width: 170, pinnedLeft:false},
                  { name:'Competitive Pool', field: 'pool_name', width: 170,  pinnedLeft:false },
                  { name:'Amount', field: 'amount', width: 125,cellFilter:'currency', pinnedLeft:false},
                  { name:'Notes', field: 'notes', width: 125,  pinnedLeft:false}
        ]
    };



// Register the grid for API calls like clearSelectedRows() and getSelectedRows()
    $scope.gridReappropsDetails.onRegisterApi = function(gridApiReappropsDetails){
        $scope.gridApiReappropsDetails = gridApiReappropsDetails;

        gridApiReappropsDetails.selection.on.rowSelectionChanged($scope,function(row){
        var msg = 'row selected'+row.isSelected;
         $scope.selectedRows = $scope.gridApiReappropsDetails.selection.getSelectedRows()[0];
         $scope.selectedguidpool = $scope.selectedRows.partner_grant_guid;
        // console.log($scope.selectedguidfund);
        });
    };




// Adding Grant details in the reappropriate modal
    $scope.addRow = function(){
            $scope.reappropriatelist.push({ 'grant_name':$scope.grantnamereapp, 'amount': $scope.reapgrantamount});
        $scope.grantnamereapp='';
        $scope.reapgrantamount='';

    };


// Remove Grant from the reappropriate modal
    $scope.removeRow = function(name){
        var index = -1;
        var comArr = eval( $scope.reappropriatelist );
        for( var i = 0; i < comArr.length; i++ ) {
            if( comArr[i].name === name ) {
                index = i;
                break;
            }
        }
        if( index === -1 ) {
            alert( "Something gone wrong" );
        }
        $scope.reappropriatelist.splice( index, 1 );
    };


// Post request for reappropriate
    $scope.submitreap = function(){
          $scope.reap_guid = $scope.appropriation_source_guid.appropriation_guid;
          console.log('reap_guid',$scope.reap_guid);
          var response = {"appropriation_source_guid":$scope.appropriation_source_guid.appropriation_guid,"appropriation_target_guid":$scope.appropriation_target_guid,"status_transfer_desc":"PENDING","transfer_amount":$scope.transfer_amount,"note":$scope.note,"detail":$scope.cpdetail};
         AddReapprop.addarepprop().save(response)
            .$promise.then(
               function(response){
                  console.log(response);
                  $uibModalInstance.close(response);
                  modalMessageService.showMessage( "Success:","Added Reappropriation Successfully");
               },
             function(response){
                 $scope.loading_data = false;
                 handleError.notify(response, '');
             }
          );
//         $uibModalInstance.close(response);
    };


// Post request for reappropriate competitive
    $scope.submitreapcomp = function(){
          $scope.reap_guid = $scope.appropriation_source_guid.appropriation_guid;
          console.log('reap_guid',$scope.reap_guid);
          var response = {"appropriation_source_guid":$scope.appropriation_source_guid.appropriation_guid,"appropriation_target_guid":$scope.appropriation_target_guid,"status_transfer_desc":"PENDING","transfer_amount":$scope.transfer_amount,"note":$scope.note,"detail":$scope.grantdetail};
         AddReapprop.addarepprop().save(response)
            .$promise.then(
               function(response){
                  console.log(response);
                  $uibModalInstance.close(response);
                  modalMessageService.showMessage( "Success:","Added Reapprop pool Successfully");
               },
             function(response){
                 $scope.loading_data = false;
                 handleError.notify(response, '');
             }
          );
//         $uibModalInstance.close(response);
    };


//Add New Grant Details for the reappropriation
// $scope.addGrant = function(){
//      var data={
//          "reappropriation_guid": $scope.selectedFundData.fund_guid,
//          "fund_id": $scope.selectedFundData.fund_id,
//          "fund_name": $scope.selectedFundData.fund_name,
//          "fund_description": $scope.selectedFundData.fund_description,
//          "balance":$scope.selectedFundData.balance,
//          "encumbered":$scope.selectedFundData.encumbered,
//          "spent":$scope.selectedFundData.spent
//      };
//      console.log(data);
//      UpdateFund.updatefund().update({guid:data.fund_guid},data);
//
//};


//Add competitive pool detail in the modal
    $scope.cpdetail = [];
    $scope.addPool = function(){
        $scope.cpdetail.push({competitive_pool_guid:$scope.competitive_pool_reap.competitive_pool_guid,pool_name:$scope.competitive_pool_reap.pool_name, amount:$scope.amount1});
        console.log($scope.cpdetail);
    };
    $scope.grantdetail = [];
    $scope.addGrant = function(){
        $scope.grantdetail.push({partner_grant_guid:$scope.partner_grant_detail.partner_grant_guid,grant_name:$scope.partner_grant_detail.grant_name, amount:$scope.amount1});
        console.log($scope.grantdetail);
    };
//console.log($scope.partner_grant1);




// removing the grant row in the modal
    $scope.removePool = function(i){
    $scope.cpdetail.splice(i, 1);
    };

    $scope.removeGrant = function(i){
    $scope.grantdetail.splice(i, 1);
    };




// Get Reappropriation Details API
     $scope.getReappropDetails = function() {
            $scope.gridReappropsDetails.data = $scope.selectedReappropDetails;
            };
      // Do Initial Pool Payments load
            $scope.getReappropDetails();

}])







.controller('ReappropModalCtrl', function($scope,$log,$state,$stateParams,$filter,$uibModalInstance,GetAppropn,GetTransactiontype,UpdateReapprop,GetTransferStatus,AddReapprop,
                                          GetReapproprData,GetReappropn,ReappropDataService,GetProgramtype,modalService,modalMessageService,handleError){



// Reappropriations  Details
    $scope.viewSelectedReapprop = function(){
      ReappropDataService.setSelectedReapprop($scope.gridApiReapprops.selection.getSelectedRows());
      $scope.selectedRows = $scope.gridApiReapprops.selection.getSelectedRows()[0];
      $scope.selectedguidreapprop = $scope.selectedRows.reappropriation_guid;
        var reappropriation_guid = $scope.selectedguidreapprop;
        $location.path('/finance/reappropdetails/'+reappropriation_guid);
    };

     $scope.selectedReappropData = ReappropDataService.getSelectedReapprop()[0];
     $scope.selectedReappropDetails = _.get($scope.selectedReappropData, 'detail');



// Transfer Status
 var transferstatus  = GetTransferStatus.gettransferstatus().query()
      .$promise.then(
        function(response){
            $scope.transferstatuslist = response;
        },function(response){
             $scope.loading_data = false;
             handleError.notify(response, '');
         });



 // Get Appropriation Details here
 var appropslist = GetAppropn.getappropn().query()
      .$promise.then(
        function(response){
            $scope.appropslist = response;
        },function(response){
             $scope.loading_data = false;
             handleError.notify(response, '');
         });


//
////Add New Grant Details for the reappropriation
// $scope.addGrant = function(){
//      var data={
//          "reappropriation_guid": $scope.selectedFundData.fund_guid,
//          "fund_id": $scope.selectedFundData.fund_id,
//          "fund_name": $scope.selectedFundData.fund_name,
//          "fund_description": $scope.selectedFundData.fund_description,
//          "balance":$scope.selectedFundData.balance,
//          "encumbered":$scope.selectedFundData.encumbered,
//          "spent":$scope.selectedFundData.spent
//      };
//      console.log(data);
//      UpdateFund.updatefund().update({guid:data.fund_guid},data);
//
//};



//Selected Reappropriation in edit mode
$scope.viewSelectedReappropriation = function(){
    if(!!$scope.selecteddatareapprop && !!$scope.selecteddatareapprop.reappropriation_guid){
        var reappropguid = $scope.selecteddatareapprop.reappropriation_guid;
        $scope.reappropguid = $scope.selecteddatareapprop;
        var reappropriationdetailsid = GetReapproprData.getreappropdata(reappropguid).get()
                              .$promise.then(
                                function(response){
                                    $scope.selectedreapppropdetails = response;

                                    $scope.selectedreapppropdetails.reappropriation_date = convertoDate($scope.selectedreapppropdetails.reappropriation_date);
                                        $location.path('/finance/reappropriations/reappropdetails/'+reappropguid);
                                },
                                function(response){
                                    $scope.loading_data = false;
                                    handleError.notify(response, '');
                                }
                             );
                }
        };
    $scope.viewSelectedReappropriation();
          if(!!$stateParams){
              $scope.selecteddatareapprop = $stateParams;

            }



// Post request for reappropriate
    $scope.submitreap = function(){
          $scope.reap_guid = $scope.appropriation_source_guid.appropriation_guid;
          console.log('reap_guid',$scope.reap_guid);
          var response = {"appropriation_source_guid":$scope.appropriation_source_guid.appropriation_guid,"appropriation_target_guid":$scope.appropriation_target_guid,"status_transfer_desc":"PENDING","transfer_amount":$scope.transfer_amount,"note":$scope.note,"detail":$scope.cpdetail};
         AddReapprop.addarepprop().save(response)
            .$promise.then(
               function(response){
                  console.log(response);
                  $uibModalInstance.close(response);
                  modalMessageService.showMessage( "Success:","Added Reappropriation Successfully");
               },
                 function(response){
                     $scope.loading_data = false;
                     handleError.notify(response, '');
                 }
          );
//         $uibModalInstance.close(response);
    };


// Post request for reappropriate competitive
    $scope.submitreapcomp = function(){
          $scope.reap_guid = $scope.appropriation_source_guid.appropriation_guid;
          console.log('reap_guid',$scope.reap_guid);
          var response = {"appropriation_source_guid":$scope.appropriation_source_guid.appropriation_guid,"appropriation_target_guid":$scope.appropriation_target_guid,"status_transfer_desc":"PENDING","transfer_amount":$scope.transfer_amount,"note":$scope.note,"detail":$scope.grantdetail};
         AddReapprop.addarepprop().save(response)
            .$promise.then(
               function(response){
                  console.log(response);
                  $uibModalInstance.close(response);
                  modalMessageService.showMessage( "Success:","Added Reapprop pool Successfully");
               },
                 function(response){
                     $scope.loading_data = false;
                     handleError.notify(response, '');
                 }
          );
//         $uibModalInstance.close(response);
    };


// Get Reappropriations details grid table data from the guid
$scope.getReappropDetails = function() {
//                loading image
                $scope.loading_data = true;
                if(!!$scope.selecteddatareapprop && !!$scope.selecteddatareapprop.reappropriation_guid){
                var reappropguid = $scope.selecteddatareapprop.reappropriation_guid;
                $scope.reappropguid = $scope.selecteddatareapprop;
                var reappropriationdetailsid = GetReapproprData.getreappropdata(reappropguid).get()
                                      .$promise.then(
                                        function(response){
                                            $scope.selectedreapppropdetails = response;

                                            $scope.selectedreapppropdetails.reappropriation_date = new Date($scope.selectedreapppropdetails.reappropriation_date);


                                        },
                                        function(response){
                                            $scope.loading_data = false;
                                            handleError.notify(response, '');
                                        }
                                     );
                        }
            };

            // Do Initial Reapprops   load
            $scope.getReappropDetails();




// Date picker
    $scope.today = function() {
    $scope.dt = new Date();
    };
    $scope.today();
    $scope.dateOptions = {
    formatYear: 'yy',
    maxDate: new Date(2020, 5, 22),
    minDate: new Date(),
    startingDay: 1
    };
    $scope.open1 = function() {
    $scope.popup1.opened = true;
    };


    $scope.setDate = function(year, month, day) {
    $scope.dt = new Date(year, month, day);
    };

    $scope.clear = function() {
    $scope.dt = null;
    };
    var convertoDate = function(dateStr){
        var tmpDate = dateStr.split('-');
        return new Date($scope.selectedreapppropdetails.reappropriation_date);
   };

    $scope.formats = ['dd-MM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
    $scope.format = $scope.formats[0];
    $scope.altInputFormats = ['M!/d!/yyyy'];

    $scope.popup1 = {
    opened: false
    };

    $scope.popup2 = {
    opened: false
    };

    var tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    var afterTomorrow = new Date();
    afterTomorrow.setDate(tomorrow.getDate() + 1);
    $scope.events = [
    {
      date: tomorrow,
      status: 'full'
    },
    {
      date: afterTomorrow,
      status: 'partially'
    }
    ];


// Submit Edited Reapprop
    $scope.submitEditReapprop = function(){
      var data={
          "reappropriation_guid": $scope.selectedreapppropdetails.reappropriation_guid,
          "reappropriation_date": $scope.selectedreapppropdetails.reappropriation_date,
          "status_transfer_desc":$scope.selectedreapppropdetails.status_transfer_desc,
          "note":$scope.selectedreapppropdetails.note
      };
      console.log(data);
//      data.reappropriation_date = $filter('date')($scope.selectedReappropData.reappropriation_date,'yyyy-MM-dd');
      UpdateReapprop.updatereapprop().update({guid:data.reappropriation_guid},data);
     $state.reload();
     modalMessageService.showMessage( "Success:","Reappropriation Edited Successfully");
     $uibModalInstance.dismiss();
    };



// Adding Grant details in the reappropriate modal
    $scope.addRow = function(){
            $scope.reappropriatelist.push({ 'grant_name':$scope.grantnamereapp, 'amount': $scope.reapgrantamount});
        $scope.grantnamereapp='';
        $scope.reapgrantamount='';

    };


// Remove Grant from the reappropriate modal
    $scope.removeRow = function(name){
        var index = -1;
        var comArr = eval( $scope.reappropriatelist );
        for( var i = 0; i < comArr.length; i++ ) {
            if( comArr[i].name === name ) {
                index = i;
                break;
            }
        }
        if( index === -1 ) {
            alert( "Something gone wrong" );
        }
        $scope.reappropriatelist.splice( index, 1 );
    };


//Add competitive pool detail in the modal
    $scope.cpdetail = [];
    $scope.addPool = function(){
        $scope.cpdetail.push({competitive_pool_guid:$scope.competitive_pool_reap.competitive_pool_guid,pool_name:$scope.competitive_pool_reap.pool_name, amount:$scope.amount1});
        console.log($scope.cpdetail);
    };
    $scope.grantdetail = [];
    $scope.addGrant = function(){
        $scope.grantdetail.push({partner_grant_guid:$scope.partner_grant_detail.partner_grant_guid,grant_name:$scope.partner_grant_detail.grant_name, amount:$scope.amount1});
        console.log($scope.grantdetail);
    };
//console.log($scope.partner_grant1);

//Add New Grant Details for the reappropriation
 $scope.addGrant = function(){
      var data={
          "reappropriation_guid": $scope.selectedFundData.fund_guid,
          "fund_id": $scope.selectedFundData.fund_id,
          "fund_name": $scope.selectedFundData.fund_name,
          "fund_description": $scope.selectedFundData.fund_description,
          "balance":$scope.selectedFundData.balance,
          "encumbered":$scope.selectedFundData.encumbered,
          "spent":$scope.selectedFundData.spent
      };
      console.log(data);
      UpdateFund.updatefund().update({guid:data.fund_guid},data);

};


// removing the grant row in the modal
    $scope.removePool = function(i){
    $scope.cpdetail.splice(i, 1);
    };

    $scope.removeGrant = function(i){
    $scope.grantdetail.splice(i, 1);
    };



$scope.close = function(){
    $uibModalInstance.dismiss();
};

});
