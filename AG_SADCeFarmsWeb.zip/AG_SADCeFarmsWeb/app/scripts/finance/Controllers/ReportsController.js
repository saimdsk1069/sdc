(function () {
    'use strict';
}());

var financeapp = angular.module('agSADCeFarms');
    financeapp.controller('ReportsController', ['$scope','$rootScope','$stateParams','$q','$location','$filter', '$uibModal','$state', '$log','GetReportType','AuthService','GetReport','modalService','modalMessageService','handleError',
        function($scope,$rootScope,$stateParams,$q,$location,$filter,$uibModal,$state,$log,GetReportType,AuthService,GetReport,modalService,modalMessageServic,handleError) {


// Date picker
    $scope.today = function() {
    $scope.dt = new Date();
    $scope.todaydate = $filter('date')($scope.dt,'yyyyMMdd');
    };
    $scope.today();
    $scope.dateOptions = {
    formatYear: 'yy',
    maxDate: new Date(2070, 5, 22),
    startingDay: 1
    };
    $scope.open1 = function() {
    $scope.popup1.opened = true;
    };


    $scope.setDate = function(year, month, day) {
    $scope.dt = new Date(year, month, day);
    };

    $scope.clear = function() {
    $scope.dt = null;
    };
    $scope.formats = ['dd-MMM-yyyy', 'yyyy-mm-dd', 'dd.MM.yyyy', 'shortDate'];
    $scope.format = $scope.formats[1];
    $scope.altInputFormats = ['M!/d!/yyyy'];

    $scope.popup1 = {
    opened: false
    };

    $scope.popup2 = {
    opened: false
    };

    var tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    var afterTomorrow = new Date();
    afterTomorrow.setDate(tomorrow.getDate() + 1);
    $scope.events = [
    {
      date: tomorrow,
      status: 'full'
    },
    {
      date: afterTomorrow,
      status: 'full'
    }
    ];

//Report Generated button
    $scope.GenerateReport = function(){
    modalMessageService.showMessage( "Report Status:", "Report has been generated");
    };


//Report Types  list
    var reportname = GetReportType.getreporttype().query()
    .$promise.then(
    function(response){
        $scope.reportname = response;
    //        $scope.getArray = $scope.reportname;
    },function(response){
                $scope.loading_data = false;
                handleError.notify(response, '');
            });


//Write CSV using angular
    $scope.separator = ",";
    $scope.decimalseparator = ".";
//    $scope.filename = "Financereport"+'-'+$scope.todaydate+".csv";
    $scope.filenamexls = "Financereport"+".xls";
    $scope.Download = function() {
    var guid = $rootScope.reportGuid;
    var type = $rootScope.reportFormat;
    };
//    console.log("Label",$rootScope.reportLabel)

//Get Json data from service
 $scope.getJSONData = function(){
        $rootScope.reportGuid = $scope.report_type.report_guid;
        $rootScope.reportFormat = $scope.report_format;
        var guid = $rootScope.reportGuid;
        var type = $rootScope.reportFormat;
        var deferred = $q.defer();
        GetReport.getreport(guid,type).query()
        .$promise.then(
        function(data,status, headers, config){
            deferred.resolve(data);
        },
        function(response){
            $scope.loading_data = false;
            handleError.notify(response, '');
        });
        return deferred.promise;
        };


//$scope.exportJsonData = null;

//ui components
    $scope.ui_components = {
            'ui_fiscal': false
        };

//Check the AuthService here
if ( AuthService.isAuthenticated() ) {
    $log.debug("++++++User is authenticated");
    $log.debug("++++++Users ui access:", AuthService.getUserUIAccess());
    $scope.ui_components = {
            'ui_fiscal':true
        };
} else {
    $log.debug("++++++User is not authenticated");
}

//Loading data from service
$scope.loadApiData = function(){
        $rootScope.reportGuid = $scope.report_type.report_guid;
        $rootScope.reportLabel = $scope.report_type.report_label.replace(/ /g, '_');
        $rootScope.reportFormat = $scope.report_format;
        var guid = $rootScope.reportGuid;
        var type = $rootScope.reportFormat;

        GetReport.getreport(guid,type).query()
        .$promise.then(
        function(data,status, headers, config){
            $scope.exportJsonData = data;
            $scope.exportData = $scope.exportJsonData.map(function(obj){
                    return Object.values(obj);
            });
//            console.log("export Data", $scope.exportData);
//            console.log("Report name", $scope.reportLabel);
            $scope.fileName = $scope.reportLabel+'_'+$scope.todaydate;
            $scope.filename =  $scope.reportLabel+'_'+$scope.todaydate+".csv";
        },function(response){
                $scope.loading_data = false;
                handleError.notify(response, '');
            }
        );
};

// Prepare Excel data:
//        $scope.fileName = "Financereport";
//        $scope.exportData = $scope.testData2;


//Csv or xls option is set here
    $scope.updateFormat = function(){
    $rootScope.reportFormat = $scope.report_format;
    };
    $scope.today = function() {
    $scope.dt = new Date();
    };
    $scope.today();
    $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];

    $scope.reportformatlist = [
    {
        "report_name":"csv",
        "report_type":"csv"
    },
    {
        "report_name":"xlsx",
        "report_type":"xlsx"
    }
    ];

}]);


/* Directive */
financeapp.directive('excelExport',
    function () {
      return {
        restrict: 'A',
        scope: {
        	fileName: "@",
            data: "&exportData"
        },
        replace: true,
        template: '<button class="btn btn-primary btn-ef btn-ef-3 btn-ef-3c mb-10" ng-click="download()">Download Report <i class="fa fa-download"></i></button>',
        link: function (scope, element) {

        	scope.download = function() {

        		function datenum(v, date1904) {
            		if(date1904) v+=1462;
            		var epoch = Date.parse(v);
            		return (epoch - new Date(Date.UTC(1899, 11, 30))) / (24 * 60 * 60 * 1000);
            	}

            	function getSheet(data, opts) {
            		var ws = {};
            		var range = {s: {c:10000000, r:10000000}, e: {c:0, r:0 }};
            		for(var R = 0; R != data.length; ++R) {
            			for(var C = 0; C != data[R].length; ++C) {
            				if(range.s.r > R) range.s.r = R;
            				if(range.s.c > C) range.s.c = C;
            				if(range.e.r < R) range.e.r = R;
            				if(range.e.c < C) range.e.c = C;
            				var cell = {v: data[R][C] };
            				if(cell.v == null) continue;
            				var cell_ref = XLSX.utils.encode_cell({c:C,r:R});

            				if(typeof cell.v === 'number') cell.t = 'n';
            				else if(typeof cell.v === 'boolean') cell.t = 'b';
            				else if(cell.v instanceof Date) {
            					cell.t = 'n'; cell.z = XLSX.SSF._table[14];
            					cell.v = datenum(cell.v);
            				}
            				else cell.t = 's';

            				ws[cell_ref] = cell;
            			}
            		}
            		if(range.s.c < 10000000) ws['!ref'] = XLSX.utils.encode_range(range);
            		return ws;
            	}

            	function Workbook() {
            		if(!(this instanceof Workbook)) return new Workbook();
            		this.SheetNames = [];
            		this.Sheets = {};
            	}

            	var wb = new Workbook(), ws = getSheet(scope.data());
            	/* add worksheet to workbook */
            	wb.SheetNames.push(scope.fileName);
            	wb.Sheets[scope.fileName] = ws;
            	var wbout = XLSX.write(wb, {bookType:'xlsx', bookSST:true, type: 'binary'});

            	function s2ab(s) {
            		var buf = new ArrayBuffer(s.length);
            		var view = new Uint8Array(buf);
            		for (var i=0; i!=s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
            		return buf;
            	}
        		saveAs(new Blob([s2ab(wbout)],{type:"application/octet-stream"}), scope.fileName+'.xlsx');
        	};

        }
      };
    }
 );

financeapp.controller('ReportsModalCtrl', function($scope,$log,$state,$filter,$uibModalInstance,modalService,modalMessageService){

});
