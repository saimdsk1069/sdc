(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    //.constant("baseURL", "http://oit-6gsgyv1.oit.state.nj.us/AG_SADCeFarmsWS/")
    .constant("baseURL", "/AG_SADCeFarms/")


    //service for get the financedetails List
     .service('Getfund', ['$resource','baseURL',function($resource,baseURL){
        var fundData = {};
        this.getfundlist = function(){
            return $resource(baseURL+'fund',{method:'GET'});

        };
        this.setFund = function(fund){
                fundData = fund;
        };
        this.getFund = function(){
                return fundData;
        };

    }])

    // service for adding new fund
     .service('AddFund', ['$resource','baseURL', function($resource,baseURL) {

        this.addfund = function(){

            return $resource(baseURL+'fund/:fund_guid', null, {'save':{method:'POST'}});
        };

    }])


    // service for Selected  Fund details
    .service('FundDataService', function() {
          this.store = {};
          this.getSelectedFund = function(){
            return this.store;
          };
          this.setSelectedFund = function(data){
            this.store = data;
            return this.store;
          };

    })


     // service for Selected  Fund Transaction details
    .service('FundTransDataService', function() {
          this.store = {};
          this.getSelectedFundTrans = function(){
            return this.store;
          };
          this.setSelectedFundTrans = function(data){
            this.store = data;
            return this.store;
          };

    })





    // service for Selected  Appropriation details
    .service('AppropDataService', function() {
          this.store = {};
          this.getSelectedApprop = function(){
            return this.store;
          };
          this.setSelectedApprop = function(data){
             this.store = data;
             return this.store;
          };

    })

    // service for Selected  Partner grant details
    .service('PartnerDataService', function() {
          this.store = {};
          this.getSelectedPartner = function(){
            return this.store;
          };
          this.setSelectedPartner = function(data){
             this.store = data;
             return this.store;
          };

    })


    // service for Selected  Competitive Grant details
    .service('PoolDataService', function() {
          this.store = {};
          this.getSelectedPool = function(){
            return this.store;
          };
          this.setSelectedPool = function(data){
             this.store = data;
             return this.store;
          };

    })



     // service for Selected  Reappropriation  details
    .service('ReappropDataService', function() {
          this.store = {};
          this.getSelectedReapprop = function(){
            return this.store;
          };
          this.setSelectedReapprop = function(data){
             this.store = data;
             return this.store;
          };

    })



   // service for Selected  Expenses  details
    .service('ExpenseDataService', function() {
          this.store = {};
          this.getSelectedExpense = function(){
            return this.store;
          };
          this.setSelectedExpense = function(data){
             this.store = data;
             return this.store;
          };

    })


     // service for Selected  Payment  details
    .service('PaymentDataService', function() {
          this.store = {};
          this.getSelectedPayment = function(){
            return this.store;
          };
          this.setSelectedPayment = function(data){
             this.store = data;
             return this.store;
          };

    })



     // service for Selected  Expenses Payment details
    .service('ExpensePayDataService', function() {
          this.store = {};
          this.getSelectedExpensePay = function(){
            return this.store;
          };
          this.setSelectedExpensePay = function(data){
             this.store = data;
             return this.store;
          };
    })





    // services for updating fund
     .service('UpdateFund', ['$resource','baseURL', function($resource,baseURL) {

        this.updatefund = function(){

            return $resource(baseURL+'fund/:guid', null, {'update':{method:'PUT'}});
        };

    }])


    // services for updating fund transaction
     .service('UpdateFundTrans', ['$resource','baseURL', function($resource,baseURL) {

        this.updatefundtrans = function(){

            return $resource(baseURL+'fundtrans/:guid', null, {'update':{method:'PUT'}});
        };

    }])

    //Delete service for Fund
    .service('DeleteFund', ['$resource','baseURL',function($resource,baseURL){
        this.deletefund = function(){
            return $resource(baseURL+'fund/:fund_guid',null, {'delete':{method:'DELETE'}});
        };
    }])


     //Delete service for Fund Transaction
    .service('DeleteFundTrans', ['$resource','baseURL',function($resource,baseURL){
        this.deletefundtrans = function(){
            return $resource(baseURL+'fundtrans/:fund_transaction_guid',null, {'delete':{method:'DELETE'}});
        };
    }])


    //service for getting all the appropriation details
    .service('GetAppropn', ['$resource','baseURL',function($resource,baseURL){
        var Appropdata = {};
        this.getappropn = function(){
            return $resource(baseURL+'appropriation',{method:'GET'});
        };
        this.setApprop = function(approp){
                Appropdata = approp;
        };
        this.getApprop = function(){
                return Appropdata;
        };
    }])

    //service for adding new appropriation
    .service('AddApprop', ['$resource','baseURL', function($resource,baseURL) {

        this.addapprop = function(){

            return $resource(baseURL+'appropriation/:appropriation_guid', null, {'save':{method:'POST'}});
        };

    }])


    //service for Updating  appropriation
    .service('UpdateApprop', ['$resource','baseURL', function($resource,baseURL) {

        this.updateapprop = function(){

            return $resource(baseURL+'appropriation/:guid', null, {'update':{method:'PUT'}});
        };

    }])



    //Delete Appropriation
    .service('DeleteAppropriation', ['$resource','baseURL',function($resource,baseURL){
        this.deleteappropriation = function(){
            return $resource(baseURL+'appropriation/:appropriation_guid',null, {'delete':{method:'DELETE'}});
        };
    }])



    //Related appropriations
    .service('GetRelatedappropn', ['$resource','baseURL',function($resource,baseURL){
        this.getrelatedappropn = function(guid){
            return $resource(baseURL+'appropriation/?fund_guid='+guid,{method:'GET'});

        };
    }])




   //Report types list
    .service('GetReportType', ['$resource','baseURL',function($resource,baseURL){
        this.getreporttype = function(guid){
            return $resource(baseURL+'reporttype',{method:'GET'});

        };
    }])

    //Get Report  here
    .service('GetReport', ['$resource','baseURL',function($resource,baseURL){
        this.getreport = function(guid,type){
            return $resource(baseURL+'report/'+guid+'/'+type,{method:'GET'});

        };
    }])





    // Reappropriation services
    .service('GetReappropn', ['$resource','baseURL',function($resource,baseURL){
        var reappropData = {};
        this.getreappropn = function(){
            return $resource(baseURL+'reappropriation',{method:'GET'});

        };
        this.setReaprop = function(reapprop){
                reappropData = reapprop;
        };
        this.getReapprop = function(){
                return reappropData;
        };
    }])




    //Delete service for reappropriation
    .service('DeleteReappropn', ['$resource','baseURL',function($resource,baseURL){
        this.deletereappropn = function(){
            return $resource(baseURL+'reappropriation/:reappropriation_guid',null, {'delete':{method:'DELETE'}});
        };
    }])



    //Post Reappropriation Service
    .service('AddReapprop', ['$resource','baseURL', function($resource,baseURL) {

        this.addarepprop = function(){

            return $resource(baseURL+'reappropriation/:reappropriation_guid', null, {'save':{method:'POST'}});
        };

    }])



     // services for updating Reappropriation
     .service('UpdateReapprop', ['$resource','baseURL', function($resource,baseURL) {

        this.updatereapprop = function(){

            return $resource(baseURL+'reappropriation/:guid', null, {'update':{method:'PUT'}});
        };

    }])





    //partner grants
    .service('GetPartnerGrant', ['$resource','baseURL',function($resource,baseURL){
        var partnergrantData = {};
        this.getpartnergrant = function(){
            return $resource(baseURL+'partnergrant',{method:'GET'});

        };
        this.setPartnerGrant = function(partnergrant){
                partnergrantData = partnergrant;
        };
        this.getPartnerGrant = function(){
                return partnergrantData;
        };
    }])




    //service for adding new Partner Grant
    .service('AddPartnerGrant', ['$resource','baseURL', function($resource,baseURL) {

        this.addpartnergrant = function(){

            return $resource(baseURL+'partnergrant/:partnergrant_guid', null, {'save':{method:'POST'}});
        };
    }])




    //Delete service for Partner Grant
    .service('DeleteGrant', ['$resource','baseURL',function($resource,baseURL){
        this.deletegrant = function(){
            return $resource(baseURL+'partnergrant/:partner_grant_guid',null, {'delete':{method:'DELETE'}});
        };
    }])




    //competitive pool grants
    .service('GetCompetitiveGrant', ['$resource','baseURL',function($resource,baseURL){
        var competitivegrantData = {};
        this.getcompetitivegrant = function(){
            return $resource(baseURL+'competitivepool',{method:'GET'});

        };
        this.setCompetitiveGrant = function(competitivegrant){
                competitivegrantData = competitivegrant;
        };
        this.getCompetitiveGrant = function(){
                return competitivegrantData;
        };
    }])




    //Service for adding Competitive Pool
    .service('AddCompetitivePool', ['$resource','baseURL', function($resource,baseURL) {

        this.addcompetitivepool = function(){

            return $resource(baseURL+'competitivepool/:competitive_pool_guid', null, {'save':{method:'POST'}});
        };
    }])




    //Delete service for Pool
    .service('DeletePool', ['$resource','baseURL',function($resource,baseURL){
        this.deletepool = function(){
            return $resource(baseURL+'competitivepool/:competitive_pool_guid',null, {'delete':{method:'DELETE'}});
        };
    }])










    //Get program type services here
    .service('GetProgramtype', ['$resource','baseURL',function($resource,baseURL){
        this.getprogramtype = function(){
            return $resource(baseURL+'programtype',{method:'GET'});

        };
    }])


     //Get Expense types  here
    .service('GetExpensetype', ['$resource','baseURL',function($resource,baseURL){
        this.getexpensetype = function(){
            return $resource(baseURL+'expensetype',{method:'GET'});

        };
    }])




     //Get Expense status  here
    .service('GetExpensestatus', ['$resource','baseURL',function($resource,baseURL){
        this.getexpensestatus = function(){
            return $resource(baseURL+'expensestatus',{method:'GET'});

        };
    }])


     //Delete service for Expenses
    .service('DeleteExpense', ['$resource','baseURL',function($resource,baseURL){
        this.deleteexpense = function(){
            return $resource(baseURL+'expense/:expense_guid',null, {'delete':{method:'DELETE'}});
        };
    }])



    //Service for adding Expenses
    .service('AddExpense', ['$resource','baseURL', function($resource,baseURL) {

        this.addexpense = function(){

            return $resource(baseURL+'expense/:expense_guid', null, {'save':{method:'POST'}});
        };
    }])

    //Get grant type services here
    .service('GetGranttype', ['$resource','baseURL',function($resource,baseURL){
        this.getgranttype = function(){
            return $resource(baseURL+'granttype',{method:'GET'});

        };
    }])


    //Get partner services here
    .service('GetPartner', ['$resource','baseURL',function($resource,baseURL){
        this.getpartner = function(){
            return $resource(baseURL+'partner',{method:'GET'});

        };
    }])


     //Get Payment Status services here
    .service('GetPayStatus', ['$resource','baseURL',function($resource,baseURL){
        this.getpaystatus = function(){
            return $resource(baseURL+'paymentstatus',{method:'GET'});

        };
    }])


    //Funds Payments History
    .service('GetPaymentsHistory', ['$resource','baseURL',function($resource,baseURL){
        this.getpaymentshistory = function(guid){
            return $resource(baseURL+'payment/?fund_guid='+guid,{method:'GET'});

        };
    }])

    //Service for getting  Expenses With Farm ID
    .service('GetFarmExpense', ['$resource','baseURL',function($resource,baseURL){
        this.getfarmexpense = function(farmguid){
            return $resource(baseURL+'expense/?farm_id='+farmguid,{method:'GET'});

        };
    }])


     //Service for getting  Expenses With Application ID
    .service('GetAppExpense', ['$resource','baseURL',function($resource,baseURL){
        this.getappexpense = function(appguid){
            return $resource(baseURL+'expense/?application_id='+appguid,{method:'GET'});

        };
    }])




    // Transaction types
    .service('GetTransactiontype', ['$resource','baseURL',function($resource,baseURL){
        this.gettransactiontype = function(guid){
            return $resource(baseURL+'transactiontype',{method:'GET'});

        };
    }])

     //Appropriations Payments History
    .service('GetAppropPayHistory', ['$resource','baseURL',function($resource,baseURL){
        this.getapproppayhistory = function(appropguid){
            return $resource(baseURL+'payment/?appropriation_guid='+appropguid,{method:'GET'});

        };
    }])

     // service for adding new fund
     .service('AddTrans', ['$resource','baseURL', function($resource,baseURL) {

        this.addtrans = function(){

            return $resource(baseURL+'fundtrans/:fund_transaction_guid', null, {'save':{method:'POST'}});
        };

    }])


    // service for adding new fund
     .service('GetTransferStatus', ['$resource','baseURL', function($resource,baseURL) {

        this.gettransferstatus = function(){

            return $resource(baseURL+'transferstatus',{method:'GET'});
        };

    }])


    //expense service
    .service('GetExpense', ['$resource','baseURL',function($resource,baseURL){
        var expenseData = {};
        this.getexpense = function(){
            return $resource(baseURL+'expense',{method:'GET'});

        };
        this.setExpense = function(exp){
            expenseData = exp;
        };
        this.getExpense = function(){
                return expenseData;
        };
    }])



      //Service for Get Expenses based on guid   here
    .service('GetExpenseData', ['$resource','baseURL',function($resource,baseURL){
        this.getexpensedata = function(expguid){
            return $resource(baseURL+'expense/'+expguid,{method:'GET'});

        };
    }])


      //Service for Get Reappropriations based on guid   here
    .service('GetReapproprData', ['$resource','baseURL',function($resource,baseURL){
        this.getreappropdata = function(reapguid){
            return $resource(baseURL+'reappropriation/'+reapguid,{method:'GET'});

        };
    }])




     //Service for Get Payment   here
    .service('GetPayment', ['$resource','baseURL',function($resource,baseURL){
        this.getpayment = function(){
            return $resource(baseURL+'payment',{method:'GET'});

        };
    }])

        //Service for Get Payment Source  here
    .service('GetPaymentSource', ['$resource','baseURL',function($resource,baseURL){
        this.getpaymentsource = function(){
            return $resource(baseURL+'paymentsource',{method:'GET'});

        };
    }])

    //Service for Post Payment   here
    .service('AddPayment', ['$resource','baseURL',function($resource,baseURL){
        this.addpayment = function(){
            return $resource(baseURL+'payment',{method:'POST'});

        };
    }])




      // service for Selected  Reappropriation Payment details here
    .service('ExpPayDataService', function() {
          this.store = {};
          this.getSelectedPayment = function(){
            return this.store;
          };
          this.setSelectedPayment = function(data){
             this.store = data;
             return this.store;
          };

    })


    //Service for Delete Payment   here
    .service('DeletePayment', ['$resource','baseURL',function($resource,baseURL){
        this.deletepayment = function(){
            return $resource(baseURL+'payment/:expense_payment_guid',{method:'DELETE'});

        };
    }])



    //Service for Get Payment   here using payment_guid
    .service('GetPaymentInfo', ['$resource','baseURL',function($resource,baseURL){
        this.getpaymentinfo = function(payID){
            return $resource(baseURL+'payment/'+payID,{method:'GET'});

        };
    }])

     //Service for Get Fund   here using fund_guid
    .service('GetFundInfo', ['$resource','baseURL',function($resource,baseURL){
        this.getfundinfo = function(fundID){
            return $resource(baseURL+'fund/'+fundID,{method:'GET'});

        };
    }])


     //Service for Get Fund  Transaction  here using fund_transaction_guid
    .service('GetFundTrans', ['$resource','baseURL',function($resource,baseURL){
        this.getfundtrans = function(fundtransID){
            return $resource(baseURL+'fundtrans/'+fundtransID,{method:'GET'});

        };
    }])

     //Service for Get Farm  ID List  here using
    .service('GetFarmIDList', ['$resource','baseURL',function($resource,baseURL){
        this.getfarmidlist = function(){
            return $resource(baseURL+'farmlist/',{method:'GET'});

        };
    }])


      //Service for Get Appropriation   here using approp_guid
    .service('GetAppropInfo', ['$resource','baseURL',function($resource,baseURL){
        this.getappropinfo = function(appropID){
            return $resource(baseURL+'appropriation/'+appropID,{method:'GET'});

        };
    }])

    //Service for Get Application ID`s  here using farm_id
    .service('GetAppID', ['$resource','baseURL',function($resource,baseURL){
        this.getappid = function(farmID){
            return $resource(baseURL+'farmapp/'+farmID,{method:'GET'});

        };
    }])

        //Service for Get Application ID`s  here using farm_id
    .service('GetAppList', ['$resource','baseURL',function($resource,baseURL){
        this.getapplist = function(){
            return $resource(baseURL+'applist',{method:'GET'});

        };
    }])

    //Service for Get Grant   here using grant_guid
    .service('GetGrantInfo', ['$resource','baseURL',function($resource,baseURL){
        this.getgrantinfo = function(grantID){
            return $resource(baseURL+'partnergrant/'+grantID,{method:'GET'});

        };
    }])


      //Service for Get Pool   here using pool_guid
    .service('GetPoolInfo', ['$resource','baseURL',function($resource,baseURL){
        this.getpoolinfo = function(poolID){
            return $resource(baseURL+'competitivepool/'+poolID,{method:'GET'});

        };
    }])


     // services for updating Payment
     .service('UpdatePayment', ['$resource','baseURL', function($resource,baseURL) {

        this.updatepayment = function(){

            return $resource(baseURL+'payment/:guid', null, {'update':{method:'PUT'}});
        };

    }])


   // services for updating Expense
     .service('UpdateExpense', ['$resource','baseURL', function($resource,baseURL) {

        this.updateexpense = function(){

            return $resource(baseURL+'expense/:guid', null, {'update':{method:'PUT'}});
        };

    }])



    //Modal services
    .service('modalService', [ '$log', '$uibModal',  function( $log, $uibModal ) {
        var modalDefaults = {
            backdrop: true,
            keyboard: true,
            modalFade: true,
            templateUrl: 'templates/authadmin/modal.html'
        };

        var modalOptions = {
            closeButtonText: 'Close',
            closeButtonVisible: true,
            actionButtonText: 'OK',
            actionButtonVisible: true,
            headerText: 'Proceed?',
            bodyText: 'Perform this action?'
        };

        this.showModal = function (customModalDefaults, customModalOptions, resultToGet ) {
            if (!customModalDefaults) customModalDefaults = {};
            customModalDefaults.backdrop = 'static';
            if (!resultToGet) resultToGet = {};
            $log.debug("in showModal resultToGet:", resultToGet);
            return this.show(customModalDefaults, customModalOptions, resultToGet );
        };

        this.show = function (customModalDefaults, customModalOptions, resultToGet ) {
            //Create temp objects to work with since we're in a singleton service
            var tempModalDefaults = {};
            var tempModalOptions = {};
            var tmpResultToGet = resultToGet;

            //Map angular-ui modal custom defaults to modal defaults defined in service
            angular.extend(tempModalDefaults, modalDefaults, customModalDefaults);

            //Map modal.html $scope custom properties to defaults defined in service
            angular.extend(tempModalOptions, modalOptions, customModalOptions);

            if (!tempModalDefaults.controller) {
                tempModalDefaults.controller = ('TempModalController', ['$scope', '$uibModalInstance',
                    function ($scope, $uibModalInstance, customModalDefaults) {
                        $scope.resultToGet = tmpResultToGet;
                        $scope.modalOptions = tempModalOptions;
                        $scope.modalOptions.ok = function (resultToGet) {
                            $uibModalInstance.close(resultToGet);
                        };
                        $scope.modalOptions.close = function () {
                            $uibModalInstance.dismiss('cancel');
                        };
                }]);
            }
            return $uibModal.open(tempModalDefaults).result;
        };
    }])

    .service('modalMessageService', [ '$log', 'modalService', '$uibModal',  function( $log, modalService, $uibModal ) {
        this.showMessage = function ( heading, message ) {
            var modalOptions = {
                actionButtonText: 'Close',
                closeButtonVisible: false,
                headerText: heading,
                bodyText: message
            };
            modalService.showModal({}, modalOptions, {})
                // We don't care about the response
                .then( function(response){}, function(){});
        };

    }]);