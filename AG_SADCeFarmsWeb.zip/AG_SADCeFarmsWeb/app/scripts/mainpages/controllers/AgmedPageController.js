(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    .controller('AgmedPageController', ['$scope', '$state', '$log','modalService','handleError', '$uibModal','GetAgmediation','modalMessageService', function($scope, $state, $log,modalService,handleError, $uibModal, GetAgmediation, modalMessageService) {
        $scope.agmediationheader = "";
        $scope.agmediationsection1 = "";
        $scope.agmediationsection2 = "";
        $scope.agmediationsection3 = "";
        $scope.agmediationfooter = "";

        GetAgmediation.getContent().query()
            .$promise.then(
            function(response){
                var sectioncontent = {};
                _.each(response, function(item){
                    sectioncontent[item.content_id] = item;
                });
                $scope.sectioncontent = sectioncontent;
                $scope.agmediationheader = sectioncontent.agmediationheader.content_markdown;
                $scope.agmediationsection1 = sectioncontent.agmediationsection1.content_markdown;
                $scope.agmediationsection2 = sectioncontent.agmediationsection2.content_markdown;
                $scope.agmediationsection3 = sectioncontent.agmediationsection3.content_markdown;
                $scope.agmediationfooter = sectioncontent.agmediationfooter.content_markdown;
                //$scope.loading_data = false;
//                console.log('agmediationheader',sectioncontent.agmediationheader.content_markdown);
//                console.log('agmediationsection1',sectioncontent.agmediationsection1.content_markdown);
//                console.log('aboutsection2',sectioncontent.aboutsection2.content_markdown);
//                console.log('aboutsection3',sectioncontent.aboutsection3.content_markdown);
//                console.log('aboutfooter',sectioncontent.aboutfooter.content_markdown);
                //$scope.$apply()
            },
            function(response) {
                // If there is an error getting user statuses from datbase,
                // this will have an error as well.  If so, put the message in the error modal.
                //$log.debug("AFTER GETING ERROR FROM DETAILS:", $scope.partnerdetails);
//                $log.debug("Error: "+response.status + " " + response.statusText);
//                modalMessageService.showMessage( "Error:", response.status + " " +
//                    response.statusText + '. Please contact ' + agSupportEmail);
                handleError.notify(response,'');

            }
        );



        $scope.editcontent = function (contentid) {
                $scope.edititem = $scope.sectioncontent[contentid];
                var modalInstance = $uibModal.open({
                    templateUrl: 'views/mainpages/editcontent.html',
                    controller: 'editcontentCtrlr',
                    size: 'md',
                    backdrop: 'static',
                    scope: $scope
                });

                modalInstance.result.then(function (selectedItem) {
                    console.log('here!');
                }, function () {
                    console.log('Modal dismissed at: ' + new Date());
                });

        };


    }])
.controller('editcontentCtrlr', function ($scope, $rootScope, $uibModal, $filter, $window, $uibModalInstance, GetAgmediation, $state, modalMessageService) {
    $scope.saveMarkdown = function () {
        GetAgmediation.updateItem().update({itemid:$scope.edititem.content_id},$scope.edititem)
            .$promise.then(
            function(response){
                $state.reload();
                $uibModalInstance.dismiss();
                modalMessageService.showMessage( "Success:","Content Edited Successfully");
            },
            function(response) {

                if (response.data.result === 'error' ) {
                    modalMessageService.showMessage( "Error:", response.data.message);
                } else {
                    modalMessageService.showMessage( "Error:", "An error occurred. ");
                }
                $state.reload();
            }
        );
    };
    $scope.editCancel = function () {
        console.log('Modal cancelled at: ' + new Date());
        $uibModalInstance.dismiss('Cancel');
        $state.reload();

    };
});



