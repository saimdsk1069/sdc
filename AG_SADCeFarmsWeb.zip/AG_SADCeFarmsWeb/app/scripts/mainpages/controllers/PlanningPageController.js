(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
//    .directive('treanGraph', function () {
//        return {
//            restrict: 'E',
//            scope: {
//                data: '=data'
//            },
//            template: '<div class="chart" id="example-graph"></div>'
//            //link: linkFn
//        };
//
//        //function linkFn(scope, element, attrs, ctrlFn) {
//        //    var tree = new Treant(scope.data);
//        //}
//    })


    .controller('PlanningPageController', ['$scope', '$state', '$log','modalService','handleError', '$uibModal','GetPlanning','modalMessageService', function($scope, $state, $log,modalService,handleError, $uibModal, GetPlanning, modalMessageService) {
        $scope.planningheader = "";
        $scope.planningsection1 = "";
        $scope.planningsection2 = "";
        $scope.planningsection3 = "";
        $scope.planningfooter = "";

//        $scope.graph = {
//            chart: {
//                container: "#example-graph"
//            },
//
//            nodeStructure: {
//                text: { name: "This Farm" },
//                children: [
//                    {
//                        text: { name: "First Farm child" }
//                    },
//                    {
//                        text: { name: "Second Farm child" }
//                    }
//                ]
//            }
//        };
        //$scope.$apply()
        GetPlanning.getContent().query()
            .$promise.then(
            function(response){
                var sectioncontent = {};
                _.each(response, function(item){
                    sectioncontent[item.content_id] = item;
                });
                $scope.sectioncontent = sectioncontent;
                $scope.planningheader = sectioncontent.planningheader.content_markdown;
                $scope.planningsection1 = sectioncontent.planningsection1.content_markdown;
                $scope.planningsection2 = sectioncontent.planningsection2.content_markdown;
                $scope.planningsection3 = sectioncontent.planningsection3.content_markdown;
                $scope.planningfooter = sectioncontent.planningfooter.content_markdown;
                //$scope.loading_data = false;
//                console.log('planningheader',sectioncontent.planningheader.content_markdown);
//                console.log('planningsection1',sectioncontent.planningsection1.content_markdown);
//                console.log('aboutsection2',sectioncontent.aboutsection2.content_markdown);
//                console.log('aboutsection3',sectioncontent.aboutsection3.content_markdown);
//                console.log('aboutfooter',sectioncontent.aboutfooter.content_markdown);
                //$scope.$apply()
            },
            function(response) {
                // If there is an error getting user statuses from datbase,
                // this will have an error as well.  If so, put the message in the error modal.
                //$log.debug("AFTER GETING ERROR FROM DETAILS:", $scope.partnerdetails);
//                $log.debug("Error: "+response.status + " " + response.statusText);
//                modalMessageService.showMessage( "Error:", response.status + " " +
//                    response.statusText + '. Please contact ' + agSupportEmail);
                handleError.notify(response,'');
            }
        );



        $scope.editcontent = function (contentid) {
                $scope.edititem = $scope.sectioncontent[contentid];
                var modalInstance = $uibModal.open({
                    templateUrl: 'views/mainpages/editcontent.html',
                    controller: 'editcontentCtrlr',
                    size: 'md',
                    backdrop: 'static',
                    scope: $scope
                });

                modalInstance.result.then(function (selectedItem) {
                    console.log('here!');
                }, function () {
                    console.log('Modal dismissed at: ' + new Date());
                });

        };


    }])
.controller('editcontentCtrlr', function ($scope, $rootScope, $uibModal, $filter, $window, $uibModalInstance, GetPlanning, $state, modalMessageService) {
    $scope.saveMarkdown = function () {
        GetPlanning.updateItem().update({itemid:$scope.edititem.content_id},$scope.edititem)
            .$promise.then(
            function(response){
                $state.reload();
                $uibModalInstance.dismiss();
                modalMessageService.showMessage( "Success:","Content Edited Successfully");
            },
            function(response) {

                if (response.data.result === 'error' ) {
                    modalMessageService.showMessage( "Error:", response.data.message);
                } else {
                    modalMessageService.showMessage( "Error:", "An error occurred. ");
                }
                $state.reload();
            }
        );
    };
    $scope.editCancel = function () {
        console.log('Modal cancelled at: ' + new Date());
        $uibModalInstance.dismiss('Cancel');
        $state.reload();

    };
});



