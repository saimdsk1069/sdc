(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    .controller('SoilPageController', ['$scope', '$state', '$log','modalService','handleError', '$uibModal','GetSoilwater','modalMessageService', function($scope, $state, $log,modalService,handleError, $uibModal, GetSoilwater, modalMessageService) {
        $scope.soilwaterheader = "";
        $scope.soilwatersection1 = "";
        $scope.soilwatersection2 = "";
        $scope.soilwatersection3 = "";
        $scope.soilwaterfooter = "";

        GetSoilwater.getContent().query()
            .$promise.then(
            function(response){
                var sectioncontent = {};
                _.each(response, function(item){
                    sectioncontent[item.content_id] = item;
                });
                $scope.sectioncontent = sectioncontent;
                $scope.soilwaterheader = sectioncontent.soilwaterheader.content_markdown;
                $scope.soilwatersection1 = sectioncontent.soilwatersection1.content_markdown;
                $scope.soilwatersection2 = sectioncontent.soilwatersection2.content_markdown;
                $scope.soilwatersection3 = sectioncontent.soilwatersection3.content_markdown;
                $scope.soilwaterfooter = sectioncontent.soilwaterfooter.content_markdown;
                //$scope.loading_data = false;
//                console.log('soilwaterheader',sectioncontent.soilwaterheader.content_markdown);
//                console.log('soilwatersection1',sectioncontent.soilwatersection1.content_markdown);
//                console.log('aboutsection2',sectioncontent.aboutsection2.content_markdown);
//                console.log('aboutsection3',sectioncontent.aboutsection3.content_markdown);
//                console.log('aboutfooter',sectioncontent.aboutfooter.content_markdown);
                //$scope.$apply()
            },
            function(response) {
                // If there is an error getting user statuses from datbase,
                // this will have an error as well.  If so, put the message in the error modal.
                //$log.debug("AFTER GETING ERROR FROM DETAILS:", $scope.partnerdetails);
//                $log.debug("Error: "+response.status + " " + response.statusText);
//                modalMessageService.showMessage( "Error:", response.status + " " +
//                    response.statusText + '. Please contact ' + agSupportEmail);
                handleError.notify(response,'');
            }
        );



        $scope.editcontent = function (contentid) {
                $scope.edititem = $scope.sectioncontent[contentid];
                var modalInstance = $uibModal.open({
                    templateUrl: 'views/mainpages/editcontent.html',
                    controller: 'editcontentCtrlr',
                    size: 'md',
                    backdrop: 'static',
                    scope: $scope
                });

                modalInstance.result.then(function (selectedItem) {
                    console.log('here!');
                }, function () {
                    console.log('Modal dismissed at: ' + new Date());
                });

        };


    }])
.controller('editcontentCtrlr', function ($scope, $rootScope, $uibModal, $filter, $window, $uibModalInstance, GetSoilwater, $state, modalMessageService) {
    $scope.saveMarkdown = function () {
        GetSoilwater.updateItem().update({itemid:$scope.edititem.content_id},$scope.edititem)
            .$promise.then(
            function(response){
                $state.reload();
                $uibModalInstance.dismiss();
                modalMessageService.showMessage( "Success:","Content Edited Successfully");
            },
            function(response) {

                if (response.data.result === 'error' ) {
                    modalMessageService.showMessage( "Error:", response.data.message);
                } else {
                    modalMessageService.showMessage( "Error:", "An error occurred. ");
                }
                $state.reload();
            }
        );
    };
    $scope.editCancel = function () {
        console.log('Modal cancelled at: ' + new Date());
        $uibModalInstance.dismiss('Cancel');
        $state.reload();

    };
});



