(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    .constant("baseURL", "/AG_SADCeFarms/")

    //service for getting the About Page dynamic content
    .service('GetAbout', ['$resource','baseURL',function($resource,baseURL){
        this.getContent = function(){
            console.log('getcontent fired');
            return $resource(baseURL+'pagecontent?content_page=about',{method:'GET'});
        };
        this.updateItem = function(){
            console.log('updateitem fired');
            return $resource(baseURL+'pagecontent?content_id=:itemid', null, {'update':{method:'PUT'}});
        };
    }])

     .service('GetPlanning', ['$resource','baseURL',function($resource,baseURL){
        this.getContent = function(){
            console.log('getcontent fired');
            return $resource(baseURL+'pagecontent?content_page=planning',{method:'GET'});
        };
        this.updateItem = function(){
            console.log('updateitem fired');
            return $resource(baseURL+'pagecontent?content_id=:itemid', null, {'update':{method:'PUT'}});
        };
    }])

     .service('GetAcquisition', ['$resource','baseURL',function($resource,baseURL){
        this.getContent = function(){
            console.log('getcontent fired');
            return $resource(baseURL+'pagecontent?content_page=acquisition',{method:'GET'});
        };
        this.updateItem = function(){
            console.log('updateitem fired');
            return $resource(baseURL+'pagecontent?content_id=:itemid', null, {'update':{method:'PUT'}});
        };
    }])

     .service('GetStewardship', ['$resource','baseURL',function($resource,baseURL){
        this.getContent = function(){
            console.log('getcontent fired');
            return $resource(baseURL+'pagecontent?content_page=stewardship',{method:'GET'});
        };
        this.updateItem = function(){
            console.log('updateitem fired');
            return $resource(baseURL+'pagecontent?content_id=:itemid', null, {'update':{method:'PUT'}});
        };
    }])

     .service('GetRtf', ['$resource','baseURL',function($resource,baseURL){
        this.getContent = function(){
            console.log('getcontent fired');
            return $resource(baseURL+'pagecontent?content_page=righttofarm',{method:'GET'});
        };
        this.updateItem = function(){
            console.log('updateitem fired');
            return $resource(baseURL+'pagecontent?content_id=:itemid', null, {'update':{method:'PUT'}});
        };
    }])

     .service('GetSoilwater', ['$resource','baseURL',function($resource,baseURL){
            this.getContent = function(){
                console.log('getcontent fired');
                return $resource(baseURL+'pagecontent?content_page=soilwater',{method:'GET'});
            };
            this.updateItem = function(){
                console.log('updateitem fired');
                return $resource(baseURL+'pagecontent?content_id=:itemid', null, {'update':{method:'PUT'}});
            };
        }])

 .service('GetAgmediation', ['$resource','baseURL',function($resource,baseURL){
        this.getContent = function(){
            console.log('getcontent fired');
            return $resource(baseURL+'pagecontent?content_page=agmediation',{method:'GET'});
        };
        this.updateItem = function(){
            console.log('updateitem fired');
            return $resource(baseURL+'pagecontent?content_id=:itemid', null, {'update':{method:'PUT'}});
        };
    }]);








