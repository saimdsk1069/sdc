(function () {
    'use strict';
}());
angular.module('agSADCeFarms')
        .controller('MyAccountController', ['$scope', '$state', '$log', 'agSupportEmail', 'MyDashboardservices','handleError', '$sce', '$http', '$window', 'modalService', 'modalMessageService', '$uibModal', '$rootScope', function ($scope, $state, $log, agSupportEmail, MyDashboardservices,handleError, $sce, $http, $window, modalService, modalMessageService, $uibModal, $rootScope) {
                $rootScope.getAccountInfo = function () {
                    MyDashboardservices.fetchAccountInfo().then(
                            function (response) {
                                $rootScope.MyDUserInfo = response.userinfo;
                            },
                            function (errResponse) {
                                handleError.notify(errResponse,'');
//                                toastr.clear();
//                                toastr.error('Bad Connectivity / Server Down', 'Error while fetching myDashboard Account Info');
                            }
                    );
                };
                $scope.email = agSupportEmail;
                $scope.editUserInfo = {};
                $scope.editable = false;
                $rootScope.getAccountInfo();

                $scope.submitMyDUserInfo = function () {
                    //console.log($scope.editUserInfo);
                    if ($scope.editable) {
                        MyDashboardservices.putAccountInfo($scope.editUserInfo).then(
                                function (response) {
                                    toastr.clear();
                                    toastr.success('Success', 'User Info updated Successfully');
                                    $rootScope.getAccountInfo();
                                },
                                function (errResponse) {
                                    toastr.clear();
                                    toastr.error('Bad Connectivity / Server Down', 'Error while fetching myDashboard Account Info');
                                }
                        );
                    }
                    $scope.editable = !$scope.editable;
                };
            }]);