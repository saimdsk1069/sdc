(function() {
    'use strict';
}());

angular.module('agSADCeFarms')
.constant("baseURL", "/AG_SADCeFarms/")
.factory('MyDashboardservices', ['$http','baseURL', '$q', function($http, baseURL, $q) {

      return {
             fetchToDos: function () {
                        return $http.get(baseURL+'mytodos')
                                .then(
                                        function (response) {
                                            return response.data;
                                        }
                                );
                    },
             fetchAccountInfo: function() {
                return $http.get(baseURL+'myaccount')
                        .then(
                        function(response) {
                            return response.data;
                        }
                );
            },
             putAccountInfo: function (putData) {
                        var URL = baseURL + 'userinfo';
                        return $http.put(URL, putData)
                                .then(
                                        function (response) {
                                            return response;
                                        },
                                        function (errResponse) {
                                            console.error('Error while Submitting User Account Info');
                                            //return $q.reject(errResponse);
                                        }
                                );
                    },
             fetchApplication: function () {
                        return $http.get(baseURL+'myapps')
                                .then(
                                        function (response) {
                                            return response.data;
                                        }
                                );
                    },
           fetchNotifications: function () {

                        return $http.get(baseURL+'notification')

                                .then(
                                        function (response) {
                                            return response.data;
                                        }
                                );
                    },
           delDashboardNotification: function (NotifyID) {
                        var url = baseURL + 'notification/' + NotifyID;
                        return $http({
                            method: 'DELETE',
                            url: url
                        }).then(
                                function (response) {
                                    return response.data;
                                },
                                function (errResponse) {
                                    console.error('Error while Deleting Notification');
                                    //return $q.reject(errResponse);
                                }
                        );
                    }
                };
            }]);
