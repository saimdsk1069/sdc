(function () {
    'use strict';
}());
angular.module('agSADCeFarms')
        .controller('MyNotificationsController', ['$scope', '$state', '$log', 'MyDashboardservices','handleError','$sce', '$http', '$window', 'modalService', 'modalMessageService', '$uibModal', '$rootScope', function ($scope, $state, $log, MyDashboardservices,handleError, $sce, $http, $window, modalService, modalMessageService, $uibModal, $rootScope) {

                $rootScope.getNotifications = function () {
                    $scope.loading_data=true;
                    MyDashboardservices.fetchNotifications().then(
                            function (response) {
                                $rootScope.gridMyDNotify.data = response;
                                 $scope.loading_data=false;
                            },
                            function (errResponse) {
                               handleError.notify(errResponse,'');
                            }
                    );
                };

                var delBTNTemplate = "<div class='ui-grid-cell-contents'> <button class='btn btn-danger' ng-click='grid.appScope.deleteMyDNotify(row.entity.notify_guid);$event.stopPropagation();' style='padding:2px 5px;margin:-4px auto 0'><i class='fa fa-trash-o'></i></button> </div>";
                var appLink = "<div class='ui-grid-cell-contents'> <a ng-click='$event.stopPropagation();' href='#/application/{{row.entity.application_id}}'><u>{{row.entity.application_id}}</u></a> </div>";
//                var appLink = "<div class='ui-grid-cell-contents'> <a class='myDAppLink' href='#application/{{row.entity.application_id}}'><u>{{row.entity.application_id}}</u></a> </div>";
                var farmLink = "<div class='ui-grid-cell-contents'><a ng-click='$event.stopPropagation();' href='#/farm/{{row.entity.farm_id}}'><u>{{row.entity.farm_id}}</u></a> </div>";
                $rootScope.gridMyDNotify = {
                    paginationPageSizes: false,
                    enableFiltering: true,
                    enableRowSelection: true,
                    enableColumnResizing: true,
                    multiSelect: false,
                    resizable: true,
                    enableFullRowSelection: true,
                    enableRowHeaderSelection: false,
                    paginationPageSize: 25,
                    enableGridMenu: true,
                    exporterCsvFilename: 'Notifications.csv',
                    exporterPdfDefaultStyle: {fontSize: 12},
                    exporterMenuVisibleData : true,
                    exporterPdfTableStyle: {margin: [60, 60, 60, 60]},
                    exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
                    exporterPdfHeader: { text: "Notifications Details", style: 'headerStyle' },
                    exporterPdfFooter: function ( currentPage, pageCount ) {
                      return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
                    },
                    exporterPdfCustomFormatter: function ( docDefinition ) {
                      docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
                      docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
                      return docDefinition;
                    },
                    exporterPdfOrientation: 'landscape',
                    exporterPdfPageSize: 'LETTER',
                    exporterPdfMaxGridWidth: 500,
                    exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
                    exporterExcelFilename: 'Notifications.xlsx',
                    exporterExcelSheetName: 'Sheet1',
                    appScopeProvider: $scope,
                    rowTemplate: '<div ng-click="grid.appScope.viewMyNotification(row)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell " ng-class="col.colIndex()" ui-grid-cell></div>',
                    columnDefs: [
                        {name: 'notify_text', displayName: 'Notification Info', cellTooltip: true},
                        {name: 'farm_id', displayName: 'Farm ID', width: '200', cellTooltip: true, cellTemplate:farmLink},
                        {name: 'application_id', displayName: 'Application ID', width: '200', cellTooltip: true, cellTemplate:appLink},
                        {name: 'created_date', displayName: 'Created Date', cellTooltip: true, width: '100', cellFilter: 'date:"MMM dd,y"'},
                        {name: 'notify_guid', displayName: '', width: '60', cellTooltip: false, enableFiltering: false, enableSorting: false, cellTemplate: delBTNTemplate}
                    ]
                };

                $rootScope.gridMyDNotify.onRegisterApi = function (gridMyDNotifyAPI) {
                    $rootScope.gridMyDNotify = gridMyDNotifyAPI;
                };

                $rootScope.getNotifications();

                $scope.deleteMyDNotify = function (delNotifyGUID) {

                    MyDashboardservices.delDashboardNotification(delNotifyGUID).then(
                            function (response) {
                                $rootScope.getNotifications();
                                toastr.clear();
                                toastr.success('Success', 'Notification Deleted Successfully');
                            },
                            function (errResponse) {
                                toastr.clear();
                                toastr.error('Bad Connectivity / Server Down', 'Error while deleting Notification');
                            }
                    );
                };

                $scope.viewMyNotification = function (row) {
                    console.log(row.entity.notify_guid);

                    var modalInstance = $uibModal.open({
                        templateUrl: 'viewNotification.html',
                        controller: 'viewNotificationCtrl',
                        size: 'md',
                        backdrop: 'static',
                        resolve: {
                            notifyOBJ: function () {
                                return row.entity;
                            }
                        }
                    });

                    modalInstance.result.then(function (selectedItem) {
                        //$scope.selected = selectedItem;
                    }, function () {
                        console.log('Modal dismissed at: ' + new Date());
                    });
                };

            }]).controller('viewNotificationCtrl', function (notifyOBJ, $scope, $rootScope, $uibModal, $filter, $window, $uibModalInstance, MyDashboardservices, $state, modalMessageService, modalService) {


                $scope.notificationDetails = notifyOBJ;

    $scope.deleteMyDNotify = function (delNotifyGUID) {

        MyDashboardservices.delDashboardNotification(delNotifyGUID).then(
                function (response) {
                    toastr.clear();
                    toastr.success('Success', 'Notification Deleted Successfully');
                    $uibModalInstance.dismiss();
                    $rootScope.getNotifications();
                },
                function (errResponse) {
                    toastr.clear();
                    toastr.error('Bad Connectivity / Server Down', 'Error while deleting Notification');
                }
        );
    };

    $scope.cancelViewNotify = function () {
        $uibModalInstance.dismiss();
    };


});
