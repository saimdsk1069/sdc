angular.module('agSADCeFarms')
.controller('searchController', ['$scope','searchFactory','AuthService', '$state','$filter',
    '$httpParamSerializer','$stateParams','getTagTypes','modalService','$window','$log',
    function($scope, SF, AuthService,$state, $filter, $httpParamSerializer,$stateParams, getTagTypes, modalService, $window,$log){

    var SrchCtrl = this;

    $log.debug("++++++++<<<<<<<<<<<<>>>>>>>>>>>>>>> Starting search controller.");
    $scope.ui_components = {
        'ui_search_auth': false
    };

    var disable_ui_components = function() {
        // reset all ui_components values to false
        angular.forEach( Object.keys($scope.ui_components), function(comp_key) {
            //$log.debug("Setting", comp_key, "to false");
            $scope.ui_components[comp_key] = false;
        });
    };

    var setUIValues = function(){
        var ui_access = AuthService.authResponse.ui_access;
        angular.forEach( ui_access, function(comp_key) {
                if($scope.ui_components.hasOwnProperty(comp_key)){
                      $scope.ui_components[comp_key] = true;
                }
            });
    };

    // Container for all query statuses
    $scope.query_search_status = [];

    // Variable to hold status of drop down queries for farm search.  The entries get removed when an ajax
    // call completes by making a call to remove_farmsearch_status_entry.
    $scope.farmsearch_query_status = [
     {query: 'preservationTypes'},
     {query: 'partners'},
     {query: 'allCountyMun'},
     {query: 'counties'},
     {query: 'allAvailableTags'}
    ];

    // Variable to hold status of drop down queries for application search.  The entries get removed when an ajax
    // call completes by making a call to remove_query_status_entry.
    $scope.appsearch_query_status = [
        {query: 'programTypes'},
        {query: 'applicationTypes'}
    ];

    // Remove an entry from the query search status object
    var remove_query_status_entry = function(element_to_remove){
     //$log.debug("/// Removing ",element_to_remove, "from query search status");
     $scope.query_search_status = $filter('filter')($scope.query_search_status, {query: '!'+element_to_remove});
    };

    var monitor_search_queries = function(){
        $scope.$watchCollection('query_search_status', function(){
            if ($scope.query_search_status.length == 0) {
                //Turn off loading data message after all have completed.
                $scope.loading_data = false;
            }
        });
    };

     var setup_query_status_monitoring = function(){
         $scope.query_search_status = $scope.query_search_status.concat($scope.farmsearch_query_status);
         if($scope.ui_components.ui_search_auth) {
             $scope.query_search_status = $scope.query_search_status.concat($scope.appsearch_query_status);
         }
         $log.debug("QUERY STATUS:",$scope.query_search_status);
         monitor_search_queries();
     };


    var onLoad = function(){
        // Turn on loading image.  It will get turned off in the watch collection for farmsearch_query_status
        $scope.loading_data = true;
        SrchCtrl.searchFarmByFilters = {};
        if($scope.ui_components.ui_search_auth){
            SF.getProgramType().then(function(response){
                remove_query_status_entry('programTypes');
                SrchCtrl.programTypes = response.data;
                SrchCtrl.programTypes = $filter('orderBy')(SrchCtrl.programTypes, 'program_name');
            }, function(response){
                remove_query_status_entry('programTypes');
                console.log(response);
            });

            SF.getApplicationType().then(function (response) {
                remove_query_status_entry('applicationTypes');
                SrchCtrl.applicationTypes = response.data;
                SrchCtrl.applicationTypes = $filter('orderBy')(SrchCtrl.applicationTypes, 'application_type_label');
            }, function (response) {
                remove_query_status_entry('applicationTypes');
                console.log(response);
            });
        }

        SF.getAppList().then(function(response){
            SrchCtrl.appLists = response.data;
        }, function(response){
            console.log(response);
        });

        SF.getPreservationType().then(function(response){
            remove_query_status_entry('preservationTypes');
            SrchCtrl.preservationTypes = response.data;
        }, function(response){
            remove_query_status_entry('preservationTypes');
            console.log(response);
        });

        SF.getPartner().then(function(response){
            remove_query_status_entry('partners');
            SrchCtrl.partners = response.data;
            SrchCtrl.partners = $filter('orderBy')(SrchCtrl.partners, 'partner_label');
        }, function(response){
            remove_query_status_entry('partners');
            console.log(response);
        });


        SF.getCountyMun().then(function(response){
            remove_query_status_entry('allCountyMun');
            SrchCtrl.allCountyMun = response.data;
        }, function(response){
            remove_query_status_entry('allCountyMun');
            console.log(response);
        });

        SF.getCounty().then(function(response){
            remove_query_status_entry('counties');
            SrchCtrl.counties = response.data;
        }, function(response){
            remove_query_status_entry('counties');
            console.log(response);
        });
        getTagTypes.getTagTypes().then(function(resp){
            remove_query_status_entry('allAvailableTags');
            if(resp.status==200){
                SrchCtrl.allAvailableTags = resp.data;
            }else{
                console.log(resp);
                toastr.error('Error occured while fectching tags');
            }
        }, function(){
            remove_query_status_entry('allAvailableTags');
            if(resp.status==200){
                SrchCtrl.allAvailableTags = resp.data;
            }else{
                console.log(resp);
                toastr.error('Error occured while fetching tags');
            }
        });

        SrchCtrl.showAppResults = false;
        SrchCtrl.showFarmResults = false;

        var filterObjs = $stateParams.filterObjs;

        if(filterObjs) {
            //Fill the values from the state params obj if exists.
            if('searchAppByFilters' in filterObjs) {
                SrchCtrl.searchAppByFilters = filterObjs.searchAppByFilters;
            }

            if('searchFarmByFilters' in filterObjs) {
                SrchCtrl.searchFarmByFilters = filterObjs.searchFarmByFilters;
            }

            if('searchFormById' in filterObjs) {
                SrchCtrl.searchFormById = filterObjs.searchFormById;
            }
        }
    };

    if ( AuthService.isAuthenticated() ) {
        console.log("++++++User is authenticated");
        console.log("++++++Users ui access:", AuthService.getUserUIAccess());
        setUIValues();
        setup_query_status_monitoring();
        onLoad();
    } else {
        disable_ui_components();
        console.log("++++++User is not authenticated, calling AuthService");
        AuthService.authenticate().then(
            function(response){
                $log.debug("****AuthService.authenticate() success", response);
                AuthService.setAuthenticateResponse(response);
                setUIValues();
                $log.debug("*****ui_componenents are now:",$scope.ui_components);
                setup_query_status_monitoring();
                onLoad();
            },
            function(response) {
                $log.debug("****AuthService.authenticate() failed");
                disable_ui_components();
                modalMessageService.showMessage( "Error:", "An error occurred while authenticating. Please contact " +
                    agSupportEmail + " and mention this message.");
            }
        );
    }

    SrchCtrl.onCountySelection = function(selectedCounty){
        //console.log(selectedCounty)
        var counties = SrchCtrl.allCountyMun.length;
        for(var i=0; i<counties;i++){
            if(JSON.parse(SrchCtrl.searchFarmByFilters.county).county_code == SrchCtrl.allCountyMun[i].county_code){
                SrchCtrl.countyMun = SrchCtrl.allCountyMun[i].munilist;
                SrchCtrl.countyMun = $filter('orderBy')(SrchCtrl.countyMun, 'name');
                break;
            }
        }
    };
    //farm id
    SrchCtrl.goToForm = function(){
        var filters = {};
        filters.viewType ="farmResults";
        if(SrchCtrl.searchFormById.selectedFarm.length>0){
            $scope.loading_data = true;
            filters.farm_id = SrchCtrl.searchFormById.selectedFarm;
            SrchCtrl.validateAndRouteToFarm(filters);
        }else{
            toastr.warning('Enter the farmId');
        }

        // $state.go('app.farm.information', {farm_id: farmId});
    };
    //all filters farms
    SrchCtrl.validateAndRouteToFarm = function(filters){
        var paramsStr = $httpParamSerializer(filters);
        // route only if results exist.
        SF.getSearchedFarm(paramsStr).then(function(resp){
            if(resp.data.length>0){
                var filtersAndObjs = {
                    filters: filters,
                    filterObjs: SrchCtrl.getSelectedFilters()
                };
                $state.go('app.searchResults', {filtersAndObjs: filtersAndObjs});
                $scope.loading_data = false;
            }else{
                $scope.loading_data = false;
                toastr.warning("Your search returned no matching farms");
            }
        }, function(resp){
            $scope.loading_data = false;
            toastr.error('Your Farm ID is invalid.');
        });
    };
    //application id
    SrchCtrl.goToApplication = function(){
        var filters = {};
        filters.viewType ="appResults";
        if(SrchCtrl.searchApplication.application.length>0){
            $scope.loading_data = true;
            filters.application_id = SrchCtrl.searchApplication.application;
            // $state.go('app.searchResults', {filters: filters});
            SrchCtrl.validateAndRouteToApp(filters);
        }else{
            toastr.warning('Enter the application Id');
        }
    };
    //all filters apps
    SrchCtrl.validateAndRouteToApp = function(filters){
        var paramsStr = $httpParamSerializer(filters);

        SF.getSearchedApp(paramsStr).then(function(resp){
            if(resp.data.length>0){
                var filtersAndObjs = {
                    filters: filters,
                    filterObjs: SrchCtrl.getSelectedFilters()
                };
                $state.go('app.searchResults', {filtersAndObjs: filtersAndObjs});
                $scope.loading_data = false;
            }else{
                $scope.loading_data = false;
                toastr.warning("Your search returned no matching applications");
            }
        }, function(){
            $scope.loading_data = false;
            toastr.warning('Your Application ID is invalid. ');
        });
    };

    SrchCtrl.searchFarm = function(){
        var filters = {};
        filters.viewType = "farmResults";
        if(SrchCtrl.searchFormById && SrchCtrl.searchFormById.selectedFarm &&  SrchCtrl.searchFormById.selectedFarm.length>0){
            filters.farm_id = SrchCtrl.searchFormById.selectedFarm;
        }
        if(SrchCtrl.searchFarmByFilters.farmName && SrchCtrl.searchFarmByFilters.farmName.length>0){
            filters.farm_name = SrchCtrl.searchFarmByFilters.farmName;
        }
        if(SrchCtrl.searchFarmByFilters.partner){
            filters.partner = JSON.parse(SrchCtrl.searchFarmByFilters.partner).partner_guid;
        }
        if(SrchCtrl.searchFarmByFilters.county){
            filters.county =JSON.parse( SrchCtrl.searchFarmByFilters.county).county_code;
        }
        if(SrchCtrl.searchFarmByFilters.block && SrchCtrl.searchFarmByFilters.block.length>0){
            filters.block = SrchCtrl.searchFarmByFilters.block;
        }
        if(SrchCtrl.searchFarmByFilters.address && SrchCtrl.searchFarmByFilters.address.length>0){
            filters.address = SrchCtrl.searchFarmByFilters.address;
        }
        if(SrchCtrl.searchFarmByFilters.municipality){
            filters.municipality = JSON.parse(SrchCtrl.searchFarmByFilters.municipality).muni_code;
        }
        if(SrchCtrl.searchFarmByFilters.preservationStatus && SrchCtrl.searchFarmByFilters.preservationStatus.length>0){
            filters.status_preserved_desc = SrchCtrl.searchFarmByFilters.preservationStatus;
        }
        if(SrchCtrl.searchFarmByFilters.lot && SrchCtrl.searchFarmByFilters.lot.length>0){
            filters.lot = SrchCtrl.searchFarmByFilters.lot;
        }
         if(SrchCtrl.searchFarmByFilters.landowner_first && SrchCtrl.searchFarmByFilters.landowner_first.length>0){
            filters.landowner_first = SrchCtrl.searchFarmByFilters.landowner_first;
        }
        if(SrchCtrl.searchFarmByFilters.landowner_last && SrchCtrl.searchFarmByFilters.landowner_last.length>0){
            filters.landowner_last = SrchCtrl.searchFarmByFilters.landowner_last;
        }
        if(SrchCtrl.searchFarmByFilters.SelectedTags && SrchCtrl.searchFarmByFilters.SelectedTags.length>0){
            filters.tags = SrchCtrl.searchFarmByFilters.SelectedTags;
            console.log('tags',SrchCtrl.searchFarmByFilters.SelectedTags);
        }

        $scope.loading_data = true;
        SrchCtrl.clearFarmFilters();
        SrchCtrl.validateAndRouteToFarm(filters);
    };

    SrchCtrl.searchApplication = function(){
        var filters = {};
        filters.viewType ="appResults";
        if(SrchCtrl.searchAppByFilters && SrchCtrl.searchAppByFilters.farm && SrchCtrl.searchAppByFilters.farm.length>0){
            filters.farm_id = SrchCtrl.searchAppByFilters.farm;
        }
        if(SrchCtrl.searchAppByFilters.partner){
            filters.partner = JSON.parse(SrchCtrl.searchAppByFilters.partner).partner_guid;
        }
        if(SrchCtrl.searchAppByFilters.applicationType){
            filters.application_type = JSON.parse( SrchCtrl.searchAppByFilters.applicationType).application_type_guid;
        }
        if(SrchCtrl.searchAppByFilters.year && SrchCtrl.searchAppByFilters.year.length>0){
            filters.year = SrchCtrl.searchAppByFilters.year;
        }
        if(SrchCtrl.searchAppByFilters.programType){
            filters.program_type= JSON.parse( SrchCtrl.searchAppByFilters.programType).program_type_guid;
        }

        $scope.loading_data = true;
        SrchCtrl.clearAppFilters();
        SrchCtrl.validateAndRouteToApp(filters);
    };

     SrchCtrl.clearFarmFilters = function() {
         SrchCtrl.searchFarmByFilters.farmName = "";
         SrchCtrl.searchFormById = "";
         SrchCtrl.searchFarmByFilters.partner = "";
         SrchCtrl.searchFarmByFilters.landowner_first = "";
         SrchCtrl.searchFarmByFilters.landowner_last = "";
         SrchCtrl.searchFarmByFilters.SelectedTags = "";
         SrchCtrl.searchFarmByFilters.county = "";
         SrchCtrl.searchFarmByFilters.block = "";
         SrchCtrl.searchFarmByFilters.address = "";
         SrchCtrl.searchFarmByFilters.municipality = "";
         SrchCtrl.countyMun = [];
         SrchCtrl.searchFarmByFilters.preservationStatus = "";
         SrchCtrl.searchFarmByFilters.lot = "";
         SrchCtrl.farmFilterFields.$setPristine();
     };
     SrchCtrl.clearAppFilters = function() {
         SrchCtrl.searchAppByFilters = "";
         SrchCtrl.searchAppByFilters.partner = "";
         SrchCtrl.searchAppByFilters.applicationType = "";
         SrchCtrl.searchAppByFilters.year = "";
         SrchCtrl.searchAppByFilters.programType = "";
         SrchCtrl.searchApplication.application = "";
         SrchCtrl.appFilterFields.$setPristine();
     };
    SrchCtrl.getSelectedFilters = function() {
        var allSelectedFilters = {
        };

        if(SrchCtrl.searchAppByFilters) {
            allSelectedFilters.searchAppByFilters = SrchCtrl.searchAppByFilters;
        }

        if(SrchCtrl.searchFarmByFilters) {
            allSelectedFilters.searchFarmByFilters = SrchCtrl.searchFarmByFilters;
        }

        if(SrchCtrl.searchFormById) {
            allSelectedFilters.searchFormById = SrchCtrl.searchFormById;
        }
        return allSelectedFilters;
    };

    SrchCtrl.addNoteGroupTag = function(){
        var isSelected = isExistsInAlreadySelectedTags();
        if(SrchCtrl.selectedTag.length > 0 && !isSelected){
            $scope.tagsError = false;
            if(SrchCtrl.searchFarmByFilters.SelectedTags.length>0){
                SrchCtrl.searchFarmByFilters.SelectedTags =SrchCtrl.searchFarmByFilters.SelectedTags+ ',' + SrchCtrl.selectedTag;
            }else {
                SrchCtrl.searchFarmByFilters.SelectedTags = SrchCtrl.selectedTag;
            }
        }
        if(isSelected) {
            var msg = 'Tag(' + SrchCtrl.selectedTag + ') already selected';
            toastr.warning(msg);
        }
        SrchCtrl.selectedTag ="";
    };

    var isExistsInAlreadySelectedTags = function(){
        if(SrchCtrl.searchFarmByFilters.SelectedTags && SrchCtrl.searchFarmByFilters.SelectedTags.length > 0) {
            var alreadySelectedTags = SrchCtrl.searchFarmByFilters.SelectedTags.split(',');
            for(var i=0; i<alreadySelectedTags.length; i++){
                if(alreadySelectedTags[i] == SrchCtrl.selectedTag){
                    return true;
                }
            }
        } else {
            SrchCtrl.searchFarmByFilters.SelectedTags = '';
        }

        return false;
    };

    SrchCtrl.deleteNoteGroupTag = function(index){
        var allTags = SrchCtrl.searchFarmByFilters.SelectedTags.split(',');
        allTags.splice(index, 1);
        SrchCtrl.searchFarmByFilters.SelectedTags = allTags.join(',');
        toastr.success('Removed tag');
    };

    $scope.$watch("SrchCtrl.searchFarmByFilters.SelectedTags", function(newVal, oldVal){
        if(newVal && newVal.length>0){
            SrchCtrl.selectedTagsInDisplay = newVal.split(',');
        } else {
            SrchCtrl.selectedTagsInDisplay = [];
        }
    });


}]);