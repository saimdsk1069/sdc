angular.module('agSADCeFarms')
        .controller('searchResultsController', ['$scope', 'searchFactory', '$log',
            '$state', '$filter', '$stateParams', '$httpParamSerializer', 'AuthService',
            function ($scope, SF, $log, $state, $filter, $stateParams, $httpParamSerializer, AuthService) {
                var SrchRsltsCtrl = this;
                SrchRsltsCtrl.viewTypes = {
                    FARMRESULTS: 'farmResults',
                    APPRESULTS: 'appResults',
                    NORESULTS: 'noResults',
                    LOADING: 'loading'
                };

                $scope.ui_components = {
                    'ui_search_auth': false

                };

                var disable_ui_components = function () {
                    $scope.ui_components['ui_search_auth'] = false;
                };
                var setUIValues = function () {
                    var ui_access = AuthService.authResponse.ui_access;
                    angular.forEach(ui_access, function (comp_key) {
                        if ($scope.ui_components.hasOwnProperty(comp_key)) {
                            $scope.ui_components[comp_key] = true;
                        }
                    });
                };

//AuthService
                if (AuthService.isAuthenticated()) {
                    console.log("++++++User is authenticated");
                    console.log("++++++Users ui access:", AuthService.getUserUIAccess());
                    setUIValues();

                } else {
                    console.log("++++++User is not authenticated");
                    disable_ui_components();
                }

                $scope.$watchCollection(function () {
                    return AuthService.authState;
                }, function () {
                    if (!AuthService.authState) {
                        $log.debug("+++AuthService.authState changed to:", AuthService.authState);
                        disable_ui_components();

                    } else {
                        setUIValues();
                    }
                });
                var onLoad = function () {
                    //get the params from the route
                    var filters = $stateParams.filtersAndObjs.filters;
                    SrchRsltsCtrl.filterObjs = $stateParams.filtersAndObjs.filterObjs;
                    //set the view based on received params
                    SrchRsltsCtrl.currentView = filters.viewType;

                    //Serialize Params
                    var onlyFilters = angular.copy(filters);
                    delete onlyFilters['viewType'];
                    var paramsStr = $httpParamSerializer(onlyFilters);

                    //Call respective view funct
                    if (filters.viewType == SrchRsltsCtrl.viewTypes.FARMRESULTS) {
                        SrchRsltsCtrl.farmResults(paramsStr);
                    } else {
                        SrchRsltsCtrl.appResults(paramsStr);
                    }
                };
                SrchRsltsCtrl.farmResults = function (paramsStr) {
                    //config the farm ui-grid

                    if ($scope.ui_components.ui_search_auth) {
                        var preFarmLink = "<div class='ui-grid-cell-contents'> <a class='myDFarmLink' href='#farm/{{row.entity.farm_id}}'><u>{{row.entity.farm_id}}</u></a> </div>";
                    } else {
                        var preFarmLink = "<div class='ui-grid-cell-contents'> <a class='myDFarmLink' href='#publicfarm/{{row.entity.farm_id}}'><u>{{row.entity.farm_id}}</u></a> </div>";
                    }
                    SrchRsltsCtrl.farmColumns =
                            [{name: 'Farm Id', field: 'farm_id', cellTooltip: true, cellTemplate: preFarmLink},
                                {name: 'Farm Name', field: 'farm_name'},
                                {name: 'Municipality', field: 'municipality'},
                                {name: 'Preserved Date', field: 'preserved_date'},
                                {name: 'Farm Status', field: 'status_preserved_desc'},
                                {name: 'Partner', field: 'partner'},
                            ];
                    SrchRsltsCtrl.farmGridOptions = {
                        //   enableSorting: true,
                        enableSorting: true,
                        enableFiltering: true,
                        enablePaginationControls: true,
                        enableRowHeaderSelection: false,
                        enableColumnResizing: true,
                        columnDefs: SrchRsltsCtrl.farmColumns,
                        enableRowSelection: false,
                        enableFullRowSelection: false,
                        appScopeProvider: $scope,
                        onRegisterApi: function (farmGridApi) {
                            SrchRsltsCtrl.farmGridApi = farmGridApi;
                        }
                    };
                    // get the results and initiate ui-grid

                     $scope.getSearchFarmDetails = function() {
            // Display loading image while fetching data
                    $scope.loading_data = true;
                    SF.getSearchedFarm(paramsStr).then(
                    function (resp) {
                        SrchRsltsCtrl.farmResults = resp.data;
                        SrchRsltsCtrl.farmGridOptions.data = resp.data;
                        $scope.loading_data = false;
                    });
                };

$scope.getSearchFarmDetails();
};
                $scope.routeToFarmInfo = function (row) {
                    $state.go('app.farm.information', {farm_id: row.entity.farm_id});
                };

    SrchRsltsCtrl.routeToSearch = function(){
        $state.go('app.search', { filterObjs: SrchRsltsCtrl.filterObjs });
    };

    SrchRsltsCtrl.appResults = function(paramsStr){
        //config the app ui-grid
         var preAppLink = "<div class='ui-grid-cell-contents'> <a class='myDAppLink' href='#application/{{row.entity.application_id}}'><u>{{row.entity.application_id}}</u></a> </div>";
         var preFarmLink = "<div class='ui-grid-cell-contents'> <a class='myDFarmLink' href='#farm/{{row.entity.farm_id}}'><u>{{row.entity.farm_id}}</u></a> </div>";
        SrchRsltsCtrl.appColumns =
        [   { name:'Application Id',field: 'application_id', cellTooltip: true, cellTemplate:preAppLink},
            { name:'Farm Id',field: 'farm_id', cellTooltip: true, cellTemplate:preFarmLink},
            { name:'Application Type', field: 'application_type' },
            { name:'Application Phase',field: 'application_phase' },
            { name:'Application Status',field: 'application_status' },
            { name:'Partner Name' ,field: 'partner_name' },
            { name:'Program Type',field: 'program_type' },
        ];
        SrchRsltsCtrl.appGridOptions = {
          enableSorting: true,
          enableFiltering: true,
          enablePaginationControls: true,
          enableRowHeaderSelection: true,
          enableColumnResizing: true,
          columnDefs: SrchRsltsCtrl.appColumns,
          enableRowSelection: false,
          enableFullRowSelection: false,
          appScopeProvider: $scope,
          onRegisterApi: function(appGridApi) {
         SrchRsltsCtrl.appGridApi = appGridApi;
          }
        };

        // get the results and initiate ui-grid
          $scope.getSearchAppDetails = function() {
            // Display loading image while fetching data
                    $scope.loading_data = true;
        SF.getSearchedApp(paramsStr).then(
        function(resp){
            SrchRsltsCtrl.searchedAppResults = resp.data;
            SrchRsltsCtrl.appGridOptions.data = resp.data;
            $scope.loading_data = false;
        }, function(){

        });
    };
    $scope.getSearchAppDetails();
    };

    onLoad();
 }]);