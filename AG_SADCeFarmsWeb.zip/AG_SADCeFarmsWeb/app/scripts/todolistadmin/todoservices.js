(function() {
    'use strict';
}());

angular.module('agSADCeFarms')
.constant("baseURL", "/AG_SADCeFarms/")
.factory('authAdminToDoService', ['$http','baseURL', '$q', function($http, baseURL, $q) {

      return {
            fetchGetToDoList: function() {
                return $http.get(baseURL+'todolist')
                        .then(
                        function(response) {
                            return response.data;
                        }
                );
            },
            putToDoList: function(putData, listGUID) {
                return $http.put(baseURL+'todolist/'+listGUID, putData)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            toastr.clear();
                            toastr.error('Bad Connectivity / Server Down', 'Error while Editing Admin ToDo Data');
                        }
                );
            },
            postToDoList: function(postData) { console.log(postData);
                return $http.post(baseURL+'todolist', postData)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            toastr.clear();
                            toastr.error('Bad Connectivity / Server Down', 'Error while Creating Admin ToDo Data');
                        }
                );
            },
            deleteToDoList: function(deleteData,listGUID) {
                return $http.delete(baseURL+'todolist/'+listGUID, deleteData)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            toastr.clear();
                            toastr.error('Bad Connectivity / Server Down', 'Error while Deleting Admin ToDo Data');
                        }
                );
            },
            fetchGetAppType: function() {
                return $http.get(baseURL+'applicationtype')
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            toastr.clear();
                            toastr.error('Bad Connectivity / Server Down', 'Error while fetching Admin ToDo App Type');
                        }
                );
            },
            fetchToDoPhaseDetails: function() {
                return $http.get(baseURL+'phase?application_type_guid=a36a0f5f-35b4-4b2a-992b-06c499a86b39')
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            toastr.clear();
                            toastr.error('Bad Connectivity / Server Down', 'Error while fetching Phase Data');
                        }
                );
            }
        };
 }]);
