#from __future__ import with_statement
from fabric.api import local, settings, abort, run, cd, env, put, hide, lcd
from fabric.contrib.console import confirm

import time
import datetime
import os

username = os.getenv("USERNAME")
env.user = 'apache'
env.hosts = ['wading01.oit.state.nj.us']

appname = 'AG_SADCeFarmsWeb'
dev_dir = '../dist/'
app_base = '/opt/webdocs'
app_dir = app_base + '/' + appname
log_dir = '/opt/webserver/webdocs_archive/'
logfile = log_dir + 'webdeploy.log'


def deploy():
    with settings( hide('running', 'stderr', 'warnings'), warn_only=True):
        #with lcd('..'):
            #local( 'gulp' )
        if run("test ! -e %s.lck" % app_dir ).succeeded: # Lock file doesn't exist, so do deployment
            timestamp = '{:%Y-%m-%d %H:%M:%S}'.format(datetime.datetime.now())
            run("echo \"%s %s\" > %s.lck" % ( timestamp, username, app_dir ) )# Create a lock file until deployment is complete
            run("echo '%s: Deployment of %s by %s has started.' >> %s" % ( timestamp, appname, username, logfile ))
            # Check to see if app exists.  May be the first deployment so don't archive what doesn't exist
            if run("test -e %s" % app_dir ).succeeded:
                if run("/usr/local/bin/webapp_archive %s" % app_dir).failed:
                    print("FAILED TO ARCHIVE %s" % appname)
                    run("rm %s.lck" % app_dir ) # Remove the lock file
                    exit(1)
                print("Archiving application is complete")
                print("Removing old application")
                if run("rm -r %s" % app_dir).failed:
                    print("FAILED TO REMOVE OLD APP %s" % appname)
            else:
                print("COULD NOT FIND EXISTING APPLICATION, ASSUMING FIRST DEPLOYMENT")
            print("Creating application directory")
            run("mkdir %s" % app_dir )
            print("Copying the application to the server.")
            put('%s/*' % dev_dir, '%s' % app_dir+'/')
            run("chown -R apache:apache %s" % app_dir )
            print("Setting permissions for the application")
            run("chmod -R 755 %s" % app_dir )
            print("Cleaning up files")
            run("find %s -name 'CVS' -exec rm -r {} \;" % app_dir ) # Get rid of any CVS files
            run("find %s -name '.idea' -exec rm -r {} \;" % app_dir ) # Get rid of any .idea files
            run("find %s -name '.DS_Store' -exec rm {} \;" % app_dir ) # Get rid of any .DS_Store
            run("rm %s.lck" % app_dir ) # Remove the lock file
            #run("rm -r %s/deployment" % app_dir ) # Remove the deployment script from the server
            timestamp = '{:%Y-%m-%d %H:%M:%S}'.format(datetime.datetime.now())
            run("echo '%s: Deployment of %s by %s has completed.' >> %s" % ( timestamp, appname, username, logfile ))
        else:
            print("ANOTHER DEPLOYMENT IS IN PROGRESS, PLEASE TRY AGAIN LATER")
            print("CURRENT DEPLOYMENT IN PROGRESS:")
            run("cat %s.lck" % app_dir ) # Show the current lock file

def build():
    with settings( hide('running', 'stderr', 'warnings'), warn_only=True):
        with lcd('..'):
            result = local( 'gulp' )
            print "RESULT:", result.failed
        if result.failed:
            abort("BUILD FAILED STOPPING DEPLOYMENT")
        else:
            print("BUILD WAS SUCCESSFUL")



