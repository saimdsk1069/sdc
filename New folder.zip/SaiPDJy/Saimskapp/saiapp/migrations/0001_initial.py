# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='ApplicationPhase',
            fields=[
                ('application_phase_guid', models.CharField(max_length=36, serialize=False, primary_key=True)),
                ('application_phase_name', models.CharField(max_length=100)),
                ('info', models.CharField(max_length=500, null=True, blank=True)),
                ('phase_seq', models.IntegerField(null=True, blank=True)),
            ],
            options={
                'db_table': 'application_phase',
                'managed': False,
            },
        ),
    ]
