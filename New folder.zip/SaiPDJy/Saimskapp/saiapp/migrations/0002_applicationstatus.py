# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('saiapp', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='ApplicationStatus',
            fields=[
                ('application_status_desc', models.CharField(max_length=100, serialize=False, primary_key=True)),
            ],
            options={
                'db_table': 'application_status',
                'managed': False,
            },
        ),
    ]
