# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('saiapp', '0002_applicationstatus'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='applicationphase',
            options={},
        ),
        migrations.AlterModelOptions(
            name='applicationstatus',
            options={},
        ),
    ]
