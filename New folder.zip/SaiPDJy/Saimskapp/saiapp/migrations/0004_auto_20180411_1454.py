# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('saiapp', '0003_auto_20180411_1407'),
    ]

    operations = [
        migrations.AlterModelTable(
            name='applicationphase',
            table=None,
        ),
        migrations.AlterModelTable(
            name='applicationstatus',
            table=None,
        ),
    ]
