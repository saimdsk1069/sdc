# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('saiapp', '0004_auto_20180411_1454'),
    ]

    operations = [
        migrations.RenameModel(
            old_name='ApplicationPhase',
            new_name='Application',
        ),
    ]
