# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('saiapp', '0005_auto_20180411_1459'),
    ]

    operations = [
        migrations.AlterModelTable(
            name='application',
            table='application',
        ),
    ]
