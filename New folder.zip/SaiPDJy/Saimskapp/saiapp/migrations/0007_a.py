# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('saiapp', '0006_auto_20180411_1502'),
    ]

    operations = [
        migrations.CreateModel(
            name='A',
            fields=[
                ('x', models.IntegerField(serialize=False, primary_key=True)),
                ('y', models.IntegerField(blank=True)),
            ],
        ),
    ]
