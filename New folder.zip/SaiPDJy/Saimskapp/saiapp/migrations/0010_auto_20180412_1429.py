# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('saiapp', '0009_auto_20180412_1026'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='a',
            options={'managed': True},
        ),
    ]
