# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('saiapp', '0010_auto_20180412_1429'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='a',
            options={},
        ),
        migrations.AlterField(
            model_name='a',
            name='x',
            field=models.CharField(max_length=30, serialize=False, primary_key=True),
        ),
        migrations.AlterField(
            model_name='a',
            name='y',
            field=models.CharField(max_length=30, blank=True),
        ),
    ]
