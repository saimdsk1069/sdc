from django.db import models


class A(models.Model):
    x = models.CharField(primary_key=True,max_length=30)
    y = models.CharField(blank=True,max_length=30)


