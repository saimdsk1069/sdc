from django.db import models
from .models import A
from rest_framework import serializers

class ASerializer(serializers.ModelSerializer):

    class Meta:
        model = A
        fields = (' x',
                  'y')


