from django.shortcuts import render
import requests
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.http import Http404, HttpResponse, JsonResponse
from rest_framework import serializers
from django.http import HttpResponse
from django.shortcuts import render
from .serializers import *
import json
# Create your views here.



class A(APIView):

    def get(self,request):
        serializer = ASerializer
        return Response(serializer.data)
