from django.db import models


class A(models.Model):
    x = models.CharField(max_length=30)
    y = models.CharField(max_length=30)

    class Meta:
        managed = False
        db_table = 'a'

class CommonInfo(models.Model):
    name = models.CharField(max_length=100)
    age = models.PositiveIntegerField()

    class Meta:
        abstract = True

class Student(CommonInfo):
    home_group = models.CharField(max_length=5)