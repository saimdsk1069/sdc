from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, inch, cm, portrait, LETTER
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image, PageBreak, ListItem, ListFlowable
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle, TA_LEFT, TA_CENTER
from reportlab.lib.enums import TA_RIGHT


class FooterCanvas(canvas.Canvas):

    def __init__(self, *args, **kwargs):
        canvas.Canvas.__init__(self, *args, **kwargs)
        self.pages = []

    def showPage(self):
        self.pages.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        page_count = len(self.pages)
        for page in self.pages:
            self.__dict__.update(page)
            self.draw_canvas(page_count)
            canvas.Canvas.showPage(self)
        canvas.Canvas.save(self)

    def draw_canvas(self, page_count):
        page = "Page %s of %s" % (self._pageNumber, page_count)
        self.saveState()
        self.setStrokeColorRGB(0, 0, 0)
        self.setLineWidth(1.0)
        self.line(47, 88, A4[0] - 47, 88)
        self.setFont('Times-Roman', 10)
        self.drawString(A4[0]-97, 75, page)
        self.restoreState()


class MyPrint:

    def __init__(self, buffer, pagesize):
        self.buffer = buffer
        if pagesize == 'A4':
            self.pagesize = A4
        elif pagesize == 'Letter':
            self.pagesize = LETTER
        self.width, self.height = self.pagesize

    @staticmethod
    def _header_footer(canvas, doc):
        # Save the state of our canvas so we can draw on it
        canvas.saveState()
        styles = getSampleStyleSheet()

        # Header
        # header = Paragraph('Betty Davis Farm Review-SADCID#17-0151-PG', styles['Normal'])
        # w, h = header.wrap(doc.width, doc.topMargin)
        # header.drawOn(canvas, doc.leftMargin, doc.height + doc.topMargin - h)

        # Footer
        footer = Paragraph('SADC Final Approval Report', styles['Normal'])
        w, h = footer.wrap(doc.width, doc.bottomMargin)
        footer.drawOn(canvas, doc.leftMargin, h)

        # Release the canvas
        canvas.restoreState()

    def print_users(self):
            buffer = self.buffer
            doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=20, leftMargin=20, topMargin=20,
                                    bottomMargin=8)

            style_l = ParagraphStyle(
                            name='Normal',
                            fontName='Helvetica-Bold',
                            fontSize=9,
                            alignment=TA_LEFT,
                            bulletFontSize=10
                        )

            style_r = ParagraphStyle(
                            name='Normal',
                            fontName='Helvetica-Bold',
                            fontSize=9,
                            alignment=TA_RIGHT,
                        )

            style_c = ParagraphStyle(
                            name='Normal',
                            fontName='Helvetica-Bold',
                            fontSize=9,
                            alignment=TA_CENTER,
                        )

            style1 = ParagraphStyle(
                            name='Normal',
                            fontName='Helvetica-Bold',
                            fontSize=9,
                            alignment=TA_CENTER,
                        )

            style_p = ParagraphStyle(
                            name='Normal',
                            fontName='Helvetica',
                            fontSize=9,
                            alignment=TA_LEFT,
                        )


            styles = getSampleStyleSheet()
            styleN = styles['Normal']
            styleH = styles['Heading1']
            styleH.alignment = TA_CENTER
            styleF = styles['Heading2']
            styleF.alignment = TA_RIGHT
            styleU = styles['Heading3']
            styleU.alignment = TA_RIGHT

            doc.pagesize = portrait(A4)

            elements = []
            logo = "efarmreport/sadc_title.gif"
            im = Image(logo, 0*inch, 0*inch)
            elements.append(im)
            elements.append(Paragraph("eFarms Final Approval Report", styleH))
            elements.append(Paragraph("<i><font color=gray>note:County PIG ONLY</font></i>", style_c))
            elements.append(Spacer(1, 0.4*inch))
            elements.append(Paragraph("SADC RESOLUTION:FY2016R2(9)", style_l))
            elements.append(Paragraph("SADC MEETING DATE: February 25, 2016", style_r))
            elements.append(Paragraph("GRANT TO: WARREN COUNTY", style_l))
            elements.append(Paragraph("PROGRAM: County Planning Incentive Grant(PIG)", style_l))
            elements.append(Paragraph("OWNER: O'Dowd & Associates and Brian O'Dowd(East)", style_l))
            elements.append(Spacer(1, 0.1 * inch))
            elements.append(Paragraph("FOR:PURCHASE OF DEVELOPMENT EASEMENT", style_r))
            elements.append(Spacer(1, 0.1 * inch))
            elements.append(Paragraph("SADC FARM ID:", style_l))
            elements.append(Paragraph("SADC APPLICATION ID:", style_c))
            elements.append(Spacer(1, 0.1 * inch))
            elements.append(Paragraph("<u>FARM DETAIL</u>", style_l))
            elements.append(Paragraph("Greenwich Township", style_l))
            elements.append(Paragraph("Block 17,Lots 1&2", style_l))
            elements.append(Paragraph("Franklin Township", style_c))
            elements.append(Paragraph("Block 40,Lot 1", style_c))
            elements.append(Paragraph("<u>Geographic Detail</u>", style_r))
            elements.append(Paragraph("Highlands Planning Area", style_r))
            elements.append(Spacer(1, 0.1 * inch))
            elements.append(Paragraph("Estimated Gross Acres:97.18", style_l))
            elements.append(Paragraph("Estimated Net Acres to be preserved:96.18", style_l))
            elements.append(Paragraph("Grant calculated based on:99.065 acres", style_l))
            elements.append(Spacer(1, 0.1 * inch))
            elements.append(Paragraph("SADC Certified Easement Values:$6,300", style_l))
            elements.append(Paragraph("<u>Note</u>", style_l))
            elements.append(Paragraph("<u>Cost Share breakdown</u>", style_l))
            elements.append(Paragraph("OTHER FUNDING WOULD BE SHOWN HERE AS WELL(OSI, ALE, Donation, etc....)", style_l))
            elements.append(Paragraph("SADC:$401,213.25($4,050/acre)", style_l))
            elements.append(Paragraph("County:$222,896.25($2,250/acre)", style_l))
            elements.append(Paragraph("Total Easement Purchase:$624,109.50($6,300/acre)", style_l))
            elements.append(Spacer(1, 0.1 * inch))
            elements.append(Paragraph("<u>Conditions of Approval</u>", style_l))
            elements.append(Paragraph("<bullet>&bull;</bullet>This is where the conditions listed", style_l))
            elements.append(Spacer(1, 0.1 * inch))
            elements.append(Paragraph("<u>Development & Infrastructure Detail</u>", style_c))
            elements.append(Spacer(1, 0.1 * inch))

            # ..................................Table Stylesheet...............................................
            styles = getSampleStyleSheet()
            styleN = styles["BodyText"]
            styleN.alignment = TA_LEFT
            styleBH = styles["Normal"]
            styleBH.alignment = TA_CENTER
            # ....................................TABLE TEXTS.................................................
            # for i in details.VALUE_CONCLUSIONS_PERACRE:
            EX = Paragraph("Exception Area", styleBH)
            AC = Paragraph("1 acre", styleBH)
            NS = Paragraph("Non-severable", styleBH)
            L = Paragraph("<bullet>&bull;</bullet>Limited to one future single family resedential unit", styleN)

            # ............................TABLE Data to be given............................................
            d1 = [[EX, AC, NS, L],
                  [EX, AC, NS, L],
                  ]
            # .....................................TABLE 1.................................................
            table1 = Table(d1, colWidths=[4.05 * cm, 4.05 * cm, 4.05 * cm, 7 * cm])

            table1.setStyle(TableStyle([
                ('INNERGRID', (0, 0), (-1, -1), 0, colors.black),
                ('BOX', (0, 0), (-1, -1), 0, colors.black),
                ('BACKGROUND', (0, 0), (-1, -1), colors.bisque),
            ]))
            # ..................................... TABLE 2................................................
            ealu = Paragraph("Existing Agricultural Labor Units", style_l)
            z = Paragraph("Zero", style_c)
            eh = Paragraph("Existing House", style_l)
            eanu = Paragraph("Existing Non Agricultural Uses", style_l)
            n = Paragraph("none", style_c)

            d2 = [[ealu, z, " ", " "],
                  [eh, z],
                  [eanu, n],
                  ]
            table2 = Table(d2, colWidths=[7.05 * cm, 4.05 * cm, 1 * cm, 1 * cm])

            table2.setStyle(TableStyle([
                ('INNERGRID', (0, 0), (-1, -1), 0, colors.black),
                ('BOX', (0, 0), (-1, -1), 0, colors.black),
                ('BACKGROUND', (0, 0), (-1, -1), colors.bisque),
            ]))

            # .............................FLOWABLES...........................................
            # Send the data and build the file
            elements.append(Paragraph("Inside Exception Area(s)", style_c))
            elements.append(table1)
            elements.append(Spacer(1, 0.29 * inch))
            elements.append(Paragraph("Outside Exception Area(s)", style_c))
            elements.append(table2)
            elements.append(PageBreak())
            elements.append(Paragraph("<u>SADC certified market value (CMV) detail N.J.A.C. 2:76-17.11</u>", style_l))
            elements.append(Paragraph("Development Easement", style_l))
            elements.append(Paragraph("Fee Simple Value", style_l))
            elements.append(Paragraph("SADC CMV approval date: November 13,2014", style_r))
            elements.append(Paragraph("Date of Value: 5.13.14", style_l))
            elements.append(Paragraph("<b>Per Acre Value 1</b>:based on zoning and environmental regulations in place as of"
                                      " and based on zoning and environmental regulations in place as of 5.13.14:", styleN))
            elements.append(Paragraph("Before value:$4,500/acre", style_p))
            elements.append(Paragraph("After Value:$8,500/acre", style_p))
            elements.append(Paragraph("Easement Value:$6,300/acre", style_p))
            elements.append(Paragraph("<b>Per Acre Value 2</b>:based on zoning and environmental regulations in place as of"
                                      " and based on zoning and environmental regulations in place as of 1/1/04:", styleN))
            elements.append(Paragraph("Before value:$4,500/acre", style_p))
            elements.append(Paragraph("After Value:$7,800/acre", style_p))
            elements.append(Paragraph("Easement Value:$5,800/acre", style_p))
            elements.append(Spacer(1, 0.19 * inch))
            elements.append(Paragraph("<u>Financial Detail</u>", style_l))
            elements.append(Paragraph("Contract Purchase detail as per <u>N.J.A.C.</u>2:76-6.23(b):", style_p))
            elements.append(Paragraph("The contract purchase agreement: Fee simple title__Easement purchase", style_p))
            elements.append(Paragraph("Contract purchase price:$1,368,638.60 for __acres=$14,083.54 per acre", style_p))
            elements.append(Spacer(1, 0.19 * inch))
            elements.append(Paragraph("<u>Special Financial Notes</u>", style_l))
            elements.append(Paragraph("<bullet>&bull;</bullet><u>N.J.A.C.</u>2:76-6.23(b)", style_p))
            elements.append(Spacer(1, 2.5 * inch))
            elements.append(Paragraph("<u>Warren County PIG Grant Detail as of February 26,2016</u>", style_l))
            elements.append(PageBreak())
            elements.append(Paragraph("<u>Quality Score</u>: Farm Quality Score: 77.03", style_l))
            elements.append(Paragraph("Exceeds 70% of county average quality score: 41 based on County PIG scores "
                                      "approved on July 25,2013 as per N.J.A.C.2:76-17.", style_p))
            elements.append(Spacer(1, 0.29 * inch))
            elements.append(Paragraph("<u>SADC Guidance & Technical Documents </u>", style_l))
            elements.append(Paragraph("signed", style_p))
            elements.append(Paragraph("Division of Premises", style_p))
            # text = '<bullet>&bull;</bullet>hiiiiiiiiiiiii'
            # elements.append(Paragraph(text, style_l))
            elements.append(Spacer(1, 2 * inch))
            elements.append(Paragraph("<u>Individual Application Details</u>", style_l))
            elements.append(Paragraph("Application Submission Date: January 28,2014", style_p))
            elements.append(Paragraph("Green Light Approval per N.J.A.C.2:76-17.9(a) and (b):February 24,2014", style_p))
            elements.append(Paragraph("Final Approval submission date:January 4,2016", style_p))
            elements.append(Spacer(1, 0.29 * inch))
            elements.append(Paragraph("Final Approval Date(s):", styleN))
            elements.append(Paragraph("Franklin Township committee: December 07,2015", style_p))
            elements.append(Paragraph("Greenwich Township Committee:December 17,2015", style_p))
            elements.append(Paragraph("Warren CADB:December 17,2015", style_p))
            elements.append(Paragraph("County Board of Chosen Freeholders:December 9,2015", style_p))
            elements.append(PageBreak())
            elements.append(Paragraph("State Agricultural Development Committe(SADC)", styleH))
            elements.append(Paragraph("Soil & Wetland Report", styleH))
            elements.append(Spacer(1, 0.29 * inch))
            elements.append(Paragraph("SADC FARM ID:______"
                                      " SADC APPLICATION ID:________"
                                      " Estimated Gross Acres:<u>97.18</u>"
                                      " Net Easement Acres:________", style_l))
            elements.append(Paragraph("Highlands Planning Area:________"
                                      " Rural Environmentally Sensitive Area(PA4B):_____________", style_c))
            elements.append(Paragraph("<u>Farm Detail</u>", style_l))
            elements.append(Paragraph("Greenwich Township, Warren", style_p))
            elements.append(Paragraph("Block 17, Lots 1 & 2", style_p))
            elements.append(Paragraph("Franklin Township, Warren", style_p))
            elements.append(Paragraph("Block 40, Lots 1", style_p))
            # var = ListFlowable([(Paragraph("<u>Farm Detail</u>", style_l)),
            #                     (Paragraph("Greenwich Township, Warren", style_p)),
            #                     (Paragraph("Block 17, Lots 1 & 2", style_p)),
            #                     (Paragraph("Franklin Township, Warren", style_p)),
            #                     (Paragraph("Block 40, Lots 1", style_p)), ], bulletColor='red', value='square',
            #                    bullettype='bullet', start='square')
            # elements.append(var)
            elements.append(Spacer(1, 0.29 * inch))
            picture = "efarmreport/pic2.jpg"
            pi = Image(picture, 350, 150)
            pi.hAlign = 'CENTER'
            #pi.spaceAfter = 50
            elements.append(pi)
            elements.append(Paragraph("<u>Soils</u>", style_c))
            elements.append(Paragraph("Based on easement area only (excludes exception area(s))", style_c))
            elements.append(Paragraph("Prime:77.61 acres 83.57%", style_c))
            elements.append(Paragraph("Statewide:15.25 acres 16.43%", style_c))
            elements.append(Spacer(1, 0.29 * inch))
            elements.append(pi)
            elements.append(Paragraph("<u>Wetland Classification</u>", style_c))
            # elements.append(Paragraph("<bulletText=\xe2\x80\xa2;>item 2</para>", style_c))
            elements.append(Paragraph("Wetlands:0.00acres 0%", style_c))
            elements.append(Paragraph("Non Wetlands:92.86 acres 100.00%", style_c))
            elements.append(Paragraph("(note-this will list all modified wetlands,wetlands,uplands,water)", style_c))
            doc.multiBuild(elements, canvasmaker=FooterCanvas, onFirstPage=self._header_footer,
                           onLaterPages=self._header_footer)
            pdf = buffer.getvalue()
            buffer.close()
            return pdf
