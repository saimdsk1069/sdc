from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, inch, cm, portrait, letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle, TA_LEFT, TA_CENTER
from reportlab.lib.enums import TA_RIGHT
from reportlab.lib import colors
from efarmreport import details


class FooterCanvas(canvas.Canvas):

        def __init__(self, *args, **kwargs):
            canvas.Canvas.__init__(self, *args, **kwargs)
            self.pages = []

        def showPage(self):
            self.pages.append(dict(self.__dict__))
            self._startPage()

        def save(self):
            page_count = len(self.pages)
            for page in self.pages:
                self.__dict__.update(page)
                self.draw_canvas(page_count)
                canvas.Canvas.showPage(self)
            canvas.Canvas.save(self)

        def draw_canvas(self, page_count):
            page = "Page %s of %s" % (self._pageNumber, page_count)
            self.saveState()
            self.setStrokeColorRGB(0, 0, 0)
            self.setLineWidth(1.0)
            self.line(47, 88, A4[0] - 47, 88)
            self.setFont('Times-Roman', 10)
            self.drawString(A4[0] - 97, 75, page)
            self.restoreState()


class MyPrint:

    def __init__(self, buffer, pagesize):
        self.buffer = buffer
        if pagesize == 'A4':
            self.pagesize = A4
        elif pagesize == 'Letter':
            self.pagesize = letter
        self.width, self.height = self.pagesize

    @staticmethod
    def _header_footer(canvas, doc):
        # Save the state of our canvas so we can draw on it
        canvas.saveState()
        styles = getSampleStyleSheet()

        # Header
        header = Paragraph('Betty Davis Farm Review-SADCID#17-0151-PG', styles['Normal'])
        w, h = header.wrap(doc.width, doc.topMargin)
        header.drawOn(canvas, doc.leftMargin, doc.height + doc.topMargin - h)

        # Footer
        footer = Paragraph('Cert Report-Final-Davis Farm.doc', styles['Normal'])
        w, h = footer.wrap(doc.width, doc.bottomMargin)
        footer.drawOn(canvas, doc.leftMargin, h)

        # Release the canvas
        canvas.restoreState()

    def print_users(self):
            buffer = self.buffer
            doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=20, leftMargin=20, topMargin=20,
                                    bottomMargin=8)
            doc.pagesize = portrait(A4)

            elements = []
            logo = "efarmreport/sadc_title.gif"
            im = Image(logo, 0 * inch, 0 * inch)
            elements.append(im)

            styles = getSampleStyleSheet()
            styleN = styles['Normal']
            styleH = styles['Heading1']
            styleH.alignment = TA_CENTER

            elements.append(Paragraph("Certification Report", styleH))
            elements.append(Paragraph("Meeting Date: January 28, 2016", styleH))
            elements.append(Paragraph("County PIG Program", styleH))
            elements.append(Spacer(1, 0.4 * inch))

            style_l = ParagraphStyle(
                name='Normal',
                fontName='Helvetica-Bold',
                fontSize=12,
                alignment=TA_LEFT,
            )

            style_r = ParagraphStyle(
                name='Normal',
                fontName='Helvetica-Bold',
                fontSize=12,
                alignment=TA_RIGHT,
            )

            style_c = ParagraphStyle(
                name='Normal',
                fontName='Helvetica-Bold',
                fontSize=12,
                alignment=TA_CENTER,
            )

            style1 = ParagraphStyle(
                name='Normal',
                fontName='Helvetica-Bold',
                fontSize=11,
                alignment=TA_CENTER,
            )

            style_p = ParagraphStyle(
                name='Normal',
                fontName='Helvetica',
                fontSize=9,
                alignment=TA_LEFT,
            )

            for i in details.COUNTY_LIST:
                elements.append(Paragraph("County:" + i["c"], style_l))
                elements.append(Paragraph("Owner:" + i["o"], style_l))
                elements.append(Paragraph("Farm:" + i["f"], style_l))
                elements.append(Paragraph("Muncipality:" + i["m"], style_r))
                elements.append(Paragraph("<u>SADC ID#</u>" + i["ID"], style_r))
                elements.append(Spacer(1, 0.3 * inch))
                elements.append(Paragraph("Acreage in Application: 42Net Acres(Appraisal Order Checklist)", style_l))
                elements.append(Spacer(1, 0.1 * inch))
                elements.append(Paragraph("<b>Residential Oppurtunities/Exceptions:</b>", style_l))
                elements.append(Paragraph("#<u>0</u>RDSOs -", style_l))
                elements.append(Paragraph("#Existing Dwellings in Easement Area", style_l))
                elements.append(Paragraph("#Non-Severable Exception(2 Acres with existing house)", style_l))
                elements.append(Spacer(1, 0.9 * inch))
                elements.append(Paragraph(
                    "Value Conclusions - Current Zoning and Environmental Regulations  ", style_c))
                elements.append(Paragraph("Based on 42 Net Acres", style_c))
                elements.append(Spacer(1, 0.3 * inch))

            # ..................................Table Stylesheet...............................................
            styles = getSampleStyleSheet()
            style_n = styles["BodyText"]
            style_n.alignment = TA_LEFT
            style_bh = styles["Normal"]
            style_bh.alignment = TA_CENTER

            hAppraiser = Paragraph('''<b>Appraiser</b>''', style_bh)
            hDate = Paragraph('''<b>Date</b>''', style_bh)
            hBefore = Paragraph('''<b>Before</b>''', style_bh)
            hAfter = Paragraph('''<b>After</b>''', style_bh)
            hEasement = Paragraph('''<b>Easement</b>''', style_bh)

            # ....................................TABLE TEXTS.................................................
            for i in details.VALUE_CONCLUSIONS_PERACRE:
                appraiser = Paragraph(i["A"], styleN)
                date = Paragraph(str(i["D"]), styleN)
                before = Paragraph(i["B"], styleN)
                after = Paragraph(i["Af"], styleN)
                easement = Paragraph(i["E"], styleN)
            # ............................TABLE Data to be given............................................
            info = [[hAppraiser, hDate, hBefore, hAfter, hEasement],
                    [appraiser, date, before, after, easement],
                    [i["A1"], i["D1"], i["B1"], i["Af1"], i["E1"]],
                    [appraiser, date, before, after, easement],
                    [appraiser, date, before, after, easement]]
            # .....................................TABLE 1.................................................
            table1 = Table(info, colWidths=[4.05 * cm, 4.05 * cm, 5 * cm, 3 * cm, 3 * cm])

            table1.setStyle(TableStyle([
                ('INNERGRID', (0, 0), (-1, -1), 0.25, colors.black),
                ('BOX', (0, 0), (-1, -1), 0.25, colors.black),
                ('BACKGROUND', (0, 0), (-1, 0), colors.pink),
            ]))
            # ..................................... TABLE 2................................................
            table2 = Table(info, colWidths=[4.05 * cm, 4.05 * cm, 5 * cm,
                                            3 * cm, 3 * cm])

            table2.setStyle(TableStyle([
                ('INNERGRID', (0, 0), (-1, -1), 0.25, colors.black),
                ('BOX', (0, 0), (-1, -1), 0.25, colors.black),
                ('BACKGROUND', (0, 0), (-1, 0), colors.pink),
            ]))

            # .....................................TABLE 3..................................................
            # Texts
            highlandsStatus = Paragraph('''<b>H</b>''', style_bh)
            location = Paragraph('''<b>L</b>''', style_bh)
            size = Paragraph('''<b>S</b>''', style_bh)
            acres = Paragraph('<b>A</b>', style_bh)
            shape = Paragraph('<b>SH</b>', style_bh)

            h = Paragraph("Highlands Status:______Preservation:_______Planning Area", style_bh)
            l = Paragraph("Loc", styleN)
            s = Paragraph("Si", styleN)
            a = Paragraph("AC", styleN)
            sh = Paragraph("SHA", styleN)
            soils = Paragraph("Soils%", styleN)
            tillability = Paragraph("Tillability%", styleN)

            data = [[h],
                    [location],
                    [size],
                    [sh, soils, tillability],
                    ]
            table3 = Table(data)
            table3.setStyle(TableStyle([
                ('INNERGRID', (0, 0), (-1, -1), 0.25, colors.black),
                ('BOX', (0, 0), (-1, -1), 0.25, colors.black),
                ('BACKGROUND', (0, 0), (-1, 0), colors.pink),
            ]))
            # .............................FLOWABLES...........................................
            # Send the data and build the file
            elements.append(Paragraph("Per Acre", style1))
            elements.append(Spacer(1, 0.009 * inch))
            elements.append(table1)
            elements.append(Spacer(1, 0.009 * inch))
            elements.append(Paragraph("Total Value", style1))
            elements.append(table2)
            elements.append(Spacer(1, 0.29 * inch))
            elements.append(Paragraph('<u>Note</u>:Both appraisers used 42 net acres as per the AOC.'
                                      ' Tim Sheehan rounded the total values.', styleN))
            elements.append(Image('efarmreport/pic2.jpg', 8 * inch, 9 * inch))
            elements.append(Paragraph("FARMLAND PRESERVATION PROGRAM NJ SADC", styleH))
            elements.append(PageBreak())
            elements.append(Image('efarmreport/pic2.jpg', 8 * inch, 9 * inch))
            elements.append(Paragraph("FARMLAND PRESERVATION PROGRAM NJ SADC", styleH))
            elements.append(Spacer(1, 0.5 * inch))
            elements.append(PageBreak())
            elements.append(Paragraph("Reviewers Comments", styleH))
            elements.append(PageBreak())
            elements.append(Paragraph("Certification Report", styleH))
            elements.append(Spacer(1, 0.9 * inch))
            elements.append(Paragraph("Physical Characteristics", style_c))
            elements.append(Spacer(1, 0.1 * inch))
            elements.append(table3)
            elements.append(PageBreak())
            elements.append(Paragraph("SADC CERTIFICATION", styleH))
            elements.append(PageBreak())
            elements.append(Paragraph("Certification Report", styleH))
            elements.append(Spacer(1, 0.2 * inch))
            elements.append(Paragraph("Before Valuation based on Current Zoning and Environmental Regulations",
                                      style_c))
            elements.append(PageBreak())
            elements.append(Paragraph("After Value", styleH))
            elements.append(PageBreak())
            elements.append(Paragraph("<u>Reviewer Assumptions and Limiting Conditions</u>", styleH))
            elements.append(PageBreak())

            elements1 = []
            logo = "efarmreport/sadc_title.gif"
            im = Image(logo, 0 * inch, 0 * inch)
            elements1.append(im)
            elements1.append(Paragraph("eFarms Final Approval Report", styleH))
            elements1.append(Paragraph("<i><font color=gray>note:County PIG ONLY</font></i>", style_c))
            elements1.append(Spacer(1, 0.4 * inch))
            elements1.append(Paragraph("SADC RESOLUTION:FY2016R2(9)", style_l))
            elements1.append(Paragraph("SADC MEETING DATE: February 25, 2016", style_r))
            elements1.append(Paragraph("GRANT TO: WARREN COUNTY", style_l))
            elements1.append(Paragraph("PROGRAM: County Planning Incentive Grant(PIG)", style_l))
            elements1.append(Paragraph("OWNER: O'Dowd & Associates and Brian O'Dowd(East)", style_l))
            elements1.append(Spacer(1, 0.1 * inch))
            elements1.append(Paragraph("FOR:PURCHASE OF DEVELOPMENT EASEMENT", style_r))
            elements1.append(Spacer(1, 0.1 * inch))
            elements1.append(Paragraph("SADC FARM ID:", style_l))
            elements1.append(Paragraph("SADC APPLICATION ID:", style_c))
            elements1.append(Spacer(1, 0.1 * inch))
            elements1.append(Paragraph("<u>FARM DETAIL</u>", style_l))
            elements1.append(Paragraph("Greenwich Township", style_l))
            elements1.append(Paragraph("Block 17,Lots 1&2", style_l))
            elements1.append(Paragraph("Franklin Township", style_c))
            elements1.append(Paragraph("Block 40,Lot 1", style_c))
            elements1.append(Paragraph("<u>Geographic Detail</u>", style_r))
            elements1.append(Paragraph("Highlands Planning Area", style_r))
            elements1.append(Spacer(1, 0.1 * inch))
            elements1.append(Paragraph("Estimated Gross Acres:97.18", style_l))
            elements1.append(Paragraph("Estimated Net Acres to be preserved:96.18", style_l))
            elements1.append(Paragraph("Grant calculated based on:99.065 acres", style_l))
            elements1.append(Spacer(1, 0.1 * inch))
            elements1.append(Paragraph("SADC Certified Easement Values:$6,300", style_l))
            elements1.append(Paragraph("<u>Note</u>", style_l))
            elements1.append(Paragraph("<u>Cost Share breakdown</u>", style_l))
            elements1.append(
                Paragraph("OTHER FUNDING WOULD BE SHOWN HERE AS WELL(OSI, ALE, Donation, etc....)", style_l))
            elements1.append(Paragraph("SADC:$401,213.25($4,050/acre)", style_l))
            elements1.append(Paragraph("County:$222,896.25($2,250/acre)", style_l))
            elements1.append(Paragraph("Total Easement Purchase:$624,109.50($6,300/acre)", style_l))
            elements1.append(Spacer(1, 0.1 * inch))
            elements1.append(Paragraph("<u>Conditions of Approval</u>", style_l))
            elements1.append(Paragraph("*This is where the conditions listed.", style_l))
            elements1.append(Spacer(1, 0.1 * inch))
            elements1.append(Paragraph("<u>Development & Infrastructure Detail</u>", style_c))
            elements1.append(Spacer(1, 0.1 * inch))

            # ..................................Table Stylesheet...............................................
            styles = getSampleStyleSheet()
            styleN = styles["BodyText"]
            styleN.alignment = TA_LEFT
            styleBH = styles["Normal"]
            styleBH.alignment = TA_CENTER
            # ....................................TABLE TEXTS.................................................
            # for i in details.VALUE_CONCLUSIONS_PERACRE:
            EX = Paragraph("Exception Area", styleBH)
            AC = Paragraph("1 acre", styleBH)
            NS = Paragraph("Non-severable", styleBH)
            L = Paragraph("*Limited to one future single family resedential unit", styleN)

            # ............................TABLE Data to be given............................................
            d1 = [[EX, AC, NS, L],
                  [EX, AC, NS, L],
                  ]
            # .....................................TABLE 1.................................................
            table1 = Table(d1, colWidths=[4.05 * cm, 4.05 * cm, 4.05 * cm, 7 * cm])

            table1.setStyle(TableStyle([
                ('INNERGRID', (0, 0), (-1, -1), 0, colors.black),
                ('BOX', (0, 0), (-1, -1), 0, colors.black),
                ('BACKGROUND', (0, 0), (-1, -1), colors.bisque),
            ]))
            # ..................................... TABLE 2................................................
            ealu = Paragraph("Existing Agricultural Labor Units", style_l)
            z = Paragraph("Zero", style_c)
            eh = Paragraph("Existing House", style_l)
            eanu = Paragraph("Existing Non Agricultural Uses", style_l)
            n = Paragraph("none", style_c)

            d2 = [[ealu, z, " ", " "],
                  [eh, z],
                  [eanu, n],
                  ]
            table2 = Table(d2, colWidths=[7.05 * cm, 4.05 * cm, 1 * cm, 1 * cm])

            table2.setStyle(TableStyle([
                ('INNERGRID', (0, 0), (-1, -1), 0, colors.black),
                ('BOX', (0, 0), (-1, -1), 0, colors.black),
                ('BACKGROUND', (0, 0), (-1, -1), colors.bisque),
            ]))

            # .............................FLOWABLES...........................................
            # Send the data and build the file
            elements1.append(Paragraph("Inside Exception Area(s)", style_c))
            elements1.append(table1)
            elements1.append(Spacer(1, 0.29 * inch))
            elements1.append(Paragraph("Outside Exception Area(s)", style_c))
            elements1.append(table2)
            elements1.append(PageBreak())
            elements1.append(Paragraph("<u>SADC certified market value (CMV) detail N.J.A.C. 2:76-17.11</u>", style_l))
            elements1.append(Paragraph("Development Easement", style_l))
            elements1.append(Paragraph("Fee Simple Value", style_l))
            elements1.append(Paragraph("SADC CMV approval date: November 13,2014", style_r))
            elements1.append(Paragraph("Date of Value: 5.13.14", style_l))
            elements1.append(
                Paragraph("<b>Per Acre Value 1</b>:based on zoning and environmental regulations in place as of"
                          "and based on zoning and environmental regulations in place as of 5.13.14:", styleN))
            elements1.append(Paragraph("Before value:$4,500/acre", style_p))
            elements1.append(Paragraph("After Value:$8,500/acre", style_p))
            elements1.append(Paragraph("Easement Value:$6,300/acre", style_p))
            elements1.append(
                Paragraph("<b>Per Acre Value 2</b>:based on zoning and environmental regulations in place as of"
                          "and based on zoning and environmental regulations in place as of 1/1/04:", styleN))
            elements1.append(Paragraph("Before value:$4,500/acre", style_p))
            elements1.append(Paragraph("After Value:$7,800/acre", style_p))
            elements1.append(Paragraph("Easement Value:$5,800/acre", style_p))
            elements1.append(Spacer(1, 0.19 * inch))
            elements1.append(Paragraph("<u>Financial Detail</u>", style_l))
            elements1.append(Spacer(1, 2 * inch))
            elements1.append(Paragraph("<u>Special Financial Notes</u>", style_l))
            elements1.append(Spacer(1, 2.5 * inch))
            elements1.append(Paragraph("<u>Warren County PIG Grant Detail as of February 26,2016</u>", style_l))
            elements1.append(PageBreak())
            elements1.append(Paragraph("<u>Quality Score</u>: Farm Quality Score: 77.03", style_l))
            elements1.append(Paragraph("Exceeds 70% of county average quality scoe: 41 based on County PIG scores "
                                      "approved on July 25,2013 as per N.J.A.C.2:76-17.", style_p))
            elements1.append(Spacer(1, 0.29 * inch))
            elements1.append(Paragraph("<u>SADC Guidance & Technical Documents </u>", style_l))
            elements1.append(Paragraph("signed", style_p))
            elements1.append(Spacer(1, 2 * inch))
            elements1.append(Paragraph("<u>Individual Application Details</u>", style_l))
            elements1.append(Spacer(1, 2 * inch))
            elements1.append(Paragraph("Final Approval Date(s):", styleN))
            elements1.append(PageBreak())
            elements1.append(Paragraph("State Agricultural Development Committe(SADC)", styleH))
            elements1.append(Paragraph("Soil & Wetland Report", styleH))
            elements1.append(Spacer(1, 0.29 * inch))
            elements1.append(Paragraph("<u>Farm Detail</u>", style_l))
            elements1.append(Paragraph("Greenwich Township, Warren", style_p))
            elements1.append(Paragraph("Block 17, Lots 1 & 2", style_p))
            elements1.append(Paragraph("Franklin Township, Warren", style_p))
            elements1.append(Paragraph("Block 40, Lots 1", style_p))
            elements1.append(Spacer(1, 0.29 * inch))
            picture = "efarmreport/pic2.jpg"
            pi = Image(picture, 350, 150)
            pi.hAlign = 'CENTER'
            # pi.spaceAfter = 50
            elements1.append(pi)
            elements1.append(Paragraph("<u>Soils</u>", style_c))
            elements1.append(Paragraph("Based on easement area only (excludes exception area(s))", style_c))
            elements1.append(Paragraph("Prime:77.61 acres 83.57%", style_c))
            elements1.append(Paragraph("Statewide:15.25 acres 16.43%", style_c))
            elements1.append(Spacer(1, 0.29 * inch))
            elements1.append(pi)
            elements1.append(Paragraph("<u>Wetland Classification</u>", style_c))
            elements1.append(Paragraph("Wetlands:0.00acres 0%", style_c))
            elements1.append(Paragraph("Non Wetlands:92.86 acres 100.00%", style_c))
            elements1.append(Paragraph("(note-this will list all modified wetlands,wetlands,uplands,water)", style_c))
            story = elements + elements1
            doc.multiBuild(story, canvasmaker=FooterCanvas, onFirstPage=self._header_footer,
                           onLaterPages=self._header_footer)

            # Get the value of the BytesIO buffer and write it to the response.
            pdf = buffer.getvalue()
            buffer.close()
            return pdf