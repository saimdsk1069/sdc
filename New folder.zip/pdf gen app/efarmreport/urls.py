from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^efarmpdf$', views.gen, name='efarmpdf'),
]
