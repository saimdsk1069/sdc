from io import BytesIO
from django.shortcuts import HttpResponse
from efarmreport.finalreport import MyPrint


def gen(request):
    # Create the HttpResponse object with the appropriate PDF headers.
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="CPP.pdf"'

    buffer = BytesIO()

    report = MyPrint(buffer, 'A4')
    pdf = report.print_users()

    response.write(pdf)
    return response

