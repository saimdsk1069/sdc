import os
import time
import datetime
import urllib2
import smtplib
from email.mime.text import MIMEText
import traceback

def send(from_person, to_person, subject, message ):
    print "MESSAGE:", message
    msg = MIMEText(message)
    msg['Subject'] = subject
    msg['From'] = from_person
    try:
        #print "Making email connection"
        s = smtplib.SMTP('appmail.state.nj.us')
        s.set_debuglevel(True)
        print "Sending email"
        # identify ourselves, prompting server for supported features
        s.ehlo()
        
        # If we can encrypt this session, do it
        if s.has_extn('STARTTLS'):
            print "Relay supports TLS!!!"
            s.starttls()
            s.ehlo()
            
        s.sendmail(from_person, [to_person], msg.as_string())
        s.quit()
    except smtplib.SMTPConnectError as e:
        #print("Error sending email to " + contact )
        print("Error sending email to %s" % contact )
    except smtplib.SMTPDataError as e:
        print("SMTP DATA ERROR:" + e.message )

##sendStartupEmail( 'james.debruyne@oit.state.nj.us', 'a test', 'this is a test')

