def getMapSizeInInches( imageSizeInPixels, dpi ):
    """
        Read in size of image as tuple of x and y in pixels.  Also read in dpi.  Convert it
        to inches and return it as a tuple.
    """
    xSize = imageSizeInPixels[0] / float(dpi) 
    ySize = imageSizeInPixels[1] / float(dpi)
    return ( xSize, ySize )
    
def getMapSizeInPixels( imageSizeInInches, dpi ):
    """
        Get image size as a tuple in the format of x and y. Also get dpi of image.  Convert it to pixels and return it
        as a query string argument.
    """
    xSize = imageSizeInInches[0] * dpi 
    ySize = imageSizeInInches[1] * dpi
    return "&size="+str(int(xSize))+"%2C"+str(int(ySize))
    

def getBoundingBoxFromPoint( point, scale, imageSizeInInches=(0,0), imageSizeInPixels=(0,0), dpi=0 ):
    """
        Calculate the size of the image bounding box from a center point, scale, and either image size
        in inches or imagesize in pixels plus the dpi of the image.  Point is a tuple of x and y.  imageSize
        is also a tuple of x and y. Return bounding box as a query parameter
    """
    if imageSizeInInches[0] == 0:
        # must have size in pixels and dpi
        if imageSizeInPixels[0] == 0 and dpi == 0:
            print "Error: Must provide both imageSizeInPixels and dpi"
            exit(1)
        else:
            boxXSize = imageSizeInPixels[0] / float(dpi) / 12.0 * scale
            boxMinX = point[0] - 0.5 * boxXSize
            boxMaxX = point[0] + 0.5 * boxXSize
            boxYSize = imageSizeInPixels[1] / float(dpi) / 12.0 * scale
            boxMinY = point[1] - 0.5 * boxYSize
            boxMaxY = point[1] + 0.5 * boxYSize
    else:  # image size is provided in inches
        boxXSize = imageSizeInInches[0] / 12.0 * scale
        boxMinX = point[0] - 0.5 * boxXSize
        boxMaxX = point[0] + 0.5 * boxXSize
        boxYSize = imageSizeInInches[1] / 12.0 * scale
        boxMinY = point[1] - 0.5 * boxYSize
        boxMaxY = point[1] + 0.5 * boxYSize
    return "&bbox="+str(boxMinX)+'%2C'+str(boxMinY)+'%2C'+str(boxMaxX)+'%2C'+str(boxMaxY)
    
def getImageScale( urlQueryString ):
    """ 
        Calculate the x and y scale of the image being requested.
    """
    # get the image DPI
    dpi = float( urlQueryString['dpi'] )
    # get the size of the bounding box
    bboxX, bboxY = getBoundingBoxSize( urlQueryString['bbox'] )
    # get the size of the image in pixels and determine size in inches
    imageX, imageY = getImageSize( urlQueryString['size'] )
    imageSizeXInFt = imageX / dpi / 12.0 # to get size of image in ft.
    imageSizeYInFt = imageY / dpi / 12.0 # to get size of image in ft.
    # Determine the scale of the image 
    xScale = bboxX / imageSizeXInFt
    yScale = bboxY / imageSizeYInFt
    return ( xScale, yScale )

def getBoundingBoxSize( boundingBoxString ):
    """ 
        Take bounding box string, break it down into x and y sizes and return as a tuple of floats
    """
    XandYs = boundingBoxString.split('%2C')
    minX = XandYs[0]
    minY = XandYs[1]
    maxX = XandYs[2]
    maxY = XandYs[3]
    
    print "Bounding Box:", minX, minY, maxX, maxY
    xSize = float(maxX) - float(minX) 
    ySize = float(maxY) - float(minY)  
    return ( xSize, ySize )
    
def getCenterOfBoundingBox( boundingBoxString ):
    """ 
        Take bounding box string, break it down into x and y components, and determine the center x and y
    """
    XandYs = boundingBoxString.split('%2C')
    minX = XandYs[0]
    minY = XandYs[1]
    maxX = XandYs[2]
    maxY = XandYs[3]
    
    print "Bounding Box:", minX, minY, maxX, maxY
    centerX = float(minX) + ( float(maxX) - float(minX) ) / 2.0
    centerY = float(minY) + ( float(maxY) - float(minY)  ) / 2.0
    return ( centerX, centerY )
    
def getImageSize( imageSizeString ):
    """
        Take image size string and break it into x and y sizes and return it as a tuple of integers
    """
    imageXandY = imageSizeString.split('%2C')
    return ( int(imageXandY[0]), int(imageXandY[1]) )



if __name__ == "__main__":    
    url = "http://fema-services.esri.com/arcgis/rest/services/2012_Sandy/SurgeExtent/MapServer/export?dpi=96&transparent=true&format=png8&bbox=-8257589.971192507%2C4816843.541699508%2C-8257381.262275495%2C4817020.600909505&bboxSR=3857&imageSR=3857&size=699%2C593&f=image"

    queryString = url.split('?')[1]
    print queryString
    arguments = queryString.split('&')
    argDict = {}
    for arg in arguments:
        argSplit = arg.split('=')
        argName = argSplit[0]
        argValue = argSplit[1]
        argDict[ argName ] = argValue
    print argDict
    cX, cY = getCenterOfBoundingBox( argDict['bbox'] )
    print "Center of image:", cX, cY
    imageX, imageY = getImageSize( argDict['size'] )
    print "Image size:", imageX, imageY
    xScale, yScale = getImageScale( argDict )
    print "Image Scale:", xScale, yScale
    print "FEEDING BACK IN TO SEE WHAT COMES OUT"
    print "FROM IMAGE 4.8 x 3.8"
    bboxString = getBoundingBoxFromPoint( (-8281363.94594, 4793059.05433), 22013, imageSizeInInches=(4.8, 3.8) )
    print "BBOX:", bboxString
    print "FROM IMAGE 699 x 593 pixels, 96 dpi "
    bboxString = getBoundingBoxFromPoint( (-8281363.94594, 4793059.05433), 22013, imageSizeInPixels=(699,593), dpi=96)
    print "BBOX:", bboxString
    ( iX, iY ) = getMapSizeInInches( (699,593), 96 )
    print "SIZE FROM PIXELS:", iX, iY
