from StringIO import StringIO
import PIL.Image, PIL.ImageEnhance
import urllib2
import copy

def reduceOpacity(im, opacity):
    """Returns an image with reduced opacity."""
    assert opacity >= 0 and opacity <= 1
    if im.mode != 'RGBA':
        im = im.convert('RGBA')
    else:
        im = im.copy()
    alpha = im.split()[3]
    alpha = PIL.ImageEnhance.Brightness(alpha).enhance(opacity)
    im.putalpha(alpha)
    return im
    
def mergeLayerURLs( layersToMerge ):
    """ 
        Takes list of tuples.  Each tuple contains the url to get and the opacity for the final image.
        First image must be the base image
    """
    baseLayerURL = layersToMerge[0][0]
    #print "BASE LAYER:", baseLayerURL
    try:
        # Create base image by reading the URL.  Convert to StringIO and seek to beginning
        # so that image doesn't have to be written to disk as a temp file.
        baseImage = StringIO(urllib2.urlopen( baseLayerURL, timeout=30).read())
        baseImage.seek(0)
        # If base map is png8, it needs to be converted in order for masking of upper layers to work
        background = PIL.Image.open(baseImage).convert('RGB')
    except IOError:
            print "Error reading url"
            exit(1)
    except urllib2.HTTPError:
            print "HTTP Error from urllib2"
            exit(1)
            
    # Process the rest of the layers       
    for layer in layersToMerge[1:]:
        layerURL = layer[0]
        layerOpacity = layer[1]
        #print "LAYER URL:", layerURL
        #print "Opacity:", layerOpacity
        try:
            # Read URL, get data, and write to temp file
            imageData = StringIO(urllib2.urlopen( layerURL, timeout=30).read())
            imageData.seek(0)
            # iOut = open('layer.image', 'wb')
            # iOut.write( imageData )
            # iOut.close()
            # Reopen the file to merge it with the base layer
            foregroundImage = PIL.Image.open(imageData)
            # Reduce opacity as required
            if layerOpacity != 1.0:
                newfg = reduceOpacity( foregroundImage, layerOpacity )
            else:
                newfg = foregroundImage
            # Merge the foreground to the base image with mask to make transparent
            #background.paste( newfg, (0,0), newfg )
            background.paste( newfg, (0,0), newfg.convert('RGBA') )
        except IOError:
            print "Error processing URL ", layerURL
        except urllib2.HTTPError:
            print "HTTP Error from urllib2 reading ", layerURL
            exit(1)
    return background
    
if __name__ == "__main__":

    #
    # Sample URLs for testing
    #  

    baseMapURL = "http://services.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/export?dpi=96&transparent=true&format=png8&layers=show%3A-1&bbox=-8286685.874032337%2C4790164.001880359%2C-8273328.503339522%2C4801495.791323621&bboxSR=3857&imageSR=3857&size=699%2C593&f=image"

    baseImageURL = "http://njwebmap.state.nj.us/arcgis/rest/services/HurricaneSandy/ImageServer/exportImage?f=image&bbox=-8286685.874032337%2C4790164.001880359%2C-8273328.503339522%2C4801495.791323621&imageSR=3857&bboxSR=3857&size=699%2C593"

    femaImageURL = "http://fema-services.esri.com/arcgis/rest/services/2012_Sandy/SurgeExtent/MapServer/export?dpi=96&transparent=true&format=png8&bbox=-8286685.874032337%2C4790164.001880359%2C-8273328.503339522%2C4801495.791323621&bboxSR=3857&imageSR=3857&size=699%2C593&f=image"

    parcelsURL = "http://njwebmap.state.nj.us/arcgis/rest/services/Applications/OIT_Parcels_wm/MapServer/export?dpi=96&transparent=true&format=png8&layers=show%3A1%2C0&bbox=-8286685.874032337%2C4790164.001880359%2C-8273328.503339522%2C4801495.791323621&bboxSR=3857&imageSR=3857&size=699%2C593&f=image"

    #
    # Build list of layers to merge and create final map to include in PDF file
    #
    layersToMerge = [ ( baseMapURL, 1.0 ), ( baseImageURL, 1.0 ), ( femaImageURL, 0.6 ), ( parcelsURL, 1.0 ) ]
    finalImage = mergeLayerURLs( layersToMerge )
    finalImage.save('testmap.png', 'PNG')
    finalImage.save('testmap.jpg', 'JPEG')

