from reportlab.lib.pagesizes import letter, A4
from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.units import inch

def hello(c, x, y):
    c.drawString(x,y, "Hello World")
    
myCanvas = Canvas('myfile.pdf', pagesize=letter)
for x in range(5):
    for y in range(5):
        hello(myCanvas, x*inch, y*inch)
#hello(myCanvas)
myCanvas.showPage()
myCanvas.save()
width, height = letter #keep for later
print "width, height", width, height