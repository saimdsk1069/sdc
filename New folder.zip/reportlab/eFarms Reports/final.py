from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, inch, cm, portrait, LETTER
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image, PageBreak, ListItem, ListFlowable, Frame
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle, TA_LEFT, TA_CENTER
from reportlab.lib.enums import TA_RIGHT


class FooterCanvas(canvas.Canvas):

    def __init__(self, *args, **kwargs):
        canvas.Canvas.__init__(self, *args, **kwargs)
        self.pages = []

    def showPage(self):
        self.pages.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        page_count = len(self.pages)
        for page in self.pages:
            self.__dict__.update(page)
            self.draw_canvas(page_count)
            canvas.Canvas.showPage(self)
        canvas.Canvas.save(self)

    def draw_canvas(self, page_count):
        page = "Page %s of %s" % (self._pageNumber, page_count)
        self.saveState()
        self.setStrokeColorRGB(0, 0, 0)
        self.setLineWidth(1.0)
        self.line(47, 88, A4[0] - 47, 88)
        self.setFont('Times-Roman', 10)
        self.drawString(A4[0]-97, 75, page)
        self.restoreState()


class MyPrint:

    def __init__(self, buffer, pagesize):
        self.buffer = buffer
        if pagesize == 'A4':
            self.pagesize = A4
        elif pagesize == 'Letter':
            self.pagesize = LETTER
        self.width, self.height = self.pagesize

    @staticmethod
    def _header_footer(canvas, doc):
        # Save the state of our canvas so we can draw on it
        canvas.saveState()
        styles = getSampleStyleSheet()

        # Header
        # header = Paragraph('Betty Davis Farm Review-SADCID#17-0151-PG', styles['Normal'])
        # w, h = header.wrap(doc.width, doc.topMargin)
        # header.drawOn(canvas, doc.leftMargin, doc.height + doc.topMargin - h)

        # Footer
        footer = Paragraph('SADC Final Approval Report', styles['Normal'])
        w, h = footer.wrap(doc.width, doc.bottomMargin)
        footer.drawOn(canvas, doc.leftMargin, h)

        # Release the canvas
        canvas.restoreState()

    @property
    def print_users(self):
            buffer = self.buffer
            doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=20, leftMargin=20, topMargin=20,
                                    bottomMargin=8)

            style_l = ParagraphStyle(
                            name='Normal',
                            fontName='Helvetica-Bold',
                            fontSize=9,
                            alignment=TA_LEFT,
                            bulletFontSize=10
                        )

            style_r = ParagraphStyle(
                            name='Normal',
                            fontName='Helvetica-Bold',
                            fontSize=9,
                            alignment=TA_RIGHT,
                        )

            style_c = ParagraphStyle(
                            name='Normal',
                            fontName='Helvetica-Bold',
                            fontSize=9,
                            alignment=TA_CENTER,
                        )

            style1 = ParagraphStyle(
                            name='Normal',
                            fontName='Helvetica-Bold',
                            fontSize=9,
                            alignment=TA_CENTER,
                        )

            style_p = ParagraphStyle(
                            name='Normal',
                            fontName='Helvetica',
                            fontSize=9,
                            alignment=TA_LEFT,
                        )


            styles = getSampleStyleSheet()
            styleN = styles['Normal']
            styleH = styles['Heading1']
            styleH.alignment = TA_CENTER
            styleF = styles['Heading2']
            styleF.alignment = TA_RIGHT
            styleU = styles['Heading3']
            styleU.alignment = TA_RIGHT

            styles = getSampleStyleSheet()
            styleN = styles["BodyText"]
            styleN.alignment = TA_LEFT
            styleBH = styles["Normal"]
            styleBH.alignment = TA_CENTER

            doc.pagesize = portrait(A4)

            elements = []
            logo = "sadc_title.gif"
            im = Image(logo, 0*inch, 0*inch)
            elements.append(im)
            elements.append(Paragraph("eFarms Final Approval Report", styleH))
            elements.append(Paragraph("<i><font color=gray>note:County PIG ONLY</font></i>", style_c))
            elements.append(Spacer(1, 0.4*inch))
            elements.append(Paragraph("SADC MEETING DATE: February 25, 2016", style_r))
            elements.append(Paragraph("FOR:PURCHASE OF DEVELOPMENT EASEMENT", style_r))
            elements.append(Paragraph("SADC RESOLUTION:FY2016R2(9)", style_l))
            elements.append(Paragraph("SADC FARM ID:", style_l))
            elements.append(Paragraph("SADC APPLICATION ID:", style_l))
            # elements.append(Paragraph("<u>Geographic Detail</u>", style_c))
            # elements.append(Paragraph("Highlands Planning Area", style_c))
            elements.append(Spacer(1, 0.09 * inch))
            ################################################################
            e = Paragraph("Estimated Gross Acres:", style_p)
            n = Paragraph("Estimated Net Acres to be preserved:", style_p)
            g = Paragraph("Grant calculated based on:", style_p)
            s = Paragraph("SADC Certified Easement Value:", style_p)

            data = [[e, ""],
                    [n, ""],
                    [g, ""],
                    [s, ""]]

            t = Table(data, colWidths=[6.05 * cm, 4.05 * cm])
            t.hAlign='LEFT'

            t.setStyle(TableStyle([
                ('INNERGRID', (0, 0), (-1, -1), 0, colors.black),
                ('BOX', (0, 0), (-1, -1), 0, colors.black),
                ('BACKGROUND', (0, 0), (-1, -1), colors.bisque),
            ]))
            ################################################################
            i = Paragraph("Note", style_p)
            text = Paragraph("<bullet>&bull;</bullet>note box for staff to input as needed",style_p)

            d = [[i, text]]
            t1 = Table(d, colWidths=[2.05 * cm, 17.05 * cm])
            t1.hAlign = 'LEFT'
            t1.setStyle(TableStyle([
                ('INNERGRID', (0, 0), (-1, -1), 0, colors.black),
                ('BOX', (0, 0), (-1, -1), 0, colors.black),
                ('BACKGROUND', (0, 0), (-1, -1), colors.bisque),
            ]))
            ################################################################
            g = Paragraph("GRANT TO:", style_l)
            p = Paragraph("PROGRAM:", style_l)
            o = Paragraph("OWNER:", style_l)
            f = Paragraph("FARM DETAIL", styleBH)
            b = Paragraph("BLOCK", styleBH)
            l = Paragraph("LOTS", styleBH)

            data = [[g, "WARREN COUNTY"],
                    [p, "County Planning Incentive Grant(PIG)"],
                    [o, "O'Dowd & Associates and Brian O'Dowd(East)"]]


            table1 = Table(data, colWidths=[2.55 * cm, 7.55 * cm, 6.05 * cm])
            table1.hAlign = 'LEFT'
            # table1.setStyle(TableStyle([
            #     ('INNERGRID', (0, 0), (-1, -1), 0, colors.black),
            #     ('BOX', (0, 0), (-1, -1), 0, colors.black),
            #     ('BACKGROUND', (0, 0), (-1, -1), colors.bisque),
            # ]))

            elements.append(table1)
            elements.append(Spacer(1, 0.1 * inch))
            elements.append(t)
            elements.append(Spacer(1, 0.09 * inch))
            elements.append(t1)
            elements.append(Spacer(1, 0.1 * inch))
            sad = Paragraph("SADC", style_p)
            c = Paragraph("County", style_p)
            t = Paragraph("Total Easement Purchase", style_p)

            data = [[sad, ""],
                    [c, ""],
                    [t, ""]]

            table5 = Table(data, colWidths=[5.05 * cm, 4.05 * cm])
            table5.hAlign = 'LEFT'

            table5.setStyle(TableStyle([
                ('INNERGRID', (0, 0), (-1, -1), 0, colors.black),
                ('BOX', (0, 0), (-1, -1), 0, colors.black),
                ('BACKGROUND', (0, 0), (-1, -1), colors.bisque),
            ]))

            elements.append(Paragraph("<u>Cost Share breakdown</u>", style_l))
            elements.append(table5)
            elements.append(Spacer(1, 0.1 * inch))
            elements.append(Paragraph("<u>Conditions of Approval</u>", style_l))
            elements.append(Paragraph("<bullet>&bull;</bullet>This is where the conditions listed", style_p))
            elements.append(Spacer(1, 0.1 * inch))
            elements.append(Paragraph("<u>Development & Infrastructure Detail</u>", style_c))
            elements.append(Spacer(1, 0.1 * inch))
            # ....................................TABLE TEXTS.................................................
            EX = Paragraph("Exception Area", styleBH)
            AC = Paragraph("1 acre", styleBH)
            NS = Paragraph("Non-severable", styleBH)
            L = Paragraph("<bullet>&bull;</bullet>Limited to one future single family resedential unit", styleN)

            # ............................TABLE Data to be given............................................
            d1 = [[EX, AC, NS, L],
                  [EX, AC, NS, L],
                  ]
            table2 = Table(d1, colWidths=[4.05 * cm, 4.05 * cm, 4.05 * cm, 7 * cm])

            table2.setStyle(TableStyle([
                ('INNERGRID', (0, 0), (-1, -1), 0, colors.black),
                ('BOX', (0, 0), (-1, -1), 0, colors.black),
                ('BACKGROUND', (0, 0), (-1, -1), colors.bisque),
            ]))
            # ..................................... TABLE 2................................................
            ealu = Paragraph("Existing Agricultural Labor Units", style_l)
            z = Paragraph("Zero", style_c)
            eh = Paragraph("Existing House", style_l)
            eanu = Paragraph("Existing Non Agricultural Uses", style_l)
            n = Paragraph("none", style_c)

            d2 = [[ealu, z, " ", " "],
                  [eh, z],
                  [eanu, n],
                  ]
            table3 = Table(d2, colWidths=[7.05 * cm, 4.05 * cm, 4 * cm, 4 * cm])

            table3.setStyle(TableStyle([
                ('INNERGRID', (0, 0), (-1, -1), 0, colors.black),
                ('BOX', (0, 0), (-1, -1), 0, colors.black),
                ('BACKGROUND', (0, 0), (-1, -1), colors.bisque),
            ]))

            # .............................FLOWABLES...........................................
            # Send the data and build the file
            elements.append(Paragraph("Inside Exception Area(s)", style_c))
            elements.append(table2)
            elements.append(Spacer(1, 0.09 * inch))
            elements.append(Paragraph("Outside Exception Area(s)", style_c))
            elements.append(table3)
            elements.append(PageBreak())
            elements.append(Paragraph("<u>SADC certified market value (CMV) detail N.J.A.C. 2:76-17.11</u>", style_l))
            elements.append(Paragraph("Development Easement", style_l))
            elements.append(Paragraph("Fee Simple Value", style_l))
            elements.append(Paragraph("SADC CMV approval date: November 13,2014", style_r))
            elements.append(Paragraph("Date of Value: 5.13.14", style_l))
            elements.append(Paragraph("<b>Per Acre Value 1</b>:based on zoning and environmental regulations in place as of"
                                      " and based on zoning and environmental regulations in place as of 5.13.14:", styleN))
            b = Paragraph("Before value", styleBH)
            c = Paragraph("After value", styleBH)
            t = Paragraph("Easement value", styleBH)

            data = [[b, c, t],
                    ["", "", ""]]

            table6 = Table(data, colWidths=[4.05 * cm, 4.05 * cm, 4.05 * cm])

            table6.setStyle(TableStyle([
                ('INNERGRID', (0, 0), (-1, -1), 0, colors.black),
                ('BOX', (0, 0), (-1, -1), 0, colors.black),
                ('BACKGROUND', (0, 0), (-1, -1), colors.bisque),
            ]))
            elements.append(table6)
            # elements.append(Paragraph("Before value:$4,500/acre", style_p))
            # elements.append(Paragraph("After Value:$8,500/acre", style_p))
            # elements.append(Paragraph("Easement Value:$6,300/acre", style_p))
            elements.append(Paragraph("<b>Per Acre Value 2</b>:based on zoning and environmental regulations in place as of"
                                      " and based on zoning and environmental regulations in place as of 1/1/04:", styleN))
            elements.append(table6)
            # elements.append(Paragraph("Before value:$4,500/acre", style_p))
            # elements.append(Paragraph("After Value:$7,800/acre", style_p))
            # elements.append(Paragraph("Easement Value:$5,800/acre", style_p))
            elements.append(Spacer(1, 0.19 * inch))
            elements.append(Paragraph("<u>Financial Detail</u>", style_l))
            elements.append(Paragraph("Contract Purchase detail as per <u>N.J.A.C.</u>2:76-6.23(b):", style_p))
            elements.append(Paragraph("The contract purchase agreement: Fee simple title__Easement purchase", style_p))
            elements.append(Paragraph("Contract purchase price:$1,368,638.60 for __acres=$14,083.54 per acre", style_p))
            elements.append(Spacer(1, 0.19 * inch))
            elements.append(Paragraph("<u>Special Financial Notes</u>", style_l))
            elements.append(Paragraph("<bullet>&bull;</bullet><u>N.J.A.C.</u>2:76-6.23(b)", style_p))
            elements.append(Spacer(1, 2.5 * inch))
            elements.append(Paragraph("<u>Warren County PIG Grant Detail as of February 26,2016</u>", style_l))
            b = Paragraph("Base Grant Balance", style1)
            c = Paragraph("Competitive Grant Eligibility", style1)
            t = Paragraph("Competitive Grant Balances", style1)
            f = Paragraph("FY", style1)
            data = [[f, b, c, t],
                    ["", "", "", ""],
                    ["", "", ""],
                    ["", "", ""]]

            table7 = Table(data, colWidths=[1.05 * cm, 6.05 * cm, 6.05 * cm, 6.05 * cm],
                           rowHeights=[0.55 * cm, 0.55 * cm, 0.55 * cm, 0.55 * cm])

            table7.setStyle(TableStyle([
                ('INNERGRID', (0, 0), (-1, -1), 0, colors.black),
                ('BOX', (0, 0), (-1, -1), 0, colors.black),
                ('BACKGROUND', (0, 0), (-1, -1), colors.bisque),
            ]))
            elements.append(Spacer(1, 0.29 * inch))
            elements.append(table7)
            elements.append(PageBreak())
            elements.append(Paragraph("<u>Quality Score</u>: Farm Quality Score: 77.03", style_l))
            elements.append(Paragraph("Exceeds 70% of county average quality score: 41 based on County PIG scores "
                                      "approved on July 25,2013 as per N.J.A.C.2:76-17.", style_p))
            elements.append(Spacer(1, 0.29 * inch))
            elements.append(Paragraph("<u>SADC Guidance & Technical Documents </u>", style_l))
            elements.append(Paragraph("signed:", style_p))
            elements.append(Paragraph("Division of Premises", style_p))
            elements.append(Spacer(1, 2 * inch))
            elements.append(Paragraph("<u>Individual Application Details</u>", style_c))
            elements.append(Spacer(1, 0.29 * inch))
            a = (Paragraph("Application Submission Date", style_p))
            g = (Paragraph("Green Light Approval per N.J.A.C.2:76-17.9", style_p))
            f = (Paragraph("Final Approval submission date", style_p))

            fr = (Paragraph("Franklin Township committee", style_p))
            gr = (Paragraph("Greenwich Township Committee", style_p))
            w = Paragraph("Warren CADB", style_p)
            co = Paragraph("County Board of Chosen Freeholders", style_p)
            data = [[a, ""],
                    [g, ""],
                    [f, ""]]

            data1 = [
                     [fr, ""],
                     [gr, ""],
                     [w, ""],
                     [co, ""]]
            t3 = Table(data, colWidths=[8.05 * cm, 4.05 * cm, 4.05 * cm])
            t4 = Table(data1, colWidths=[8.05 * cm, 4.05 * cm])
            t3.setStyle(TableStyle([
                ('INNERGRID', (0, 0), (-1, -1), 0, colors.black),
                ('BOX', (0, 0), (-1, -1), 0, colors.black),
                ('BACKGROUND', (0, 0), (-1, -1), colors.bisque),
            ]))
            t4.setStyle(TableStyle([
                ('INNERGRID', (0, 0), (-1, -1), 0, colors.black),
                ('BOX', (0, 0), (-1, -1), 0, colors.black),
                ('BACKGROUND', (0, 0), (-1, -1), colors.bisque),
            ]))
            elements.append(t3)
            elements.append(Spacer(1, 0.29 * inch))
            elements.append(Paragraph("<u>Final Approval Date(s)</u>:", style_c))
            elements.append(Spacer(1, 0.29 * inch))
            elements.append(t4)
            elements.append(PageBreak())
            elements.append(Paragraph("State Agricultural Development Committe(SADC)", styleH))
            elements.append(Paragraph("Soil & Wetland Report", styleH))
            elements.append(Spacer(1, 0.29 * inch))
            elements.append(Paragraph("SADC FARM ID:", style_l))
            elements.append(Paragraph("Highlands Planning Area:", style_r))
            elements.append(Paragraph("SADC APPLICATION ID:", style_l))
            elements.append(Paragraph("Rural Environmentally Sensitive Area(PA4B)", style_r))
            elements.append(Spacer(1, 0.49 * inch))
            f = Paragraph("Farm Detail", styleBH)
            b = Paragraph("Block", styleBH)
            t = Paragraph("Lot", styleBH)

            data = [[f, b, t],
                    [],
                    []]

            table9 = Table(data, colWidths=[6.05 * cm, 6.05 * cm, 6.05 * cm])

            table9.setStyle(TableStyle([
                ('INNERGRID', (0, 0), (-1, -1), 0, colors.black),
                ('BOX', (0, 0), (-1, -1), 0, colors.black),
                ('BACKGROUND', (0, 0), (-1, -1), colors.bisque),
            ]))

            elements.append(table9)

            e = Paragraph("Estimated Gross Acres", styleBH)
            n = Paragraph("Net Easement Acres", styleBH)

            data = [[e, ""],
                    [n, ""]]
            t2 = Table(data, colWidths=[4.05 * cm, 4.05 * cm, 4.05 * cm])
            t2.hAlign = 'CENTER'
            t2.setStyle(TableStyle([
                ('INNERGRID', (0, 0), (-1, -1), 0, colors.black),
                ('BOX', (0, 0), (-1, -1), 0, colors.black),
                ('BACKGROUND', (0, 0), (-1, -1), colors.bisque),
            ]))
            elements.append(Spacer(1, 0.09 * inch))
            elements.append(t2)
            elements.append(Spacer(1, 0.29 * inch))
            picture = "pic2.jpg"
            pi = Image(picture, 190, 150)
            pi.hAlign = 'CENTER'
            data = [[pi],

                    [pi, ""]
                    ]

            table8 = Table(data, colWidths=[7.05 * cm, 9.05 * cm, 4.05 * cm])
            table8.hAlign = "CENTER"

            table8.setStyle(TableStyle([('INNERGRID', (0, 0), (-1, -1), 0, colors.black),
                                        ('BOX', (0, 0), (-1, -1), 0, colors.black),
                                        ]))
            elements.append(table8)
            elements.append(PageBreak())
            doc.multiBuild(elements, canvasmaker=FooterCanvas, onFirstPage=self._header_footer,
                           onLaterPages=self._header_footer)
            return doc

