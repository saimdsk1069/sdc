from io import BytesIO

from final import MyPrint

buffer = BytesIO()

report = MyPrint('efpr.pdf', 'Letter')
pdf = report.print_users


