from io import BytesIO

from printing import MyPrint

buffer = BytesIO()

report = MyPrint('testvg.pdf', 'Letter')
pdf = report.print_users()



