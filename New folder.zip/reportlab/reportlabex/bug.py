# from datetime import datetime
# from rest_framework.response import Response
#from rest_framework.views import APIView

from reportlab.graphics.shapes import Drawing, Line
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.lib.pagesizes import A4
#from pdf_creator import settings
import constants
#from report.utils import response_json

style_b = getSampleStyleSheet()
page_info = "Coffee Shop | Sale Report"



def myPage(self, canvas, doc):
        canvas.saveState()
        canvas.setFont('Times-Roman', 9)
        canvas.drawString(inch, 0.75 * inch, "Page %d %s" % (doc.page, page_info))
        canvas.restoreState()


        style_h1 = style_b["Heading1"]
        style_h4 = style_b["Heading4"]
        style_n = style_b["Normal"]

        d_line = Drawing(100, 1)
        d_line.add(Line(0, 0, 250, 0))

        doc = SimpleDocTemplate("pr.pdf", pagesize=A4, rightMargin=20, leftMargin=20, topMargin=20, bottomMargin=8)
        Story = [Paragraph("X Shop -  Sales Report", style_h1)]

        Story.append(Spacer(1, 0.2*inch))
        Story.append(d_line)
        Story.append(Spacer(1, 0.2*inch))
        Story.append(Paragraph("Sales Amount: PKR XXXXX.XX", style_n))
        Story.append(Paragraph("Orders Count: XX", style_n))
        Story.append(Paragraph("Orders Pending Count: XX", style_n))
        Story.append(Paragraph("Orders Cancel Count: XX", style_n))
        Story.append(Spacer(1, 0.2*inch))
        Story.append(d_line)

        Story.append(Spacer(1, 0.2*inch))
        Story.append(Paragraph("Order Details", style_h1))
        Story.append(Spacer(1, 0.2*inch))

        Story.append(d_line)
        Story.append(Spacer(1, 0.2*inch))
        Story.append(Paragraph("Order Price: PKR XXXXX.XX", style_n))
        Story.append(Paragraph("Customer Name: Aamish Baloch", style_n))
        Story.append(Paragraph("Products", style_h4))

        for product in constants.PRODUCT_LIST:
            Story.append(Spacer(1, 0.2*inch))
            Story.append(Paragraph("Name: " + product["name"], style_n))
            Story.append(Paragraph("Price: " + str(product["price"]), style_n))
            Story.append(Paragraph("Quantity: " + str(product["quantity"]), style_n))

        Story.append(Spacer(1, 0.2*inch))
        Story.append(d_line)
        doc.multiBuild(Story, onFirstPage=self.myPage, onLaterPages=self.myPage)