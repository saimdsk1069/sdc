import details



for county in details.COUNTY_LIST:
    print county
