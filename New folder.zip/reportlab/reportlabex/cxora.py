import cx_Oracle


con = cx_Oracle.connect('ag_sadc', 'farm16LandPres', 'exm_gis1d')
cursor = con.cursor()
cursor.execute('select * from COUNTY')
for result in cursor:
    print result
con.close()

# print con.version
# cursor.execute("SHOW TABLES")
# cursor.execute("USE ")
# cursor.execute("SHOW TABLES")
# __author__ = 'OAXRAJA'
# import cx_Oracle
# import uuid
#
# def getNewGUID():
#     """Create a GUID"""
#     return str(uuid.uuid4())
#
# def addPgmPartner():
#     tier = 'PARTNER'
#     group = 'PROGRAM PARTNER'
#     subgroup = ['SIGNATORY OFFICIAL', 'COORDINATOR', 'SUPPORT STAFF']
#     createRoles(None, tier, group, subgroup)
#
#     return
#
# def addEasementPartner():
#     tier = 'PARTNER'
#     group = 'EASEMENT PARTNER'
#     subgroup = ['COORDINATOR', 'MONITOR']
#     createRoles(None, tier, group, subgroup)
#     return
#
# def createRoles(partnerName, tier, group, sgArr):
#     con = cx_Oracle.connect('ag_sadc', 'farm16LandPres', 'exm_gis1d')
#     pullCur = con.cursor()
#     pushCur = con.cursor()
#     pList = None
#     try:
#
#         if 'PARTNER' == tier and None == partnerName:
#             # fetch from DB
#             # pFilter = " and PARTNER_NAME = '" + partnerName + "'"
#             pFilter = ""
#             if 'EASEMENT PARTNER' == group:
#                 # apply filter to get only counties; as of 2016 there are no muni easement partner
#                 # other partners, manage individually
#                 pFilter += " Where COUNTY_CODE is not null"
#
#             # During initial data push; if partner is inactive, ensure role is also inactive
#             # Use the following filter while bringing in new partners the role list
#             # PARTNER_GUID NOT IN (select distinct PARTNER_GUID from AUTH_ROLE_SADC where " \
#             #              "  PARTNER_GUID is not null)
#             partnerSQL = " select PARTNER_NAME, PARTNER_GUID, COUNTY_CODE, MUNI_CODE, ACTIVE from partner " \
#                          + pFilter
#
#             # print partnerSQL
#             pullCur.execute(partnerSQL)
#             pList = pullCur.fetchall()
#
#             for pRec in pList:
#                 for sg in sgArr:
#                     # params = {'pid': pRec[1], 'ccode': pRec[2], 'mcode': pRec[3]}
#                     # pushSQL = " INSERT INTO AUTH_ROLE_SADC (AUTH_ROLE_GUID, ACTIVE, " \
#                     #           " AUTH_ROLE_NAME, " \
#                     #           " TIER_TYPE_GUID, TIER_GROUP_TYPE_GUID, TIER_SUBGROUP_TYPE_GUID, " \
#                     #           " PARTNER_GUID, COUNTY_CODE, MUNI_CODE) " \
#                     #           " select '" + getNewGUID() + "', 1, " \
#                     #           " ( '" + pRec[0] + " - ' || t.TYPEVAL || ' - ' || g.TYPEVAL || ' - ' || s.TYPEVAL) as RN, " \
#                     #           " t.TIER_TYPE_GUID, g.TIER_GROUP_TYPE_GUID, s.TIER_SUBGROUP_TYPE_GUID, " \
#                     #           " :pid, :ccode, :mcode " \
#                     #           "from (select * from TIER_TYPE where TYPEVAL = '" + tier + "') t, " \
#                     #           " (select * from TIER_GROUP_TYPE where TYPEVAL = '" + group + "') g," \
#                     #           " (select * from TIER_SUBGROUP_TYPE where TYPEVAL = '" + subgroup + "') s;"
#                     # print pushSQL + " @@@@ " + str(params)
#                     # # not pushing Description as of now
#                     # pushCur.execute(pushSQL, params)
#
#                     # With params through cx_oracle --> python 'None' is not getting translated to oracle NULL.
#                     # enough time spent; moving on.
#                     pushSQL = " INSERT INTO AUTH_ROLE_SADC (AUTH_ROLE_GUID, ACTIVE, " \
#                               " AUTH_ROLE_NAME, " \
#                               " TIER_TYPE_GUID, TIER_GROUP_TYPE_GUID, TIER_SUBGROUP_TYPE_GUID, " \
#                               " PARTNER_GUID, COUNTY_CODE, MUNI_CODE) " \
#                               " select '" + getNewGUID() + "', " + str(pRec[4]) + ", " \
#                               " ( '" + pRec[0] + " - ' || t.TYPEVAL || ' - ' || g.TYPEVAL || ' - ' || s.TYPEVAL) as RN, " \
#                               " t.TIER_TYPE_GUID, g.TIER_GROUP_TYPE_GUID, s.TIER_SUBGROUP_TYPE_GUID, " \
#                               " '" + pRec[1] +"',"
#                     if pRec[2]:
#                         pushSQL += " '" + pRec[2] + "', "
#                     else:
#                         pushSQL += " Null, "
#
#                     if pRec[3]:
#                         pushSQL += " '" + pRec[3] + "' "
#                     else:
#                         pushSQL += " Null "
#
#                     pushSQL += " from (select * from TIER_TYPE where TYPEVAL = '" + tier + "') t, " \
#                               " (select * from TIER_GROUP_TYPE where TYPEVAL = '" + group + "') g," \
#                               " (select * from TIER_SUBGROUP_TYPE where TYPEVAL = '" + sg + "') s"
#                     # print pushSQL
#                     # break
#                     # not pushing Description as of now
#                     pushCur.execute(pushSQL)
#
#         con.commit()
#     finally:
#         pushCur.close()
#         pullCur.close()
#         con.close()
#
#     return
#
# def nonPartnerRoles():
#     tgsArr = []
#     tgsArr.append(['FARM/PROGRAM CONTACT', 'LAND OWNER', 'CONTRACT PURCHASER'])
#     tgsArr.append(['FARM/PROGRAM CONTACT', 'LAND OWNER', 'LAND OWNER'])
#     tgsArr.append(['FARM/PROGRAM CONTACT', 'LAND OWNER', 'LAND OWNER REP'])
#     tgsArr.append(['FARM/PROGRAM CONTACT', 'FARM OPERATOR', 'FARM OPERATOR'])
#     tgsArr.append(['FARM/PROGRAM CONTACT', 'FARM OPERATOR', 'FARM OPERATOR REP'])
#     tgsArr.append(['FARM/PROGRAM CONTACT', 'NEIGHBOR', 'NEIGHBOR'])
#     tgsArr.append(['VENDOR', 'CONTRACTOR', 'PROFESSIONAL SUPPORT'])
#     tgsArr.append(['VENDOR', 'VENDOR', 'MEDIATOR'])
#     tgsArr.append(['VENDOR', 'VENDOR', 'TITLE COMPANY'])
#     tgsArr.append(['VENDOR', 'VENDOR', 'SURVEYOR'])
#     tgsArr.append(['VENDOR', 'VENDOR', 'APPRAISER'])
#     # tgsArr.append(['SADC STAFF', 'SADC STAFF', 'VIEW ALL'])
#     tgsArr.append(['SADC STAFF', 'LEGAL', 'DEPUTY AG'])
#     tgsArr.append(['SADC STAFF', 'LEGAL', 'SPECIALIST'])
#     tgsArr.append(['SADC STAFF', 'LEGAL', 'CHIEF'])
#     tgsArr.append(['SADC STAFF', 'FISCAL', 'ASSISTANT'])
#     tgsArr.append(['SADC STAFF', 'FISCAL', 'MANAGER'])
#     tgsArr.append(['SADC STAFF', 'PLANNING', 'GIS SPECIALIST'])
#     tgsArr.append(['SADC STAFF', 'PLANNING', 'SPECIALIST'])
#     tgsArr.append(['SADC STAFF', 'PLANNING', 'MANAGER'])
#     tgsArr.append(['SADC STAFF', 'ACQUISITION', 'REVIEW APPRAISER'])
#     tgsArr.append(['SADC STAFF', 'ACQUISITION', 'REVIEW APPRAISER MANAGER'])
#     tgsArr.append(['SADC STAFF', 'ACQUISITION', 'GIS SPECIALIST'])
#     tgsArr.append(['SADC STAFF', 'ACQUISITION', 'GREEN LIGHT REVIEWER'])
#     tgsArr.append(['SADC STAFF', 'ACQUISITION', 'PROJECT MANAGER'])
#     tgsArr.append(['SADC STAFF', 'ACQUISITION', 'CLOSER'])
#     tgsArr.append(['SADC STAFF', 'ACQUISITION', 'CHIEF'])
#     tgsArr.append(['SADC STAFF', 'STEWARDSHIP', 'MONITOR'])
#     tgsArr.append(['SADC STAFF', 'STEWARDSHIP', 'MANAGER'])
#     tgsArr.append(['SADC STAFF', 'STEWARDSHIP', 'RTF SPECIALIST'])
#     tgsArr.append(['SADC STAFF', 'STEWARDSHIP', 'AG RESOURCE SPECIALIST'])
#     tgsArr.append(['SADC STAFF', 'STEWARDSHIP', 'CHIEF'])
#     tgsArr.append(['SADC STAFF', 'ADMIN', 'ADMINISTRATIVE ASSISTANT'])
#     tgsArr.append(['SADC STAFF', 'ADMIN', 'POLICY & COMMUNICATIONS'])
#     tgsArr.append(['SADC STAFF', 'ADMIN', 'ED'])
#     tgsArr.append(['SADC MANAGEMENT', 'COMMITTEE MEMBER', 'CHAIR'])
#     tgsArr.append(['SADC MANAGEMENT', 'COMMITTEE MEMBER', 'EXOFFICIO'])
#     tgsArr.append(['SADC MANAGEMENT', 'COMMITTEE MEMBER', 'FARMER'])
#     tgsArr.append(['SADC MANAGEMENT', 'COMMITTEE MEMBER', 'PUBLIC'])
#     tgsArr.append(['SADC MANAGEMENT', 'GOVERNOR OFFICE', 'GO STAFF'])
#     tgsArr.append(['SADC MANAGEMENT', 'DEPARTMENT OF AG', 'SECRETARY'])
#     # tgsArr.append(['SADC MANAGEMENT', 'DEPARTMENT OF AG', 'CIO'])
#     tgsArr.append(['ADMIN', 'OGIS', 'SUPER ADMIN'])
#     tgsArr.append(['ADMIN', 'OGIS', 'ADMIN'])
#     tgsArr.append(['ADMIN', 'AGIT', 'ADMIN'])
#     tgsArr.append(['ADMIN', 'SADC', 'ADMIN'])
#     tgsArr.append(['ADMIN', 'SADC', 'USER MANAGER'])
#     tgsArr.append(['ADMIN', 'SADC', 'APPLICATION MANAGER'])
#
#     # insertRoles(tgsArr)
#     prepInsScript (tgsArr)
#     print "Done - nonPartnerRoles"
#
#     return
#
# def insertRoles(tgsList):
#     con = cx_Oracle.connect('ag_sadc', 'farm16LandPres', 'exm_gis1d')
#     pushCur = con.cursor()
#     try:
#         for tgs in tgsList:
#             pushSQL = " INSERT INTO AUTH_ROLE_SADC (AUTH_ROLE_GUID, ACTIVE, " \
#                       " AUTH_ROLE_NAME, " \
#                       " TIER_TYPE_GUID, TIER_GROUP_TYPE_GUID, TIER_SUBGROUP_TYPE_GUID) " \
#                       " select '" + getNewGUID() + "', 1, " \
#                       " ( t.TYPEVAL || ' - ' || g.TYPEVAL || ' - ' || s.TYPEVAL) as RN, " \
#                       " t.TIER_TYPE_GUID, g.TIER_GROUP_TYPE_GUID, s.TIER_SUBGROUP_TYPE_GUID " \
#                       " from (select * from TIER_TYPE where TYPEVAL = '" + tgs[0] + "') t, " \
#                       " (select * from TIER_GROUP_TYPE where TYPEVAL = '" + tgs[1] + "') g," \
#                       " (select * from TIER_SUBGROUP_TYPE where TYPEVAL = '" + tgs[2] + "') s"
#             # print pushSQL
#             # not pushing Description as of now
#             pushCur.execute(pushSQL)
#
#         con.commit()
#     finally:
#         pushCur.close()
#         con.close()
#
#     return
#
# def prepInsScript(tgsList):
#     f = open("AUTH_ROLE_SADC_nonPrtnr.sql", 'w')
#     f.write("SET DEFINE OFF; \n")
#     for tgs in tgsList:
#         pushSQL = " INSERT INTO AUTH_ROLE_SADC (AUTH_ROLE_GUID, ACTIVE, " \
#                   " AUTH_ROLE_NAME, " \
#                   " TIER_TYPE_GUID, TIER_GROUP_TYPE_GUID, TIER_SUBGROUP_TYPE_GUID) " \
#                   " select '" + getNewGUID() + "', 1, " \
#                   " ( t.TYPEVAL || ' - ' || g.TYPEVAL || ' - ' || s.TYPEVAL) as RN, " \
#                   " t.TIER_TYPE_GUID, g.TIER_GROUP_TYPE_GUID, s.TIER_SUBGROUP_TYPE_GUID " \
#                   " from (select * from TIER_TYPE where TYPEVAL = '" + tgs[0] + "') t, " \
#                   " (select * from TIER_GROUP_TYPE where TYPEVAL = '" + tgs[1] + "') g," \
#                   " (select * from TIER_SUBGROUP_TYPE where TYPEVAL = '" + tgs[2] + "') s;"
#
#         f.write(pushSQL + "\n")
#
#     return
#
