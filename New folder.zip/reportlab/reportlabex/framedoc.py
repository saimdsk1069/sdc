from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, inch, cm, portrait, LETTER, landscape
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image, PageBreak, ListItem, ListFlowable, Frame, PageTemplate, BaseDocTemplate, FrameBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle, TA_LEFT, TA_CENTER
from reportlab.lib.enums import TA_RIGHT


def createPlatypusPage(pieChart1, pieChart2, table1):
	# PDF Properties
        Title = "ECS Report #1"
        Author = "ECS Information Systems"
        PageInfo = "Sample Report"

        # define frames - for frames in page
        frameHeader = Frame(x1=0*inch, y1=7.5*inch, width=11*inch, height=1*inch)
        frameChart1 = Frame(x1=0*inch, y1=2.5*inch, width=5.5*inch, height=5*inch)
        frameChart2 = Frame(x1=5.5*inch, y1=2.5*inch, width=5.5*inch, height=5*inch)
        frameTable1 = Frame(x1=0*inch, y1=0*inch, width=5.5*inch, height=2.5*inch)
        frameTable2 = Frame(x1=5.5*inch, y1=0*inch, width=5.5*inch, height=2.5*inch)

        # define pageTemplates - for page in document
        mainPage = PageTemplate(frames=[frameHeader, frameChart1, frameChart2,
                                        frameTable1, frameTable2])

        # define BasicDocTemplate - for document
        doc = BaseDocTemplate('report_1.pdf', pagesize=landscape(letter),
                               pageTemplates=mainPage, leftMargin=72,
                               title=Title, author=Author, showBoundary=0)

        # styles
        styles = getSampleStyleSheet()
        styleH = styles['Heading1']

        # create a story
        story = []
        heading = Paragraph("This is a Heading for the Report", styleH)
        heading.hAlign = 'CENTER'
        pieChart1.hAlign = 'CENTER'
        pieChart2.hAlign = 'CENTER'

        story.append(heading)
        story.append(FrameBreak())		# move to next frame
        story.append(pieChart1)			# note that frame order is based upon order
    # used in PageTemplate
        story.append(FrameBreak())		# move to next frame
        story.append(pieChart2)
        story.append(FrameBreak())		# move to next frame
        story.append(table1)

        doc.build(story)