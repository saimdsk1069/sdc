from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, inch, cm, portrait, LETTER
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image, PageBreak, ListItem, ListFlowable, Frame
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle, TA_LEFT, TA_CENTER
from reportlab.lib.enums import TA_RIGHT


def run():
    styles = getSampleStyleSheet()
    styleN = styles['Normal']
    styleH = styles['Heading1']
    story = []

    story.append(Paragraph('I2of5', styleN))

    story.append(Paragraph('MSI', styleN))

    story.append(Paragraph('Codabar', styleN))

    story.append(Paragraph('Code 11', styleN))

    story.append(Paragraph('Code 39', styleN))

    story.append(Paragraph('Extended Code 39', styleN))

    story.append(Paragraph('Code93', styleN))

    story.append(Paragraph('Extended Code93', styleN))

    story.append(Paragraph('Code 128', styleN))


    story.append(Paragraph('USPS FIM', styleN))

    story.append(Paragraph('USPS POSTNET', styleN))

    story.append(Paragraph('Label Size', styleN))

    story.append(Paragraph('Label Size', styleN))

    c = canvas.Canvas('out.pdf')
    f = Frame(inch, inch, 6*inch, 9*inch, showBoundary=1)
    f.addFromList(story, c)
    c.save()