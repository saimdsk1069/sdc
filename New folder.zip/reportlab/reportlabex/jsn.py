import json

from pprint import pprint


data = json.dumps([{"name": "Shoe A", "price": 1040.00, "quantity": 2},
                {"name": "Shoe B", "price": 100.00, "quantity": 3},
                {"name": "Shoe C", "price": 100.00, "quantity": 2},
                {"name": "Shoe D", "price": 100.00, "quantity": 6},
                {"name": "Shoe E", "price": 100.00, "quantity": 2},
                {"name": "Shoe F", "price": 1060.00, "quantity": 2},
                {"name": "Shoe G", "price": 100.00, "quantity": 45},
                {"name": "Shoe H", "price": 100.00, "quantity": 2},
                {"name": "Shoe I", "price": 100.00, "quantity": 2},
                {"name": "Shoe J", "price": 100.00, "quantity": 2},
                {"name": "Shoe K", "price": 150.00, "quantity": 1},
                {"name": "Shoe L", "price": 100.00, "quantity": 2},
                {"name": "Shoe M", "price": 1003.00, "quantity": 2},
                {"name": "Shoe N", "price": 100.00, "quantity": 5},
                {"name": "Shoe O", "price": 156.00, "quantity": 2},
                {"name": "Shoe P", "price": 67.00, "quantity": 2},
                {"name": "Shoe Q", "price": 100.00, "quantity": 2},
                {"name": "Shoe R", "price": 100435.00, "quantity": 9},
                {"name": "Shoe S", "price": 100.00, "quantity": 2},
                {"name": "Shoe T", "price": 100.00, "quantity": 2},
                {"name": "Shoe U", "price": 100.00, "quantity": 2},
                {"name": "Shoe V", "price": 100.00, "quantity": 25},
                {"name": "Shoe W", "price": 1002.00, "quantity": 2},
                {"name": "Shoe X", "price": 160.00, "quantity": 2},
                {"name": "Shoe Y", "price": 100.00, "quantity": 2},
                {"name": "Shoe Z", "price": 100.00, "quantity": 2}])

print(data)