from reportlab.lib.units import inch


def print_users(self):
    buffer = self.buffer
    doc = SimpleDocTemplate(buffer,
                            rightMargin=inch / 4,
                            leftMargin=inch / 4,
                            topMargin=inch / 2,
                            bottomMargin=inch / 4,
                            pagesize=self.pagesize)

    # Our container for 'Flowable' objects
    elements = []

    # A large collection of style sheets pre-made for us
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name='centered', alignment=TA_CENTER))

    # Draw things on the PDF. Here's where the PDF generation happens.
    # See the ReportLab documentation for the full list of functionality.
    users = User.objects.all()
    elements.append(Paragraph('My User Names', styles['Heading1']))
    for i, user in enumerate(users):
        elements.append(Paragraph(user.get_full_name(), styles['Normal']))

    doc.build(elements, onFirstPage=self._header_footer, onLaterPages=self._header_footer)

    # Get the value of the BytesIO buffer and write it to the response.
    pdf = buffer.getvalue()
    buffer.close()
    return pdf


print_users()