from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import Paragraph, Frame, Image
from reportlab.lib.pagesizes import letter
#from reportlab.lib.utils import haveImages, _RL_DIR, rl_isfile, fileName2Utf8
from StringIO import StringIO

import urllib2

# imageURL = "http://raritan20.sa.state.nj.us/ArcGIS/rest/services/Applications/NJ_TaxListSearch/MapServer/export?dpi=96&transparent=true&format=jpg&bbox=376030.88888888864%2C378330.90104166686%2C377061.097222222%2C378906.9427083335&bboxSR=3424&imageSR=3424&size=512%2C512&f=image"
imageURL = "http://njwebmaptest.state.nj.us/ArcGIS/rest/services/Applications/AC_Demo/MapServer/export?dpi=96&transparent=true&format=png8&bbox=563877.8359471112%2C328710.1711317586%2C615705.3433248574%2C358743.0124291246&bboxSR=3424&imageSR=3424&size=994%2C576&f=image"
styles = getSampleStyleSheet()
styleN = styles['Normal']
styleH = styles['Heading1']
c = Canvas('FramesTest.pdf',pagesize=letter)

story2 = []
story2.append(Paragraph("Incredible Map Information", styleH))

botStory = []
botStory.append(Paragraph("Detailed Map Information", styleH))
botStory.append(Paragraph("Extremely cool information regarding your map.",
styleN))
botFrame = Frame(0.5*inch, 0.5*inch, 7.5*inch, 5.0*inch, showBoundary=1)
botFrame.addFromList(botStory,c)

f = Frame(0.5*inch, 5.5*inch, 3.5*inch, 4.0*inch, showBoundary=1)
mapFrame = Frame(4.0*inch, 5.5*inch, 4.0*inch, 4.0*inch, showBoundary=1)
try:
    mapImage = urllib2.urlopen( imageURL, timeout=30)
    image_output = StringIO(mapImage.read())
    # fout = open('mapimage.jpg', 'wb')
    # fout.write(image_output)
    # fout.close()
    img = Image( image_output, 3.8*inch, 3.8*inch)
    mapStory = []
    mapStory.append(img)
    mapFrame.addFromList(mapStory,c)
except IOError:
    print "Error reading url"
except urllib2.HTTPError:
    print "HTTP Error from urllib2"


headerFrame = Frame(0.5*inch, 9.5*inch, 7.5*inch, 0.5*inch, showBoundary=1)
headerStory = []
headerStory.append(Paragraph("Incredible Map Information", styleH))
f.drawBoundary(c)
headerFrame.addFromList(headerStory, c)
c.save()