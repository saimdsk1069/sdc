import GenerateMapExtents as GME
import LayeredMapGenerator as LMG

# Start with URLs that do not have bounding boxes and size and generate them
# from a point, scale and image size

baseMapURL = "http://services.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/export?dpi=96&transparent=true&format=png8&layers=show%3A-1&bboxSR=3857&imageSR=3857&f=image"

baseImageURL = "http://njwebmap.state.nj.us/arcgis/rest/services/HurricaneSandy/ImageServer/exportImage?f=image&imageSR=3857&bboxSR=3857"

femaImageURL = "http://fema-services.esri.com/arcgis/rest/services/2012_Sandy/SurgeExtent/MapServer/export?dpi=96&transparent=true&format=png8&bboxSR=3857&imageSR=3857&f=image"

parcelsURL = "http://njwebmap.state.nj.us/arcgis/rest/services/Applications/OIT_Parcels_wm/MapServer/export?dpi=96&transparent=true&format=png8&layers=show%3A1%2C0&bboxSR=3857&imageSR=3857&f=image"


# Center of image: -8281363.94594 4793059.05433
# Image size: 699 x 593
# Image Scale: 22013
# Size of image from pixels and dpi : 7.28125 x 6.17708333333 inches
#
# Calculate bounding box and size
#
bboxString = GME.getBoundingBoxFromPoint( (-8281363.94594, 4793059.05433), 22013, imageSizeInPixels=(699,593), dpi=96)
sizeString = GME.getMapSizeInPixels( (7.28125, 6.17708333333 ), 96 )
newBaseMapURL = baseMapURL + bboxString + sizeString
newBaseImageURL = baseImageURL + bboxString + sizeString
newFemaImageURL = femaImageURL + bboxString + sizeString
newParcelsURL = parcelsURL + bboxString + sizeString
#
# Build list of layers to merge and create final map to include in PDF file
#
layersToMerge = [ ( newBaseMapURL, 1.0 ), ( newBaseImageURL, 1.0 ), ( newFemaImageURL, 0.6 ), ( newParcelsURL, 1.0 ) ]
finalImage = LMG.mergeLayerURLs( layersToMerge )
finalImage.save('testmap_20013.png', 'PNG')
finalImage.save('testmap_200013.jpg', 'JPEG')
#
# try again with different scale
#
bboxString = GME.getBoundingBoxFromPoint( (-8281363.94594, 4793059.05433), 60000, imageSizeInPixels=(699,593), dpi=96)
sizeString = GME.getMapSizeInPixels( (7.28125, 6.17708333333 ), 96 )
newBaseMapURL = baseMapURL + bboxString + sizeString
newBaseImageURL = baseImageURL + bboxString + sizeString
newFemaImageURL = femaImageURL + bboxString + sizeString
newParcelsURL = parcelsURL + bboxString + sizeString
#
# Build list of layers to merge and create final map to include in PDF file
#
layersToMerge = [ ( newBaseMapURL, 1.0 ), ( newBaseImageURL, 1.0 ), ( newFemaImageURL, 0.6 ), ( newParcelsURL, 1.0 ) ]
finalImage = LMG.mergeLayerURLs( layersToMerge )
finalImage.save('testmap_60000.png', 'PNG')
finalImage.save('testmap_60000.jpg', 'JPEG')
#
# zoom in close
#
# Center of image: -8257485.61673 4816932.0713
# Image size: 699 593
# Image Scale: 343.966627179 343.966627178
#
bboxString = GME.getBoundingBoxFromPoint( (-8257485.61673, 4816932.0713), 344, imageSizeInPixels=(699,593), dpi=96)
sizeString = GME.getMapSizeInPixels( (7.28125, 6.17708333333 ), 96 )
newBaseMapURL = baseMapURL + bboxString + sizeString
newBaseImageURL = baseImageURL + bboxString + sizeString
newFemaImageURL = femaImageURL + bboxString + sizeString
newParcelsURL = parcelsURL + bboxString + sizeString
#
# Build list of layers to merge and create final map to include in PDF file
#
layersToMerge = [ ( newBaseMapURL, 1.0 ), ( newBaseImageURL, 1.0 ), ( newFemaImageURL, 0.6 ), ( newParcelsURL, 1.0 ) ]
finalImage = LMG.mergeLayerURLs( layersToMerge )
finalImage.save('testmap_344.png', 'PNG')
finalImage.save('testmap_344.jpg', 'JPEG')
