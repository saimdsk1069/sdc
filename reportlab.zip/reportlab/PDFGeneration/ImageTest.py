from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import Paragraph, Frame, Image
from reportlab.lib.pagesizes import letter
from reportlab.lib.utils import haveImages, _RL_DIR, rl_isfile, open_for_read

import urllib2

imageURL = "http://localhost/AG_SADCeFarmsWeb/app/images/sadc_title.gif"
styles = getSampleStyleSheet()
styleN = styles['Normal']
styleH = styles['Heading1']
story = []
story2 = []
#add some flowables
story.append(Paragraph("Important Information About The Map",styleH))
story.append(Paragraph("Cool map below, isn't it????",
styleN))
try:
    mapImage = urllib2.urlopen( imageURL, timeout=30)
    image_output = mapImage.read()
    fout = open('mapimage.jpg', 'wb')
    fout.write(image_output)
    fout.close()
    img = Image( open_for_read('mapimage.jpg','b'), 1.8*inch, 1.8*inch)
    story2 = []
    story2.append(img)
except IOError:
    print "Error reading url"
except urllib2.HTTPError:
    print "HTTP Error from urllib2"
c = Canvas('FramesTest.pdf',pagesize=letter)
f1 = Frame(1.0*inch, 1.0*inch, 4*inch, 4*inch, showBoundary=1)
f2 = Frame(1.0*inch, 5.0*inch, 4*inch, 4*inch, showBoundary=1)
f2.addFromList(story,c)
f1.addFromList(story2,c)
c.save()