from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_RIGHT, TA_CENTER, TA_JUSTIFY
from reportlab.lib.units import inch
from reportlab.platypus import Paragraph, Frame, Image
from reportlab.lib.pagesizes import letter
from reportlab.lib.utils import haveImages, _RL_DIR, open_for_read, rl_isfile, fileName2Utf8
from StringIO import StringIO
import PIL.Image, PIL.ImageEnhance
import urllib2
import copy

def reduceOpacity(im, opacity):
    """Returns an image with reduced opacity."""
    assert opacity >= 0 and opacity <= 1
    if im.mode != 'RGBA':
        im = im.convert('RGBA')
    else:
        im = im.copy()
    alpha = im.split()[3]
    alpha = PIL.ImageEnhance.Brightness(alpha).enhance(opacity)
    im.putalpha(alpha)
    return im
    
def mergeLayerURLs( layersToMerge ):
    """ 
        Takes list of tuples.  Each tuple contains the url to get and the opacity for the final image.
        First image must be the base image
    """
    baseLayerURL = layersToMerge[0][0]
    #print "BASE LAYER:", baseLayerURL
    try:
        baseImage = urllib2.urlopen( baseImageURL, timeout=30).read()
        fout = open('base.image', 'wb')
        fout.write(baseImage)
        fout.close()
        background = PIL.Image.open('base.image' )
    except IOError:
            print "Error reading url"
            exit(1)
    except urllib2.HTTPError:
            print "HTTP Error from urllib2"
            exit(1)
            
    # Process the rest of the layers       
    for layer in layersToMerge[1:]:
        layerURL = layer[0]
        layerOpacity = layer[1]
        #print "URL:", layerURL
        #print "Opacity:", layerOpacity
        try:
            # Read URL, get data, and write to temp file
            imageData = urllib2.urlopen( layerURL, timeout=30).read()
            iOut = open('layer.image', 'wb')
            iOut.write( imageData )
            iOut.close()
            # Reopen the file to merge it with the base layer
            foregroundImage = PIL.Image.open('layer.image')
            # Reduce opacity as required
            newfg = reduceOpacity( foregroundImage, layerOpacity )
            # Merge the foreground to the base image with mask to make transparent
            background.paste( newfg, (0,0), newfg.convert('RGBA') )
        except IOError:
            print "Error processing URL ", layerURL
        except urllib2.HTTPError:
            print "HTTP Error from urllib2 reading ", layerURL
            exit(1)
    return background
#
# Sample URLs for testing
#  
baseImageURL = "http://njwebmap.state.nj.us/arcgis/rest/services/HurricaneSandy/ImageServer/exportImage?f=image&bbox=-8253077.566150613%2C4822424.859082321%2C-8252868.857233601%2C4822589.079260226&imageSR=3857&bboxSR=3857&size=699%2C550"

femaImageURL = "http://fema-services.esri.com/arcgis/rest/services/2012_Sandy/SurgeExtent/MapServer/export?dpi=96&transparent=true&format=png8&bbox=-8253077.566150613%2C4822424.859082321%2C-8252868.857233601%2C4822589.079260226&bboxSR=3857&imageSR=3857&size=699%2C550&f=image"

parcelsURL = "http://njwebmap.state.nj.us/arcgis/rest/services/Applications/OIT_Parcels_wm/MapServer/export?dpi=96&transparent=true&format=png8&layers=show%3A1&bbox=-8253077.566150613%2C4822424.859082321%2C-8252868.857233601%2C4822589.079260226&bboxSR=3857&imageSR=3857&size=699%2C550&f=image"
#
# Define the output PDF file
#
c = Canvas('MapDocumentLayered.pdf',pagesize=letter)

styles = getSampleStyleSheet()
styleN = styles['Normal']
styleNC = copy.copy(styleN)
styleNC.alignment = TA_CENTER
styleH = styles['Heading1']
styleHC = copy.copy(styleH)
styleHC.alignment = TA_CENTER
#print styles.list()

#
# Build list of layers to merge and create final map to include in PDF file
#
layersToMerge = [ ( baseImageURL, 1.0 ), ( femaImageURL, 0.6 ), ( parcelsURL, 1.0 ) ]
finalImage = mergeLayerURLs( layersToMerge )
#finalImage.save('wholemap.png')
#exit()
#
# Header Stuff
#
headerFrame = Frame(0.5*inch, 9.5*inch, 7.5*inch, 0.5*inch, showBoundary=1)
headerStory = []
headerStory.append(Paragraph("Incredible Map Information", styleHC))
headerFrame.addFromList(headerStory, c)
#
# Map Stuff
#
mapFrame = Frame(3.0*inch, 5.5*inch, 5.0*inch, 4.0*inch, showBoundary=1)
mapFrame.drawBoundary(c)
mapImage = Image( 'wholemap.png', 4.8*inch, 3.8*inch)
# mapStory = []
# mapStory.append(mapImage)
#mapFrame.addFromList(mapStory,c)
mapFrame.add(mapImage,c)
#
# Left Hand Frame
#
leftFrame = Frame(0.5*inch, 5.5*inch, 2.5*inch, 4.0*inch, showBoundary=1)
leftFrame.drawBoundary(c)
lframeStory = []
lframeStory.append(Paragraph("Left Panel Information",styleHC))
lframeStory.append(Paragraph("This is where we will stuff all of the left handed stuff to be shown in the PDF file soon after generation.", styleN))
leftFrame.addFromList(lframeStory,c)

#
# Footer Stuff
#
footerFrame = Frame(0.5*inch, 0.5*inch, 7.5*inch, 5.0*inch, showBoundary=1)
footerStory = []
footerStory.append(Paragraph("Detailed Map Information",styleH))
footerStory.append(Paragraph("Extremely cool information regarding your map.", styleNC))
footerFrame.addFromList(footerStory,c)

c.showPage()
c.save()