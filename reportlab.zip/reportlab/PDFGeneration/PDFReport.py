from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_RIGHT, TA_CENTER, TA_JUSTIFY
from reportlab.lib.units import inch
from reportlab.platypus import Paragraph, Frame, Image
from reportlab.lib.pagesizes import letter
from reportlab.lib.utils import haveImages, _RL_DIR, open_for_read, rl_isfile, fileName2Utf8
from StringIO import StringIO
import PIL.Image, PIL.ImageEnhance
import urllib2
import copy
import LayeredMapGenerator as LMG
import GenerateMapExtents as GME
#
# Sample URLs for testing.  Note they do not have bounding box calculated.  This will be derived from a point, scale, and image size.
#  
baseMapURL = "http://services.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/export?dpi=96&transparent=true&format=png8&layers=show%3A-1&bboxSR=3857&imageSR=3857&f=image"
baseImageURL = "http://njwebmap.state.nj.us/arcgis/rest/services/HurricaneSandy/ImageServer/exportImage?f=image&imageSR=3857&bboxSR=3857"
femaImageURL = "http://fema-services.esri.com/arcgis/rest/services/2012_Sandy/SurgeExtent/MapServer/export?dpi=96&transparent=true&format=png8&bboxSR=3857&imageSR=3857&f=image"
parcelsURL = "http://njwebmap.state.nj.us/arcgis/rest/services/Applications/OIT_Parcels_wm/MapServer/export?dpi=96&transparent=true&format=png8&layers=show%3A1%2C0&bboxSR=3857&imageSR=3857&f=image"

#
# Center of image: -8257485.61673 4816932.0713
# Image size: 699 593
# Image Scale: 344
#
bboxString = GME.getBoundingBoxFromPoint( (-8257485.61673, 4816932.0713), 344, imageSizeInPixels=(699,593), dpi=96)
sizeString = GME.getMapSizeInPixels( (7.28125, 6.17708333333 ), 96 )
newBaseMapURL = baseMapURL + bboxString + sizeString
newBaseImageURL = baseImageURL + bboxString + sizeString
newFemaImageURL = femaImageURL + bboxString + sizeString
newParcelsURL = parcelsURL + bboxString + sizeString
#
# Build list of layers to merge and create final map to include in PDF file
#
layersToMerge = [ ( newBaseMapURL, 1.0 ), ( newBaseImageURL, 1.0 ), ( newFemaImageURL, 0.6 ), ( newParcelsURL, 1.0 ) ]
finalMapImage = LMG.mergeLayerURLs( layersToMerge )
#
# Define the output PDF file
#
c = Canvas('MapDocumentLayered.pdf',pagesize=letter)

styles = getSampleStyleSheet()
styleN = styles['Normal']
styleNC = copy.copy(styleN)
styleNC.alignment = TA_CENTER
styleH = styles['Heading1']
styleHC = copy.copy(styleH)
styleHC.alignment = TA_CENTER
#
# Header Stuff
#
headerFrame = Frame(0.5*inch, 9.5*inch, 7.5*inch, 0.5*inch, showBoundary=1)
headerStory = []
headerStory.append(Paragraph("Incredible Map Information", styleHC))
headerFrame.addFromList(headerStory, c)
#
# Map Stuff
#
mapFrame = Frame(3.0*inch, 5.5*inch, 5.0*inch, 4.0*inch, showBoundary=1)
mapFrame.drawBoundary(c)
#
# Try to add image from StringIO type.  This is needed as platypus.Image requires
# file name or file handler.  The file handler can be created using a StringIO 
# object.
#
mapToAdd = StringIO()
finalMapImage.save(mapToAdd, 'PNG' )
mapToAdd.seek(0)
#
mapImage = Image( mapToAdd, 4.8*inch, 3.8*inch)
mapFrame.add(mapImage,c)
#
# Left Hand Frame
#
leftFrame = Frame(0.5*inch, 5.5*inch, 2.5*inch, 4.0*inch, showBoundary=1)
leftFrame.drawBoundary(c)
lframeStory = []
lframeStory.append(Paragraph("Left Panel Information",styleHC))
lframeStory.append(Paragraph("This is where we will stuff all of the left handed stuff to be shown in the PDF file soon after generation.", styleN))
leftFrame.addFromList(lframeStory,c)

#
# Footer Stuff
#
footerFrame = Frame(0.5*inch, 0.5*inch, 7.5*inch, 5.0*inch, showBoundary=1)
footerStory = []
footerStory.append(Paragraph("Detailed Map Information",styleH))
footerStory.append(Paragraph("Extremely cool information regarding your map.", styleNC))
footerFrame.addFromList(footerStory,c)

c.showPage()
c.save()