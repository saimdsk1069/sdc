def fahrenheit(T):
    return ((float(9)/5)*T + 32)
def celsius(T):
    return (float(5)/9)*(T-32)
temp = [36.5, 37, 37.5,39]

F = map(fahrenheit, temp)
C = map(celsius, F)

print F
print C

f = (x**5 for x in range(1,10))
t = enumerate(f,50)
for i in t:
    print i


noprimes = [j for i in range(2, 8) for j in range(i*2, 100, i)]
primes = [x for x in range(2, 100) if x not in noprimes]
print noprimes

import string
from random import *
characters = string.ascii_letters + string.punctuation  + string.digits
password =  "".join(choice(characters) for x in range(randint(8, 16)))
print password

#
try:
    b = 12/0
    print "succes",b
except ZeroDivisionError:
    print "error"

class Account(object):
    def __init__(self, holder, number, balance,credit_line=1500):
        self.Holder = holder
        self.Number = number
        self.Balance = balance
        self.CreditLine = credit_line

    def deposit(self, amount):
        self.Balance = amount
        print amount

    def withdraw(self, amount):
        if(self.Balance - amount < -self.CreditLine):
            # coverage insufficient
            return False
        else:
            self.Balance -= amount
            return True

    def balance(self):
        return self.Balance

    def transfer(self, target, amount):
	if(self.Balance - amount < -self.CreditLine):
            # coverage insufficient
            return False
        else:
            self.Balance -= amount
            target += amount
            print amount
            return True

x = Account(1,2,3)
print x.deposit(11)
print x.withdraw(15)
print x.transfer(12,15)

import urllib2
import re

#connect to a URL
website = urllib2.urlopen('http://www.pythonforbeginners.com/code/regular-expression-re-findall')

#read html code
html = website.read()

#use re.findall to get all the links
links = re.findall('"((http|ftp)s?://.*?)"', html)

print links