__author__ = 'sai'

COUNTY_LIST = [{"c": "Salem County", "o": "Betty Ann Davis", "f": "Betty Ann Davis Farm",
                "m": "Upper Pittsgrove Township", "ID": "17-0151-PG"}]
               # {"County": "", "owner": "", "Farm": "", "Muncipality": "", "SADCID#": ""},
               # {"County": "", "owner": "", "Farm": "", "Muncipality": "", "SADCID#": ""},
               # {"County": "", "owner": "", "Farm": "", "Muncipality": "", "SADCID#": ""},
               # {"County": "", "owner": "", "Farm": "", "Muncipality": "", "SADCID#": ""},
               # {"County": "", "owner": "", "Farm": "", "Muncipality": "", "SADCID#": ""},
               # {"County": "", "owner": "", "Farm": "", "Muncipality": "", "SADCID#": ""},
               # {"County": "", "owner": "", "Farm": "", "Muncipality": "", "SADCID#": ""},
               # {"County": "", "owner": "", "Farm": "", "Muncipality": "", "SADCID#": ""},
               # {"County": "", "owner": "", "Farm": "", "Muncipality": "", "SADCID#": ""},
               # {"County": "", "owner": "", "Farm": "", "Muncipality": "", "SADCID#": ""},
               # {"County": "", "owner": "", "Farm": "", "Muncipality": "", "SADCID#": ""},
               # {"County": "", "owner": "", "Farm": "", "Muncipality": "", "SADCID#": ""},
               # {"County": "", "owner": "", "Farm": "", "Muncipality": "", "SADCID#": ""},
               # {"County": "", "owner": "", "Farm": "", "Muncipality": "", "SADCID#": ""}]


VALUE_CONCLUSIONS_PERACRE = [{"A": "Tim Sheehan", "D": "11/07/2015", "B": "$8,900", "Af": "$3,600", "E": "$5,300",
                              "A1": "Edward Molinari", "D1": "11/25/2015", "B1": "$8,400", "Af1": "$3,300", "E1": "$5,100"}]
                             # {"Appraiser": "", "Date": 1, "Before": "$", "After": "$", "Easement": "$"},
                             # {"Appraiser": "", "Date": 1, "Before": "$", "After": "$", "Easement": "$"},
                             # {"Appraiser": "", "Date": 1, "Before": "$", "After": "$", "Easement": "$"},
                             # {"Appraiser": "", "Date": 1, "Before": "$", "After": "$", "Easement": "$"},
                             # {"Appraiser": "", "Date": 1, "Before": "$", "After": "$", "Easement": "$"}]


VALUE_CONCLUSIONS_TOTALVALUE = [{"A": "Tim Sheehan", "D": 11-7-2015, "B": "$374,000", "Af": "$151,000", "E": "$223,000"}]
                                # {"Appraiser": "", "Date": "", "Before": "$", "After": "$", "Easement": "$"},
                                # {"Appraiser": "", "Date": "", "Before": "$", "After": "$", "Easement": "$"},
                                # {"Appraiser": "", "Date": "", "Before": "$", "After": "$", "Easement": "$"},
                                # {"Appraiser": "", "Date": "", "Before": "$", "After": "$", "Easement": "$"},
                                # {"Appraiser": "", "Date": "", "Before": "$", "After": "$", "Easement": "$"}]