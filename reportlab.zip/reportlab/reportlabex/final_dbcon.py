import cx_Oracle


con = cx_Oracle.connect('ag_sadc', 'farm16LandPres', 'exm_gis1d')
cursor = con.cursor()
cursor.execute('SELECT * FROM COUNTY')
# cursor.fetchone()
for result in cursor:
     print result

con.close()
