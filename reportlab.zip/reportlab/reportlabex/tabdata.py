from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, inch, cm, portrait, LETTER
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image, PageBreak, ListItem, ListFlowable
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle, TA_LEFT, TA_CENTER
from reportlab.lib.enums import TA_RIGHT

a = (Paragraph("Application Submission Date: January 28,2014", style_p))
g = (Paragraph("Green Light Approval per N.J.A.C.2:76-17.9(a) and (b):February 24,2014", style_p))
f = (Paragraph("Final Approval submission date:January 4,2016", style_p))
fi = (Paragraph("Final Approval Date(s):", styleN))
fr = (Paragraph("Franklin Township committee: December 07,2015", style_p))
gr = (Paragraph("Greenwich Township Committee:December 17,2015", style_p))

data = [[a, ""],
        [g, ""],
        [f, ""]]
t3 = Table(data, colWidths=[6.05 * cm, 4.05 * cm, 4.05 * cm])

t3.setStyle(TableStyle([
                            ('INNERGRID', (0, 0), (-1, -1), 0, colors.black),
                            ('BOX', (0, 0), (-1, -1), 0, colors.black),
                            ('BACKGROUND', (0, 0), (-1, -1), colors.bisque),
                            ]))
f = Paragraph("FARM DETAIL", styleBH)
b = Paragraph("BLOCK", styleBH)
l = Paragraph("LOTS", styleBH)

farm = [f, b, l],
       ["", "", ""],
       ["", "", ""]]
fd = Table(farm, colWidths=[5.05 * cm, 5.05 * cm, 5.05 * cm])

fd.setStyle(TableStyle([
                            ('INNERGRID', (0, 0), (-1, -1), 0, colors.black),
                            ('BOX', (0, 0), (-1, -1), 0, colors.black),
                            ('BACKGROUND', (0, 0), (-1, -1), colors.bisque),
                            ]))