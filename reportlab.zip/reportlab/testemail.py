import OGIS_Email

from_person = "DoNotReply@oit.nj.gov"
to_person = "saikumar.medishetty@tech.nj.gov"
subject = "Another test"
access_code = "ABD77739499CCCFEE88E888"

message = """
This is to notify you that you are registered for the eFarms application.
"""

OGIS_Email.send( from_person, to_person, subject, message )
